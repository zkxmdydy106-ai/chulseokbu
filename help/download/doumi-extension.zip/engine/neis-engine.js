﻿// E0 나이스 공통 엔진 — 페이지(MAIN world)에서 eXbuilder6 앱의 데이터셋을 직접 다룬다.
// - 화면별 설정은 모른다. 패널이 보낸 계획(앱 ID·데이터셋·칼럼·값)대로만 움직인다.
// - 값은 그리드 칸이 아니라 데이터셋에 넣는다 → 안 보이는 행까지 한 번에 채워진다.
// - 마감·확정·결재 같은 버튼은 어떤 계획이 와도 누르지 않는다.
// - 학생 자료를 console에 남기지 않는다.
(() => {
  // 도우미를 업데이트하면 열린 탭에 새 엔진이 다시 들어온다. 같은 판 이상이면 그대로 두고, 옛 판이면 멈추고 바꾼다
  // (확장을 다시 로드하기 전에는 크롬이 옛 판 내용 스크립트를 넣으므로, 옛 판이 새 판을 덮으면 안 됨 — 2026-11-02 교사 제보: 결재선이 안 들어감)
  const VERSION = '0.16.7'; // 엔진을 고치면 꼭 올린다(같은 판이면 열린 나이스 탭의 옛 엔진이 그대로 남음)
  const old = window.__doumiEngine2;
  const notOlder = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return true; };
  if (old && notOlder(old.version, VERSION)) return;
  if (old && typeof old.stop === 'function') old.stop();

  const FORBIDDEN_WORDS = ['마감', '확정', '결재', '상신', '삭제', '발송', '취소', '승인']; // 승인: 복무 [승인요청](결재 요청, 2026-10-30)
  const FILL_BG = '#fff1b8';

  class DoumiError extends Error {
    constructor(code, message, detail) { super(message); this.code = code; this.detail = detail; }
  }
  const fail = (code, message, detail) => { throw new DoumiError(code, message, detail); };
  const str = (v) => (v == null ? '' : String(v));
  const norm = (v) => str(v).trim();

  // ── 앱 찾기 ─────────────────────────────────────────────
  const platform = () => window.cpr?.core?.Platform?.INSTANCE || null;
  const appIdOf = (inst) => str(inst?.app?.id ?? inst?.id).replace(/\.clx(\.js)?$/, '');

  function runningApps() {
    const p = platform();
    if (!p || typeof p.getAllRunningAppInstances !== 'function') return [];
    return (p.getAllRunningAppInstances() || []).filter((i) => !(typeof i.isDisposed === 'function' && i.isDisposed()));
  }

  function needApp(appId) {
    if (!platform()) fail('no-framework', '나이스 화면 엔진(eXbuilder6)을 찾지 못했어요. 나이스 메뉴 화면이 열린 탭인지 확인해 주세요.');
    const hits = runningApps().filter((i) => appIdOf(i) === appId);
    if (!hits.length) fail('no-app', '이 화면을 인식하지 못했어요. 해당 메뉴를 나이스에서 먼저 열어 주세요.');
    return hits[hits.length - 1]; // 같은 화면이 두 번 열려 있으면 나중에 연 것
  }

  // ── 데이터셋 ────────────────────────────────────────────
  function needDataset(inst, id) {
    const ds = inst.lookup(id);
    if (!ds || typeof ds.getRowCount !== 'function') fail('no-dataset', `화면 안에서 자료(${id})를 찾지 못했어요. 나이스 화면이 바뀌었을 수 있어요.`);
    return ds;
  }

  function columnsOf(ds) {
    try {
      if (typeof ds.getColumnNames === 'function') return ds.getColumnNames().map(str);
      if (typeof ds.getHeaders === 'function') return ds.getHeaders().map((h) => str(h.getName ? h.getName() : h.name));
    } catch { /* 칼럼 목록을 못 읽어도 값 읽기는 시도한다 */ }
    return [];
  }

  function readRows(ds, columns) {
    const rows = [];
    const n = ds.getRowCount();
    for (let r = 0; r < n; r++) {
      const o = { _row: r };
      for (const c of columns) o[c] = str(ds.getValue(r, c));
      rows.push(o);
    }
    return rows;
  }

  function findRows(ds, keyColumns, key) {
    const hit = [];
    const n = ds.getRowCount();
    for (let r = 0; r < n; r++) {
      if (keyColumns.every((c) => norm(ds.getValue(r, c)) === norm(key[c]))) hit.push(r);
    }
    return hit;
  }

  // 컨트롤 → 화면 요소. 실제 나이스는 data-ndid="uuid-<uuid>"로 잇는다(2026-10-27 로그인 화면에서 확인).
  function domOf(ctl) {
    const u = ctl?.uuid;
    if (u == null || u === '') return null;
    return document.querySelector(`[data-ndid="uuid-${CSS.escape(String(u))}"]`) || document.getElementById(String(u));
  }

  // ── 버튼 ───────────────────────────────────────────────
  const controlText = (c) => norm(c?.value ?? c?.text);

  function needSafeButton(inst, id, forbiddenIds = []) {
    const btn = inst.lookup(id);
    if (!btn) fail('no-button', '저장 버튼을 찾지 못했어요. 나이스에서 직접 저장해 주세요.');
    const text = controlText(btn);
    if (forbiddenIds.includes(id) || FORBIDDEN_WORDS.some((w) => text.includes(w))) {
      fail('forbidden-button', `"${text || id}" 버튼은 도우미가 누르지 않아요.`);
    }
    if (btn.enabled === false) fail('button-disabled', '나이스 저장 버튼이 꺼져 있어요. 나이스 화면 안내를 확인해 주세요.');
    // 생기부 화면은 마감이면 저장 버튼을 꺼지 않고 숨기기만 한다(2026-10-30 화면 스크립트) → 숨은 버튼도 누르지 않는다
    if (btn.visible === false) fail('button-hidden', '나이스 저장 버튼이 숨겨져 있어요(마감됐을 수 있어요). 나이스 화면을 확인해 주세요.');
    return btn;
  }

  function clickControl(ctl) {
    if (typeof ctl.click === 'function') { ctl.click(); return 'api'; }
    if (typeof ctl.dispatchEvent === 'function' && window.cpr?.events?.CMouseEvent) {
      ctl.dispatchEvent(new window.cpr.events.CMouseEvent('click', new MouseEvent('click')));
      return 'event';
    }
    const el = domOf(ctl);
    if (el) { el.click(); return 'dom'; }
    fail('click', '저장 버튼을 누르지 못했어요. 나이스에서 직접 저장해 주세요.');
  }

  // ── 나이스 확인·알림 창 ─────────────────────────────────
  // 확인 창 app/cmn/confirm(optMsg, btnConfirm, btnCancel), 알림 창 app/cmn/alert(optMsg, btnConfirm) — 2026-10-27 확인.
  // 확인 창은 문구가 allow에 맞고 마감·삭제·취소 같은 말이 없을 때만 [확인]을 누른다. 나머지는 교사 몫으로 남긴다.
  const DIALOG_DENY = /마감|삭제|취소|결재|상신|발송|초기화|분할점수/; // 분할점수: 학생 답안이 있을 때 문항정보표 저장 경고 — 선생님이 직접(교사 결정 2026-10-29)
  const dialogs = (id) => runningApps().filter((i) => appIdOf(i) === id);
  const dialogText = (d) => norm(d.lookup('optMsg')?.value) + (norm(d.lookup('optSubMsg')?.value) ? ` ${norm(d.lookup('optSubMsg')?.value)}` : '');

  function pressConfirmIf(allow) {
    for (const d of dialogs('app/cmn/confirm')) {
      const text = dialogText(d);
      if (allow.test(text) && !DIALOG_DENY.test(text)) { d.lookup('btnConfirm')?.click(); return text; }
    }
    return null;
  }
  // OTP(2차 인증) 창: 실제 앱 ID는 아래(2026-10-29 교과 세특에서 확인 — 창 제목 '2차인증', M-OTP·ARS·PC-OTP 탭, 화면 앱과 함께 뜸).
  // 그 밖에는 이름 낱말로 짐작하되 화면 안 부품(udc/…, 예: 권한 고르기 칸 udcSwcAuth — 일일출결·자율에 들어 있어 OTP로 잘못 보였음)과 공용 창(app/…)은 뺀다
  const OTP_APP_IDS = ['edu/cm/sym/usm/sc/sym_usmsc99_p04'];
  const OTP_APP = /otp|crtf|cert|athn|auth|mfa|scnd|2nd/i;
    // 2차 인증 창 앱 ID(2026-11-02 실제: edu/cm/sym/usm/sc/sym_usmsc99_p04, 일일출결에서도 뜸 — '(2차인증:130분)' 시간이 끝나면)
const isOtpApp = (id) => /sym_usmsc\d+_p\d+/.test(id) || OTP_APP_IDS.includes(id) || (!/^(udc|app)\//.test(id) && OTP_APP.test(id));
  const otpApps = () => [...new Set(runningApps().map(appIdOf))].filter(isOtpApp);
  // before 이후 새로 뜬 앱 ID(나이스 첫 화면 제외) — 값은 담지 않는다
  const newApps = (before) => [...new Set(runningApps().filter((i) => !before.has(i)).map(appIdOf))].filter((id) => id && id !== 'app/com/main/Index').slice(0, 8);

  // 새로 뜬 알림 창을 읽고 닫는다
  // 알림 창은 먼저 뜨고 글은 조금 뒤에 채워진다(2026-10-28 실제 확인: '과목은(는) 필수 입력입니다.'가 '(빈 알림)'으로 보였음)
  // → 글이 비어 있으면 1.5초까지 기다렸다 읽는다
  const alertBorn = new WeakMap();
  // 조건 칸을 차례로 바꿔 볼 때 나이스가 띄우는 '○○은(는) 필수 입력입니다' 알림만 닫는다(그 뒤 빈 칸은 다시 채움, 2026-11-02 실제). 다른 알림은 그대로
  function closeRequiredAlerts() {
    let n = 0;
    for (const d of dialogs('app/cmn/alert')) {
      if (/필수 ?입력/.test(dialogText(d))) { d.lookup('btnConfirm')?.click(); n++; }
    }
    return n;
  }
  function takeAlert(seen) {
    for (const d of dialogs('app/cmn/alert')) {
      if (seen.has(d)) continue;
      if (!alertBorn.has(d)) alertBorn.set(d, Date.now());
      if (!dialogText(d) && Date.now() - alertBorn.get(d) < 1500) continue;
      seen.add(d);
      const text = dialogText(d);
      d.lookup('btnConfirm')?.click();
      return text || '(빈 알림)';
    }
    return null;
  }

  // 저장 결과를 기다린다. 버튼을 누르기 전에 걸어 둬야 놓치지 않는다.
  // 성공: 저장 통신 성공 또는 "저장했습니다" 알림. 실패: 통신 오류 또는 다른 알림(문구를 돌려줌).
  const saveWaits = new Map();
  let saveSeq = 0;
  function watchSave(inst, save) {
    const token = `s${++saveSeq}`;
    const sub = save.submission && inst.lookup(save.submission);
    const seen = new Set(dialogs('app/cmn/alert'));
    const toRe = (x) => (x instanceof RegExp ? x : typeof x === 'string' && x ? new RegExp(x) : null);
    const okText = toRe(save.successText) || /저장했습니다|저장되었습니다|저장 되었습니다|저장이 완료/;
    const confirmText = toRe(save.confirmText) || /저장/;
    saveWaits.set(token, new Promise((resolve) => {
      let subState = null;
      const offs = [];
      if (sub && typeof sub.addEventListener === 'function') {
        for (const [ev, st] of Object.entries({ 'submit-success': 'success', 'submit-error': 'error', 'submit-timeout': 'error' })) {
          const h = () => { subState = st; };
          sub.addEventListener(ev, h);
          offs.push(() => sub.removeEventListener(ev, h));
        }
      }
      let afterSub = 0;
      const timer = setInterval(() => {
        pressConfirmIf(confirmText);
        const alertText = takeAlert(seen);
        const done = (r) => { clearInterval(timer); offs.forEach((f) => f()); resolve(r); };
        if (alertText) return done(okText.test(alertText) ? { state: 'success', message: alertText } : { state: 'error', message: alertText });
        if (subState === 'error') return done({ state: 'error', message: '나이스가 저장 통신 오류를 알렸어요.' });
        // 통신은 성공했는데 알림이 안 뜨는 화면도 있다 → 잠깐 더 기다렸다가 성공으로
        if (subState === 'success' && ++afterSub > 15) return done({ state: 'success', message: '' });
      }, 200);
    }));
    return token;
  }

  // ── 채운 줄 표시 (그리드 DOM, 가능한 경우에만) ───────────
  // eXbuilder6 그리드는 화면에 보이는 줄만 그리므로, 다시 그려질 때마다 표시를 다시 입힌다.
  const mark = { observers: [], timer: null, targets: [] };

  function rowElements(root) {
    let rows = root.querySelectorAll('[role="row"]');
    if (!rows.length) rows = root.querySelectorAll('[class*="cl-grid-row"]');
    return rows;
  }

  function cellsOf(rowEl) {
    const cells = rowEl.querySelectorAll('[role="gridcell"]');
    return cells.length ? [...cells] : [...rowEl.children];
  }

  function paintMarks({ root, keys }) {
    let painted = 0;
    for (const rowEl of rowElements(root)) {
      const cells = cellsOf(rowEl);
      const texts = cells.map((c) => norm(c.textContent));
      const hit = keys.some((k) => k.every((v) => texts.includes(v)));
      if (!hit) continue;
      for (const cell of cells) cell.style.setProperty('background-color', FILL_BG, 'important');
      rowEl.dataset.doumiFilled = '1';
      painted++;
    }
    return painted;
  }

  // targets: [{ grid, keys }] — 그리드마다 채운 줄의 키 값들
  function markRows(targets) {
    mark.observers.forEach((o) => o.disconnect());
    clearTimeout(mark.timer);
    mark.targets = targets.map((t) => ({ root: domOf(t.grid), keys: t.keys })).filter((t) => t.root);
    let painted = 0;
    mark.observers = mark.targets.map((t) => {
      painted += paintMarks(t);
      let queued = false;
      const o = new MutationObserver(() => {
        if (queued) return;
        queued = true;
        requestAnimationFrame(() => { queued = false; paintMarks(t); });
      });
      o.observe(t.root, { childList: true, subtree: true, characterData: true });
      return o;
    });
    mark.timer = setTimeout(() => { mark.observers.forEach((o) => o.disconnect()); mark.observers = []; mark.targets = []; }, 15 * 60 * 1000);
    return painted;
  }

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ── 나이스 길잡이(신규 교사용, 2026-10-30 교사 요청) ─────────────
  // 나이스 화면 위에 '여기를 누르세요' 테두리 + 말풍선을 그린다. 교사가 테두리 친 곳을 누르면 패널이 다음 단계로 넘긴다.
  // 화면 위치·앱 이름·표 줄 수만 본다. 학생 값·교사 이름 칸은 읽지 않고, 나이스 값을 바꾸거나 버튼을 누르지 않는다.
  const GUIDE_HOST = 'doumi-guide-host';
  const guide = { step: null, timer: 0, clicked: false, action: '', found: 0, covered: 0, els: [], cache: [], lastMenu: null, shownAt: 0, run: null, ended: null, scrolled: [], kickUntil: 0, opening: false, note: '' };
  const GUIDE_KEY = 'doumi.guide.run'; // 지금 길잡이(글·앱 이름뿐, 학생 정보 없음) — 나이스 탭을 새로고침해도 이어지게 그 탭 sessionStorage에
  const appInst = (id) => { const hits = runningApps().filter((i) => appIdOf(i) === id); return hits[hits.length - 1] || null; };

  function shownRect(el) {
    if (!el || !el.isConnected) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2 || r.bottom < 0 || r.right < 0 || r.top > innerHeight || r.left > innerWidth) return null;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') return null;
    return r;
  }
  // 같은 글자를 가진 가장 안쪽 요소(보이는 것만). 메뉴 이름·표 머리 글자처럼 짧은 글자만 찾는다
  function textEls(name, within) {
    const out = [];
    if (!name) return out;
    const w = document.createTreeWalker(within || document.body, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (norm(n.nodeValue) === name ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP) });
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      const el = n.parentElement;
      if (el && !el.closest(`#${GUIDE_HOST}`) && shownRect(el)) out.push(el);
    }
    return out;
  }
  const namesOf = (v) => [].concat(v || []).map(norm).filter(Boolean);
  // 메뉴 칸: 업무 탭은 가장 위, 메뉴 칸은 앞 단계에서 누른 칸보다 아래에서 가장 가까운 것(같은 이름 '출결관리'가 묶음·화면으로 두 번 나옴)
  function pickMenu(t) {
    const els = namesOf(t.menu).flatMap((nm) => textEls(nm));
    if (!els.length) return null;
    const rc = (el) => el.getBoundingClientRect();
    if (t.pick === 'top') return els.sort((a, b) => rc(a).top - rc(b).top || rc(a).left - rc(b).left)[0];
    const last = guide.lastMenu;
    if (last) {
      const below = els.filter((el) => el !== last.el && rc(el).top >= last.top - 2);
      if (below.length) return below.sort((a, b) => (rc(a).top - last.top) + Math.abs(rc(a).left - last.left) / 4 - ((rc(b).top - last.top) + Math.abs(rc(b).left - last.left) / 4))[0];
    }
    return els.sort((a, b) => rc(a).left - rc(b).left || rc(a).top - rc(b).top)[0];
  }
  // 화면에 실제로 보이는 부분(2026-11-02 교사 제보: 패널을 열어 창이 좁아지면 테두리가 어긋남): 스크롤 칸에 잘린 만큼 빼고, 다 잘렸으면 null
  function visibleRect(el) {
    const r0 = shownRect(el);
    if (!r0) return null;
    let { left, top, right, bottom } = r0;
    for (let p = el.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      const cs = getComputedStyle(p);
      if (cs.position === 'fixed') break;
      if (cs.overflowX === 'visible' && cs.overflowY === 'visible') continue;
      const q = p.getBoundingClientRect();
      if (cs.overflowX !== 'visible') { left = Math.max(left, q.left); right = Math.min(right, q.right); }
      if (cs.overflowY !== 'visible') { top = Math.max(top, q.top); bottom = Math.min(bottom, q.bottom); }
      if (right - left < 2 || bottom - top < 2) return null;
    }
    left = Math.max(left, 0); top = Math.max(top, 0); right = Math.min(right, innerWidth); bottom = Math.min(bottom, innerHeight);
    if (right - left < 2 || bottom - top < 2) return null;
    return { left, top, right, bottom, width: right - left, height: bottom - top, whole: r0.width * r0.height };
  }
  // 다른 창(공지·알림 창 등)이 이 칸을 덮고 있는지(2026-11-02 실제: 공지 창이 메뉴를 가렸는데 테두리가 그 위에 그려짐)
  function coveredNow(el, r) {
    const hits = document.elementsFromPoint((r.left + r.right) / 2, (r.top + r.bottom) / 2);
    const o = hits.find((x) => x.id !== GUIDE_HOST && !x.closest?.(`#${GUIDE_HOST}`));
    return !!o && o !== el && !el.contains(o) && !o.contains(el);
  }
  function findTarget(t) {
    if (t.menu) return pickMenu(t);
    const inst = t.app ? appInst(t.app) : null;
    if (t.app && !inst) return null;
    const names = namesOf(t.text);
    if (t.id) {
      let ctl = null;
      try { ctl = inst?.lookup(t.id); } catch { ctl = null; }
      const el = domOf(ctl);
      if (!el) return null;
      for (const nm of names) { const hit = textEls(nm, el)[0]; if (hit) return hit; }
      return el;
    }
    if (names.length) {
      let nearRect = null;
      try { nearRect = t.near ? shownRect(domOf(inst?.lookup(t.near))) : null; } catch { nearRect = null; }
      let best = null, bd = Infinity;
      for (const nm of names) {
        for (const el of textEls(nm)) {
          const r = el.getBoundingClientRect();
          const d = nearRect ? Math.hypot(r.left - nearRect.left, r.top - nearRect.top) : r.top;
          if (d < bd) { bd = d; best = el; }
        }
      }
      return best;
    }
    return null;
  }

  const GUIDE_CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    .ring { position: fixed; pointer-events: none; border-radius: 3px; border: 2px solid #2a64d6; box-shadow: 0 0 0 1px #fff, 0 0 0 4px rgba(42,100,214,.22); }
    .ring.press { animation: halo 1.6s ease-out infinite; }
    .ring.see { border-style: dashed; box-shadow: 0 0 0 1px #fff; }
    .ring.nopress { border: 2px dashed #d33a2c; box-shadow: 0 0 0 1px #fff; }
    .ring .lb { position: absolute; padding: 1px 6px; border-radius: 2px; background: #2a64d6; color: #fff; font: 600 11px/16px "Noto Sans KR", Pretendard, "Malgun Gothic", sans-serif; white-space: nowrap; }
    .ring .lb.num { left: -10px; top: -10px; width: 18px; height: 18px; padding: 0; border-radius: 50%; text-align: center; line-height: 18px; }
    .ring .lb.no { left: -2px; background: #d33a2c; }
    @keyframes halo { 0% { box-shadow: 0 0 0 1px #fff, 0 0 0 2px rgba(42,100,214,.35); } 100% { box-shadow: 0 0 0 1px #fff, 0 0 0 9px rgba(42,100,214,0); } }
    @media (prefers-reduced-motion: reduce) { .ring.press { animation: none; } }
    .tip { position: fixed; width: 312px; max-width: calc(100vw - 24px); background: #fff; color: #222; border: 1px solid #c9d1dc; border-left: 3px solid #2a64d6; border-radius: 3px;
      box-shadow: 0 6px 22px rgba(20,32,54,.18); font: 13px/1.55 "Noto Sans KR", Pretendard, "Malgun Gothic", "맑은 고딕", sans-serif; padding: 10px 12px 9px; pointer-events: auto; }
    .tip.nopress { border-left-color: #d33a2c; }
    .hd { display: flex; align-items: baseline; gap: 8px; margin-bottom: 4px; }
    .hd .n { flex: none; color: #8a9099; font-size: 11px; font-variant-numeric: tabular-nums; }
    .hd b { font-size: 14px; }
    .bd { margin: 0; white-space: pre-line; }
    .ct { margin: 7px 0 0; padding: 5px 8px; background: #fdf6e3; border-left: 2px solid #c9a227; color: #4d3d00; white-space: pre-line; font-size: 12px; }
    .tip.nopress .ct { background: #fdeeed; border-left-color: #d33a2c; color: #7a1d14; }
    .miss { margin: 7px 0 0; color: #d33a2c; font-size: 12px; }
    .lg { margin: 6px 0 0; color: #2a64d6; font-size: 12px; font-weight: 600; }
    .how { margin: 6px 0 0; color: #555; font-size: 12px; }
    .ac { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; }
    .ac button { font: inherit; font-size: 12px; padding: 3px 10px; border-radius: 2px; border: 1px solid #c9d1dc; background: #fff; color: #222; cursor: pointer; }
    .ac button.main { background: #2a64d6; border-color: #2a64d6; color: #fff; }
    .ac button:hover { border-color: #2a64d6; }
    .ac .stop { margin-right: auto; color: #555; }
  `;
  function guideRoot() {
    let host = document.getElementById(GUIDE_HOST);
    if (!host) {
      host = document.createElement('div');
      host.id = GUIDE_HOST;
      host.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;z-index:2147483600;';
      host.attachShadow({ mode: 'open' });
      host.shadowRoot.innerHTML = `<style>${GUIDE_CSS}</style><div class="rings"></div><div class="tip" role="dialog" aria-live="polite"></div>`;
      host.shadowRoot.querySelector('.tip').addEventListener('click', (e) => {
        const b = e.target.closest('button[data-a]');
        if (b) { guide.action = b.dataset.a; guideDrive(); }
      });
      document.documentElement.appendChild(host);
    }
    return host.shadowRoot;
  }
  function drawTip(root) {
    const s = guide.step;
    const tip = root.querySelector('.tip');
    tip.className = `tip ${s.look || 'press'}`;
    tip.textContent = '';
    const add = (parent, tag, cls, text) => { const x = document.createElement(tag); if (cls) x.className = cls; if (text != null) x.textContent = text; parent.appendChild(x); return x; };
    const hd = add(tip, 'div', 'hd');
    if (s.n) add(hd, 'span', 'n', `${s.n} / ${s.total}`);
    add(hd, 'b', '', s.title || '');
    if (s.body) add(tip, 'p', 'bd', s.body);
    const legend = guideLegend(s);
    if (legend) add(tip, 'p', 'lg', legend);
    if (s.caution) add(tip, 'p', 'ct', s.caution);
    if (s.how) add(tip, 'p', 'how', s.how);
    add(tip, 'p', 'miss', '화면에서 이 칸을 찾지 못했어요. 설명대로 찾아 눌러 주세요.').hidden = true;
    add(tip, 'p', 'miss cover', '나이스 창이 이 칸을 가리고 있어요. 떠 있는 창을 먼저 닫아 주세요.').hidden = true;
    const ac = add(tip, 'div', 'ac');
    add(ac, 'button', 'stop', '그만').dataset.a = 'stop';
    if (guide.run && guide.run.open && guide.run.i < guide.run.menuN) add(ac, 'button', '', guide.opening ? '여는 중…' : '메뉴 바로 열기').dataset.a = 'open';
    if (s.n > 1) add(ac, 'button', '', '이전').dataset.a = 'prev';
    add(ac, 'button', s.manual ? 'main' : '', s.n === s.total ? '마치기' : '다음').dataset.a = 'next';
  }
  // 칸이 여럿이면 테두리에 ①②만 붙이고 뜻은 말풍선에(이름표가 위 칸 글자를 가리지 않게 — 2026-10-30 스크린샷)
  const CIRCLED = '①②③④⑤⑥⑦⑧';
  const guideLegend = (s) => ((s.targets || []).length > 1 && (s.targets || []).some((t) => t.label) && (s.look || 'press') !== 'nopress'
    ? s.targets.map((t, i) => `${CIRCLED[i]} ${t.label || ''}`.trim()).join(' · ') : '');
  function guideTick() {
    const s = guide.step;
    if (!s) return;
    const root = guideRoot();
    if (!root.querySelector('.tip .hd')) drawTip(root);
    const targets = s.targets || [];
    const now = Date.now();
    guide.els = targets.map((t, i) => {
      const c = guide.cache[i];
      // 컨트롤 칸은 매번(가벼움), 글자로 찾는 칸은 1초마다 또는 안 보일 때만 다시 찾는다
      if (c && !t.id && shownRect(c.el) && now - c.at < 1000) return c.el;
      const el = findTarget(t);
      guide.cache[i] = { el, at: now };
      return el;
    });
    const rings = root.querySelector('.rings');
    guide.covered = 0;
    const rects = guide.els.map((el, i) => {
      const r = el ? visibleRect(el) : null;
      // 칸이 스크롤 칸 밖에 있으면(창이 좁아졌을 때) 그 칸으로 한 번 스크롤해 준다. 값은 안 바뀜
      if (el && shownRect(el) && (!r || r.width * r.height < r.whole * 0.6) && !guide.scrolled[i]) {
        guide.scrolled[i] = true;
        try { el.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch { /* 스크롤 못 해도 그대로 */ }
        return visibleRect(el);
      }
      if (r && coveredNow(el, r)) { guide.covered++; return null; }
      return r;
    });
    guide.found = rects.filter(Boolean).length;
    while (rings.children.length < targets.length) {
      const r = document.createElement('div');
      r.appendChild(document.createElement('span')).className = 'lb';
      rings.appendChild(r);
    }
    while (rings.children.length > targets.length) rings.lastChild.remove();
    targets.forEach((t, i) => {
      const ring = rings.children[i];
      const r = rects[i];
      ring.hidden = !r;
      if (!r) return;
      const look = t.look || s.look || 'press';
      ring.className = `ring ${look}`;
      Object.assign(ring.style, { left: `${r.left - 3}px`, top: `${r.top - 3}px`, width: `${r.width + 6}px`, height: `${r.height + 6}px` });
      // 이름표: '누르지 마세요'는 테두리 아래(위쪽 단추 글자를 가리지 않게), 칸이 여럿이면 모서리에 ①②, 하나면 없음
      const lb = ring.firstChild;
      const no = look === 'nopress';
      lb.textContent = no ? `${targets.length > 1 && t.label ? `${t.label} ` : ''}누르지 마세요` : targets.length > 1 ? CIRCLED[i] : '';
      lb.className = `lb ${no ? 'no' : 'num'}`;
      lb.hidden = !lb.textContent;
      lb.style.top = no ? (r.bottom + 24 > innerHeight ? '-20px' : `${r.height + 4}px`) : '';
    });
    const tip = root.querySelector('.tip');
    const miss = tip.querySelector('.miss:not(.cover)');
    if (miss) miss.hidden = !(targets.length && !guide.found && !guide.covered);
    const cov = tip.querySelector('.miss.cover');
    if (cov) { cov.hidden = !(guide.covered && !guide.found); cov.textContent = guide.note || '나이스 창이 이 칸을 가리고 있어요. 떠 있는 창을 먼저 닫아 주세요.'; }
    // 말풍선: 첫 번째로 찾은 칸 아래(자리가 없으면 위·오른쪽), 못 찾으면 오른쪽 아래 구석
    const ai = rects.findIndex(Boolean);
    const a = rects[ai];
    // 첫 칸 아래에 '누르지 마세요' 이름표가 있으면 그만큼 더 띄움
    const gap = ai >= 0 && (targets[ai].look || s.look) === 'nopress' ? 30 : 12;
    const w = tip.offsetWidth || 312, h = tip.offsetHeight || 120;
    let x, y;
    // 못 찾았거나 표처럼 큰 칸이면 오른쪽 아래 구석(표 앞쪽 번호·이름 칸을 가리지 않게)
    if (!a || (a.width > innerWidth * 0.5 && a.height > innerHeight * 0.35)) { x = innerWidth - w - 16; y = innerHeight - h - 16; }
    else {
      x = Math.min(Math.max(8, a.left), innerWidth - w - 8);
      if (a.bottom + gap + h < innerHeight) y = a.bottom + gap;
      else if (a.top - 12 - h > 0) y = a.top - 12 - h;
      else { y = Math.min(Math.max(8, a.top), innerHeight - h - 8); x = a.right + 12 + w < innerWidth ? a.right + 12 : Math.max(8, a.left - w - 12); }
    }
    tip.style.left = `${Math.round(x)}px`;
    tip.style.top = `${Math.round(Math.max(8, y))}px`;
  }
  // 테두리 친 곳을 눌렀는지(막지 않고 보기만). eXbuilder 칸은 글자 바깥 부분을 눌러도 되도록 칸 둘레 6px까지
  function onGuideDown(e) {
    const s = guide.step;
    if (!s) return;
    if ((e.composedPath?.() || []).some((n) => n && n.id === GUIDE_HOST)) return;
    guide.els.forEach((el, i) => {
      const r = shownRect(el);
      if (!r) return;
      const inside = el === e.target || el.contains(e.target)
        || (e.clientX >= r.left - 6 && e.clientX <= r.right + 6 && e.clientY >= r.top - 6 && e.clientY <= r.bottom + 6);
      if (!inside) return;
      guide.clicked = true;
      if (s.targets[i]?.menu) guide.lastMenu = { el, top: r.top, left: r.left };
    });
  }
  function guideKick() { guide.kickUntil = Date.now() + 1500; guide.scrolled = []; }
  function guideOnScroll() { if (guide.step) requestAnimationFrame(guideTick); }
  function guideHide() {
    clearInterval(guide.timer);
    guide.timer = 0;
    guide.step = null;
    guide.els = [];
    guide.cache = [];
    guide.lastMenu = null;
    document.removeEventListener('pointerdown', onGuideDown, true);
    window.removeEventListener('resize', guideKick);
    window.removeEventListener('scroll', guideOnScroll, true);
    document.getElementById(GUIDE_HOST)?.remove();
  }
  function guideSave() {
    try { if (guide.run) sessionStorage.setItem(GUIDE_KEY, JSON.stringify(guide.run)); else sessionStorage.removeItem(GUIDE_KEY); } catch { /* 저장 못 해도 진행 */ }
  }
  function guideClear() {
    guide.run = null;
    guideSave();
    guideHide();
  }
  // 한 단계 보여 주기: 테두리·말풍선을 그리고 0.25초마다 위치를 맞춘다(창이 바뀌는 동안은 더 자주)
  function guideShowStep(step, keepClick = false) {
    guide.step = step;
    guide.cache = [];
    guide.scrolled = [];
    if (!keepClick) guide.clicked = false;
    guide.action = '';
    guide.shownAt = Date.now();
    const root = guideRoot();
    drawTip(root);
    document.removeEventListener('pointerdown', onGuideDown, true);
    document.addEventListener('pointerdown', onGuideDown, true);
    window.removeEventListener('resize', guideKick);
    window.addEventListener('resize', guideKick);
    window.removeEventListener('scroll', guideOnScroll, true);
    window.addEventListener('scroll', guideOnScroll, true);
    clearInterval(guide.timer);
    guide.timer = setInterval(() => {
      if (guide.run) guideDrive();
      if (guide.step) guideTick();
    }, 120);
    guideTick();
  }
  // 길잡이 진행은 엔진이 맡는다(2026-11-02 교사 제보: 패널을 닫으면 다음으로 안 넘어감). 패널은 보여 주기만
  function guideStep(i, keepClick = false) {
    const run = guide.run;
    if (!run) return;
    run.i = Math.max(0, Math.min(i, run.steps.length - 1));
    guideSave();
    const s = run.steps[run.i];
    guideShowStep({ n: run.i + 1, total: run.steps.length, title: s.title, body: s.body || '', caution: s.caution || '', look: s.look || 'press', manual: !s.when,
      how: s.when ? '테두리 친 곳을 누르면 저절로 다음으로 넘어가요.' : '', targets: s.targets || [] }, keepClick);
  }
  function guideEnd(how) {
    const id = guide.run?.id || '';
    guideClear();
    guide.ended = { id, how, at: Date.now() };
  }
  function guideDrive() {
    const run = guide.run;
    if (!run || !guide.step) return;
    const a = guide.action;
    guide.action = '';
    if (a === 'stop') { guideEnd('stop'); return; }
    if (a === 'prev') { guideStep(run.i - 1); return; }
    if (a === 'open') {
      if (guide.opening || !run.open) return;
      guide.opening = true;
      drawTip(guideRoot());
      OPS.openMenu({ menuId: run.open.menu.menuId, prefer: run.open.menu.prefer, appId: run.open.appId, step: run.open.step || null, tab: run.open.tab || null })
        .catch((x) => { guide.note = x?.message || '메뉴를 열지 못했어요. 나이스 메뉴에서 직접 눌러 주세요.'; guide.covered = 1; })
        .finally(() => { guide.opening = false; if (guide.step) drawTip(guideRoot()); });
      return;
    }
    const s = run.steps[run.i];
    const lastOne = run.i >= run.steps.length - 1;
    if (a === 'next' || (s.when && Date.now() - guide.shownAt > 250 && guideMet(s.when))) {
      if (lastOne) guideEnd('done'); else guideStep(run.i + 1);
      return;
    }
    // 메뉴 단계 중에 화면이 열리면(바로 열기 포함) 화면 단계로
    if (run.i < run.menuN && namesOf(run.apps).some((x) => appInst(x))) guideStep(run.menuN);
  }
  // 단계 조건: 적힌 것이 모두 맞아야 함 — app(화면이 열림) · rows(표 줄 수, 값은 안 읽음) · clicked(테두리 친 곳을 누름)
  function guideMet(when) {
    if (!when || !Object.keys(when).length) return false;
    if (when.app && !namesOf(when.app).some((a) => appInst(a))) return false;
    if (when.rows) {
      const ds = appInst(when.rows.app)?.lookup?.(when.rows.dataset);
      if (!ds || typeof ds.getRowCount !== 'function' || ds.getRowCount() < (when.rows.min || 1)) return false;
    }
    if (when.clicked && !guide.clicked) return false;
    return true;
  }

  // 복무 결재선 자동 지정(교사 요청 2026-11-02: 출장 관내 교감, 관외·초과근무 교감+교장). 실제 확인: 교사가 [승인요청]을 누르면 나이스가 임시 저장하고 결재 창(wam_woapm07_p00)을 연다
  // → [결재자지정](p04)에서 직위로 사람을 찾아 옮기고 그 창 [저장](서버 통신 없음, 결재 창으로 돌려줄 뿐) → 결재 창 줄에 들어감. [상신]은 교사가. 이름은 저장하지 않는다(직위로 그때 찾음)
  const LINE_APP = 'edu/cm/wam/woa/pm/wam_woapm07_p00', LINE_PICK = 'edu/cm/wam/woa/pm/wam_woapm07_p04';
  const lineWatch = { timer: 0, until: 0, jobs: [], state: '', note: '', seen: null, goneAt: 0 };
  function lineToast(text, bad = false) {
    if (typeof document.createElement !== 'function') return;
    let h = document.getElementById('doumi-line-note');
    if (!h) { h = document.createElement('div'); h.id = 'doumi-line-note'; document.documentElement.appendChild(h); }
    h.style.cssText = `position:fixed;right:16px;top:64px;z-index:2147483600;max-width:340px;padding:10px 12px;background:#fff;color:#222;border:1px solid #c9d1dc;border-left:3px solid ${bad ? '#d33a2c' : '#2a64d6'};border-radius:3px;box-shadow:0 6px 22px rgba(20,32,54,.18);font:13px/1.55 "Malgun Gothic",sans-serif;`;
    h.textContent = text;
    setTimeout(() => { if (h.textContent === text) h.remove(); }, 12000);
  }
  async function fillDutyLine(jobs, p00) {
    const ds = p00?.lookup('dsSancr');
    if (!ds) { lineWatch.state = 'fail'; lineToast('결재 창의 결재선 칸을 찾지 못했어요. 결재선을 직접 골라 주세요.', true); return; }
    // 결재 창이 기안자 줄을 받아 올 때까지 기다린다. 그 전에 누르면 뒤늦게 온 줄이 넣은 결재선을 덮는다(느린 PC·학교 망)
    for (const end = Date.now() + 15000; ds.getRowCount() < 1 && Date.now() < end; await sleep(150));
    await sleep(400);
    // 이미 사람이 들어 있으면(개인결재선을 골랐거나 선생님이 고침) 건드리지 않음
    if (ds.getRowCount() > 1) { lineWatch.state = 'kept'; lineToast('결재 창에 결재선이 이미 있어서 그대로 뒀어요. 확인하고 [상신]을 눌러 주세요.'); return; }
    clickControl(p00.lookup('btnSelectSancr'));
    let d = null;
    for (const end = Date.now() + 12000; !(d = appInst(LINE_PICK)) && Date.now() < end; await sleep(150));
    const list = d?.lookup('dsMain'), param = d?.lookup('dsParam'), g = d?.lookup('grdUserListFrom');
    if (!list || !param || !g) { lineWatch.state = 'fail'; lineToast('결재자 지정 창을 열지 못했어요. 결재선을 직접 골라 주세요.', true); return; }
    for (const end = Date.now() + 12000; list.getRowCount() === 0 && Date.now() < end; await sleep(150));
    const missing = [];
    for (const job of jobs) {
      const hits = [];
      for (let r = 0; r < list.getRowCount(); r++) if (str(list.getValue(r, 'jbpsNm')).startsWith(job)) hits.push(r);
      if (hits.length !== 1) { missing.push(`${job}(${hits.length}명)`); continue; }
      try { g.clearAllCheck?.(); } catch { /* 체크 없음 */ }
      g.setCheckRowIndex(hits[0], true);
      const n0 = param.getRowCount();
      clickControl(d.lookup('btn1'));
      for (const end = Date.now() + 2000; param.getRowCount() === n0 && Date.now() < end; await sleep(80));
    }
    if (missing.length) {
      // 못 찾은 사람이 있으면 그 창을 열어 둔 채 교사에게 맡긴다(앞 사람까지만 옮겨져 있음)
      lineWatch.state = 'fail';
      lineToast(`직위로 찾지 못했어요: ${missing.join(', ')}. 결재자를 직접 골라 [저장]을 눌러 주세요.`, true);
      return;
    }
    clickControl(d.lookup('btn4'));
    for (const end = Date.now() + 6000; ds.getRowCount() < jobs.length + 1 && Date.now() < end; await sleep(100));
    lineWatch.state = ds.getRowCount() >= jobs.length + 1 ? 'done' : 'fail';
    lineToast(lineWatch.state === 'done' ? `결재선에 ${jobs.join(' → ')}을(를) 넣었어요. 확인하고 [상신]을 눌러 주세요.` : '결재선을 넣지 못했어요. 직접 골라 주세요.', lineWatch.state !== 'done');
  }
  // [승인요청] 뒤에 결재 창이 뜨기를 기다린다(패널이 닫혀 있어도). 결재 창을 취소하고 [승인요청]을 다시 누르면 새 창에도 넣는다.
  // 신청 창과 결재 창이 모두 닫히면 끝(뒤에 선생님이 손으로 여는 다른 복무 결재에 끼어들지 않게), 20분 지나도 끝
  function armDutyLine(jobs, dialog = '') {
    clearInterval(lineWatch.timer);
    Object.assign(lineWatch, { jobs, until: Date.now() + 20 * 60000, state: 'wait', seen: null, goneAt: 0 });
    let running = false;
    lineWatch.timer = setInterval(async () => {
      if (running) return;
      if (Date.now() > lineWatch.until) { clearInterval(lineWatch.timer); if (lineWatch.state === 'wait') lineWatch.state = 'timeout'; return; }
      const p00 = appInst(LINE_APP);
      if (!p00) {
        if (!dialog || appInst(dialog)) { lineWatch.goneAt = 0; return; }
        // 임시 저장 뒤 결재 창이 뜰 때까지 잠깐 둘 다 없을 수 있어 바로 끝내지 않는다
        lineWatch.goneAt = lineWatch.goneAt || Date.now();
        if (Date.now() - lineWatch.goneAt > 20000) { clearInterval(lineWatch.timer); if (lineWatch.state === 'wait') lineWatch.state = 'closed'; }
        return;
      }
      lineWatch.goneAt = 0;
      if (p00 === lineWatch.seen) return;
      lineWatch.seen = p00;
      running = true;
      lineToast(`결재선에 ${lineWatch.jobs.join(' → ')}을(를) 넣는 중이에요. 잠깐만 기다려 주세요.`);
      try { await fillDutyLine(lineWatch.jobs, p00); } catch { lineWatch.state = 'fail'; lineToast('결재선을 넣지 못했어요. 직접 골라 주세요.', true); }
      running = false;
    }, 300);
  }

  // ── 작업 ───────────────────────────────────────────────
  // 나이스 첨부 칸(RAON K 업로더 + udcSingleUploader/udcRaonkSingleUpload)에 파일 하나 올리기 (2026-10-28 문항정보표 조사).
  // 교사가 파일 칸을 누를 때와 같은 길(openFileDialog)을 타되, 파일 고르는 창 대신 받은 파일을 넣는다.
  // 나이스가 올리기를 마치면 dataMap(dmAtchFile)의 파일 이름이 바뀐다 → 그것을 기다림. 실제 저장은 화면 [저장]이 한다.
  async function attachFile(inst, { uploader, picker, dataMap, nameColumn = 'fileNm', idColumn = 'screAtchFileCn', file, timeout = 60000 }) {
    const R = window.RAONKUPLOAD;
    const up = inst.lookup(uploader);
    const pk = inst.lookup(picker);
    const dm = inst.lookup(dataMap);
    if (!R || typeof R.AddLocalFileObject !== 'function' || !up || !pk || !dm) fail('no-attach', '나이스 첨부 칸을 찾지 못했어요. 나이스 화면에서 직접 붙여 주세요.');
    if (pk.visible === false) fail('attach-closed', '나이스 첨부 칸이 닫혀 있어요(마감·입력완료). 나이스에서 풀어야 붙일 수 있어요.');
    const emb = pk.getEmbeddedAppInstance?.();
    if (!emb || typeof up.callAppMethod !== 'function') fail('no-attach', '나이스 첨부 칸을 찾지 못했어요. 나이스 화면에서 직접 붙여 주세요.');
    const bin = atob(file.b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const f = new File([bytes], file.name, { type: file.type || 'application/octet-stream' });
    const before = str(dm.getValue(nameColumn));
    const beforeId = str(dm.getValue(idColumn));
    // 교사가 파일 칸을 눌렀을 때처럼 지금 파일 이름을 알려 주면, 나이스가 옛 첨부를 새 파일로 바꾼다
    const cur = emb.lookup?.('siFile')?.value;
    if (cur) try { up.setAppProperty('openFileNm', cur); } catch { /* 없으면 나이스 기본 동작 */ }
    const orig = R.OpenFileDialog;
    let handed = false;
    R.OpenFileDialog = function (id) { R.OpenFileDialog = orig; handed = true; R.AddLocalFileObject({ type: 'file', files: [f] }, undefined, id); };
    try { up.callAppMethod('openFileDialog', emb, emb.getAppProperty?.('fileGubunCd')); } finally { if (!handed) R.OpenFileDialog = orig; }
    if (!handed) fail('no-attach', '나이스 첨부 칸이 파일을 받지 않았어요. 나이스 화면에서 직접 붙여 주세요.');
    for (const end = Date.now() + timeout; Date.now() < end; await sleep(300)) {
      // 올리기가 끝나면 나이스가 새 파일 참조 번호와 이름을 dmAtchFile에 넣는다
      if (str(dm.getValue(nameColumn)) === file.name && str(dm.getValue(idColumn)) && str(dm.getValue(idColumn)) !== beforeId) return { name: file.name, replaced: before };
    }
    fail('attach-timeout', '첨부 파일을 나이스에 올리지 못했어요(시간 초과). 값은 들어갔지만 아직 저장하지 않았어요 — 나이스 화면에서 파일을 직접 붙이고 [저장]을 눌러 주세요.');
  }

  // 화면 안 탭 고르기. tab: { folder: 'tabFolder', item: '학생부자료기록' } — 이미 그 탭이면 그대로. → 'switched' | 'same' | false(탭 없음)
  // 자율·진로는 메뉴로 열면 [출결관리] 탭이 먼저 열려 조회 조건이 비어 있다(2026-10-29 실제 확인). setSelectedTabItem으로 고르면 화면이 조건을 채운다
  function pickTab(inst, tab) {
    const f = tab && inst.lookup(tab.folder);
    if (!f || typeof f.getTabItems !== 'function' || typeof f.setSelectedTabItem !== 'function') return false;
    // tab.id가 있으면 탭 id로(개인별 세특은 탭 1·4 글자가 '보통교과및전문교과'로 같음 — 2026-10-30 실제), 없으면 글자로
    const it = f.getTabItems().find((t) => (tab.id != null ? String(t.id) === String(tab.id) : norm(t.text) === tab.item));
    if (!it) return false;
    if (f.getSelectedTabItem?.() === it) return 'same';
    f.setSelectedTabItem(it);
    return 'switched';
  }

  // 막 연 화면이 조회 조건을 다 채울 때까지 기다린다. 나이스 화면은 앱이 생긴 뒤 0.7~1.5초 동안 학년도(ayr)를 비롯한 조건이 비어 있다가
  // 한 번에 채워진다(2026-10-29 실제: 일일출결·과목별출결·성취기준·수행평가·문항정보표). 그 사이에 [조회]를 누르면
  // 'CM000 자료권한이 존재하지 않습니다'·'학년도은(는) 필수 입력입니다' 알림이 뜨고, 출석부 명단 같은 결과가 달라졌다.
  // 학년도 칸이 있으면 그것이 채워지고 조건이 잠깐(0.3초) 그대로일 때, 없으면 0.6초 그대로일 때 준비로 본다.
  // 그동안 OTP 창(otp)이나 나이스 알림(seen 밖의 새 알림)이 뜨면 그 내용으로 멈춘다. 시간 안에 안 채워지면 그대로 넘어간다(조회가 나이스 안내를 받아 옴)
  // needChange: 탭을 막 바꾼 때처럼 조건이 한 번은 바뀌어야 준비로 본다(학년도는 이미 차 있고 과정·반이 0.3~0.6초 뒤에 채워짐)
  async function settle(inst, { tab = null, otp = false, seen = null, needChange = false, timeout = 8000 } = {}) {
    const switched = tab ? pickTab(inst, tab) === 'switched' : false;
    const dm = inst.lookup('dmSearch');
    const cols = dm && typeof dm.getColumnNames === 'function' ? dm.getColumnNames().map(str) : [];
    const sig = () => cols.map((k) => str(dm.getValue(k))).join('|');
    const needAyr = cols.includes('ayr');
    let last = sig();
    let since = Date.now();
    let changed = !(needChange || switched);
    const t0 = Date.now();
    for (const end = t0 + timeout; Date.now() < end; await sleep(150)) {
      if (otp && otpApps().length) fail('otp', '나이스에 OTP(2차 인증) 창이 떴어요.', { apps: otpApps() });
      const text = seen ? takeAlert(seen) : null;
      if (text) fail('menu-alert', `나이스 안내: ${text}`);
      const now = sig();
      if (now !== last) { last = now; since = Date.now(); changed = true; }
      // 예전에 채워 둔 탭으로 돌아가면 조건이 안 바뀔 수도 있다 → 1.2초가 지나면 바뀌지 않아도 준비로 본다
      if ((changed || Date.now() - t0 >= 1200) && (!needAyr || str(dm.getValue('ayr'))) && Date.now() - since >= (needAyr ? 300 : 600)) return true;
    }
    return false;
  }

  const OPS = {
    // 지금 열려 있는 나이스 화면 목록(앱 ID만). otp: 떠 있는 OTP(2차 인증) 창 앱 ID
    detect() {
      if (!platform()) return { framework: false, apps: [], otp: [] };
      return { framework: true, apps: [...new Set(runningApps().map(appIdOf))], otp: otpApps() };
    },

    // 길잡이: 메뉴 이름 순서(업무 탭 아래 묶음 → 화면). 메인 앱 dsAllMenu의 MENU_NM과, 다른 줄을 가리키는 부모 칼럼(이름은 모름)을 따라 위로.
    // 메뉴 이름만 읽는다. 부모 칼럼을 못 찾으면 화면 이름 하나만, 메뉴 목록이 없으면 names: null
    menuPath({ menuId, prefer = '' }) {
      const ds = appInst('app/com/main/Index')?.lookup?.('dsAllMenu');
      const n = ds && typeof ds.getRowCount === 'function' ? ds.getRowCount() : 0;
      if (!n) return { names: null };
      const val = (r, c) => { try { return str(ds.getValue(r, c)); } catch { return ''; } };
      const ok = (r) => !prefer || !val(r, 'V_MENU_ID') || val(r, 'V_MENU_ID').startsWith(prefer);
      let row = -1;
      for (let r = 0; r < n && row < 0; r++) if (val(r, 'MENU_ID') === menuId && ok(r)) row = r;
      for (let r = 0; r < n && row < 0; r++) if (val(r, 'MENU_ID') === menuId) row = r;
      if (row < 0) return { names: null };
      const findRow = (v) => {
        let hit = -1;
        for (let r = 0; r < n; r++) {
          if (val(r, 'V_MENU_ID') === v) return r;
          if (hit < 0 && val(r, 'MENU_ID') === v && ok(r)) hit = r;
        }
        return hit;
      };
      const skip = new Set(['MENU_ID', 'V_MENU_ID', 'MENU_NM', 'CALL_PAGE', 'SHOW_YN']);
      const rank = (c) => (/UP|PRNT|PARENT|UPPR|HGRK|HIGH|SUPER/i.test(c) ? 0 : 1);
      const cols = columnsOf(ds).filter((c) => !skip.has(c)).sort((a, b) => rank(a) - rank(b));
      let parent = null;
      for (const c of cols) {
        const v = val(row, c);
        if (!v || v === val(row, 'MENU_ID') || v === val(row, 'V_MENU_ID')) continue;
        const p = findRow(v);
        if (p >= 0 && p !== row) { parent = c; break; }
      }
      const names = [val(row, 'MENU_NM')];
      if (parent) {
        const seen = new Set([row]);
        for (let r = row, k = 0; k < 8; k++) {
          const p = findRow(val(r, parent));
          if (p < 0 || seen.has(p)) break;
          seen.add(p);
          names.unshift(val(p, 'MENU_NM'));
          r = p;
        }
      }
      const out = names.map(norm).filter(Boolean);
      return { names: out.length ? out : null, deep: !!parent };
    },

    // 길잡이 한 단계 그리기. step: { n, total, title, body, caution, how, look, manual, targets:[{app,id,text,near,menu,pick,label,look}] }
    guideShow({ step = null, keepClick = false } = {}) {
      if (!step) { guideClear(); return { shown: false }; }
      guide.run = null;
      guideShowStep(step, keepClick);
      return { shown: true, found: guide.found, total: (step.targets || []).length };
    },
    // 길잡이 시작: 단계 전부를 엔진에 맡긴다. run: { id, i, menuN, apps, open, steps: [{ title, body, caution, look, when, targets }] }
    guideStart({ run }) {
      guide.ended = null;
      guide.run = run;
      guideStep(run.i || 0);
      return { shown: true, found: guide.found, total: (guide.step?.targets || []).length, i: run.i };
    },
    guideGo({ i, keepClick = false }) {
      if (!guide.run) return { shown: false };
      guide.ended = null;
      guideStep(i, keepClick);
      return { shown: true, found: guide.found, total: (guide.step?.targets || []).length, i: guide.run.i };
    },

    // 길잡이 상태: 단계 조건이 맞았는지, 말풍선 단추([다음]·[이전]·[그만]), 열린 화면(앱 ID만)
    guideState({ when = null, full = false } = {}) {
      // 진행을 엔진이 맡는 동안 말풍선 단추는 엔진이 처리한다(패널이 닫혀 있어도 됨)
      const action = guide.run ? '' : guide.action;
      if (!guide.run) guide.action = '';
      return {
        shown: !!guide.step && !!document.getElementById(GUIDE_HOST),
        found: guide.found,
        covered: guide.covered,
        total: guide.step?.targets?.length || 0,
        clicked: guide.clicked,
        action,
        met: guideMet(when),
        apps: platform() ? [...new Set(runningApps().map(appIdOf))] : [],
        run: guide.run ? (full ? guide.run : { id: guide.run.id, i: guide.run.i, total: guide.run.steps.length }) : null,
        ended: guide.ended,
      };
    },

    guideClear() { guideClear(); return {}; },
    dutyLineState() { return { state: lineWatch.state, jobs: lineWatch.jobs }; },

    // 나이스 메뉴를 연다. 나이스 첫 화면이 쓰는 openMdiMenu(메뉴키)를 그대로 부른다(2026-10-27 실제 확인).
    // 메뉴키는 메인 앱의 메뉴 목록(dsAllMenu)에서 menuId로 찾고, 같은 메뉴가 여러 업무(학급담임·교과담임…)에 있으면 prefer로 시작하는 것.
    // step: { appId: 래퍼 앱, button: 단계 버튼 } — 메뉴가 래퍼(예: 성취기준관리)를 열고, 그 안의 단계 버튼으로 바꾸는 화면
    //       { appId: 래퍼 앱, tab: { folder, item | id } } — 래퍼의 탭을 골라야 안쪽 화면이 생기는 화면(독서 '반별')
    // otp: 생기부처럼 열 때 OTP(2차 인증) 창이 뜰 수 있는 메뉴 — 화면이 안 뜨면 'menu-timeout' 대신 'otp'로 알린다
    // waitFirst: 메뉴를 누르기 전에 화면이 저절로 뜨는지 먼저 기다리는 시간(OTP 인증을 마친 뒤 [이어서] — 나이스가 화면을 늦게 열 수 있음)
    // tab: 조회 조건이 있는 탭(settle 참고). 새로 연 화면은 조회 조건이 채워질 때까지 기다린 뒤 '열림'으로 돌려준다
    async openMenu({ menuId, prefer = '', appId, step = null, tab = null, timeout = 15000, otp = false, waitFirst = 0 }) {
      if (!platform()) fail('no-framework', '나이스 화면 엔진을 찾지 못했어요. 나이스에 로그인한 탭인지 확인해 주세요.');
      const running = (id) => runningApps().some((i) => appIdOf(i) === id);
      // 교과 세특은 화면 앱이 OTP 창 뒤에 함께 뜬다(2026-10-29) → 화면이 있어도 OTP 창이 떠 있으면 인증이 먼저
      if (otp && otpApps().length) fail('otp', 'OTP 인증 창이 아직 열려 있어요. 나이스에서 인증을 마쳐 주세요.', { apps: otpApps() });
      if (running(appId)) return { opened: false, already: true };
      for (const end = Date.now() + waitFirst; Date.now() < end; await sleep(300)) {
        if (running(appId)) return { opened: false, already: true, waited: true };
        if (otp && otpApps().length) break;
      }
      if (step) {
        if (!running(step.appId)) await OPS.openMenu({ menuId, prefer, appId: step.appId, timeout });
        const seen = new Set(dialogs('app/cmn/alert'));
        // 래퍼가 첫 단계 화면을 저절로 띄우기도 한다(예: 성적산출관리 → 결시생 인정점) — 이미 떠 있으면 단계 버튼을 누르지 않는다
        if (!running(appId) && step.tab) {
          if (!pickTab(needApp(step.appId), step.tab)) fail('no-step', '나이스 화면 탭을 찾지 못했어요. 나이스에서 해당 탭을 직접 눌러 주세요.');
          for (const end = Date.now() + timeout; Date.now() < end && !running(appId); await sleep(300));
          if (!running(appId)) fail('menu-timeout', '나이스 화면이 열리지 않았어요. 나이스에 안내 창이 떠 있는지 확인해 주세요.');
        }
        if (!running(appId)) {
          const wrapper = needApp(step.appId);
          let btn = null;
          for (const end = Date.now() + 5000; Date.now() < end && !btn; await sleep(200)) btn = wrapper.lookup(step.button);
          if (!btn) fail('no-step', '나이스 화면 단계 버튼을 찾지 못했어요. 나이스에서 해당 단계를 직접 눌러 주세요.');
          if (FORBIDDEN_WORDS.some((w) => controlText(btn).includes(w))) fail('forbidden-button', `"${controlText(btn)}" 버튼은 도우미가 누르지 않아요.`);
          clickControl(btn);
          for (const end = Date.now() + timeout; Date.now() < end && !running(appId); await sleep(300));
          if (!running(appId)) fail('menu-timeout', '나이스 화면이 열리지 않았어요. 나이스에 안내 창이 떠 있는지 확인해 주세요.');
        }
        await settle(needApp(appId), { tab, otp, seen: otp ? null : seen });
        return { opened: true, step: true };
      }
      if (typeof window.openMdiMenu !== 'function') fail('no-menu', '나이스 메뉴를 열지 못했어요. 메뉴에서 직접 열어 주세요.');
      // 2026-11-02 실제(교사 제보 '나이스 화면이 열리지 않았어요'의 원인): 같은 탭에서 로그인하면 나이스 전역 voMainApp이 사라진 로그인 앱을 가리켜
      // openMdiMenu가 조용히 아무것도 안 한다(새로고침한 탭에서만 됨) → 그때는 메인 앱에 같은 일을 직접 시킨다
      const openMdi = (k) => {
        const m = runningApps().find((i) => appIdOf(i) === 'app/com/main/Index');
        const vo = window.voMainApp;
        const stale = !vo || vo.disposed || !(typeof vo.hasAppMethod === 'function' && vo.hasAppMethod('doInitMenu'));
        if (stale && typeof m?.hasAppMethod === 'function' && m.hasAppMethod('doInitMenu')) {
          platform().initParameter?.({ menuId: k, params: {} });
          m.callAppMethod('doInitMenu', [k]);
          return;
        }
        window.openMdiMenu(k);
      };
      const main = runningApps().find((i) => appIdOf(i) === 'app/com/main/Index');
      // 업무 메뉴(dsAllMenu)에 없으면 왼쪽 '기본 메뉴'(dsBaseMenu — 복무 일일근무상황조회 등)에서 찾는다.
      // 확인 필요(2026-10-29): 기본 메뉴의 열쇠 칸 이름 — V_MENU_ID가 없으면 MENU_ID 그대로 openMdiMenu에 준다
      const findKeys = () => {
        const out = [];
        for (const name of ['dsAllMenu', 'dsBaseMenu']) {
          const ds = main?.lookup(name);
          if (!ds || typeof ds.getRowCount !== 'function') continue;
          for (let r = 0; r < ds.getRowCount(); r++) {
            if (str(ds.getValue(r, 'MENU_ID')) === menuId) out.push(str(ds.getValue(r, 'V_MENU_ID')) || menuId);
          }
          if (out.length) break;
        }
        return out;
      };
      // 나이스를 막 열면 업무 메뉴 목록이 10초쯤 비어 있다(2026-10-29 실제: 0줄 → 473줄). 비어 있는 동안은 기다린다
      // (전에는 이때 '이 계정의 나이스 메뉴에서 해당 화면을 찾지 못했어요'가 떴다)
      const menuRows = () => { const ds = main?.lookup('dsAllMenu'); return ds && typeof ds.getRowCount === 'function' ? ds.getRowCount() : 0; };
      let keys = findKeys();
      for (const end = Date.now() + 15000; !keys.length && !menuRows() && Date.now() < end;) { await sleep(500); keys = findKeys(); }
      if (!keys.length) fail('no-menu', '이 계정의 나이스 메뉴에서 해당 화면을 찾지 못했어요. 권한이 있는 메뉴인지 확인해 주세요.');
      const key = keys.find((k) => k.startsWith(prefer)) || keys[0];
      // OTP 인증 창이 아직 떠 있으면 메뉴를 다시 누르지 않는다(창이 겹쳐 뜨지 않게)
      if (otp && otpApps().length) fail('otp', 'OTP 인증 창이 아직 열려 있어요. 나이스에서 인증을 마쳐 주세요.', { apps: otpApps() });
      // 나이스는 화면 탭을 20개까지만 연다(Index.clx.js mnMaxItemCount 20 — 2026-10-30 실제). 넘으면 안내만 띄우고 안 염
      const tabsNow = () => { try { return main?.lookup('mdiCn')?.getTabItems?.().length || 0; } catch { return 0; } };
      if (tabsNow() >= 20) fail('too-many-tabs', `나이스 화면 탭이 ${tabsNow()}개 열려 있어 더 열 수 없어요(나이스는 20개까지). 나이스 아래쪽 탭에서 안 쓰는 화면을 닫고 다시 눌러 주세요.`);
      const before = new Set(runningApps());
      const seenAlerts = new Set(dialogs('app/cmn/alert'));
      openMdi(key);
      // 교사 제보(2026-10-30): 초과근무가 선생님 나이스에서 안 열림(시험 탭에서는 열림) → 6초 안에 안 뜨면 한 번 더 누른다
      // (이미 열린 화면은 나이스가 그 탭으로만 옮겨 두 번 열리지 않음 — isOpenMenuId)
      const t0 = Date.now();
      let again = false;
      for (const end = Date.now() + timeout; Date.now() < end; await sleep(300)) {
        if (running(appId)) {
          await settle(needApp(appId), { tab, otp, seen: otp ? null : seenAlerts });
          return { opened: true, key, again };
        }
        if (!again && !otp && Date.now() - t0 > 6000) { again = true; try { openMdi(key); } catch { /* 첫 번째 결과를 기다림 */ } }
        // 화면 대신 OTP(2차 인증) 창처럼 보이는 앱이 뜨면 기다리지 않고 바로 알린다
        if (otp && otpApps().length) fail('otp', '나이스에 OTP(2차 인증) 창이 떴어요.', { apps: newApps(before) });
        // 메뉴를 누르자 나이스가 알림을 띄우면 15초를 기다리지 않고 그 글로 멈춘다
        // (2026-10-29 실제: 첫 화면이 다 뜨기 전에 누르면 '화면에 대한 권한이 없거나 화면이 존재하지 않습니다(4)')
        if (!otp) { const text = takeAlert(seenAlerts); if (text) fail('menu-alert', `나이스 안내: ${text}`); }
      }
      if (otp) {
        // 실제 OTP 창의 앱 ID는 아직 모른다(2026-10-28) → 메뉴는 눌렀는데 화면이 시간 안에 안 뜨면 OTP 인증 중일 수 있다고 본다.
        // 새로 뜬 앱 ID(값 없음)와 알림 글만 돌려준다 — 실제 OTP 창 이름을 알아내는 데 쓴다
        const alert = dialogs('app/cmn/alert').find((d) => !seenAlerts.has(d));
        fail('otp', '나이스 화면이 아직 열리지 않았어요. OTP(2차 인증) 창이 떠 있을 수 있어요.', { apps: newApps(before), alert: alert ? dialogText(alert).slice(0, 120) : '' });
      }
      // 무엇이 막았는지 함께: 떠 있는 안내 글(optMsg가 있는 창이면 무엇이든), 새로 뜬 창, 화면 탭 수
      const shown = runningApps().map((i) => { try { return norm(i.lookup?.('optMsg')?.value); } catch { return ''; } }).filter(Boolean);
      if (shown.length) fail('menu-alert', `나이스 안내: ${shown[shown.length - 1].slice(0, 160)}`);
      fail('menu-timeout', `나이스 화면이 열리지 않았어요(메뉴 ${key}). 나이스 로그인 시간이 끝났거나 나이스가 다른 창을 띄웠을 수 있어요 — 나이스 탭을 새로고침(F5)하고 다시 로그인돼 있는지 본 뒤 다시 눌러 주세요.`, { apps: newApps(before).filter((a) => !a.startsWith('udc/')), tabs: tabsNow() });
    },

    // 정해진 칼럼만 읽는다. dataMaps: { dmSearch: ['ayr', ...] }, extraDatasets: { dsAtteGb: ['code', 'data'] }
    read({ appId, dataset, columns = [], dataMaps = {}, extraDatasets = {} }) {
      const inst = needApp(appId);
      const ds = needDataset(inst, dataset);
      const have = columnsOf(ds);
      const missingColumns = have.length ? columns.filter((c) => !have.includes(c)) : [];
      const dm = {};
      for (const [id, keys] of Object.entries(dataMaps)) {
        const m = inst.lookup(id);
        dm[id] = {};
        if (m && typeof m.getValue === 'function') for (const k of keys) dm[id][k] = str(m.getValue(k));
      }
      const extra = {};
      for (const [id, cols] of Object.entries(extraDatasets)) {
        const x = inst.lookup(id);
        extra[id] = x && typeof x.getRowCount === 'function' ? readRows(x, cols) : null;
      }
      return { rows: readRows(ds, columns), missingColumns, dm, extra };
    },

    // 계획대로 값을 넣고(선택) 저장 버튼을 누른다.
    // rows: [{ key: {clsNo, stuFlnm}, expect: {칼럼: 미리보기 때 값}, set: {칼럼: 새 값} }]
    // 표가 둘 이상이면 parts: [{ dataset, grid, keyColumns, rows, insert }] (예: 문항정보표의 객관식·서답형)
    // insert: { button: '행추가 버튼', rows: [{ set }] } — 화면의 [행추가]를 눌러 생긴 빈 줄(키 칸이 빈 줄)에 값을 넣는다.
    // 미리보기 뒤에 나이스 값이 바뀌었으면 아무것도 넣지 않고 멈춘다.
    async apply({ appId, dataset, grid, keyColumns, rows = [], insert = null, parts = null, save = null, attach = null }) {
      const inst = needApp(appId);
      if (otpApps().length) fail('otp', '나이스에 2차 인증(OTP) 창이 떠 있어요. 그 창에서 인증을 마친 뒤 다시 눌러 주세요.', { apps: otpApps() });
      const list = (parts || [{ dataset, grid, keyColumns, rows, insert }]).map((p) => ({ ...p, rows: p.rows || [], ds: needDataset(inst, p.dataset) }));
      if (!attach && !list.some((p) => p.rows.length || p.insert?.rows?.length)) fail('empty', '넣을 값이 없어요.');

      for (const p of list) {
        p.targets = p.rows.map((item, index) => {
          const hit = findRows(p.ds, p.keyColumns, item.key);
          if (hit.length !== 1) fail('key', hit.length ? '같은 줄이 나이스 표에 두 번 있어요.' : '넣을 줄을 나이스 표에서 찾지 못했어요. 다시 조회해 주세요.', { index });
          const r = hit[0];
          for (const [c, v] of Object.entries(item.expect || {})) {
            if (str(p.ds.getValue(r, c)) !== str(v)) fail('stale', '확인한 뒤에 나이스 값이 바뀌었어요. 다시 확인해 주세요.', { index });
          }
          return { r, item };
        });
        if (p.insert?.rows?.length) p.addBtn = needSafeButton(inst, p.insert.button, save?.forbidden);
      }

      const btn = save ? needSafeButton(inst, save.button, save.forbidden) : null;
      // save.clearChecks: 체크된 줄이 있으면 나이스가 저장을 막는 화면(진로·독서) — 넣기 전에 표의 체크를 모두 푼다
      if (save?.clearChecks) for (const p of list) { const g = p.grid ? inst.lookup(p.grid) : null; try { g?.clearAllCheck?.(); } catch { /* 체크 칸 없는 표 */ } }

      let changed = 0;
      let added = 0;
      for (const p of list) {
        // 있는 줄 먼저(새 줄이 위에 끼면 줄 번호가 밀리므로)
        for (const { r, item } of p.targets) {
          for (const [c, v] of Object.entries(item.set || {})) { p.ds.setValue(r, c, v); changed++; }
        }
        // 새 줄: [행추가]를 눌러 화면이 기본값을 채운 줄을 만들게 하고, 키 칸이 빈 그 줄에 값을 넣는다
        for (const item of p.insert?.rows || []) {
          const before = p.ds.getRowCount();
          clickControl(p.addBtn);
          let blank = [];
          for (const end = Date.now() + 3000; Date.now() < end; await sleep(100)) {
            blank = [];
            for (let r = 0; r < p.ds.getRowCount(); r++) if (p.keyColumns.every((c) => !norm(p.ds.getValue(r, c)))) blank.push(r);
            if (p.ds.getRowCount() > before && blank.length === 1) break;
          }
          if (p.ds.getRowCount() <= before || blank.length !== 1) fail('insert', '[행추가]로 새 줄을 만들지 못했어요. 나이스에서 [조회]를 다시 누르고(넣던 값은 사라짐) 직접 확인해 주세요.');
          for (const [c, v] of Object.entries(item.set)) { p.ds.setValue(blank[0], c, v); changed++; }
          p.targets.push({ r: blank[0], item: { key: Object.fromEntries(p.keyColumns.map((c) => [c, item.set[c]])) } });
          added++;
        }
      }
      let painted = 0;
      const marks = [];
      for (const p of list) {
        const g = p.grid ? inst.lookup(p.grid) : null;
        try { g?.redraw?.(); } catch { /* 다시 그리기 실패는 값 입력과 무관 */ }
        if (g && p.targets.length) marks.push({ grid: g, keys: p.targets.map(({ item }) => p.keyColumns.map((c) => norm(item.key[c]))) });
      }
      painted = markRows(marks);

      // 첨부 파일(문항정보표 서답형 채점기준표): 값을 넣은 뒤, 저장 누르기 전에 나이스 첨부 칸에 올린다
      let attached = null;
      if (attach) attached = await attachFile(inst, attach);

      let saveToken = null;
      let clickedBy = null;
      if (btn) {
        saveToken = watchSave(inst, save);
        clickedBy = clickControl(btn);
      }
      return { applied: list.reduce((n, p) => n + p.targets.length, 0) + (attached ? 1 : 0), added, cells: changed, painted, saveToken, clickedBy, attached };
    },

    // 조회 조건(예: 날짜)을 바꾸고 [조회]를 눌러, 표 자료를 다시 받아올 때까지 기다린다. 값은 넣지 않는다.
    // 끝났다는 신호: 표 데이터셋의 'load' 이벤트, 또는 화면의 통신(submission) 하나가 성공한 뒤 잠깐.
    // tab: 조회 조건이 있는 탭 — 다른 탭이 열려 있으면 고르고, 학년도가 아직 비어 있으면(막 연 화면) 채워질 때까지 기다린 뒤 조회한다
    async search({ appId, dataMap, values = {}, button, dataset, tab = null, timeout = 20000 }) {
      const inst = needApp(appId);
      closeRequiredAlerts(); // 앞서 조건 칸을 바꾸다 남은 알림이 조회를 가리지 않게
      const dm = inst.lookup(dataMap);
      if (!dm || typeof dm.setValue !== 'function') fail('no-datamap', '조회 조건을 찾지 못했어요. 나이스 화면이 바뀌었을 수 있어요.');
      const switched = tab ? pickTab(inst, tab) === 'switched' : false;
      const noYear = typeof dm.getColumnNames === 'function' && dm.getColumnNames().includes('ayr') && !str(dm.getValue('ayr'));
      if (switched || noYear) await settle(inst, { needChange: switched, timeout: 6000 });
      const ds = needDataset(inst, dataset);
      const btn = needSafeButton(inst, button);
      const Submission = window.cpr?.protocols?.Submission;
      const subs = typeof inst.getAllDataControls === 'function' && Submission
        ? inst.getAllDataControls().filter((c) => c instanceof Submission) : [];

      const offs = [];
      const listen = (target, ev, fn) => {
        if (typeof target?.addEventListener !== 'function') return;
        target.addEventListener(ev, fn);
        offs.push(() => target.removeEventListener(ev, fn));
      };
      let timer;
      let alertText = null;
      const seenAlerts = new Set(dialogs('app/cmn/alert'));
      const outcome = new Promise((resolve) => {
        listen(ds, 'load', () => resolve('loaded'));
        // [조회]는 통신을 여러 개 보낼 수 있다(성취기준: subRelm 먼저, subSearch 나중, 2026-11-02 실제). 앞 통신만 끝났을 때 읽으면 빈 표를 읽는다
        // → 있는 코드를 새 줄로 넣으려 하게 됨. 돌고 있는 통신이 다 끝난 뒤에 끝으로 본다(한 통신이 안 끝나도 5초 뒤에는 넘어감)
        let pending = 0, quiet = 0, giveUp = 0;
        offs.push(() => { clearTimeout(quiet); clearTimeout(giveUp); });
        for (const s of subs) {
          listen(s, 'before-submit', () => { pending++; clearTimeout(quiet); });
          listen(s, 'submit-success', () => {
            pending--;
            clearTimeout(quiet);
            quiet = setTimeout(() => { if (pending <= 0) resolve('loaded'); }, 300);
            if (!giveUp) giveUp = setTimeout(() => resolve('loaded'), 5000);
          });
          listen(s, 'submit-error', () => resolve('error'));
        }
        timer = setTimeout(() => resolve('timeout'), timeout);
        // 조회 중 나이스가 알림(휴업일·권한 없음 등)을 띄우면 그 문구로 멈춘다
        const poll = setInterval(() => { alertText = takeAlert(seenAlerts); if (alertText) resolve('alert'); }, 200);
        offs.push(() => clearInterval(poll));
      });

      for (const [k, v] of Object.entries(values)) dm.setValue(k, v);
      clickControl(btn);
      const res = await outcome;
      clearTimeout(timer);
      offs.forEach((off) => off());
      if (res === 'alert') fail('search-alert', `나이스 안내: ${alertText}`);
      if (res === 'error') fail('search-error', '나이스가 조회 오류를 알렸어요. 나이스 화면의 안내를 확인해 주세요.');
      if (res === 'timeout') fail('search-timeout', '조회가 끝나지 않았어요. 나이스 화면에 안내 창이 떠 있는지 확인해 주세요.');
      const now = {};
      for (const k of Object.keys(values)) now[k] = str(dm.getValue(k));
      return { values: now, rowCount: ds.getRowCount() };
    },

    // 목록 데이터셋에서 한 줄(예: 과목별출결의 '그 날 3교시 1학년 3반 수업')을 골라, 그 줄에 딸린 자료(학생 목록)를 불러온다.
    // 1순위: 그리드 줄을 실제로 누른다(나이스 자기 처리 그대로). 2순위: 화면 처리와 같은 값을 조회 조건에 넣고 통신을 보낸다.
    // copy: { 조회조건칸: '목록칸' | { col: '목록칸', last: 2 } }, verify: 조회조건칸 목록 — 불러온 뒤 고른 줄 값과 같은지 확인
    // 병합된 표(성취수준관리처럼 한 성취기준이 여러 줄): first=true면 맞는 줄 중 첫 줄, rowText면 화면 줄을 순서 대신 글자로 찾는다.
    // rowState=true: 2순위를 '고른 줄만 INSERTED로 표시하고 통신 보내기'(화면 처리 doEvlSearch와 같음)로 한다.
    // emptyRows: 불러온 표가 비면(처음 입력) 화면이 만드는 기본 줄을 똑같이 만든다. verifyTarget: 불러온 줄마다 같아야 할 값.
    // 조회 조건 고르기 칸(udcSwcAuth: 안에 cmbUdcAuth 콤보 + dsAuth 목록) 읽기 — 학기·고사·학년·과목처럼 앞 칸을 바꾸면 뒤 칸 목록이 다시 불러와짐
    udcOptions({ appId, udcs = [] }) {
      const inst = needApp(appId);
      const out = {};
      for (const id of udcs) {
        const emb = inst.lookup(id)?.getEmbeddedAppInstance?.();
        const cmb = emb?.lookup('cmbUdcAuth');
        const ds = emb?.lookup('dsAuth');
        if (!cmb || !ds) { out[id] = null; continue; }
        const items = [];
        for (let r = 0; r < ds.getRowCount(); r++) {
          const cd = str(ds.getValue(r, 'cd')), nm = str(ds.getValue(r, 'nm'));
          if (cd) items.push({ cd, nm });
        }
        out[id] = { value: str(cmb.value), items };
      }
      return { options: out };
    },
    // 성취기준 목록(N3): 문항정보표가 [성취기준] 칸에서 여는 '성취기준자료 가져오기' 창을 화면과 같은 값으로 열어
    // 목록(성취기준 × 성취수준 줄)만 읽고 고르지 않은 채 닫는다 → 문항 값은 그대로(2026-10-29 실제 나이스에서 확인: 70줄 읽고 닫음, 줄 상태 그대로)
    async stdList({ appId, popup, list, rowDataset, columns = [], menuName, examScCd = 'G', title = '', timeout = 10000 }) {
      const inst = needApp(appId);
      const dlg = window.cpr?.core?.Module?.require?.('module/sw/scr')?.Dialog;
      if (!dlg || typeof dlg.open !== 'function') fail('std-no-dialog', '나이스 성취기준 창을 열지 못했어요.');
      const ds = needDataset(inst, rowDataset);
      const first = (c) => (ds.getRowCount() ? ds.getValue(0, c) : '');
      const init = {
        titl: title, dmSearch: inst.lookup('dmSearch')?.getDatas?.() || {},
        relmNoList: first('relmNoList'), sccesCtrCdList: first('sccesCtrCdList'), sccesCtrCnList: first('sccesCtrCnList'),
        evlCriaSccesCtrCdList: first('evlCriaSccesCtrCdList'), quitmNo: first('quitmNo'), examScCd, menuName, readOnlyVal: true,
      };
      const prod = inst.lookup('dmScreProdCtrExmSbjt');
      if (prod?.getDatas) init.dmScreProdCtrSbjt = prod.getDatas();
      const old = new Set(runningApps().filter((i) => appIdOf(i) === popup));
      dlg.open(inst, popup, 1000, 1000, () => {}, init, { headerTitle: title });
      let pop = null, rows = null, seen = -1, still = 0;
      const seenAlerts = new Set(dialogs('app/cmn/alert'));
      try {
        for (const end = Date.now() + timeout; Date.now() < end;) {
          await sleep(250);
          const alertText = takeAlert(seenAlerts);
          if (alertText) fail('std-alert', `나이스 안내: ${alertText}`);
          pop = pop || runningApps().find((i) => appIdOf(i) === popup && !old.has(i));
          const L = pop?.lookup(list);
          if (!L || typeof L.getRowCount !== 'function') continue;
          // 목록 통신이 끝나 줄 수가 두 번 잇달아 같으면 다 온 것(빈 목록이면 2초 더 기다림)
          const n = L.getRowCount();
          still = n === seen ? still + 1 : 0;
          seen = n;
          if ((n > 0 && still >= 2) || (n === 0 && still >= 8)) { rows = readRows(L, columns.length ? columns : columnsOf(L)); break; }
        }
      } finally {
        try { pop?.close?.(); } catch { /* 창이 이미 닫혔으면 그대로 */ }
      }
      if (!rows) fail('std-timeout', '나이스 성취기준 목록을 읽지 못했어요.');
      return { rows };
    },
    // 한 칸 고르기: 교사가 콤보를 고른 것처럼(selectItem + selection-change) → 나이스가 뒤 칸 목록을 다시 불러옴. 고른 뒤 모든 칸을 다시 읽어 돌려줌
    async udcPick({ appId, udc, value, udcs = [], settle = 1500, timeout = 8000, repick = true }) {
      const inst = needApp(appId);
      const emb = inst.lookup(udc)?.getEmbeddedAppInstance?.();
      const cmb = emb?.lookup('cmbUdcAuth');
      const SE = window.cpr?.events?.CSelectionEvent;
      const cmbOf = (u) => inst.lookup(u)?.getEmbeddedAppInstance?.()?.lookup('cmbUdcAuth');
      // 막 연 화면은 뒤 칸 목록이 아직 오는 중일 수 있다 → 다 올 때까지 기다린 뒤 고른다(안 그러면 '과목은(는) 필수 입력입니다' — 2026-11-02 실제)
      // (목록만 미리 읽을 때는 건너뜀: 과목이 없는 학년은 칸이 계속 비어 있어 고를 때마다 3초씩 늘어난다)
      for (const end = Date.now() + 3000; repick && Date.now() < end && udcs.some((u) => { const c = cmbOf(u); return c && !c.getItemCount?.(); }); await sleep(150));
      if (!cmb || typeof cmb.selectItem !== 'function' || !SE) fail('no-pick', '나이스 조회 조건 칸을 찾지 못했어요. 나이스 화면 위쪽에서 직접 골라 주세요.');
      const idx = typeof cmb.getIndexByValue === 'function' ? cmb.getIndexByValue(value) : -1;
      if (idx < 0) fail('no-pick', '그 항목이 나이스 목록에 없어요. 다시 골라 주세요.');
      closeRequiredAlerts();
      const old = str(cmb.value);
      cmb.selectItem(idx);
      cmb.dispatchEvent(new SE('selection-change', { newSelection: [cmb.getItem(idx)], oldSelection: [] }));
      // 뒤 칸 목록이 다시 불러와질 시간
      for (const end = Date.now() + timeout; Date.now() < end && str(cmb.value) !== str(value); await sleep(150));
      await sleep(old === str(value) ? 0 : settle);
      // 앞 칸을 바꾸면 뒤 칸 목록이 새로 오는데, 화면에 첫 값이 보여도 조회 조건에는 안 들어가 '과목은(는) 필수 입력입니다'가 뜬다(2026-11-02 실제, 고사 → 과목)
      // → 뒤 칸을 보이는 값으로 한 번 더 고른다(교사가 그 칸을 다시 고르는 것과 같음)
      // (목록만 미리 읽을 때는 조회가 없으니 건너뜀 — 고사×학년마다 하면 수십 초 걸림, repick: false)
      const at = udcs.indexOf(udc);
      for (const u of at >= 0 && repick ? udcs.slice(at + 1) : []) {
        const c = inst.lookup(u)?.getEmbeddedAppInstance?.()?.lookup('cmbUdcAuth');
        if (!c || typeof c.selectItem !== 'function' || !c.getItemCount?.()) continue;
        let i = c.getIndexByValue?.(c.value) ?? -1;
        if (i < 0) i = 0;
        const item = c.getItem(i);
        c.selectItem(i);
        c.dispatchEvent(new SE('selection-change', { newSelection: [item], oldSelection: [] }));
        await sleep(settle);
      }
      // 뒤 칸이 다시 찰 때까지 잠깐 더(조회가 빈 조건으로 나가지 않게)
      for (const end = Date.now() + 3000; repick && Date.now() < end && (at >= 0 ? udcs.slice(at + 1) : []).some((u) => { const c = cmbOf(u); return c && c.getItemCount?.() && !str(c.value); }); await sleep(150));
      closeRequiredAlerts();
      return OPS.udcOptions({ appId, udcs });
    },

    async pickRow({ appId, grid, dataset, match, target, dataMap, copy = {}, submission, verify = [], first = false, rowText = '', rowState = false, emptyRows = null, verifyTarget = null, timeout = 20000 }) {
      const inst = needApp(appId);
      const ds = needDataset(inst, dataset);
      const tds = needDataset(inst, target);
      const hits = [];
      for (let r = 0; r < ds.getRowCount(); r++) {
        if (Object.entries(match).every(([c, v]) => norm(ds.getValue(r, c)) === norm(v))) hits.push(r);
      }
      if (!hits.length || (hits.length > 1 && !first)) fail('no-row', hits.length ? '같은 줄이 목록에 여러 개 있어요.' : '고를 줄을 나이스 목록에서 찾지 못했어요. 다시 조회해 주세요.');
      const r = hits[0];
      const want = {};
      for (const [to, from] of Object.entries(copy)) {
        const v = str(ds.getValue(r, typeof from === 'string' ? from : from.col));
        want[to] = typeof from === 'string' ? v : v.slice(-from.last);
      }
      const dm = inst.lookup(dataMap);

      const Submission = window.cpr?.protocols?.Submission;
      const subs = typeof inst.getAllDataControls === 'function' && Submission ? inst.getAllDataControls().filter((c) => c instanceof Submission) : [];
      const offs = [];
      const listen = (t, ev, fn) => { if (typeof t?.addEventListener === 'function') { t.addEventListener(ev, fn); offs.push(() => t.removeEventListener(ev, fn)); } };
      const seenAlerts = new Set(dialogs('app/cmn/alert'));
      let alertText = null;
      const outcome = new Promise((resolve) => {
        listen(tds, 'load', () => resolve('loaded'));
        for (const s of subs) {
          listen(s, 'submit-success', () => setTimeout(() => resolve('loaded'), 300));
          listen(s, 'submit-error', () => resolve('error'));
        }
        const t = setTimeout(() => resolve('timeout'), timeout);
        const poll = setInterval(() => { alertText = takeAlert(seenAlerts); if (alertText) resolve('alert'); }, 200);
        offs.push(() => { clearTimeout(t); clearInterval(poll); });
      });

      let how = null;
      // 1) 나이스 표 API로 줄을 고르고 'cell-click'을 보낸다(2026-10-28 실제 확인: 과목별출결 수업 목록은 화면 클릭 흉내로는 학생 목록이 안 열림)
      const gc = inst.lookup(grid);
      const GM = window.cpr?.events?.CGridMouseEvent;
      if (gc && typeof gc.selectRows === 'function' && typeof gc.dispatchEvent === 'function' && GM) {
        try {
          gc.selectRows([r]);
          gc.dispatchEvent(new GM('cell-click', { row: typeof gc.getRow === 'function' ? gc.getRow(r) : undefined }));
          how = 'grid';
        } catch { how = null; }
      }
      // 2) 안 되면(이 화면이 다른 이벤트를 들으면) 화면 클릭 흉내
      const domClick = () => {
        const root = domOf(gc);
        if (!root) return false;
        const rowEls = [...root.querySelectorAll('[role="row"]')].filter((el) => el.querySelector('[role="gridcell"]'));
        const rowEl = rowText ? rowEls.find((el) => [...el.querySelectorAll('[role="gridcell"]')].some((c) => norm(c.textContent).includes(norm(rowText)))) : rowEls[r];
        const cell = rowEl?.querySelector('[role="gridcell"]');
        if (!cell) return false;
        for (const type of ['mousedown', 'mouseup', 'click']) cell.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
        return true;
      };
      let early = null;
      if (how === 'grid') {
        early = await Promise.race([outcome, sleep(5000).then(() => 'slow')]);
        if (early === 'slow') { early = null; if (domClick()) how = 'grid+click'; }
      } else if (domClick()) how = 'click';
      if (!how) {
        const sub = inst.lookup(submission);
        const RS = window.cpr?.data?.tabledata?.RowState;
        if (!sub || typeof sub.send !== 'function') fail('no-pick', '줄을 고르지 못했어요. 나이스에서 그 줄을 직접 눌러 주세요.');
        if (rowState) {
          if (typeof ds.setRowState !== 'function') fail('no-pick', '줄을 고르지 못했어요. 나이스에서 그 줄을 직접 눌러 주세요.');
          for (let i = 0; i < ds.getRowCount(); i++) ds.setRowState(i, RS?.UNCHANGED ?? 'unchanged');
          ds.setRowState(r, RS?.INSERTED ?? 'inserted');
        } else {
          if (!dm || typeof dm.setValue !== 'function') fail('no-pick', '수업을 고르지 못했어요. 나이스에서 그 수업을 직접 눌러 주세요.');
          for (const [k, v] of Object.entries(want)) dm.setValue(k, v);
        }
        sub.send();
        how = 'send';
      }
      const res = early || await outcome;
      offs.forEach((off) => off());
      if (res === 'alert') fail('pick-alert', `나이스 안내: ${alertText}`);
      if (res === 'error') fail('pick-error', '나이스가 목록 조회 오류를 알렸어요.');
      if (res === 'timeout') fail('pick-timeout', '자료를 불러오지 못했어요. 나이스 화면을 확인해 주세요.');
      // 엉뚱한 줄이 눌렸으면 멈춘다(정렬 등으로 화면 줄 순서가 다를 때)
      for (const k of verify) {
        if (dm && norm(dm.getValue(k)) !== norm(want[k])) fail('pick-mismatch', '고른 수업과 나이스가 불러온 수업이 달라요. 나이스에서 직접 확인해 주세요.');
      }
      // 화면이 통신 뒤에 기본 줄을 만드는 경우가 있어 잠깐 기다린다
      if (emptyRows) for (const end = Date.now() + 2500; Date.now() < end && !tds.getRowCount(); await sleep(150));
      let made = 0;
      if (emptyRows && !tds.getRowCount()) {
        for (const row of emptyRows) {
          const i = tds.getRowCount();
          if (typeof tds.insertRow === 'function') tds.insertRow(i); else if (typeof tds.addRow === 'function') tds.addRow(); else fail('no-pick', '빈 줄을 만들지 못했어요. 나이스에서 그 줄을 직접 눌러 주세요.');
          for (const [c, v] of Object.entries(row)) tds.setValue(i, c, v);
          made++;
        }
      }
      if (verifyTarget) {
        for (let i = 0; i < tds.getRowCount(); i++) {
          // 빈 값은 비교하지 않는다(서버가 그 칸을 안 돌려주는 화면이 있을 수 있어서)
          if (Object.entries(verifyTarget).some(([c, v]) => norm(tds.getValue(i, c)) && norm(tds.getValue(i, c)) !== norm(v))) fail('pick-mismatch', '고른 줄과 나이스가 불러온 자료가 달라요. 나이스에서 직접 확인해 주세요.');
        }
      }
      return { how, made, rowCount: tds.getRowCount() };
    },

    async waitSave({ token, timeout = 120000 }) {
      const p = saveWaits.get(token);
      if (!p) return { state: 'unknown' };
      const res = await Promise.race([p, new Promise((r) => setTimeout(() => r({ state: 'timeout' }), timeout))]);
      saveWaits.delete(token);
      return res;
    },

    // 개발용 화면 진단: 칼럼 이름·줄 수·버튼 상태와, 지정한 코드 칼럼의 짧은 값 종류만. 이름·사유 등 값은 담지 않는다.
    // 복무 신청 창 채우기(2026-10-30 교사 결정 — 즐겨찾기 그대로, docs/specs/복무-신청-즐겨찾기.md).
    // 메뉴 화면(appId)의 [신청](open)으로 나이스 안 창(dialog)을 띄우고, 줄마다(첫 줄은 창이 넣어 둔 오늘 줄, 나머지는 [행추가]) 칸을
    // 선생님이 고르듯 넣는다: 입력칸·날짜(value + value-change) · 콤보(selectItem + selection-change) · 체크(checked + value-change).
    // 값이 이미 같으면 건드리지 않음. [승인요청]·[행삭제]·[닫기]는 누르지 않는다. 넣은 뒤 줄 값(read 칼럼)을 다시 읽어 돌려준다.
    // 창이 이미 떠 있으면 선생님이 쓰던 것일 수 있어 멈춘다(덮어쓰지 않게).
    async dutyFill({ appId, open, dialog, dataset, grid = 'grdMain', addRow, rows = [], read = [], timeout = 15000, line = [] }) {
      const main = needApp(appId);
      if (runningApps().some((i) => appIdOf(i) === dialog)) fail('dialog-open', '나이스 신청 창이 이미 열려 있어요. 그 창을 [닫기]로 닫은 뒤 다시 눌러 주세요(쓰던 내용을 덮지 않게).');
      const press = (inst, id, what) => {
        const b = inst.lookup(id);
        if (!b) fail('no-button', `나이스 ${what} 단추를 찾지 못했어요.`);
        const text = controlText(b);
        if (FORBIDDEN_WORDS.some((w) => text.includes(w))) fail('forbidden-button', `"${text}" 단추는 도우미가 누르지 않아요.`);
        if (b.enabled === false) fail('button-disabled', `나이스 ${what} 단추가 꺼져 있어요.`);
        clickControl(b);
      };
      press(main, open, '[신청]');
      let dlg = null;
      for (const end = Date.now() + timeout; !(dlg = runningApps().find((i) => appIdOf(i) === dialog)) && Date.now() < end; await sleep(200));
      if (!dlg) fail('no-dialog', '나이스 신청 창이 열리지 않았어요. 나이스에서 [신청]을 눌러 창이 뜨는지 봐 주세요.');
      const ds = needDataset(dlg, dataset);
      // 창이 오늘 줄·목록(시·분·종류)을 불러올 때까지
      for (const end = Date.now() + 6000; ds.getRowCount() < 1 && Date.now() < end; await sleep(200));
      await sleep(800);
      const VE = window.cpr?.events?.CValueChangeEvent, SE = window.cpr?.events?.CSelectionEvent, GM = window.cpr?.events?.CGridMouseEvent;
      if (!VE || !SE) fail('no-events', '나이스 화면 엔진의 입력 알림을 찾지 못했어요. 창에서 직접 적어 주세요.');
      const g = dlg.lookup(grid);
      const pick = (r) => {
        if (!g || typeof g.selectRows !== 'function') return;
        try { g.selectRows([r]); if (GM) g.dispatchEvent(new GM('cell-click', { row: typeof g.getRow === 'function' ? g.getRow(r) : undefined })); } catch { /* 고른 줄 그대로 */ }
      };
      const put = async (f) => {
        const c = dlg.lookup(f.ctl);
        if (!c) fail('no-field', `나이스 신청 창에서 '${f.label || f.ctl}' 칸을 찾지 못했어요.`);
        const v = str(f.value);
        if (f.type === 'combo') {
          const at = (x) => (typeof c.getIndexByValue === 'function' ? c.getIndexByValue(x) : -1);
          let idx = at(v);
          if (idx < 0 && /^\d$/.test(v)) idx = at(`0${v}`);
          if (idx < 0) fail('no-item', `나이스 '${f.label}' 목록에 '${v}'이(가) 없어요.`);
          const item = c.getItem(idx);
          if (str(c.value) === str(item?.value)) return;
          c.selectItem(idx);
          c.dispatchEvent(new SE('selection-change', { newSelection: [item], oldSelection: [] }));
        } else if (f.type === 'check') {
          const want = v === 'Y';
          const now = typeof c.checked === 'boolean' ? c.checked : str(c.value) === 'Y';
          if (now === want) return;
          const old = c.value;
          if (typeof c.checked === 'boolean') c.checked = want; else c.value = want ? 'Y' : 'N';
          c.dispatchEvent(new VE('value-change', { oldValue: old, newValue: c.value }));
        } else {
          if (str(c.value) === v) return;
          const old = c.value;
          c.value = v;
          c.dispatchEvent(new VE('value-change', { oldValue: old, newValue: v }));
        }
        await sleep(f.wait || 150);
      };
      const out = [];
      for (const [i, row] of rows.entries()) {
        let r = 0;
        if (i > 0 || ds.getRowCount() < 1) {
          const n0 = ds.getRowCount();
          press(dlg, addRow, '[행추가]');
          for (const end = Date.now() + 5000; ds.getRowCount() <= n0 && Date.now() < end; await sleep(150));
          if (ds.getRowCount() <= n0) fail('no-row', '나이스 신청 창에 줄을 더하지 못했어요.');
          r = ds.getRowCount() - 1;
          await sleep(400);
        }
        pick(r);
        await sleep(200);
        for (const f of row.fields || []) await put(f);
        await sleep(300);
        out.push({ date: str(row.date), row: r, values: Object.fromEntries(read.map((c) => [c, str(ds.getValue(r, c))])) });
      }
      if (line.length) armDutyLine(line, str(appIdOf(dlg)));
      return { rows: out, count: ds.getRowCount(), line };
    },

    // [이 창 내용을 즐겨찾기로]: 열려 있는 복무 신청 창에서 고른 줄(없으면 첫 줄)의 칼럼 값(선생님 본인 복무 신청 내용)만 읽는다
    dutyRead({ dialogs = [], dataset = {}, grid = 'grdMain', columns = {} }) {
      const dlg = runningApps().filter((i) => dialogs.includes(appIdOf(i))).pop();
      if (!dlg) fail('no-dialog', '나이스 신청 창이 열려 있지 않아요. 나이스에서 [신청]을 눌러 평소처럼 한 줄 적어 둔 뒤 다시 눌러 주세요.');
      const id = appIdOf(dlg);
      const ds = needDataset(dlg, dataset[id]);
      if (!ds.getRowCount()) fail('no-row', '나이스 신청 창에 줄이 없어요.');
      const g = dlg.lookup(grid);
      let r = 0;
      try { const s = g?.getSelectedRowIndex?.(); if (Number.isInteger(s) && s >= 0 && s < ds.getRowCount()) r = s; } catch { /* 첫 줄 */ }
      return { dialog: id, row: r, values: Object.fromEntries((columns[id] || []).map((c) => [c, str(ds.getValue(r, c))])) };
    },

    diagnose({ appId = null, datasets = [], probeColumns = [], buttons = [], grid = null }) {
      const out = { framework: !!platform(), apps: [...new Set(runningApps().map(appIdOf))], app: null };
      if (!appId || !out.apps.includes(appId)) return out;
      const inst = needApp(appId);
      const app = { id: appId, datasets: {}, buttons: {}, grid: null };
      for (const id of datasets) {
        const ds = inst.lookup(id);
        if (!ds || typeof ds.getRowCount !== 'function') { app.datasets[id] = null; continue; }
        const columns = columnsOf(ds);
        const n = ds.getRowCount();
        const probe = {};
        for (const c of probeColumns.filter((x) => columns.includes(x))) {
          const seen = new Set();
          for (let r = 0; r < n && seen.size < 20; r++) {
            const v = str(ds.getValue(r, c));
            if (v.length <= 4) seen.add(v);
          }
          probe[c] = [...seen];
        }
        app.datasets[id] = { rowCount: n, columns, probe };
      }
      for (const id of buttons) {
        const b = inst.lookup(id);
        app.buttons[id] = b ? {
          text: controlText(b).slice(0, 20),
          enabled: b.enabled !== false,
          hasClick: typeof b.click === 'function',
          inDom: !!domOf(b),
        } : null;
      }
      if (grid) {
        const g = inst.lookup(grid);
        const root = domOf(g);
        app.grid = {
          found: !!g,
          hasRedraw: typeof g?.redraw === 'function',
          inDom: !!root,
          roleRows: root ? root.querySelectorAll('[role="row"]').length : 0,
          roleCells: root ? root.querySelectorAll('[role="gridcell"]').length : 0,
          classRows: root ? root.querySelectorAll('[class*="cl-grid-row"]').length : 0,
        };
      }
      out.app = app;
      return out;
    },
  };

  async function onRequest(e) {
    let msg;
    try { msg = JSON.parse(e.detail); } catch { return; }
    if (!msg || typeof OPS[msg.op] !== 'function') return;
    let res;
    try {
      res = { ok: true, ...(await OPS[msg.op](msg.args || {})) };
    } catch (x) {
      res = x instanceof DoumiError
        ? { ok: false, code: x.code, error: x.message, detail: x.detail }
        : { ok: false, code: 'error', error: '나이스 화면을 다루다가 오류가 났어요.', tech: str(x?.message).slice(0, 200) };
    }
    document.dispatchEvent(new CustomEvent('doumi2:res', { detail: JSON.stringify({ id: msg.id, res }) }));
  }
  document.addEventListener('doumi2:req', onRequest);
  Object.defineProperty(window, '__doumiEngine2', {
    configurable: true,
    value: Object.freeze({ version: VERSION, stop: () => { document.removeEventListener('doumi2:req', onRequest); guideHide(); clearInterval(lineWatch.timer); } }),
  });
  // 나이스 탭을 새로고침했거나 도우미가 바뀌었어도 하던 길잡이를 이어 간다(패널이 닫혀 있어도)
  try {
    const saved = JSON.parse(sessionStorage.getItem(GUIDE_KEY) || 'null');
    if (saved && Array.isArray(saved.steps)) { guide.run = saved; setTimeout(() => { if (guide.run === saved) guideStep(saved.i, true); }, 800); }
  } catch { /* 없으면 그대로 */ }
})();
