// 패널·기능 로직 공용 도구. 브라우저(패널)와 node 테스트 양쪽에서 돈다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;

  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  D.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);

  // 나이스 4세대는 UTF-8 기준으로 바이트를 센다(한글 3바이트).
  D.bytes = (s) => new TextEncoder().encode(String(s ?? '')).length;
  // 생기부 글 바이트(기재요령: 한글 3, 영문·숫자·띄어쓰기 1, 줄바꿈 2 — 2026-10-29, 실제 나이스 셈과 같은지 확인 필요). 양식의 바이트 수식과 같은 셈
  D.neisBytes = (s) => { const t = String(s ?? '').replace(/\r\n?/g, '\n'); return D.bytes(t) + (t.match(/\n/g) || []).length; };
  D.squash = (s) => String(s ?? '').replace(/\s+/g, '');
  D.normNo = (s) => {
    const m = String(s ?? '').match(/\d+/);
    return m ? String(parseInt(m[0], 10)) : '';
  };

  // '2026-10-27', '2026.10.27.', '20261027', '10/27', '10월 27일' → '20261027'
  D.normDate = (s, year) => {
    const g = String(s ?? '').match(/\d+/g);
    if (!g) return '';
    let y, m, d;
    if (g.length === 1 && g[0].length === 8) [y, m, d] = [g[0].slice(0, 4), g[0].slice(4, 6), g[0].slice(6)];
    else if (g.length >= 3) [y, m, d] = g;
    else if (g.length === 2 && year) [y, m, d] = [year, g[0], g[1]];
    else return '';
    if (y.length === 2) y = `20${y}`;
    const mm = parseInt(m, 10), dd = parseInt(d, 10);
    if (y.length !== 4 || !(mm >= 1 && mm <= 12) || !(dd >= 1 && dd <= 31)) return '';
    return `${y}${String(mm).padStart(2, '0')}${String(dd).padStart(2, '0')}`;
  };
  D.isDateToken = (t) => /^(\d{4}[-./]\d{1,2}[-./]\d{1,2}\.?|\d{8}|\d{1,2}[/.]\d{1,2}\.?|\d{1,2}월\d{1,2}일)$/.test(t);
  // 기간: '10/14~16', '10/14~10/16', '2026-10-14~2026-10-16' (토·일은 뺀다)
  D.isDateRangeToken = (t) => {
    const i = t.indexOf('~');
    if (i < 0) return false;
    const a = t.slice(0, i), b = t.slice(i + 1);
    return D.isDateToken(a) && (D.isDateToken(b) || /^\d{1,2}일?$/.test(b));
  };
  D.expandDateRange = (t, year) => {
    const i = t.indexOf('~');
    const from = D.normDate(t.slice(0, i), year);
    const b = t.slice(i + 1);
    const to = /^\d{1,2}일?$/.test(b) ? `${from.slice(0, 6)}${String(parseInt(b, 10)).padStart(2, '0')}` : D.normDate(b, year || from.slice(0, 4));
    if (!from || !/^\d{8}$/.test(to) || to < from) return { dates: [], error: `기간을 알 수 없어요: "${t}"` };
    const toDate = (ymd) => new Date(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6));
    const dates = [];
    for (let d = toDate(from); d <= toDate(to) && dates.length < 62; d.setDate(d.getDate() + 1)) {
      if (d.getDay() === 0 || d.getDay() === 6) continue;
      dates.push(`${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`);
    }
    return { dates, error: dates.length ? '' : `기간 안에 평일이 없어요: "${t}"` };
  };
  D.weekday = (ymd) => (/^\d{8}$/.test(ymd) ? '일월화수목금토'[new Date(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6)).getDay()] : '');
  // 나이스 조회 조건에 날짜를 넣을 때 원래 값과 같은 모양으로 ('20261027' / '2026-10-27' / '2026.10.27')
  D.formatDateLike = (raw, ymd) => {
    const m = /^\d{4}([-./])\d{1,2}\1\d{1,2}/.exec(String(raw ?? '').trim());
    return m ? `${ymd.slice(0, 4)}${m[1]}${ymd.slice(4, 6)}${m[1]}${ymd.slice(6)}` : ymd;
  };
  D.showDate = (ymd) => (/^\d{8}$/.test(ymd) ? `${ymd.slice(0, 4)}.${ymd.slice(4, 6)}.${ymd.slice(6)}` : ymd || '');
  D.showDay = (ymd) => (/^\d{8}$/.test(ymd) ? `${+ymd.slice(4, 6)}월 ${+ymd.slice(6)}일(${D.weekday(ymd)})` : ymd || '');

  // 엑셀에서 저장한 CSV는 대개 EUC-KR(CP949)이다. UTF-8로 먼저 읽어 보고 깨지면 EUC-KR로 읽는다.
  const BOM = String.fromCharCode(0xfeff);
  D.decodeText = (buf) => {
    const u8 = new Uint8Array(buf);
    try {
      const t = new TextDecoder('utf-8', { fatal: true }).decode(u8);
      return t.startsWith(BOM) ? t.slice(1) : t;
    } catch {
      return new TextDecoder('euc-kr').decode(u8);
    }
  };

  // 따옴표를 지키는 한 줄 CSV/TSV 나누기
  D.splitCells = (line, sep) => {
    if (sep !== ',') return line.split(sep).map((c) => c.trim());
    const out = [];
    let cur = '', q = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (q) {
        if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (ch === '"') q = false;
        else cur += ch;
      } else if (ch === '"') q = true;
      else if (ch === ',') { out.push(cur.trim()); cur = ''; }
      else cur += ch;
    }
    out.push(cur.trim());
    return out;
  };

  D.lines = (text) => String(text ?? '').replace(/\r\n?/g, '\n').split('\n')
    .map((raw, i) => ({ raw, no: i + 1 }))
    .filter((l) => l.raw.trim() && !l.raw.trim().startsWith('#'));

  D.debounce = (fn, ms) => {
    let t;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  };
})();
