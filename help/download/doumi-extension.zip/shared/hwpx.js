// 아주 작은 .hwpx(한글 문서) 읽기 — 문서 안의 표를 행 배열로. 표가 없으면 문단을 한 줄씩.
// hwpx = zip + OWPML XML. 본문은 Contents/section0.xml…, 표는 hp:tbl > hp:tr > hp:tc, 글은 hp:t.
// 파일은 이 브라우저 안에서만 읽는다(어디에도 올리지 않음).
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const { entries, text, unescape } = D.zip;

  // <hp:t>…</hp:t> 글 모으기(줄바꿈·탭 태그는 공백으로)
  const textsOf = (xml) => unescape(
    [...xml.matchAll(/<hp:t(?:\s[^>]*)?>([\s\S]*?)<\/hp:t>|<hp:t\s*\/>/g)].map((m) => (m[1] || '').replace(/<hp:(?:lineBreak|tab)[^>]*\/>/g, ' ').replace(/<[^>]+>/g, '')).join(''),
  ).replace(/\s+/g, ' ').trim();

  // 같은 태그가 안에 또 있을 수 있어서(표 안의 표) 짝을 세며 자른다
  function blocks(xml, tag) {
    const out = [];
    const open = new RegExp(`<${tag}[\\s>]`, 'g');
    const close = `</${tag}>`;
    let m;
    while ((m = open.exec(xml))) {
      let depth = 1, i = m.index + 1;
      while (depth > 0) {
        const nextOpen = xml.slice(i).search(new RegExp(`<${tag}[\\s>]`));
        const nextClose = xml.indexOf(close, i);
        if (nextClose < 0) return out;
        if (nextOpen >= 0 && i + nextOpen < nextClose) { depth++; i += nextOpen + 1; } else { depth--; i = nextClose + close.length; }
      }
      out.push(xml.slice(m.index, i));
      open.lastIndex = i;
    }
    return out;
  }

  function tableRows(tbl) {
    return blocks(tbl, 'hp:tr').map((tr) => blocks(tr, 'hp:tc').map((tc) => textsOf(tc)));
  }

  // ArrayBuffer → [[칸, 칸…], …]: 가장 큰 표(행이 2줄 이상). 표가 없으면 문단 한 줄씩 [글]
  // all: true면 모든 표의 줄을 차례로 이어 붙인다(평가기준안처럼 표가 여러 개인 문서)
  D.readHwpx = async (buf, { all = false } = {}) => {
    const files = entries(new Uint8Array(buf));
    const names = [...files.keys()].filter((n) => /^Contents\/section\d+\.xml$/i.test(n)).sort((a, b) => +a.match(/\d+/)[0] - +b.match(/\d+/)[0]);
    if (!names.length) throw new Error('한글(.hwpx) 문서가 아니거나 손상됐어요.');
    let best = [];
    const every = [];
    const paras = [];
    for (const n of names) {
      const xml = await text(files, n);
      for (const t of blocks(xml, 'hp:tbl')) {
        const rows = tableRows(t).filter((r) => r.some((c) => c));
        every.push(...rows);
        if (rows.length >= 2 && rows.length * (rows[0]?.length || 1) > best.length * (best[0]?.length || 1)) best = rows;
      }
      for (const p of blocks(xml.replace(/<hp:tbl[\s\S]*?<\/hp:tbl>/g, ''), 'hp:p')) {
        const t = textsOf(p);
        if (t) paras.push([t]);
      }
    }
    if (all && every.length) return every;
    return best.length ? best : paras;
  };
})();
