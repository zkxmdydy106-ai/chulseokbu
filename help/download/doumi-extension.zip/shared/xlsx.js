// 아주 작은 .xlsx 읽기 — 첫 번째 시트를 표(행 배열)로. 외부 라이브러리 없이 브라우저의 DecompressionStream만 쓴다.
// 파일은 이 브라우저 안에서만 읽는다(어디에도 올리지 않음). 수식은 마지막 계산값, 날짜 서식 칸은 'YYYY-MM-DD'로 돌려준다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;

  // ── zip ───────────────────────────────────────────────
  function zipEntries(u8) {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('엑셀 파일(.xlsx)이 아니거나 손상됐어요.');
    const count = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const out = new Map();
    const dec = new TextDecoder();
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true);
      const size = dv.getUint32(p + 20, true);
      const nameLen = dv.getUint16(p + 28, true);
      const extraLen = dv.getUint16(p + 30, true);
      const commentLen = dv.getUint16(p + 32, true);
      const local = dv.getUint32(p + 42, true);
      const name = dec.decode(u8.subarray(p + 46, p + 46 + nameLen));
      const lNameLen = dv.getUint16(local + 26, true);
      const lExtraLen = dv.getUint16(local + 28, true);
      const start = local + 30 + lNameLen + lExtraLen;
      out.set(name, { method, data: u8.subarray(start, start + size) });
      p += 46 + nameLen + extraLen + commentLen;
    }
    return out;
  }

  async function inflate(entry) {
    if (entry.method === 0) return entry.data;
    if (entry.method !== 8) throw new Error('지원하지 않는 압축 방식이에요.');
    const stream = new Blob([entry.data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  async function text(files, name) {
    const e = files.get(name);
    return e ? new TextDecoder().decode(await inflate(e)) : null;
  }

  // ── xml 조각 ──────────────────────────────────────────
  const unescape = (s) => s
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(+d))
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
  const attr = (tag, name) => { const m = new RegExp(`\\s${name}="([^"]*)"`).exec(tag); return m ? m[1] : null; };
  const texts = (xml) => [...xml.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map((m) => unescape(m[1])).join('');

  function sharedStrings(xml) {
    if (!xml) return [];
    return [...xml.matchAll(/<si>([\s\S]*?)<\/si>/g)].map((m) => texts(m[1]));
  }

  // 날짜 서식인 스타일 번호 모음
  function dateStyles(xml) {
    const out = new Set();
    if (!xml) return out;
    const custom = new Map([...xml.matchAll(/<numFmt\s[^>]*>/g)].map((m) => [attr(m[0], 'numFmtId'), attr(m[0], 'formatCode') || '']));
    const isDateFmt = (id) => {
      const n = +id;
      if ((n >= 14 && n <= 22) || (n >= 45 && n <= 47)) return true;
      const code = (custom.get(id) || '').replace(/\[[^\]]*\]|"[^"]*"/g, '');
      return /[yd]/i.test(code) || /m{1,2}[^a-z]*d/i.test(code);
    };
    const xfs = /<cellXfs[^>]*>([\s\S]*?)<\/cellXfs>/.exec(xml);
    if (!xfs) return out;
    [...xfs[1].matchAll(/<xf\s[^>]*?\/?>/g)].forEach((m, i) => { if (isDateFmt(attr(m[0], 'numFmtId'))) out.add(String(i)); });
    return out;
  }

  const colIndex = (ref) => {
    const letters = /^[A-Z]+/.exec(ref)[0];
    let n = 0;
    for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64);
    return n - 1;
  };
  // 엑셀 날짜 숫자(1900 체계) → YYYY-MM-DD
  const serialDate = (v) => {
    const d = new Date(Math.round((+v - 25569) * 86400000));
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
  };

  function sheetRows(xml, strings, dates) {
    const rows = [];
    for (const rm of xml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>|<row\b[^>]*\/>/g)) {
      const cells = [];
      for (const cm of (rm[1] || '').matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const tag = cm[1], body = cm[2] || '';
        const ref = attr(tag, 'r');
        const t = attr(tag, 't');
        const s = attr(tag, 's');
        const v = /<v>([\s\S]*?)<\/v>/.exec(body);
        let val = '';
        if (t === 's') val = strings[+(v?.[1] ?? -1)] ?? '';
        else if (t === 'inlineStr') val = texts(body);
        else if (t === 'b') val = v?.[1] === '1' ? 'TRUE' : 'FALSE';
        else if (v) val = t !== 'str' && t !== 'e' && dates.has(s) && /^\d+(\.\d+)?$/.test(v[1]) ? serialDate(v[1]) : unescape(v[1]);
        cells[ref ? colIndex(ref) : cells.length] = String(val).trim();
      }
      rows.push(Array.from(cells, (c) => c ?? ''));
    }
    return rows.filter((r) => r.some((c) => c !== ''));
  }

  // ArrayBuffer → [[칸, 칸…], …] (첫 번째 시트)
  D.readXlsx = async (buf) => {
    const files = zipEntries(new Uint8Array(buf));
    const book = await text(files, 'xl/workbook.xml');
    const rels = await text(files, 'xl/_rels/workbook.xml.rels');
    let path = 'xl/worksheets/sheet1.xml';
    const first = book && /<sheet\b[^>]*>/.exec(book);
    const rid = first && attr(first[0], 'r:id');
    if (rid && rels) {
      const rel = [...rels.matchAll(/<Relationship\b[^>]*>/g)].map((m) => m[0]).find((r) => attr(r, 'Id') === rid);
      const target = rel && attr(rel, 'Target');
      if (target) path = target.startsWith('/') ? target.slice(1) : `xl/${target.replace(/^\.\//, '')}`;
    }
    const sheet = await text(files, path);
    if (!sheet) throw new Error('엑셀 파일에서 시트를 찾지 못했어요.');
    return sheetRows(sheet, sharedStrings(await text(files, 'xl/sharedStrings.xml')), dateStyles(await text(files, 'xl/styles.xml')));
  };

  // ArrayBuffer → [{ name, rows }] (모든 시트, 순서대로)
  D.readXlsxSheets = async (buf) => {
    const files = zipEntries(new Uint8Array(buf));
    const book = await text(files, 'xl/workbook.xml');
    const rels = await text(files, 'xl/_rels/workbook.xml.rels');
    const strings = sharedStrings(await text(files, 'xl/sharedStrings.xml'));
    const dates = dateStyles(await text(files, 'xl/styles.xml'));
    const out = [];
    for (const m of (book || '').matchAll(/<sheet\b[^>]*>/g)) {
      const rid = attr(m[0], 'r:id');
      const rel = rels && [...rels.matchAll(/<Relationship\b[^>]*>/g)].map((x) => x[0]).find((r) => attr(r, 'Id') === rid);
      const target = rel && attr(rel, 'Target');
      if (!target) continue;
      const xml = await text(files, target.startsWith('/') ? target.slice(1) : `xl/${target.replace(/^\.\//, '')}`);
      if (xml) out.push({ name: unescape(attr(m[0], 'name') || ''), rows: sheetRows(xml, strings, dates) });
    }
    return out;
  };

  // hwpx(한글 문서)도 zip+XML이라 같은 도구로 읽는다 → shared/hwpx.js
  D.zip = { entries: zipEntries, text, unescape };

  // 표 → 탭으로 나눈 글(출결 자료 해석기가 그대로 읽는다)
  D.rowsToTsv = (rows) => rows.map((r) => r.map((c) => String(c).replace(/[\t\r\n]+/g, ' ')).join('\t')).join('\n');
})();
