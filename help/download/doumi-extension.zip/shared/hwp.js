// 아주 작은 .hwp(한글 2002 이후, HWP 5.0 바이너리) 읽기 — 문서 안의 표를 행 배열로. 표가 없으면 문단을 한 줄씩(.hwpx와 같은 모양).
// hwp = OLE 복합 파일(FileHeader·BodyText/Section0…). 본문은 압축된 레코드 줄이고, 표는 CTRL_HEADER 'tbl ' 아래 칸(LIST_HEADER)마다 문단이 이어진다.
// 파일은 이 브라우저 안에서만 읽는다(어디에도 올리지 않음). 읽기만 하고 고치지 않는다. 암호·배포용 문서는 본문이 잠겨 있어 못 읽는다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const FAIL = (m) => { throw new Error(`${m} 한글에서 "다른 이름으로 저장 → .hwpx"로 저장해 넣어 주세요.`); };

  // ── OLE 복합 파일 ─────────────────────────────────────
  function openCfb(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const sig = [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1];
    if (bytes.length < 512 || sig.some((b, i) => bytes[i] !== b)) FAIL('한글(.hwp) 문서가 아니거나 손상됐어요.');
    const secSize = 1 << view.getUint16(30, true);
    const miniSize = 1 << view.getUint16(32, true);
    const fatCount = view.getUint32(44, true);
    const dirStart = view.getUint32(48, true);
    const miniCut = view.getUint32(56, true);
    const miniFatStart = view.getUint32(60, true);
    const difatStart = view.getUint32(68, true);
    const offset = (s) => 512 + (secSize === 4096 ? 3584 : 0) + s * secSize - (secSize === 4096 ? 3584 : 0);
    const END = 0xfffffffe;
    const FREE = 0xffffffff;
    // 큰 표(FAT): 머리의 109칸 + 이어지는 DIFAT 구역
    const fatSecs = [];
    for (let i = 0; i < 109 && fatSecs.length < fatCount; i++) {
      const s = view.getUint32(76 + i * 4, true);
      if (s !== FREE) fatSecs.push(s);
    }
    for (let d = difatStart, guard = 0; d < END && fatSecs.length < fatCount && guard < 4096; guard++) {
      const base = offset(d);
      const per = secSize / 4 - 1;
      for (let i = 0; i < per && fatSecs.length < fatCount; i++) {
        const s = view.getUint32(base + i * 4, true);
        if (s !== FREE) fatSecs.push(s);
      }
      d = view.getUint32(base + per * 4, true);
    }
    const fat = new Uint32Array((fatSecs.length * secSize) / 4);
    fatSecs.forEach((s, n) => {
      const base = offset(s);
      for (let i = 0; i < secSize / 4; i++) fat[n * (secSize / 4) + i] = view.getUint32(base + i * 4, true);
    });
    const chain = (start, table) => {
      const out = [];
      const seen = new Set();
      for (let s = start; s < END && s < table.length && !seen.has(s); s = table[s]) { seen.add(s); out.push(s); }
      return out;
    };
    const readBig = (start, size) => {
      const secs = chain(start, fat);
      const out = new Uint8Array(secs.length * secSize);
      secs.forEach((s, i) => out.set(bytes.subarray(offset(s), offset(s) + secSize), i * secSize));
      return size == null ? out : out.subarray(0, size);
    };
    // 디렉터리
    const dirBytes = readBig(dirStart);
    const dirView = new DataView(dirBytes.buffer, dirBytes.byteOffset, dirBytes.byteLength);
    const dec = new TextDecoder('utf-16le');
    const entries = [];
    for (let p = 0; p + 128 <= dirBytes.length; p += 128) {
      const len = dirView.getUint16(p + 64, true);
      if (len < 2) { entries.push(null); continue; }
      entries.push({
        name: dec.decode(dirBytes.subarray(p, p + len - 2)),
        type: dirBytes[p + 66],
        left: dirView.getUint32(p + 68, true),
        right: dirView.getUint32(p + 72, true),
        child: dirView.getUint32(p + 76, true),
        start: dirView.getUint32(p + 116, true),
        size: dirView.getUint32(p + 120, true),
      });
    }
    const root = entries[0];
    if (!root) FAIL('한글(.hwp) 문서가 아니거나 손상됐어요.');
    // 작은 조각 표(miniFAT)
    const miniFatBytes = miniFatStart < END ? readBig(miniFatStart) : new Uint8Array(0);
    const miniFatView = new DataView(miniFatBytes.buffer, miniFatBytes.byteOffset, miniFatBytes.byteLength);
    const miniFat = new Uint32Array(miniFatBytes.length / 4);
    for (let i = 0; i < miniFat.length; i++) miniFat[i] = miniFatView.getUint32(i * 4, true);
    const miniStream = root.start < END ? readBig(root.start, root.size) : new Uint8Array(0);
    const readStream = (e) => {
      if (e.size >= miniCut) return readBig(e.start, e.size);
      const secs = chain(e.start, miniFat);
      const out = new Uint8Array(secs.length * miniSize);
      secs.forEach((s, i) => out.set(miniStream.subarray(s * miniSize, (s + 1) * miniSize), i * miniSize));
      return out.subarray(0, e.size);
    };
    // 한 폴더의 자식들(이름 나무를 돎)
    const childrenOf = (e) => {
      const out = [];
      const seen = new Set();
      const walk = (i) => {
        if (i === FREE || seen.has(i) || !entries[i]) return;
        seen.add(i);
        walk(entries[i].left);
        out.push(entries[i]);
        walk(entries[i].right);
      };
      walk(e.child);
      return out;
    };
    return { root, childrenOf, readStream };
  }

  // 압축 풀기(deflate). 한글 파일은 압축 뒤에 여분 바이트가 붙기도 하는데, 브라우저의 DecompressionStream은 그걸 오류로 내고
  // 마지막 조각까지 버린다(2026-11-02 실제 크롬에서 'Failed to fetch', Node에서는 통과). 그래서 끝 표시에서 멈추는 작은 풀기를 직접 쓴다
  const LEN_BASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
  const LEN_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
  const DIST_BASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  const DIST_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
  const ORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
  function inflate(src) {
    let pos = 0, buf = 0, cnt = 0, n = 0;
    let out = new Uint8Array(Math.max(src.length * 4, 65536));
    const room = (k) => { if (n + k > out.length) { const b = new Uint8Array(Math.max(out.length * 2, n + k)); b.set(out.subarray(0, n)); out = b; } };
    const bits = (w) => {
      while (cnt < w) { if (pos >= src.length) FAIL('이 한글 문서의 압축을 풀지 못했어요.'); buf |= src[pos++] << cnt; cnt += 8; }
      const v = buf & ((1 << w) - 1);
      buf >>>= w; cnt -= w;
      return v;
    };
    const table = (lens) => {
      const count = new Uint16Array(16), offs = new Uint16Array(16), symbol = new Uint16Array(lens.length);
      for (const l of lens) count[l]++;
      count[0] = 0;
      for (let i = 1; i < 15; i++) offs[i + 1] = offs[i] + count[i];
      lens.forEach((l, s) => { if (l) symbol[offs[l]++] = s; });
      return { count, symbol };
    };
    const decode = (h) => {
      let code = 0, first = 0, index = 0;
      for (let len = 1; len <= 15; len++) {
        code |= bits(1);
        const c = h.count[len];
        if (code - c < first) return h.symbol[index + (code - first)];
        index += c; first += c; first <<= 1; code <<= 1;
      }
      return FAIL('이 한글 문서의 압축을 풀지 못했어요.');
    };
    let fixed = null;
    for (let last = 0; !last;) {
      last = bits(1);
      const type = bits(2);
      if (type === 0) {
        buf = 0; cnt = 0;
        const len = src[pos] | (src[pos + 1] << 8);
        pos += 4;
        room(len);
        out.set(src.subarray(pos, pos + len), n);
        n += len; pos += len;
        continue;
      }
      if (type === 3) FAIL('이 한글 문서의 압축을 풀지 못했어요.');
      let lit, dist;
      if (type === 1) {
        if (!fixed) {
          const l = new Array(288);
          for (let i = 0; i < 288; i++) l[i] = i < 144 ? 8 : i < 256 ? 9 : i < 280 ? 7 : 8;
          fixed = { lit: table(l), dist: table(new Array(30).fill(5)) };
        }
        ({ lit, dist } = fixed);
      } else {
        const nlen = bits(5) + 257, ndist = bits(5) + 1, ncode = bits(4) + 4;
        const cl = new Array(19).fill(0);
        for (let i = 0; i < ncode; i++) cl[ORDER[i]] = bits(3);
        const ch = table(cl);
        const lens = [];
        while (lens.length < nlen + ndist) {
          const s = decode(ch);
          if (s < 16) { lens.push(s); continue; }
          const prev = s === 16 ? lens[lens.length - 1] : 0;
          for (let k = s === 16 ? 3 + bits(2) : s === 17 ? 3 + bits(3) : 11 + bits(7); k > 0; k--) lens.push(prev);
        }
        lit = table(lens.slice(0, nlen));
        dist = table(lens.slice(nlen, nlen + ndist));
      }
      for (;;) {
        const s = decode(lit);
        if (s === 256) break;
        if (s < 256) { room(1); out[n++] = s; continue; }
        const len = LEN_BASE[s - 257] + bits(LEN_EXTRA[s - 257]);
        const d = decode(dist);
        const back = DIST_BASE[d] + bits(DIST_EXTRA[d]);
        room(len);
        for (let k = 0; k < len; k++, n++) out[n] = out[n - back];
      }
    }
    return out.subarray(0, n);
  }

  // ── 본문 레코드 ───────────────────────────────────────
  const PARA_HEADER = 66, PARA_TEXT = 67, CTRL_HEADER = 71, LIST_HEADER = 72;
  const TBL = 0x74626c20; // 'tbl '
  // 글자 안 제어 문자: 8칸을 차지하는 것(인라인·확장) / 1칸인 것(줄바꿈 등)
  const WIDE = new Set([1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]);
  function textOf(view, start, size) {
    let out = '';
    const end = start + (size & ~1);
    for (let p = start; p < end;) {
      const c = view.getUint16(p, true);
      if (c < 32) {
        if (c === 9 || c === 10 || c === 24 || c === 30 || c === 31) out += ' ';
        p += WIDE.has(c) ? 16 : 2;
        continue;
      }
      out += String.fromCharCode(c);
      p += 2;
    }
    return out;
  }
  function recordsOf(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const out = [];
    for (let p = 0; p + 4 <= bytes.length;) {
      const h = view.getUint32(p, true);
      p += 4;
      let size = h >>> 20;
      if (size === 0xfff) { if (p + 4 > bytes.length) break; size = view.getUint32(p, true); p += 4; }
      if (p + size > bytes.length) break;
      out.push({ tag: h & 0x3ff, level: (h >>> 10) & 0x3ff, start: p, size });
      p += size;
    }
    return { view, records: out };
  }

  // 레코드 줄 → 위에서 차례로 [{ table: 줄들 } | { text }]. 표 안 표의 글은 바깥 칸 글에 이어 붙인다(.hwpx 읽기와 같음)
  function parseSection(bytes) {
    const { view, records } = recordsOf(bytes);
    let i = 0;
    const clean = (t) => t.replace(/\s+/g, ' ').trim();
    // level 이상인 문단들을 읽어 글·표로. stop: level보다 얕아지면 끝
    function readParas(level, stopAtList) {
      const blocks = [];
      while (i < records.length) {
        const r = records[i];
        if (r.level < level) break;
        if (stopAtList && r.tag === LIST_HEADER && r.level === level) break;
        if (r.tag !== PARA_HEADER || r.level !== level) { i++; continue; }
        i++;
        let text = '';
        while (i < records.length && records[i].level > level) {
          const c = records[i];
          if (c.tag === PARA_TEXT && c.level === level + 1) { text += textOf(view, c.start, c.size); i++; continue; }
          if (c.tag === CTRL_HEADER && c.level === level + 1 && c.size >= 4 && view.getUint32(c.start, true) === TBL) {
            i++;
            blocks.push({ table: readTable(level + 2) });
            continue;
          }
          i++;
        }
        if (clean(text)) blocks.push({ text: clean(text) });
      }
      return blocks;
    }
    function readTable(level) {
      const cells = new Map();
      while (i < records.length && records[i].level >= level) {
        const r = records[i];
        if (r.tag !== LIST_HEADER || r.level !== level) { i++; continue; }
        // 칸 머리: 문단 수(4) · 속성(4) · 열 주소(2) · 행 주소(2) · 열 병합(2) · 행 병합(2) …
        const col = r.size >= 12 ? view.getUint16(r.start + 8, true) : 0;
        const row = r.size >= 12 ? view.getUint16(r.start + 10, true) : 0;
        i++;
        const inner = readParas(level, true);
        const txt = inner.map((b) => (b.table ? b.table.map((x) => x.join(' ')).join(' ') : b.text)).join(' ');
        if (!cells.has(row)) cells.set(row, []);
        cells.get(row).push([col, clean(txt)]);
      }
      return [...cells.keys()].sort((a, b) => a - b).map((k) => cells.get(k).sort((a, b) => a[0] - b[0]).map((x) => x[1]));
    }
    return readParas(0, false);
  }

  // ArrayBuffer → [[칸, 칸…], …]: D.readHwpx와 같은 약속. all: true면 모든 표의 줄을 차례로
  D.readHwp = async (buf, { all = false } = {}) => {
    const cfb = openCfb(new Uint8Array(buf));
    const top = cfb.childrenOf(cfb.root);
    const header = top.find((e) => e.name === 'FileHeader');
    if (!header) FAIL('한글(.hwp) 문서가 아니거나 손상됐어요.');
    const hd = cfb.readStream(header);
    const hv = new DataView(hd.buffer, hd.byteOffset, hd.byteLength);
    if (new TextDecoder('ascii').decode(hd.subarray(0, 17)) !== 'HWP Document File') FAIL('아주 옛날 한글 형식(.hwp 3.0 이하)은 못 읽어요.');
    const flags = hv.getUint32(36, true);
    if (flags & 2) FAIL('암호가 걸린 한글 문서는 못 읽어요.');
    if (flags & 4) FAIL('배포용 한글 문서는 못 읽어요.');
    const body = top.find((e) => e.name === 'BodyText');
    if (!body) FAIL('이 한글 문서에서 본문을 찾지 못했어요.');
    const secs = cfb.childrenOf(body).filter((e) => /^Section\d+$/.test(e.name)).sort((a, b) => +a.name.slice(7) - +b.name.slice(7));
    let best = [];
    const every = [];
    const paras = [];
    for (const s of secs) {
      const raw = cfb.readStream(s);
      const data = flags & 1 ? inflate(raw) : raw;
      for (const b of parseSection(data)) {
        if (b.text) { paras.push([b.text]); continue; }
        const rows = b.table.filter((r) => r.some((c) => c));
        every.push(...rows);
        if (rows.length >= 2 && rows.length * (rows[0]?.length || 1) > best.length * (best[0]?.length || 1)) best = rows;
      }
    }
    if (all && every.length) return every;
    return best.length ? best : paras;
  };
})();
