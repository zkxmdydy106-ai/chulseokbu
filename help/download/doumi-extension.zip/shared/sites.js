// 나이스·K-에듀파인 주소 — 전국 17개 시도(2026-10-28 교사 결정: 다른 학교·다른 시도에서도 쓰게)
// 4세대 나이스는 시도마다 <코드>.neis.go.kr, K-에듀파인은 klef.<코드>.go.kr. 충남(cne) 말고는 실제 확인 전(미확인).
// manifest.json의 host_permissions·content_scripts 목록과 같아야 한다(tests/run-tests.js가 확인).
(() => {
  const CODES = ['sen', 'pen', 'dge', 'ice', 'gen', 'dje', 'use', 'sje', 'goe', 'gwe', 'cbe', 'cne', 'jbe', 'jne', 'gbe', 'gne', 'jje'];
  const neis = CODES.map((c) => `https://${c}.neis.go.kr/`);
  const edufine = CODES.map((c) => `https://klef.${c}.go.kr/`);
  const starts = (list) => (url) => !!url && list.some((h) => String(url).startsWith(h));
  const sites = {
    CODES,
    neisMatches: neis.map((h) => `${h}*`),
    edufineMatches: edufine.map((h) => `${h}*`),
    isNeis: starts(neis),
    isEdufine: starts(edufine),
  };
  globalThis.DoumiSites = sites;
  if (globalThis.Doumi) globalThis.Doumi.sites = sites;
})();
