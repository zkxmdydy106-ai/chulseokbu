// 에듀파인 결재대기 목록 읽기·한 건 열기. 화면 설정은 screens/edufine-inbox.js, 판단은 features/edufine-inbox.js.
// 누르는 것: ① 넥사크로 메뉴의 '결재대기'(화면이 안 열렸을 때) ② 목록 [조회] ③ 교사가 [열기]를 누른 줄의 제목 링크 하나.
// 결재·일괄결재·상신은 찾지도 누르지도 않는다. 누르기 전에 페이지에서 후보를 받아 패널이 검사한 뒤 그것만 누른다.
// 읽은 목록은 이 패널 메모리에만 있다(저장소에 쓰지 않음).
(() => {
  const D = globalThis.Doumi;
  const L = D.edufineInboxLogic;
  const cfg = D.edufineScreens.inbox;
  const MATCHES = D.edufine.MATCHES;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ── 페이지 안에서 도는 함수들(따로 직렬화되므로 바깥 변수를 쓰지 않는다) ──
  function pageWhere(listPath, tableSel) {
    return { path: location.pathname, top: window === window.top, list: location.pathname === listPath && !!document.querySelector(tableSel), ready: document.readyState };
  }

  function pageRead(c) {
    const t = document.querySelector(c.table);
    if (!t) return { error: 'no-table' };
    const text = (e) => String((e && (e.innerText || e.textContent)) || '').replace(/\s+/g, ' ').trim().slice(0, 300);
    const fnOf = (s) => (/^\s*(?:javascript:)?\s*([\w$.]+)\s*\(/.exec(s || '') || [])[1] || '';
    let heads = [...t.querySelectorAll('thead th')].map(text);
    const body = t.tBodies[0];
    if (!heads.length && body?.rows[0]?.querySelector('th')) heads = [...body.rows[0].cells].map(text);
    const rows = [...(body?.rows || [])].filter((tr) => !tr.querySelector('th')).map((tr) => {
      const di = tr.querySelector(c.docinfo);
      const link = [...tr.querySelectorAll('[onclick], a[href^="javascript"]')].find((e) => fnOf(e.getAttribute('onclick') || e.getAttribute('href')) === c.openFn);
      let docId = String(di?.value || '').split(',')[0].trim();
      if (!docId && link) docId = (/\(\s*[^,]*,\s*['"]([^'"]+)/.exec(link.getAttribute('onclick') || link.getAttribute('href')) || [])[1] || '';
      const marks = [...tr.querySelectorAll('img, [title], [alt]')].map((e) => `${e.getAttribute('alt') || ''} ${e.getAttribute('title') || ''}`).join(' ');
      const urgent = /긴급/.test(text(tr)) || /긴급/.test(marks) || /urgent|emerg/i.test(tr.className);
      return { cells: [...tr.cells].map(text), docId, link: !!link, urgent };
    });
    const tot = /총\s*([\d,]+)\s*건/.exec(document.body ? document.body.innerText : '');
    return { heads, rows, total: tot ? Number(tot[1].replace(/,/g, '')) : null };
  }

  // [조회] 후보: 글자가 '조회'인 누를 수 있는 것. pick이 있으면 그 순번을 누르고, 바뀌었는지 볼 표시를 남긴다
  function pageSearch(c, pick) {
    const fnOf = (s) => (/^\s*(?:javascript:)?\s*([\w$.]+)\s*\(/.exec(s || '') || [])[1] || '';
    const seen = new Set();
    const list = [];
    for (const e of document.querySelectorAll('a, button, input[type=button], input[type=submit], span')) {
      const label = String(e.innerText || e.value || '').replace(/\s+/g, '').trim();
      if (label !== c.searchLabel) continue;
      const el = e.closest('a, button, input') || e;
      if (seen.has(el) || !(el.offsetWidth || el.offsetHeight)) continue;
      seen.add(el);
      list.push({ el, label, fn: fnOf(el.getAttribute('onclick') || el.getAttribute('href') || e.getAttribute('onclick')) });
    }
    if (pick == null) return list.map(({ label, fn }) => ({ label, fn }));
    const hit = list[pick];
    if (!hit) return { clicked: false };
    const t = document.querySelector(c.table);
    window.__doumiInboxMark = { table: t, row0: t?.tBodies[0]?.rows[0] || null };
    hit.el.click();
    return { clicked: true };
  }

  function pageChanged(c) {
    const m = window.__doumiInboxMark;
    const t = document.querySelector(c.table);
    if (document.readyState !== 'complete' || !t) return false;
    if (!m) return true; // 프레임이 새로 열림
    return t !== m.table || (t.tBodies[0]?.rows[0] || null) !== m.row0;
  }

  // 넥사크로 첫 화면의 공지사항 창(mainframe…MainFrame.noticePopup0, 2026-10-29 실제)이 보이는지
  function pageNotice() {
    return [...document.querySelectorAll('[id*="noticePopup"]')].some((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
  }

  // 넥사크로 메뉴: 정해 둔 글자와 똑같은 보이는 글자를 찾아(pick 없으면 목록만) 마우스 누름을 흉내 낸다
  // 같은 글자가 위쪽 알림 줄(divNtzn — '결재(긴급) 0(0)')에도 있어 그것을 먼저 눌렀었다(2026-10-29 실제) → 알림 줄은 빼고 왼쪽 메뉴 트리(dMenu) 먼저
  function pageMenu(texts, pick) {
    const out = [];
    const walk = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    for (let n = walk.nextNode(); n; n = walk.nextNode()) {
      const s = n.nodeValue.replace(/\s+/g, '');
      const base = s.replace(/\(\d+\)$|\d+$/, '');
      if (!texts.includes(base)) continue;
      const el = n.parentElement;
      const r = el?.getBoundingClientRect();
      if (!r || !r.width || !r.height) continue;
      const id = el.id || el.closest('[id]')?.id || '';
      if (/divNtzn/.test(id)) continue;
      out.push({ el, text: s, x: r.left + r.width / 2, y: r.top + r.height / 2, tree: /dMenu|treeitem/i.test(id) });
    }
    out.sort((a, b) => b.tree - a.tree);
    if (pick == null) return out.map(({ text }) => text);
    const hit = out[pick];
    if (!hit) return { clicked: false };
    const o = { bubbles: true, cancelable: true, view: window, clientX: hit.x, clientY: hit.y, button: 0 };
    hit.el.dispatchEvent(new PointerEvent('pointerdown', o));
    hit.el.dispatchEvent(new MouseEvent('mousedown', o));
    hit.el.dispatchEvent(new PointerEvent('pointerup', o));
    hit.el.dispatchEvent(new MouseEvent('mouseup', o));
    hit.el.dispatchEvent(new MouseEvent('click', o));
    return { clicked: true };
  }

  // 그 문서 줄의 제목 링크: pick=false면 함수 이름만, true면 누름. mark=true면 줄을 노랗게 표시만
  function pageOpen(c, docId, pick, mark) {
    const fnOf = (s) => (/^\s*(?:javascript:)?\s*([\w$.]+)\s*\(/.exec(s || '') || [])[1] || '';
    const t = document.querySelector(c.table);
    const tr = [...(t?.tBodies[0]?.rows || [])].find((r) => {
      const di = r.querySelector(c.docinfo);
      return String(di?.value || '').split(',')[0].trim() === docId || [...r.querySelectorAll('[onclick], a[href^="javascript"]')].some((e) => (e.getAttribute('onclick') || e.getAttribute('href') || '').includes(`'${docId}'`));
    });
    if (!tr) return { gone: true };
    const link = [...tr.querySelectorAll('[onclick], a[href^="javascript"]')].find((e) => fnOf(e.getAttribute('onclick') || e.getAttribute('href')) === c.openFn);
    if (!link) return { gone: true };
    if (mark) {
      tr.style.outline = '3px solid #e0b400';
      tr.style.background = '#fff4c2';
      tr.scrollIntoView({ block: 'center' });
      return { marked: true };
    }
    if (!pick) return { fn: link.getAttribute('onclick') || link.getAttribute('href') };
    link.scrollIntoView({ block: 'center' });
    link.click();
    return { clicked: true };
  }

  // 위쪽 알림 줄 건수(넥사크로 본창): '결재(긴급) 1(0)|' → { n: 1, urgent: 0 }
  function pageCounts(c) {
    const out = {};
    for (const [k, id] of Object.entries(c.items)) {
      const e = document.getElementById(`${c.prefix}${id}:text`);
      const g = String(e?.textContent || '').match(/\d+/g);
      if (g) out[k] = { n: +g[0], ...(g.length > 1 ? { urgent: +g[1] } : {}) };
    }
    return out;
  }

  // 넥사크로 메뉴를 메뉴 ID로 열기(왼쪽 프레임의 화면 함수 — 메뉴를 누른 것과 같음)
  function pageOpenMenuId(menuId, fn) {
    try {
      const form = nexacro.getApplication().mainframe.MainVFrameSet.SubHFrameSet.LeftFrame.form;
      if (typeof form[fn] !== 'function') return { ok: false };
      form[fn](menuId);
      return { ok: true };
    } catch { return { ok: false }; }
  }

  // 문서등록대장: 칸을 비우고 채운 뒤 페이지 검색 함수(폼 제출 → 페이지가 다시 그려짐)
  function pageRegistSearch(c, plan) {
    const f = document.forms[0];
    if (!f || typeof window[c.searchFn] !== 'function') return { ok: false };
    for (const n of c.clear) if (f.elements[n]) f.elements[n].value = '';
    const set = (k, v) => { const e = f.elements[c.fields[k]]; if (e && v != null) e.value = v; };
    set('docNo', plan.docNo);
    set('orignlDocNo', plan.orignlDocNo);
    set('from', plan.from); set('to', plan.to);
    set('basicFrom', plan.basicFrom); set('basicTo', plan.basicTo);
    window.__doumiRegistAt = Date.now();
    setTimeout(() => window[c.searchFn](), 0); // 기간 알림이 뜨더라도 이 함수가 기다리지 않게
    return { ok: true };
  }
  function pageRegistState(c) {
    const t = document.querySelector(c.table);
    const tot = /총\s*([\d,]+)\s*건/.exec(document.body ? document.body.innerText : '');
    return { fresh: !window.__doumiRegistAt, ready: document.readyState === 'complete' && !!t, total: tot ? Number(tot[1].replace(/,/g, '')) : null };
  }

  // ── 패널 쪽 ──
  const run = async (target, func, args = []) => {
    const res = await chrome.scripting.executeScript({ target, world: 'MAIN', func, args });
    return res[0]?.result;
  };

  async function eduTabs() {
    const tabs = await chrome.tabs.query({ url: MATCHES });
    const out = [];
    for (const t of tabs) {
      let type = 'normal';
      try { type = (await chrome.windows.get(t.windowId)).type; } catch { /* 닫히는 중 */ }
      out.push({ ...t, popup: type === 'popup' });
    }
    // 본창(새 창 아님), 그중 지금 보는 탭 먼저
    return out.sort((a, b) => (a.popup - b.popup) || (b.active - a.active));
  }

  // 결재대기 목록 프레임 찾기
  async function findList() {
    for (const t of await eduTabs()) {
      if (t.popup) continue;
      let res = [];
      try { res = await chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, world: 'MAIN', func: pageWhere, args: [cfg.listPath, cfg.table] }); } catch { continue; }
      const f = res.find((r) => r.result?.list);
      if (f) return { tabId: t.id, frameId: f.frameId };
    }
    return null;
  }

  async function waitList(timeout) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const at = await findList();
      if (at) return at;
      await sleep(400);
    }
    return null;
  }

  // 넥사크로 메뉴로 결재대기 열기: '결재대기'가 보이면 그것만, 안 보이면 업무관리 → 결재 → 결재대기 차례로
  async function openMenu(tabId) {
    const target = { tabId, frameIds: [0] };
    const clickText = async (text) => {
      const found = (await run(target, pageMenu, [[text], null])) || [];
      const i = found.findIndex((s) => L.safe.menu(s, cfg) && s.replace(/\(\d+\)$|\d+$/, '') === text);
      if (i < 0) return false;
      return !!(await run(target, pageMenu, [[text], i]))?.clicked;
    };
    const last = cfg.menuPath[cfg.menuPath.length - 1];
    if (await clickText(last)) return waitList(8000);
    for (const step of cfg.menuPath) {
      await clickText(step);
      await sleep(700);
      const at = await findList();
      if (at) return at;
    }
    return waitList(6000);
  }

  async function pressSearch(at) {
    const target = { tabId: at.tabId, frameIds: [at.frameId] };
    const cands = (await run(target, pageSearch, [cfg, null])) || [];
    const i = cands.findIndex((x) => L.safe.search(x.label, x.fn, cfg));
    if (i < 0) return at;
    if (!(await run(target, pageSearch, [cfg, i]))?.clicked) return at;
    const end = Date.now() + 8000;
    await sleep(300);
    while (Date.now() < end) {
      const now = await findList();
      if (now) {
        let changed = false;
        try { changed = await run({ tabId: now.tabId, frameIds: [now.frameId] }, pageChanged, [cfg]); } catch { /* 새로 여는 중 */ }
        if (changed) return now;
      }
      await sleep(300);
    }
    return (await findList()) || at;
  }

  D.edufineInbox = {
    last: null, // '오늘' 칸에 보일 건수·읽은 시각(제목 등은 담지 않음)
    at: null,

    // 결재함 읽기. search=true면 에듀파인 [조회]를 눌러 새로 받은 뒤 읽는다
    async load({ search = true, step = () => {} } = {}) {
      const tabs = await eduTabs();
      if (!tabs.length) return { ok: false, error: '열린 에듀파인 창이 없어요. 에듀파인에 로그인한 뒤 다시 눌러 주세요.' };
      const main = tabs.find((t) => !t.popup);
      if (!main) return { ok: false, error: '에듀파인 본창을 찾지 못했어요. 에듀파인 첫 화면 탭을 연 뒤 다시 눌러 주세요.' };
      let at = await findList();
      let opened = false;
      if (!at) {
        // 로그인 직후 뜨는 공지사항 창은 메뉴를 가린다(2026-10-29 실제). 공지 창은 교사가 닫는다(도우미가 누를 수 있는 것은 메뉴·[조회]·제목 링크뿐)
        let notice = false;
        try { notice = !!(await run({ tabId: main.id, frameIds: [0] }, pageNotice, [])); } catch { /* 못 보면 그냥 메뉴로 */ }
        if (notice) return { ok: false, error: '에듀파인 공지사항 창이 떠 있어요. 공지 창을 닫은 뒤 [다시 읽기]를 눌러 주세요.' };
        step('결재대기 화면 여는 중');
        try { at = await openMenu(main.id); } catch { at = null; }
        if (!at) return { ok: false, needMenu: true, error: '에듀파인 결재대기 화면을 열지 못했어요.' };
        opened = true;
      } else if (search) {
        step('에듀파인 [조회]로 새로 받는 중');
        try { at = await pressSearch(at); } catch { /* 조회 실패 → 지금 목록이라도 읽음 */ }
      }
      step('목록 읽는 중');
      let raw;
      try { raw = await run({ tabId: at.tabId, frameIds: [at.frameId] }, pageRead, [cfg]); } catch { raw = null; }
      if (!raw || raw.error) return { ok: false, error: '에듀파인 화면을 읽지 못했어요. 에듀파인 탭을 새로고침한 뒤 다시 눌러 주세요.' };
      const r = L.toCards(raw, cfg);
      if (!r.ok) return { ok: false, error: '결재대기 표 모양이 예상과 달라요(제목 칸을 못 찾음). 설정 → 개발자 모드 → [에듀파인 화면 구조 기록] 파일을 알려 주세요.' };
      this.at = at;
      this.last = { count: r.total, urgent: r.cards.filter((c) => c.urgent).length, time: Date.now() };
      return { ...r, ok: true, opened };
    },

    // 한 건 열기: 그 줄의 제목 링크만 누르고, 새 에듀파인 브라우저 창이 뜨는지 본다.
    // 엣지에서는 문서가 브라우저 창이 아니라 WXSClient(wxsclient:// 별도 프로그램)로 열려 도우미가 볼 수 없다 →
    // 브라우저 창이 안 뜨면 에듀파인 탭을 앞으로(프로그램 열기 확인 창이 거기 뜸) + 그 줄을 노랗게 표시(직접 누를 수 있게)
    async open(docId) {
      const at = (await findList()) || this.at;
      if (!at) return { ok: false, error: '결재대기 화면이 닫혔어요. [새로 읽기]를 눌러 주세요.' };
      const target = { tabId: at.tabId, frameIds: [at.frameId] };
      const look = await run(target, pageOpen, [cfg, docId, false, false]);
      if (!look || look.gone) return { ok: false, gone: true, error: '이 문서는 목록에 없어요(이미 처리됐을 수 있어요). [새로 읽기]를 눌러 주세요.' };
      if (!L.safe.open(look.fn, cfg)) return { ok: false, error: '이 줄의 제목 링크가 예상과 달라 누르지 않았어요. 에듀파인에서 직접 눌러 주세요.' };
      const before = new Set((await chrome.tabs.query({ url: MATCHES })).map((t) => t.id));
      const r = await run(target, pageOpen, [cfg, docId, true, false]);
      if (!r?.clicked) return { ok: false, error: '제목 링크를 누르지 못했어요. 에듀파인에서 직접 눌러 주세요.' };
      const end = Date.now() + 3000;
      while (Date.now() < end) {
        await sleep(300);
        const fresh = (await chrome.tabs.query({ url: MATCHES })).find((t) => !before.has(t.id));
        if (fresh) {
          try { await chrome.windows.update(fresh.windowId, { focused: true }); } catch { /* 이미 앞 */ }
          return { ok: true, opened: true };
        }
      }
      try { await run(target, pageOpen, [cfg, docId, false, true]); } catch { /* 표시 못 함 */ }
      try { await chrome.tabs.update(at.tabId, { active: true }); } catch { /* 탭 닫힘 */ }
      return { ok: true, opened: false };
    },

    // 위쪽 알림 줄 건수(결재·공람·문서진행). 숫자만, 에듀파인 본창이 없으면 null
    async counts() {
      const main = (await eduTabs()).find((t) => !t.popup);
      if (!main) return null;
      try {
        const r = await run({ tabId: main.id, frameIds: [0] }, pageCounts, [D.edufineScreens.counts]);
        return r && Object.keys(r).length ? { ...r, time: Date.now() } : null;
      } catch { return null; }
    },

    // 관련 공문 찾기: 문서등록대장을 열고(없으면 메뉴) 번호를 넣어 에듀파인 검색까지 → 에듀파인 탭을 앞으로. 결과 문서는 교사가 연다
    async findRelated(plan) {
      const rc = D.edufineScreens.docRegist;
      const main = (await eduTabs()).find((t) => !t.popup);
      if (!main) return { ok: false, error: '에듀파인 본창을 찾지 못했어요. 에듀파인 첫 화면 탭을 연 뒤 다시 눌러 주세요.' };
      const findRegist = async () => {
        let res = [];
        try { res = await chrome.scripting.executeScript({ target: { tabId: main.id, allFrames: true }, world: 'MAIN', func: pageWhere, args: [rc.path, rc.table] }); } catch { return null; }
        const f = res.find((x) => x.result?.list);
        return f ? { tabId: main.id, frameId: f.frameId } : null;
      };
      let at = await findRegist();
      if (!at) {
        const r = await run({ tabId: main.id, frameIds: [0] }, pageOpenMenuId, [rc.menuId, rc.menuFn]);
        if (!r?.ok) return { ok: false, error: '문서등록대장 메뉴를 열지 못했어요. 에듀파인에서 업무관리 → 문서관리 → 문서함 → 문서등록대장을 열어 주세요.' };
        const end = Date.now() + 10000;
        while (!at && Date.now() < end) { await sleep(500); at = await findRegist(); }
        if (!at) return { ok: false, error: '문서등록대장 화면이 열리지 않았어요. 잠시 뒤 다시 눌러 주세요.' };
      }
      const ok = await run({ tabId: at.tabId, frameIds: [at.frameId] }, pageRegistSearch, [rc, plan]);
      if (!ok?.ok) return { ok: false, error: '문서등록대장 검색 칸을 찾지 못했어요. 에듀파인 화면이 바뀌었을 수 있어요.' };
      try { await chrome.tabs.update(main.id, { active: true }); await chrome.windows.update(main.windowId, { focused: true }); } catch { /* 이미 앞 */ }
      // 검색하면 목록 프레임이 새로 그려진다 → 새 페이지(표시 없음)에서 '총 N건'을 읽는다
      const end = Date.now() + 15000;
      await sleep(800);
      while (Date.now() < end) {
        const now = await findRegist();
        if (now) {
          let st = null;
          try { st = await run({ tabId: now.tabId, frameIds: [now.frameId] }, pageRegistState, [rc]); } catch { /* 다시 그리는 중 */ }
          if (st?.fresh && st.ready) return { ok: true, total: st.total };
        }
        await sleep(500);
      }
      return { ok: true, total: null };
    },

    clear() { this.last = null; this.at = null; },
  };
})();
