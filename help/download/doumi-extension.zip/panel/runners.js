// 파일 하나를 나이스에 넣는 두 가지 흐름(일일출결·과목별출결).
// 둘 다 같은 모양: check(글) → 묶음별 확인 결과, apply(확인 결과) → 묶음별 저장. 나이스 화면 열기·조회·수업 고르기는 도우미가 한다.
(() => {
  const D = globalThis.Doumi;
  const A = D.attendance, S = D.subject;
  const pause = () => new Promise((r) => setTimeout(r, 600)); // 나이스에 연달아 보내지 않도록
  const today = () => { const d = new Date(); return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`; };
  const call = (op, args, tabId, timeout = 30000) => D.neis.call(op, args, { tabId, timeout });

  // 화면이 안 열려 있으면 메뉴로 연다(값은 바꾸지 않음)
  async function openScreen(screen, tabId, step) {
    const w = await openScreenWhy(screen, tabId, step);
    return w ? w.error : null;
  }
  // 못 열면 { error, otp, apps } — otp: 생기부 메뉴에서 OTP(2차 인증) 창이 떴거나 화면이 시간 안에 안 뜸
  // resume: OTP 인증을 마친 뒤 [이어서] — 메뉴를 다시 누르기 전에 화면이 저절로 뜨는지 먼저 기다린다
  async function openScreenWhy(screen, tabId, step, { resume = false } = {}) {
    const det = await call('detect', {}, tabId, 5000);
    if (!det.ok) return { error: det.error, otp: !!screen.otp && det.code === 'no-response' };
    if (!det.framework || det.apps.includes('app/com/inc/login')) return { error: '나이스에 로그인해 주세요.' };
    // 교과 세특은 화면이 OTP(2차 인증) 창 뒤에 함께 뜬다(2026-10-29) → 화면이 있어도 OTP 창이 떠 있으면 인증부터
    if (screen.otp && det.otp?.length) return { error: 'OTP 인증 창이 아직 열려 있어요. 나이스에서 인증을 마쳐 주세요.', otp: true, apps: det.otp };
    if (det.apps.includes(screen.appId)) return null;
    step(resume ? `${screen.title} 화면이 열렸는지 확인 중` : `나이스에서 ${screen.title} 화면 여는 중`);
    const o = await D.neis.open(screen, tabId, { waitFirst: resume ? 6000 : 0 });
    if (o.ok) return null;
    const otp = !!screen.otp && ['otp', 'menu-timeout', 'no-response'].includes(o.code);
    return { error: o.error, otp, apps: o.detail?.apps || [], alert: o.detail?.alert || '' };
  }

  const searchArgs = (screen, rawLike, ymd, dataset) => ({
    appId: screen.appId, dataMap: screen.search.dataMap, values: { [screen.search.date]: D.formatDateLike(rawLike, ymd) },
    button: screen.search.button, dataset: dataset || screen.dataset,
  });

  // 확인 결과 묶음들에서 합계와 시험 단계 검사
  // { '묶음 열쇠|번호': 'neis' } 중 이 묶음 것만 { 번호: 'neis' }로
  const choicesOf = (choices, key) => Object.fromEntries(Object.entries(choices || {}).filter(([k]) => k.startsWith(`${key}|`)).map(([k, v]) => [k.slice(String(key).length + 1), v]));
  function dailyResult(g, screen) {
    g.result = A.compare({ parsed: g.parsed, rows: g.rows, screen, context: g.ctx, codes: g.codes, verified: true, choices: g.choices });
    if (!g.rows.length) g.result.issues = ['이 날은 나이스 표가 비어 있어요. 휴업일인지 확인해 주세요.'];
    if (g.missing?.length) g.result.issues.push(`나이스 화면 구조가 달라졌어요(없는 칸: ${g.missing.join(', ')}).`);
  }

  // perGroup: 파일 한 줄이 묶음마다 1건씩 되는 화면(수행평가: 학생 1명 = 영역 수만큼). 묶음마다 1건까지를 '1건 시험'으로 친다 — 안 그러면 영역이 2개인 과목은 1건 시험을 영영 못 넘어감(2026-11-02 실제 기하)
  function finish(groups, verified, issues, { perGroup = false } = {}) {
    const change = groups.reduce((n, g) => n + (g.result?.summary.change || 0), 0);
    const one = perGroup ? Math.max(1, groups.filter((g) => g.result?.summary.change).length) : 1;
    // 화면마다 처음 한 번만: 1건 넣고 나이스에서 맞는지 본 뒤 전체(교사 질문 2026-10-29 — 패널이 1건만 골라 넣고 [나머지 넣기]로 이어 감, 파일을 따로 만들 필요 없음)
    const needTrial = !verified && change > one;
    if (needTrial) issues.push(`이 화면은 처음이라 1건 먼저 넣어 나이스에서 맞는지 본 뒤 나머지 ${change - one}건을 넣어요(처음 한 번만).`);
    const blocked = groups.some((g) => g.error || (g.result && (g.result.issues.length || g.result.summary.error)));
    return { groups, issues, change, needTrial, canApply: !issues.length && !blocked && change > 0 };
  }

  // ── 일일출결 ───────────────────────────────────────────
  const daily = {
    id: 'daily',
    screenId: 'neis.dailyAttendance',
    label: '일일출결',
    sub: '하루치·한 달치 한 번에',
    template: '일일출결_양식.xlsx',
    fill: '번호 · 이름 · 날짜 · 구분 · 사유',
    // choices: { '날짜|번호': 'neis' } — 나이스 구분과 자료 구분이 다른 줄 중 '나이스 그대로'로 고른 줄(교사 결정 2026-10-30)
    async check(text, { tabId, step, verified, choices = {} }) {
      const screen = D.screens.get(this.screenId);
      const err = await openScreen(screen, tabId, step);
      if (err) return { fatal: err };
      const first = await call('read', A.readArgs(screen), tabId);
      if (!first.ok) return { fatal: first.error };
      const ctx0 = A.contextOf(screen, first.dm);
      const { codes } = A.codeTable(screen, first.extra);
      const parsed = A.parseInput(text, codes, { year: (ctx0.date || today()).slice(0, 4) });
      const issues = [...parsed.issues];
      const groups = [];
      const parts = A.splitByDate(parsed, ctx0.date || today());
      for (const [i, part] of parts.entries()) {
        if (i) await pause();
        step(`${D.showDay(part.date)} 확인 중 (${i + 1}/${parts.length})`);
        const g = { key: part.date, date: part.date, title: D.showDay(part.date), parsed: part.parsed, codes };
        const s = await call('search', A.searchArgs(screen, ctx0, part.date), tabId);
        if (!s.ok) { g.error = s.error; groups.push(g); continue; }
        const r = await call('read', A.readArgs(screen), tabId);
        if (!r.ok) { g.error = r.error; groups.push(g); continue; }
        // 나이스 표는 그룹에 둔다(패널 메모리) — [폰 값으로]·[나이스 그대로]를 고를 때 나이스에 다시 묻지 않고 바로 다시 계산
        Object.assign(g, { rows: r.rows, ctx: A.contextOf(screen, r.dm), missing: r.missingColumns, choices: choicesOf(choices, g.key) });
        dailyResult(g, screen);
        groups.push(g);
      }
      if (ctx0.date && parts.some((p) => p.date !== ctx0.date)) {
        // 원래 날짜로 돌리다 나이스가 막으면(예: CM000 자료권한) 그 글을 그대로 보여 준다 — 전에는 버려져 '휴업일' 안내만 남았음
        const back = await call('search', A.searchArgs(screen, ctx0, ctx0.date), tabId);
        if (!back.ok) issues.push(`나이스 화면을 처음 날짜(${D.showDay(ctx0.date)})로 돌리지 못했어요. ${back.error}`);
      }
      return { ...finish(groups, verified, [...issues]), baseIssues: issues, screen, ctx: ctx0, verified };
    },
    // 고른 것만 바꿔 다시 계산(나이스에 묻지 않음)
    recompute(checked, choices) {
      for (const g of checked.groups) if (g.result && g.rows) { g.choices = choicesOf(choices, g.key); dailyResult(g, checked.screen); }
      return { ...checked, ...finish(checked.groups, checked.verified, [...(checked.baseIssues || [])]) };
    },
    async apply(checked, { tabId, step }) {
      const screen = checked.screen;
      const todo = checked.groups.filter((g) => g.result?.summary.change);
      const saved = [];
      let stop = '';
      for (const [i, g] of todo.entries()) {
        if (i) await pause();
        step(`${g.title} 넣는 중 (${i + 1}/${todo.length})`);
        const s = await call('search', A.searchArgs(screen, checked.ctx, g.date), tabId);
        if (!s.ok) { stop = `${g.title}: ${s.error}`; break; }
        const r = await call('read', A.readArgs(screen), tabId);
        if (!r.ok) { stop = `${g.title}: ${r.error}`; break; }
        const fresh = A.compare({ parsed: g.parsed, rows: r.rows, screen, context: A.contextOf(screen, r.dm), codes: g.codes, verified: true, choices: g.choices || {} });
        const out = await saveOne(screen, fresh, g.result, tabId);
        if (out.error) { stop = `${g.title}: ${out.error}`; break; }
        saved.push({ title: g.title, count: out.count, date: g.date });
      }
      if (checked.ctx.date) await call('search', A.searchArgs(screen, checked.ctx, checked.ctx.date), tabId);
      return { saved, stop, total: todo.length };
    },
  };

  // ── 과목별출결 ─────────────────────────────────────────
  const subject = {
    id: 'subject',
    screenId: 'neis.subjectAttendance',
    label: '과목별출결',
    async check(text, { tabId, step, verified, choices = {} }) {
      const screen = D.screens.get(this.screenId);
      const err = await openScreen(screen, tabId, step);
      if (err) return { fatal: err };
      const first = await call('read', S.readPeriodsArgs(screen), tabId);
      if (!first.ok) return { fatal: first.error };
      const rawDate = first.dm[screen.search.dataMap]?.[screen.search.date] || today();
      const parsed = S.parse(text, { year: D.normDate(rawDate).slice(0, 4) || today().slice(0, 4) });
      const issues = [...parsed.issues];
      const groups = [];
      const parts = S.split(parsed, D.normDate(rawDate) || today());
      for (const [i, part] of parts.entries()) {
        if (i) await pause();
        step(`${S.groupTitle(part)} 확인 중 (${i + 1}/${parts.length})`);
        const g = { key: part.key, date: part.date, title: S.groupTitle(part), part };
        const found = await this.load(screen, rawDate, part, tabId);
        if (found.error) { g.error = found.error; groups.push(g); continue; }
        Object.assign(g, { rows: found.rows, choices: choicesOf(choices, g.key) });
        g.result = S.compare({ group: part, rows: found.rows, screen, verified: true, choices: g.choices });
        groups.push(g);
      }
      return { ...finish(groups, verified, [...issues]), baseIssues: issues, screen, rawDate, verified };
    },
    recompute(checked, choices) {
      for (const g of checked.groups) {
        if (!g.result || !g.rows) continue;
        g.choices = choicesOf(choices, g.key);
        g.result = S.compare({ group: g.part, rows: g.rows, screen: checked.screen, verified: true, choices: g.choices });
      }
      return { ...checked, ...finish(checked.groups, checked.verified, [...(checked.baseIssues || [])]) };
    },
    // 그 날 조회 → 수업 줄 찾기 → 학생 목록
    async load(screen, rawDate, part, tabId) {
      const s = await call('search', searchArgs(screen, rawDate, part.date, screen.periods.dataset), tabId);
      if (!s.ok) return { error: s.error };
      const list = await call('read', S.readPeriodsArgs(screen), tabId);
      if (!list.ok) return { error: list.error };
      if (!list.rows.length) return { error: '이 날은 수업 목록이 비어 있어요. 휴업일인지 확인해 주세요.' };
      const f = S.findPeriod(part, list.rows, screen);
      if (f.error) return { error: f.error };
      const p = await call('pickRow', S.pickArgs(screen, f.row), tabId);
      if (!p.ok) return { error: p.error };
      const st = await call('read', S.readStudentsArgs(screen), tabId);
      return st.ok ? { rows: st.rows } : { error: st.error };
    },
    async apply(checked, { tabId, step }) {
      const screen = checked.screen;
      const todo = checked.groups.filter((g) => g.result?.summary.change);
      const saved = [];
      let stop = '';
      for (const [i, g] of todo.entries()) {
        if (i) await pause();
        step(`${g.title} 넣는 중 (${i + 1}/${todo.length})`);
        const found = await this.load(screen, checked.rawDate, g.part, tabId);
        if (found.error) { stop = `${g.title}: ${found.error}`; break; }
        const fresh = S.compare({ group: g.part, rows: found.rows, screen, verified: true, choices: g.choices || {} });
        const out = await saveOne(screen, fresh, g.result, tabId);
        if (out.error) { stop = `${g.title}: ${out.error}`; break; }
        saved.push({ title: g.title, count: out.count, date: g.date });
      }
      return { saved, stop, total: todo.length };
    },
  };

  // 다시 읽어 비교한 결과가 확인 때와 같을 때만 넣고 저장한다
  async function saveOne(screen, fresh, checkedResult, tabId, attach = null) {
    if (!fresh.canApply || fresh.summary.change !== checkedResult.summary.change) return { error: '확인한 뒤에 나이스 값이 바뀌었어요. 다시 확인해 주세요.' };
    const { accept: _a, ...at } = screen.attach || {};
    const withFile = fresh.plan.attach && attach ? { attach: { ...at, file: { name: attach.name, type: attach.type, b64: attach.b64 } } } : {};
    const a = await call('apply', { ...fresh.plan, ...withFile, save: screen.save }, tabId, attach ? 90000 : 20000);
    if (!a.ok) return { error: a.error };
    const w = await call('waitSave', { token: a.saveToken, timeout: 120000 }, tabId, 125000);
    if (!w.ok || w.state !== 'success') return { error: w.message ? `나이스 안내: ${w.message}` : '저장 완료 신호를 받지 못했어요. 나이스 화면에서 확인해 주세요.' };
    return { count: a.applied };
  }

  // ── 화면 하나에 한 번 조회해서 넣는 일(생기부 글·교과 세특·성취기준·문항정보표) ──
  // F: { readArgs(screen), compare(text, read, screen, opts) } — 조회 조건은 나이스 화면에 이미 고른 그대로
  const oneScreen = (screenId, F, extra = {}) => ({
    id: screenId,
    screenId,
    get label() { return D.screens.get(screenId).short; },
    ...extra,
    async load(text, screen0, tabId, opts) {
      let screen = screen0;
      // 개정마다 탭·칸이 다른 화면(개인별 세특): 나이스 조회 조건 값(chasuFlag)으로 고른 뒤 그 탭으로 조회
      if (screen.variant && F.resolve) {
        const v = await call('read', D.record.variantArgs(screen), tabId);
        if (!v.ok) return { error: v.error };
        screen = F.resolve(screen, v.dm?.[screen.variant.dataMap]?.[screen.variant.column]);
      }
      const s = await call('search', { appId: screen.appId, dataMap: 'dmSearch', values: {}, button: screen.search.button, dataset: screen.dataset, tab: screen.tab || null }, tabId);
      if (!s.ok) return { error: s.error };
      const r = await call('read', F.readArgs(screen), tabId);
      if (!r.ok) return { error: r.error };
      if (F.more) await F.more(screen, tabId, opts);
      const result = F.compare(text, r, screen, opts);
      if (r.missingColumns?.length) result.issues.push(`나이스 화면 구조가 달라졌어요(없는 칸: ${r.missingColumns.join(', ')}).`);
      return { result, screen };
    },
    // [OTP 인증](생기부): 파일 없이 메뉴만 연다 → 나이스가 OTP 창을 띄움. 조회·입력은 하지 않음
    async openOnly({ tabId, step, resume = false }) {
      const screen = D.screens.get(screenId);
      const why = await openScreenWhy(screen, tabId, step, { resume });
      return why ? { fatal: why.error, otp: why.otp, otpApps: why.apps, otpAlert: why.alert } : { opened: true };
    },
    async check(text, { tabId, step, verified, attach = null, resume = false, trialFrom = '' }) {
      const screen = D.screens.get(screenId);
      const why = await openScreenWhy(screen, tabId, step, { resume });
      if (why) return { fatal: why.error, otp: why.otp, otpApps: why.apps, otpAlert: why.alert };
      step('나이스에서 조회 중');
      const opts = { ...(await options()), attach: attach && screen.attach ? { name: attach.name, size: attach.size } : null, trialFrom };
      const got = await this.load(text, screen, tabId, opts);
      // 조회가 막힌 까닭이 OTP 창일 때만 OTP 안내로(나이스 '필수 입력' 알림까지 OTP 화면으로 보이던 것 — 2026-10-29)
      if (got.error) {
        const det = screen.otp ? await call('detect', {}, tabId, 5000) : null;
        return det?.otp?.length ? { fatal: got.error, otp: true, otpApps: det.otp } : { fatal: got.error };
      }
      const g = { key: screenId, date: '', title: screen.title, text, opts, result: got.result, attach: opts.attach ? attach : null };
      return { ...finish([g], verified, []), screen: got.screen || screen };
    },
    async apply(checked, { tabId, step }) {
      const screen = checked.screen;
      const g = checked.groups[0];
      step(`${screen.title} 넣는 중`);
      const got = await this.load(g.text, D.screens.get(screenId), tabId, g.opts);
      if (got.error) return { saved: [], stop: got.error, total: 1 };
      if (g.attach) step('채점기준표 파일 붙이는 중');
      const out = await saveOne(got.screen || screen, got.result, g.result, tabId, g.attach);
      return out.error ? { saved: [], stop: out.error, total: 1 } : { saved: [{ title: screen.title, count: out.count }], stop: '', total: 1 };
    },
  });
  // 패널 설정 중 입력에 쓰는 것(학생 자료 없음)
  async function options() {
    const s = D.store ? await D.store.settings() : {};
    return { levelRule: s.levelRule || null };
  }

  const R = D.record;
  const RECORD = {
    readArgs: R.readArgs,
    resolve: R.resolve,
    compare: (text, r, screen) => R.compare({ parsed: R.parse(text), rows: r.rows, screen, dm: r.dm }),
  };
  const recordExtra = { cols: ['번호', '성명'], hint: '칸 예시: 번호 · 이름 · 내용. 바이트 한도와 기재요령(사교육·수상·부모 직업 등), 학생 사이 겹치는 문장도 살펴 드려요.' };
  // 빈 양식(extension/templates, tools/make-templates.py로 만듦). fill: 양식에서 채울 칸(패널 '1 → 2 → 3' 안내)
  const RECORD_TEMPLATES = {
    'neis.record.jayul': ['자율활동_양식.xlsx', '번호 · 이름 · 자율활동'],
    'neis.record.jinro': ['진로활동_양식.xlsx', '번호 · 이름 · 진로활동 · 희망분야'],
    'neis.record.haengteuk': ['행동특성_양식.xlsx', '번호 · 이름 · 행동특성 및 종합의견'],
    // 2026-10-30 더함(교사 결정 2026-10-28 '넷 다')
    'neis.record.personal': ['개인별세특_양식.xlsx', '번호 · 이름 · 개인별 세부능력 및 특기사항'],
    'neis.record.reading': ['독서활동_양식.xlsx', '번호 · 이름 · 도서명 · 저자(책 한 권에 한 줄)'],
    'neis.record.club': ['동아리활동_양식.xlsx', '학번 · 이름 · 동아리활동 특기사항'],
  };
  const RECORD_HINTS = {
    'neis.record.jinro': '칸 예시: 번호 · 이름 · 진로활동 · 희망분야. 희망분야만 적어도 돼요(150바이트, 특기사항과 합쳐 한도). 바이트 한도와 기재요령도 살펴 드려요.',
    'neis.record.personal': '칸 예시: 번호 · 이름 · 개인별 세특. 나이스가 정한 탭(2015 개정 1번 · 2022 개정 4번 보통교과및전문교과)에 넣고, 세 탭 글자 합 한도로 검사해요.',
    'neis.record.reading': '칸 예시: 번호 · 이름 · 도서명 · 저자 — 책 한 권에 한 줄. 학생마다 \'도서명(저자), …\'로 모아 반별 화면에 넣어요. 학기는 나이스 화면에 고른 그대로예요.',
    'neis.record.club': '칸 예시: 학번(또는 학년·반·번호) · 이름 · 동아리활동. 나이스 [동아리활동관리]에서 부서를 먼저 골라 두세요. 자율동아리·청소년단체 학생은 넣지 않아요.',
  };
  const records = Object.entries(RECORD_TEMPLATES).map(([id, [template, fill]]) => oneScreen(id, RECORD, { ...recordExtra, template, fill, ...(RECORD_HINTS[id] ? { hint: RECORD_HINTS[id] } : {}) }));
  const setuk = oneScreen('neis.record.setuk', RECORD, { ...recordExtra, cols: ['번호', '성명'], template: '교과세특_양식.xlsx', fill: '반 · 번호 · 이름 · 세부능력 및 특기사항', hint:'칸 예시: 학번(또는 반·번호) · 이름 · 세특. 나이스 화면에 과목·반을 먼저 골라 두세요. 바이트 한도·기재요령·겹치는 문장을 살펴 드려요.' });

  const AS = D.assess;
  const standard = oneScreen('neis.assess.standard', {
    readArgs: AS.standard.readArgs,
    compare: (text, r, screen) => AS.standard.compare({ parsed: AS.standard.parse(text), rows: r.rows, areas: r.extra?.[screen.areas.dataset] || [], screen }),
  }, {
    cols: ['코드', '영역'], allTables: true, plain: true,
    hint: '평가계획 한글 파일(.hwp·.hwpx)이나 엑셀을 그대로 넣어도 돼요. [12기하-01-01] 같은 코드가 든 줄을 찾아 내용·영역을 넣고, 나이스에 없는 코드는 새 줄로 넣어요. 나이스 화면에 학년도·학기·과목을 먼저 골라 두세요.',
  });
  const items = oneScreen('neis.assess.items', {
    readArgs: AS.items.readArgs,
    compare: (text, r, screen, opts) => AS.items.compare({
      parsed: AS.items.parse(text, { rule: opts?.levelRule, mixFrom: opts?.trialFrom }), obt: r.rows, sbjct: r.extra?.[screen.types.J.dataset] || [],
      totals: r.extra?.[screen.totals.dataset] || [], dm: r.dm?.dmSearch || {}, screen,
      attach: opts?.attach || null, atch: (screen.attach && r.dm?.[screen.attach.dataMap]) || {}, std: opts?.std || null,
    }),
    // 성취기준 목록(N3): 확인할 때 한 번 읽어 두고 저장 때 그대로 씀(나이스 창이 또 뜨지 않게)
    async more(screen, tabId, opts) {
      if (!screen.std || !opts || opts.std) return;
      const s = await call('stdList', AS.items.stdArgs(screen), tabId, 20000);
      opts.std = s.ok ? { rows: s.rows } : { error: s.error || '나이스 성취기준 목록을 읽지 못했어요.' };
    },
  }, {
    cols: ['문항', '평가요소'], plain: true,
    template: '문항정보표_양식.xlsx',
    fill: '배점 · 정답 · 평가요소',
    // 학기·고사·학년·과목 고르기(교사 요청 2026-10-28): 나이스 화면 위쪽 조회 조건 칸을 그대로 읽고 고른다
    async loadPicks(tabId, step = () => {}) {
      const screen = D.screens.get('neis.assess.items');
      const err = await openScreen(screen, tabId, step);
      if (err) return { error: err };
      // 화면이 막 열리면 조건 칸 목록을 아직 불러오는 중이라 비어 보인다(교사 제보 '(없음)'으로 다 나옴) → 학기·고사·학년 목록이 찰 때까지 10초까지 기다림
      let r = null;
      for (const end = Date.now() + 10000; ;) {
        r = await call('udcOptions', { appId: screen.appId, udcs: screen.picks.map((p) => p.udc) }, tabId, 10000);
        if (!r.ok) return { error: r.error };
        const ready = screen.picks.filter((p) => p.key !== 'subject').every((p) => r.options[p.udc]?.items.length);
        if (ready || Date.now() > end) break;
        await new Promise((ok) => setTimeout(ok, 700));
      }
      // 고사×학년마다 과목 목록을 미리 읽어 둠 → 패널에서 학년·고사를 바꿔도 나이스는 그대로(교사 결정 2026-10-28). 다 읽고 원래 조건으로 되돌림
      const U = Object.fromEntries(screen.picks.map((p) => [p.key, p.udc]));
      const start = Object.fromEntries(screen.picks.map((p) => [p.key, r.options[p.udc]?.value || '']));
      const tree = {};
      const udcs = screen.picks.map((p) => p.udc);
      const pickNow = async (key, value, repick = false) => { const x = await call('udcPick', { appId: screen.appId, udc: U[key], value, udcs, repick }, tabId, 20000); if (x.ok) r = x; return x.ok; };
      for (const ex of (r.options[U.exam]?.items || []).slice()) {
        tree[ex.cd] = {};
        if (r.options[U.exam].value !== ex.cd && !(await pickNow('exam', ex.cd))) continue;
        for (const gr of (r.options[U.grade]?.items || []).slice()) {
          if (r.options[U.grade].value !== gr.cd && !(await pickNow('grade', gr.cd))) continue;
          tree[ex.cd][gr.cd] = (r.options[U.subject]?.items || []).slice();
        }
      }
      // 원래 조건으로 되돌림(고사 → 학년 → 과목)
      for (const key of ['exam', 'grade', 'subject']) if (start[key] && r.options[U[key]]?.value !== start[key]) await pickNow(key, start[key], true);
      return { picks: screen.picks, options: r.options, start, tree };
    },
    // [나이스에서 확인하기] 때: 고른 값을 앞 칸부터 차례로 나이스에 넣음(바뀐 칸만)
    async applyPicks(tabId, want) {
      const screen = D.screens.get('neis.assess.items');
      const udcs = screen.picks.map((p) => p.udc);
      let r = await call('udcOptions', { appId: screen.appId, udcs }, tabId, 10000);
      if (!r.ok) return { error: r.error };
      for (const p of screen.picks) {
        const v = want[p.key];
        const o = r.options[p.udc];
        if (!v || !o || o.value === v) continue;
        if (!o.items.some((it) => it.cd === v)) return { error: `나이스 ${p.label} 목록에 고른 값이 없어요. 패널에서 다시 골라 주세요.` };
        r = await call('udcPick', { appId: screen.appId, udc: p.udc, value: v, udcs }, tabId, 20000);
        if (!r.ok) return { error: r.error };
      }
      return { ok: true };
    },
    async setPick(tabId, key, value) {
      const screen = D.screens.get('neis.assess.items');
      const p = screen.picks.find((x) => x.key === key);
      const r = await call('udcPick', { appId: screen.appId, udc: p.udc, value, udcs: screen.picks.map((x) => x.udc) }, tabId, 20000);
      return r.ok ? { picks: screen.picks, options: r.options } : { error: r.error };
    },
    hint: '양식은 배점 · 정답 · 평가요소만 쓰면 돼요(유형은 정답으로, 난이도는 문항 수로 상 3 : 보통 5 : 쉬움 2 자동, 아래 기준 점수를 적으면 그 기준대로). 배점 합계가 나이스 만점과 맞는지, 역배점이 없는지 확인해요. 나이스 화면에 고사·과목을 먼저 골라 두세요.',
  });

  const areas = oneScreen('neis.assess.areas', {
    readArgs: AS.areas.readArgs,
    compare: (text, r, screen) => AS.areas.compare({ parsed: AS.areas.parse(text), rows: r.rows, screen }),
  }, {
    cols: ['번호', '영역'], allTables: true, plain: true,
    hint: "평가계획 한글 파일(.hwp·.hwpx)이나 엑셀을 그대로 넣어도 돼요. '평가 영역 · 만점 · 반영비율' 표를 찾아 같은 이름은 고치고 없는 영역은 새 줄로 넣어요. 지필(고사) 비율까지 있으면 합계가 100%인지 확인해요.",
  });

  // ── 성취수준(평가기준): 한 번 조회해 모두 비교 → 성취기준마다 [왼쪽 줄 고르기 → 오른쪽 상·중·하 글 넣기 → 저장] ──
  // 나이스 저장(btn1)이 고른 성취기준 하나씩만 저장하므로 성취기준마다 차례로 저장한다. 1건 = 성취기준 하나.
  const LV = AS.levels;
  const levels = {
    ...oneScreen('neis.assess.levels', {
      readArgs: LV.readArgs,
      compare: (text, r, screen) => LV.compare({ parsed: LV.parse(text), rows: r.rows, screen }),
    }),
    cols: ['코드', '성취기준'], allTables: true, plain: true,
    trialBlock: (lines, i) => LV.block(lines, i),
    hint: "평가계획 한글 파일(.hwp·.hwpx)을 그대로 넣어도 돼요. '교육과정 성취기준 | 평가기준' 표에서 성취기준마다 상·중·하(2022 개정은 A~E) 글을 찾아 넣어요. 나이스 [성취기준관리]에 성취기준이 먼저 있어야 하고, 화면에 학년도·학기·과목을 먼저 골라 두세요.",
    async apply(checked, { tabId, step }) {
      const screen = checked.screen;
      const g = checked.groups[0];
      const steps = g.result.plan?.steps || [];
      const saved = [];
      let stop = '';
      for (const [i, s] of steps.entries()) {
        if (i) await pause();
        step(`${s.code} 넣는 중 (${i + 1}/${steps.length})`);
        // 저장마다 나이스가 다시 조회하므로, 넣기 직전에 다시 읽어 확인 때와 같은지 본다
        const r = await call('read', LV.readArgs(screen), tabId);
        if (!r.ok) { stop = `${s.code}: ${r.error}`; break; }
        const fresh = LV.compare({ parsed: LV.parse(g.text), rows: r.rows, screen });
        const now = fresh.plan?.steps.find((x) => x.code === s.code && x.cria === s.cria);
        if (!now || JSON.stringify(now.set) !== JSON.stringify(s.set) || JSON.stringify(now.expect) !== JSON.stringify(s.expect)) { stop = `${s.code}: 확인한 뒤에 나이스 값이 바뀌었어요. 다시 확인해 주세요.`; break; }
        const p = await call('pickRow', LV.pickArgs(screen, now), tabId);
        if (!p.ok) { stop = `${s.code}: ${p.error}`; break; }
        const d = await call('read', LV.detailArgs(screen), tabId);
        if (!d.ok) { stop = `${s.code}: ${d.error}`; break; }
        const made = LV.part(now, d.rows, screen);
        if (made.error) { stop = `${s.code}: ${made.error}`; break; }
        const a = await call('apply', { appId: screen.appId, parts: [made.part], save: screen.save }, tabId, 20000);
        if (!a.ok) { stop = `${s.code}: ${a.error}`; break; }
        const w = await call('waitSave', { token: a.saveToken, timeout: 120000 }, tabId, 125000);
        if (!w.ok || w.state !== 'success') { stop = `${s.code}: ${w.message ? `나이스 안내: ${w.message}` : '저장 완료 신호를 받지 못했어요. 나이스 화면에서 확인해 주세요.'}`; break; }
        saved.push({ title: s.code, count: 1 });
      }
      return { saved, stop, total: steps.length };
    },
  };

  // ── 수행평가 점수: 파일의 영역 칸마다 나이스 영역을 바꿔 조회 → 확인 → 영역마다 차례로 저장 ──
  const P = D.perf;
  const perf = {
    id: 'neis.assess.perf',
    screenId: 'neis.assess.perf',
    get label() { return D.screens.get(this.screenId).short; },
    cols: ['번호', '성명'], plain: true, groupWord: '영역', notesOnTop: true,
    template: '수행평가성적_양식.xlsx',
    fill: '학번 · 이름 · 영역별 점수 · 결시는 질병결·미인정결·인정결·기타결',
    hint: '칸 예시: 학번(또는 반·번호) · 이름 · 영역 이름(논술·실험보고서…)마다 점수. 결시는 점수 대신 사유 이름(질병결·미인정결·인정결·기타결). 만점을 넘거나 점수가 빈 학생을 알려 드려요. 나이스 화면에 과목·반을 먼저 골라 두세요.',
    searchArgs(screen, areaNo) {
      return { appId: screen.appId, dataMap: screen.search.dataMap, values: areaNo == null ? {} : { [screen.search.area]: areaNo }, button: screen.search.button, dataset: screen.dataset };
    },
    // 파일의 점수 칸 → 나이스 영역들
    plan(parsed, areas, current) {
      const out = [];
      const issues = [];
      for (const key of parsed.areasUsed) {
        if (key !== '*') { const a = areas.find((x) => x.no === key); if (a) out.push({ key, area: a }); continue; }
        const a = areas.length === 1 ? areas[0] : areas.find((x) => x.no === current);
        if (a) out.push({ key, area: a });
        else issues.push(`점수 칸이 어느 영역인지 모르겠어요. 칸 이름을 영역 이름(${areas.map((x) => x.name).join(', ')})으로 적어 주세요.`);
      }
      return { parts: out, issues };
    },
    async load(screen, part, parsed, tabId) {
      const s = await call('search', this.searchArgs(screen, part.area.no), tabId);
      if (!s.ok) return { error: s.error };
      const r = await call('read', P.readArgs(screen), tabId);
      if (!r.ok) return { error: r.error };
      const area = P.areasOf(r.extra, screen).find((a) => a.no === part.area.no) || part.area;
      const result = P.compare({ parsed, areaKey: part.key, area, rows: r.rows, reasons: P.reasonsOf(r.extra, screen), screen });
      if (r.missingColumns?.length) result.issues.push(`나이스 화면 구조가 달라졌어요(없는 칸: ${r.missingColumns.join(', ')}).`);
      return { result };
    },
    // 명단 든 양식의 탭 이름('2학년 기하')으로 나이스 학년·과목을 맞춘다([나이스에서 확인하기] 때만). 다른 이름의 탭이면 건드리지 않음
    async matchSheet(screen, sheet, tabId, step) {
      const m = /^(\d)학년\s*(.+)$/.exec(String(sheet || '').trim());
      if (!m) return { changed: false };
      const U = screen.picks, udcs = [U.grade, U.subject, U.area, U.room];
      const sq = (s) => D.squash(String(s || '').replace(/\(\d+\)$/, ''));
      let r = await call('udcOptions', { appId: screen.appId, udcs }, tabId, 10000);
      if (!r.ok) return { error: r.error };
      let changed = false;
      const grade = r.options[U.grade]?.items.find((x) => String(x.nm).trim() === m[1]);
      if (!grade) return { error: `나이스 학년 목록에 ${m[1]}학년이 없어요.` };
      if (r.options[U.grade].value !== grade.cd) {
        step(`나이스 조건을 ${m[1]}학년으로 바꾸는 중`);
        r = await call('udcPick', { appId: screen.appId, udc: U.grade, value: grade.cd, udcs }, tabId, 30000);
        if (!r.ok) return { error: r.error };
        changed = true;
      }
      const sb = r.options[U.subject]?.items.find((x) => sq(x.nm) === sq(m[2]));
      if (!sb) return { error: `나이스 ${m[1]}학년 과목 목록에 '${m[2]}'이 없어요. 나이스 화면에서 과목을 확인해 주세요.` };
      if (r.options[U.subject].value !== sb.cd) {
        step(`나이스 조건을 ${m[2]}(으)로 바꾸는 중`);
        const x = await call('udcPick', { appId: screen.appId, udc: U.subject, value: sb.cd, udcs }, tabId, 30000);
        if (!x.ok) return { error: x.error };
        changed = true;
      }
      return { changed };
    },
    // 명단 든 양식(교사 요청 2026-11-02): 이 화면의 학년 × 과목 × 강의실을 돌며 학번·이름과 영역 이름을 읽고 조건을 되돌린다. 점수는 읽지 않는다
    async formData({ tabId, step }) {
      const screen = D.screens.get(this.screenId);
      const err = await openScreen(screen, tabId, step);
      if (err) return { fatal: err };
      const U = screen.picks, K = screen.key, udcs = [U.grade, U.subject, U.area, U.room];
      let r;
      for (const end = Date.now() + 10000; ;) {
        r = await call('udcOptions', { appId: screen.appId, udcs }, tabId, 10000);
        if (!r.ok) return { fatal: r.error };
        if (r.options[U.grade]?.items.length || Date.now() > end) break;
        await new Promise((ok) => setTimeout(ok, 700));
      }
      if (!r.options[U.grade]?.items.length) return { fatal: '나이스 학년·과목 칸을 읽지 못했어요. 나이스 화면을 확인한 뒤 다시 해 주세요.' };
      const start = { grade: r.options[U.grade].value, subject: r.options[U.subject]?.value || '', room: r.options[U.room]?.value || '' };
      const pick = async (key, value) => {
        const x = await call('udcPick', { appId: screen.appId, udc: U[key], value, udcs }, tabId, 30000);
        if (!x.ok) throw new Error(x.error);
        return x.options;
      };
      const out = [];
      try {
        for (const g of r.options[U.grade].items.slice()) {
          let og = r.options[U.grade].value === g.cd ? r.options : await pick('grade', g.cd);
          for (const sb of (og[U.subject]?.items || []).slice()) {
            const os = og[U.subject].value === sb.cd ? og : await pick('subject', sb.cd);
            const seen = new Map();
            for (const rm of (os[U.room]?.items || []).slice()) {
              if (os[U.room].value !== rm.cd) await pick('room', rm.cd);
              step(`${g.nm}학년 ${sb.nm} ${rm.nm} 명단 읽는 중`);
              const s = await call('search', this.searchArgs(screen, null), tabId);
              if (!s.ok) continue;
              const rd = await call('read', { appId: screen.appId, dataset: screen.dataset, columns: [screen.gradeColumn, K.cls, K.no, K.name] }, tabId);
              for (const x of rd.ok ? rd.rows : []) {
                const name = String(x[K.name] ?? '').trim();
                if (!name) continue;
                const sid = `${String(x[screen.gradeColumn] ?? g.nm).trim()}${+String(x[K.cls] ?? '').replace(/\D/g, '') || ''}${String(+x[K.no] || 0).padStart(2, '0')}`;
                if (!seen.has(sid)) seen.set(sid, { sid, name });
              }
            }
            if (seen.size) out.push({ grade: String(g.nm).trim(), name: String(sb.nm).replace(/\(\d+\)$/, '').trim(), areas: (os[U.area]?.items || []).map((a) => String(a.nm).trim()), students: [...seen.values()].sort((a, b) => a.sid.localeCompare(b.sid, 'ko', { numeric: true })) });
            og = os;
          }
        }
      } catch (e) { return { fatal: e.message }; } finally {
        // 원래 조건으로 되돌림
        step('나이스 조건을 원래대로 되돌리는 중');
        const now = await call('udcOptions', { appId: screen.appId, udcs }, tabId, 10000);
        for (const key of ['grade', 'subject', 'room']) if (start[key] && now.ok && now.options[U[key]]?.value !== start[key]) await call('udcPick', { appId: screen.appId, udc: U[key], value: start[key], udcs }, tabId, 30000);
        // 조건만 되돌리면 표와 영역 목록은 마지막에 읽은 과목 그대로라, 바로 파일을 넣으면 영역을 못 찾는다(2026-11-02 실제) → 다시 조회
        await call('search', this.searchArgs(screen, null), tabId);
      }
      return out.length ? { subjects: out } : { fatal: '나이스에서 수행평가 학생 명단을 읽지 못했어요. [수행평가영역관리]에 영역이 있는지 확인해 주세요.' };
    },
    async check(text, { tabId, step, verified, sheet = '' }) {
      const screen = D.screens.get(this.screenId);
      const err = await openScreen(screen, tabId, step);
      if (err) return { fatal: err };
      const matched = sheet ? await this.matchSheet(screen, sheet, tabId, step) : { changed: false };
      if (matched.error) return { fatal: matched.error };
      let first = await call('read', P.readArgs(screen), tabId);
      if (!first.ok) return { fatal: first.error };
      if (sheet || matched.changed || !P.areasOf(first.extra, screen).length) {
        step('나이스에서 조회 중');
        const s = await call('search', this.searchArgs(screen, null), tabId);
        if (!s.ok) return { fatal: s.error };
        first = await call('read', P.readArgs(screen), tabId);
        if (!first.ok) return { fatal: first.error };
      }
      const areas = P.areasOf(first.extra, screen);
      if (!areas.length) return { fatal: '나이스에서 수행평가 영역을 찾지 못했어요. 나이스 화면에 과목·반을 고르고 [수행평가영역관리]에 영역이 있는지 확인해 주세요.' };
      const current = first.dm?.[screen.search.dataMap]?.[screen.search.area] || '';
      const parsed = P.parse(text, areas);
      const { parts, issues } = this.plan(parsed, areas, current);
      issues.unshift(...parsed.issues);
      const groups = [];
      for (const [i, part] of parts.entries()) {
        if (i) await pause();
        step(`${part.area.name} 확인 중 (${i + 1}/${parts.length})`);
        const g = { key: part.area.no, date: '', title: `${part.area.name} (만점 ${part.area.max || '?'}점)`, part, text };
        const got = await this.load(screen, part, parsed, tabId);
        if (got.error) g.error = got.error; else g.result = got.result;
        groups.push(g);
      }
      if (current && parts.some((p) => p.area.no !== current)) await call('search', this.searchArgs(screen, current), tabId);
      return { ...finish(groups, verified, issues, { perGroup: true }), screen, current, areas, verified };
    },
    async apply(checked, { tabId, step }) {
      const screen = checked.screen;
      const todo = checked.groups.filter((g) => g.result?.summary.change);
      const saved = [];
      let stop = '';
      for (const [i, g] of todo.entries()) {
        if (i) await pause();
        step(`${g.part.area.name} 넣는 중 (${i + 1}/${todo.length})`);
        const parsed = P.parse(g.text, checked.areas);
        const got = await this.load(screen, g.part, parsed, tabId);
        if (got.error) { stop = `${g.part.area.name}: ${got.error}`; break; }
        const out = await saveOne(screen, got.result, g.result, tabId);
        if (out.error) { stop = `${g.part.area.name}: ${out.error}`; break; }
        saved.push({ title: g.part.area.name, count: out.count });
      }
      if (checked.current) await call('search', this.searchArgs(screen, checked.current), tabId);
      return { saved, stop, total: todo.length };
    },
  };

  // ── 반영비율 점검(V2, 읽기만): 반영비율/만점관리 → 수행평가영역관리를 차례로 조회해 맞대어 봄. 평가기준안 파일은 있어도 되고 없어도 됨 ──
  const ratio = {
    id: 'neis.assess.ratio',
    screenId: 'neis.assess.ratio',
    get label() { return D.screens.get(this.screenId).short; },
    cols: ['구분', '평가'], plain: true, checkOnly: true, noFile: true, allTables: true,
    hint: '평가기준안(.hwpx·엑셀)을 놓으면 계획의 반영비율·만점과 나이스를 맞대어 봐요. 파일 없이 [나이스만 점검]도 돼요. 지필 + 수행 = 100%인지, 수행평가영역관리의 영역 만점·반영비율과 같은지 봐요. 나이스 값은 바꾸지 않아요.',
    async read(screen, tabId, step) {
      const err = await openScreen(screen, tabId, step);
      if (err) return { error: err };
      step(`${screen.title} 조회 중`);
      const s = await call('search', { appId: screen.appId, dataMap: 'dmSearch', values: {}, button: screen.search.button, dataset: screen.dataset }, tabId);
      if (!s.ok) return { error: s.error };
      const r = await call('read', AS.ratio.readArgs(screen), tabId);
      return r.ok ? { rows: r.rows, missing: r.missingColumns || [] } : { error: r.error };
    },
    async check(text, { tabId, step }) {
      const screen = D.screens.get(this.screenId);
      const got = await this.read(screen, tabId, step);
      if (got.error) return { fatal: got.error };
      const areaScreen = D.screens.get('neis.assess.areas');
      const a = await this.read(areaScreen, tabId, step);
      const parsed = String(text || '').trim() ? AS.areas.parse(text) : null;
      const result = AS.ratio.compare({ parsed, rows: got.rows, areas: a.error ? null : a.rows, screen, areaScreen });
      if (a.error) result.notes.unshift(`수행평가영역관리: ${a.error}`);
      if (got.missing.length) result.issues.push(`나이스 화면 구조가 달라졌어요(없는 칸: ${got.missing.join(', ')}).`);
      const g = { key: this.screenId, date: '', title: `${result.subject || screen.title} 반영비율 · 만점`, text, result };
      return { ...finish([g], true, []), screen };
    },
    async apply() { return { saved: [], stop: '반영비율 점검은 나이스 값을 바꾸지 않아요.', total: 0 }; },
  };

  // ── 결시생 인정점: 고사·영역 목록을 먼저 읽고(칸 이름이 고사마다 만들어짐) 학생 표를 읽어 비교 → 한 번에 저장 ──
  const AB = P.absence;
  const absence = {
    ...oneScreen('neis.assess.absence', { readArgs: AB.readArgs, compare: () => null }), // 조회·읽기는 아래 load로 바꿔 씀
    cols: ['번호', '성명 · 고사'], plain: true,
    hint: "수행평가 점수 파일을 그대로 넣어도 돼요. 결시 칸에 '질병결시 16'처럼 사유와 인정점을 적으면(기준점까지는 '질병결시 16 기준 18') 그 칸만 넣어요. 인정점은 계산하지 않아요. [수행평가성적관리]에 결시 사유를 먼저 넣어 두세요.",
    async load(text, screen, tabId) {
      const s = await call('search', { appId: screen.appId, dataMap: 'dmSearch', values: {}, button: screen.search.button, dataset: screen.dataset }, tabId);
      if (!s.ok) return { error: s.error };
      const e = await call('read', AB.readArgs(screen), tabId);
      if (!e.ok) return { error: e.error };
      const exams = AB.examsOf({ [screen.exams.dataset]: e.rows }, screen);
      const r = await call('read', AB.gridArgs(screen, exams), tabId);
      if (!r.ok) return { error: r.error };
      const st = e.dm?.[screen.status.dataMap] || {};
      const result = AB.compare({ parsed: AB.parse(text, exams), rows: r.rows, exams, status: { closed: st[screen.status.closed], reg: st[screen.status.reg], trgtStuCnt: st.trgtStuCnt }, screen });
      if (r.missingColumns?.length) result.issues.push(`나이스 화면 구조가 달라졌어요(없는 칸: ${r.missingColumns.slice(0, 4).join(', ')}).`);
      return { result };
    },
  };

  // 결시생 인정점은 메뉴에서 뺌(교사 결정 2026-10-29) — 코드는 남겨 두고 메뉴·1건 시험 목록에는 안 보임
  const all = [daily, subject, ...records, setuk, standard, items, areas, levels, perf, ratio];
  const hidden = [absence];
  const GROUPS = [
    { name: '출결', items: [daily, subject] },
    { name: '생기부', items: records },
    { name: '평가 · 교과', items: [setuk, standard, items, areas, levels, perf, ratio] },
  ];

  // 파일 내용으로 가장 알맞은 곳을 고른다: 교시가 있으면 과목별출결, 출결 구분이 대부분이면 일일출결, 긴 글이면 생기부(머리줄 낱말로)
  function suggest(text, current = null) {
    const lines = D.lines(text);
    if (!lines.length) return null;
    if (lines.slice(0, 6).some((l) => /문항/.test(l.raw) && /배점|정답|난이도/.test(l.raw))) return items;
    // 평가기준안 한 파일에 성취기준과 수행평가 영역 표가 함께 있으니, 고른 일에 맞는 내용이 있으면 그대로
    const codeLines = lines.filter((l) => AS.CODE.test(l.raw)).length;
    const areaTable = lines.some((l) => /반영\s*비율/.test(l.raw) && /영역|평가/.test(l.raw));
    // 처음엔 1건만 넣을 수 있어 성취기준 한 줄짜리 파일도 흔하다(2026-10-29 실제: 1줄이면 '자율 파일처럼 보여요'가 떴음)
    if (current === standard && codeLines >= 1) return standard;
    if (current === levels && codeLines >= 1) return levels;
    if (current === absence) return absence;
    if (current === areas && areaTable) return areas;
    if (codeLines >= 2 && codeLines >= lines.length / 4) return standard;
    if (areaTable) return areas;
    // 수행평가 점수: 머리줄에 '점수·수행'이 있거나, 고른 일이 수행평가이고 내용이 대부분 숫자
    if (/(^|[,\t])\s*(점수|총점|수행평가|득점)/.test(lines[0].raw)) return perf;
    if (current === perf) return perf;
    // 과목별출결은 '교시'와 '반'이 함께 있다. 일일출결도 '교시' 칸(출석부 웹앱이 시각으로 계산)이 있을 수 있어 '반'으로 가른다
    const hasCls = /(^|[,\t\s])(반|학반|학급)([,\t\s]|$)/.test(lines[0].raw);
    if (/(^|[,\t\s])교시([,\t\s]|$)/.test(lines[0].raw) && (hasCls || current === subject)) return subject;
    const withPeriod = lines.filter((l) => /\d{1,2}\s*교시/.test(l.raw)).length;
    if (withPeriod && withPeriod >= lines.length / 2) return subject;
    const att = A.parseInput(text, D.screens.get(daily.screenId).codes);
    if (att.items.length && att.items.filter((i) => i.kind !== null).length >= att.items.length / 2) return daily;
    const rec = R.parse(text);
    // 독서: 책 제목은 짧아 '긴 글' 짐작에 안 걸림 → 머리줄에 도서명 칸이 있으면 독서
    if ((rec.headers || []).some((h) => ['도서명', '책', '책이름', '도서', '책제목'].includes(D.squash(h)))) return records.find((x) => x.screenId === 'neis.record.reading');
    const long = rec.items.filter((i) => i.text.length >= 20).length;
    if (long) {
      const kinds = [...records, setuk];
      const best = kinds.map((x) => [x, R.score(rec, D.screens.get(x.screenId))]).sort((a, b) => b[1] - a[1]);
      // 고른 일이 생기부 글이고 머리줄로 더 나은 곳을 못 찾으면 고른 그대로
      if (kinds.includes(current) && R.score(rec, D.screens.get(current.screenId)) >= best[0][1]) return current;
      return best[0][1] > 0 ? best[0][0] : records[0];
    }
    // 글이 짧은(20자 미만) 생기부 파일: 고른 일이 생기부 글이면 그대로(전에는 '일일출결 파일처럼 보여요'가 떴음 — 2026-10-29)
    if (rec.items.length && [...records, setuk].includes(current)) return current;
    return daily;
  }

  // ── 출석부 웹앱 명단 만들기: 나이스에서 번호·이름만 읽는다(생년월일·연락처 등은 읽지 않음) ──
  const roster = {
    // 담임: 일일출결 화면의 우리 반
    async homeroom({ tabId, step }) {
      const screen = D.screens.get(daily.screenId);
      const err = await openScreen(screen, tabId, step);
      if (err) return { fatal: err };
      let r = await call('read', A.readArgs(screen), tabId);
      if (!r.ok) return { fatal: r.error };
      const ctx = A.contextOf(screen, r.dm);
      if (!r.rows.length) {
        step('나이스에서 조회 중');
        const s = await call('search', A.searchArgs(screen, ctx, ctx.date || today()), tabId);
        if (!s.ok) return { fatal: s.error };
        r = await call('read', A.readArgs(screen), tabId);
        if (!r.ok) return { fatal: r.error };
      }
      if (!r.rows.length) return { fatal: '나이스 출결 화면에 학생이 없어요. 학년·반을 확인해 주세요.' };
      const name = `${+ctx.grade || ctx.grade}-${+ctx.cls || ctx.cls}`;
      return { classes: [{ name, subject: '담임', students: r.rows.map((x) => ({ no: D.normNo(x.clsNo), name: D.squash(x.stuFlnm) })) }] };
    },
    // 교과: 최근 3주 과목별출결 수업 목록에서 정규 수업 반만(2주 이상 나온 반) 학생 목록.
    // 한 번만 나온 반은 교체·보강으로 보고 빼되 skipped로 알림(교사 요청 2026-10-28: 교체된 명단은 읽지 않기). include로 다시 넣을 수 있음
    async subjects({ tabId, step, include = [] }) {
      const screen = D.screens.get(subject.screenId);
      const err = await openScreen(screen, tabId, step);
      if (err) return { fatal: err };
      const first = await call('read', S.readPeriodsArgs(screen), tabId);
      if (!first.ok) return { fatal: first.error };
      const rawDate = first.dm[screen.search.dataMap]?.[screen.search.date] || today();
      const base = D.normDate(rawDate) || today();
      const d0 = new Date(+base.slice(0, 4), +base.slice(4, 6) - 1, +base.slice(6));
      d0.setDate(d0.getDate() - ((d0.getDay() + 6) % 7) - 14);
      const WEEKS = 3;
      const found = new Map(); // 반|과목 → { date, row, weeks }
      const weeksWithData = new Set();
      for (let i = 0; i < WEEKS * 7; i++) {
        const d = new Date(d0); d.setDate(d0.getDate() + i);
        if (d.getDay() === 0 || d.getDay() === 6) continue;
        const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
        const week = Math.floor(i / 7);
        if (i) await pause();
        step(`${D.showDay(ymd)} 수업 목록 읽는 중`);
        const s = await call('search', searchArgs(screen, rawDate, ymd, screen.periods.dataset), tabId);
        if (!s.ok) continue;
        const list = await call('read', S.readPeriodsArgs(screen), tabId);
        for (const row of list.ok ? list.rows : []) {
          const c = S.classOf(row, screen);
          if (!c.cls && !row[screen.periods.clsCd]) continue;
          // 반 이름은 나이스 수업 반 이름 그대로(과목 괄호만 뗌): '3학년 302', '2학년 201(F)' — 선택과목 반이 많아 'n-n' 꼴로 줄이지 않음
          const k = `${row[screen.periods.clsCd]}|${row.etbSbjtCd}`;
          weeksWithData.add(week);
          if (!found.has(k)) found.set(k, { key: k, ymd, row, name: S.groupLabel(row, screen.periods) || `${c.grade}-${c.cls}`, subject: row[screen.periods.subject] || '', weeks: new Set() });
          const f = found.get(k);
          f.weeks.add(week);
          f.ymd = ymd; f.row = row; // 가장 최근 날짜로 명단을 읽음
        }
      }
      if (!found.size) return { fatal: '최근 3주 과목별출결 수업 목록이 비어 있어요.' };
      // 정규 수업 = 2주 이상 나온 반(자료가 한 주뿐이면 모두)
      const split = S.splitRegular([...found.values()], weeksWithData.size, include);
      const skipped = split.skipped.map((v) => ({ key: v.key, name: v.name, subject: v.subject, day: v.ymd }));
      const classes = [];
      for (const v of split.regular) {
        await pause();
        step(`${v.name} ${v.subject} 명단 읽는 중`);
        const s = await call('search', searchArgs(screen, rawDate, v.ymd, screen.periods.dataset), tabId);
        if (!s.ok) continue;
        const p = await call('pickRow', S.pickArgs(screen, v.row), tabId);
        if (!p.ok) continue;
        const st = await call('read', S.readStudentsArgs(screen), tabId);
        if (!st.ok || !st.rows.length) continue;
        classes.push({ name: v.name, subject: v.subject, students: S.rosterStudents(st.rows) });
      }
      await call('search', searchArgs(screen, rawDate, base, screen.periods.dataset), tabId);
      return classes.length ? { classes, skipped } : { fatal: '수업 반의 학생 목록을 읽지 못했어요.' };
    },
  };

  D.runners = { daily, subject, records, all, roster, groups: GROUPS, suggest, byId: (id) => [...all, ...hidden].find((x) => x.id === id) };
})();
