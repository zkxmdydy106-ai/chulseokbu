// 기안 양식 즐겨찾기(교사 요청 2026-10-28): 자주 쓰는 서식·결재선·제목·본문 틀을 저장 → 누르면 그 서식 기안 창이 열리고 패널에 내용이 채워진다.
// 저장: chrome.storage.local 'draftFavs'(이 PC, 교직원 이름·직위 포함 가능, '저장된 자료'에서 지움). 상신은 교사가 기안 창에서 누른다(교사 결정 2026-11-02).
// + 회신 양식 기본 칸 채우기(F5): 내 정보(학교·담당자·직위·연락처)는 처음 한 번 적어 이 PC 설정에 둔다.
(() => {
  const D = globalThis.Doumi;
  const esc = D.esc;
  const KEY = 'draftFavs';
  const MAX = 30;
  let formsOpen = false; // 공용서식 목록 펼침
  let forms = null;      // 읽어 온 공용서식 [{ formId, cat, name }]
  let formsErr = '';
  let picked = null;     // 저장할 서식 { formId, name }
  let saving = false;    // 이름 적는 칸 펼침

  async function load() { const v = (await chrome.storage.local.get(KEY))[KEY]; return Array.isArray(v) ? v : []; }
  async function save(list) { if (list.length) await chrome.storage.local.set({ [KEY]: list }); else await chrome.storage.local.remove(KEY); }
  const newId = () => `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
  const today = () => { const d = new Date(); return `${d.getFullYear()}. ${d.getMonth() + 1}. ${d.getDate()}.`; };

  async function html(s) {
    const list = await load();
    return `<div class="dr-favs" id="drFavs">
      <div class="dr-chips">${list.map((f) => `<span class="dr-chip"><button class="link" data-fav="${esc(f.id)}" title="${esc([f.formName || '서식 미지정', f.line?.length ? `결재선 ${f.line.length}명` : f.lineType, f.tkcrd ? '과제카드' : '', f.disclosureLabel].filter(Boolean).join(' · '))}">${esc(f.name)}</button><button class="btn-text" data-fav-del="${esc(f.id)}" aria-label="${esc(f.name)} 지우기">지우기</button></span>`).join('')}<button class="btn-text" id="drFavSave">지금 것을 양식으로</button></div>
      ${saving ? `<div class="dr-fav-new"><input id="drFavName" placeholder="양식 이름(예: 내부결재 계획)" maxlength="40"><button class="btn-main small" id="drFavOk">저장</button><button class="btn-text" id="drFavNo">닫기</button></div><p class="hint" id="drFavNote"></p>` : ''}
    </div>`;
  }

  // [더 보기] 안: 서식 고르기
  function formHtml(s) {
    const pick = !formsOpen ? '' : forms ? `<ul class="dr-forms">${forms.map((x) => `<li><button class="link" data-form-pick="${esc(x.formId)}">${esc(x.name)}</button> <span class="dim small">${esc(x.cat || '')}</span></li>`).join('') || '<li class="dim">공용서식을 찾지 못했어요.</li>'}</ul>` : formsErr ? `<p class="err">${esc(formsErr)}</p>` : '<p class="hint">공용서식 목록을 읽는 중…</p>';
    return `<div class="dr-fav-new"><button class="btn-line small" id="drFormPick">${s.formName ? `서식: ${esc(s.formName)}` : '서식 고르기'}</button>${s.formId ? '<button class="btn-line small" id="drFormOpen">이 서식 기안 창 열기</button>' : ''}</div>
      ${pick}`;
  }

  // 기안 창이 뜨기를 기다린다(PC 도우미가 있을 때만 확인)
  async function openForm(c, formId, formName) {
    c.msg(`'${formName}' 서식 기안 창을 여는 중…`);
    let r;
    try { r = await D.edufineDraft.openForm(formId); } catch { r = { ok: false, error: '기안 창을 열지 못했어요. 에듀파인에서 [기안] → 서식을 직접 눌러 주세요.' }; }
    if (!r.ok) { c.msg(r.error, true); return; }
    c.msg(r.opened ? '기안 창이 열렸어요. [기안 창에 넣기]를 누르세요.' : "기안 창은 에듀파인 문서 프로그램으로 열려요. '앱을 열까요?'가 뜨면 '항상 허용' 체크 후 [열기]. 창이 뜨면 [기안 창에 넣기]를 누르세요.");
  }

  async function onClick(e, c) {
    const t = e.target.closest('button');
    if (!t) return false;
    if (t.dataset.fav) {
      const f = (await load()).find((x) => x.id === t.dataset.fav);
      if (!f) return true;
      c.setState({ ...c.blank(), kind: f.kind || 'free', subject: f.subject || '', titleEdit: f.title ?? null, bodyEdit: f.body ?? null, lineType: f.lineType || '내부결재', disclosure: f.disclosure || 'partial6', receiver: f.receiver || '', attachText: f.attachText || '', formId: f.formId || '', formName: f.formName || '', favId: f.id, rcverOrgs: f.rcverOrgs || '', cnrsText: f.cnrsText || '', tkcrd: f.tkcrd || '' });
      if (f.line?.length) { const all = await c.loadLines(); all[f.lineType || '내부결재'] = f.line; await c.saveLines(all); }
      await c.saveWork();
      await c.render();
      c.msg(`'${f.name}' 양식을 불러왔어요. 내용을 쓰고 [기안 창에 넣기]를 누르세요.`);
      return true;
    }
    if (t.dataset.favDel) {
      await save((await load()).filter((x) => x.id !== t.dataset.favDel));
      await c.render();
      return true;
    }
    if (t.dataset.formPick) {
      const f = (forms || []).find((x) => x.formId === t.dataset.formPick);
      if (f) { c.st.formId = f.formId; c.st.formName = f.name; formsOpen = false; await c.saveWork(); await c.render(); c.msg(`서식을 '${f.name}'(으)로 골랐어요. 다음부터 이 서식으로 열어요.`); }
      return true;
    }
    switch (t.id) {
      case 'drFormPick':
        formsOpen = !formsOpen;
        await c.render();
        if (formsOpen) {
          forms = null; formsErr = '';
          let r;
          try { r = await D.edufineDraft.listForms(); } catch { r = { ok: false, error: '공용서식 목록을 읽지 못했어요. 에듀파인 첫 화면 탭을 확인해 주세요.' }; }
          if (r.ok) forms = r.forms; else formsErr = r.error;
          await c.render();
        }
        return true;
      case 'drFormOpen': openForm(c, c.st.formId, c.st.formName); return true;
      case 'drFavSave': saving = true; await c.render(); c.el.querySelector('#drFavName')?.focus(); return true;
      case 'drFavNo': saving = false; await c.render(); return true;
      case 'drFavOk': {
        const name = String(c.el.querySelector('#drFavName')?.value || '').trim();
        const note = c.el.querySelector('#drFavNote');
        if (!name) { if (note) { note.className = 'err'; note.textContent = '이름을 적어 주세요.'; } return true; }
        const doc = c.docOf();
        // 본문 틀에 개인정보가 있으면 저장하지 않고 알린다(이 PC에 남는 틀이라)
        const mk = D.mask ? D.mask(`${doc.title}\n${doc.body}`) : { total: 0 };
        if (mk.total) { if (note) { note.className = 'err'; note.textContent = `틀에 ${D.mask.summary(mk.kinds)}가 있어요. 지운 뒤 저장해 주세요.`; } return true; }
        const list = await load();
        if (list.length >= MAX) { if (note) { note.className = 'err'; note.textContent = `즐겨찾기는 ${MAX}개까지예요. 안 쓰는 것을 지워 주세요.`; } return true; }
        const s = c.st;
        const disc = c.DISCLOSURE[s.disclosure] || c.DISCLOSURE.partial6;
        const line = (await c.loadLines())[s.lineType] || [];
        list.push({ id: newId(), name, kind: s.kind, subject: s.subject, title: doc.title, body: doc.body, lineType: s.lineType, line, disclosure: s.disclosure, disclosureLabel: disc.label.replace(' (기본)', ''), receiver: s.receiver, attachText: s.attachText, formId: s.formId, formName: s.formName, rcverOrgs: s.rcverOrgs, cnrsText: s.cnrsText, tkcrd: s.tkcrd });
        await save(list);
        saving = false;
        await c.render();
        c.msg(`'${name}' 양식을 저장했어요(이 PC). 학생 이름이 틀에 들어 있으면 지우고 다시 저장해 주세요.`);
        return true;
      }
      default: return false;
    }
  }

  // ── 회신 양식 기본 칸 ──
  async function meOf() { const s = await D.store.settings(); return s.me || {}; }
  async function replyBlock() {
    const me = await meOf();
    const ready = me.school && me.name;
    return `<div class="df wide dr-reply"><span>회신 양식</span>
      <label class="upload dr-drop" id="drFormDrop"><span class="upload-sub">받은 양식(.xlsx·.hwpx)을 끌어다 놓으면 학교명·담당자·직위·연락처·작성일 칸을 채운 사본을 드려요(조사 내용은 직접)</span><input type="file" id="drFormFile" accept=".xlsx,.hwpx,.hwp" hidden></label>
      <details${ready ? '' : ' open'}><summary class="hint">내 정보 ${ready ? `<span class="dim">${esc(me.school)} · ${esc(me.name)}</span>` : '(처음 한 번)'}</summary>
        <div class="dr-me"><input id="drMeSchool" placeholder="학교 이름" value="${esc(me.school || '')}"><input id="drMeName" placeholder="담당자 이름" value="${esc(me.name || '')}"><input id="drMePos" placeholder="직위(예: 교사)" value="${esc(me.position || '')}"><input id="drMePhone" placeholder="연락처" value="${esc(me.phone || '')}"><button class="btn-line small" id="drMeSave">저장</button></div>
        <p class="hint">이 PC 설정에만 저장돼요('저장된 자료 · 설정'에서 지움).</p>
      </details>
      <p class="hint" id="drFormMsg"></p>
    </div>`;
  }
  function download(name, bytes) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([bytes]));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }
  async function takeForm(file, el) {
    const box = el.querySelector('#drFormMsg');
    const say = (t, cls = 'hint') => { if (box) { box.className = cls; box.textContent = t; } };
    if (!file) return;
    const me = await meOf();
    const r = await D.formFill.fill(file.name, await file.arrayBuffer(), { school: me.school, name: me.name, position: me.position, phone: me.phone, date: today() });
    if (!r.ok) { say(r.error, 'err'); return; }
    if (D.edufineFiles?.saveBytes) {
      const put = await D.edufineFiles.saveBytes(r.name, r.bytes);
      if (put.ok) { say(`${r.names.join('·') || '채울 칸 없음'} — 채운 사본을 ${put.path}에 저장해 열었어요.`, 'ok'); return; }
    }
    download(r.name, r.bytes);
    say(r.filled.length ? `${r.names.join('·')} 칸을 채운 사본 '${r.name}'을 내려받았어요. 열어서 나머지를 적어 주세요.` : `이름을 아는 칸을 찾지 못했어요. 사본 '${r.name}'을 내려받았어요. 직접 적어 주세요.`, r.filled.length ? 'ok' : 'warn');
  }
  async function meSave(el) {
    const v = (id) => String(el.querySelector(id)?.value || '').trim();
    await D.store.saveSettings({ me: { school: v('#drMeSchool'), name: v('#drMeName'), position: v('#drMePos'), phone: v('#drMePhone') } });
  }

  D.draftFavs = { html, formHtml, onClick, load, replyBlock, takeForm, meSave };
})();
