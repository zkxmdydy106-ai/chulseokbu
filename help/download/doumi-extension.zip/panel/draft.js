// F3 기안·품의 패널 화면: 종류 → 입력(요청 문장·관련 공문·견적서·붙임·결재선) → 공문 미리보기·검사 → [제목 복사]·[본문 복사]
// 기안 창은 WXSClient 프로그램이라 확장이 직접 못 채운다(docs/selectors.md) → PC 도우미(panel/pc-helper.js)가 있으면 [기안 창에 채우기], 없으면 복사.
// 저장: 작업 중 초안 → storage.session(브라우저 닫으면 사라짐), 결재선 저장본(교직원 이름·직위) → storage.local '저장된 자료 보기'·'전체 자료 삭제'에 포함.
// 외부 전송 없음. 견적서 파일은 브라우저 안에서만 읽는다.
(() => {
  const D = globalThis.Doumi;
  const DR = D.draft;
  const esc = D.esc;
  const WORK = 'draft';
  const LINES = 'draftLines';
  const ROLES = ['검토', '협조', '결재', '전결', '대결'];
  const LINE_TYPES = ['내부결재', '지출품의', '대외 회신'];
  const lineTypeOf = (kind) => (kind === 'expense' ? '지출품의' : kind === 'reply' ? '대외 회신' : '내부결재');

  let el;
  let st = null; // 초안
  // 결재선 고치는 칸: 미리보기를 다시 그려도 열린 상태와 적던 글이 남게
  let lineOpen = false;
  let lineDraft = null;

  const blank = () => ({ kind: 'plan', request: '', subject: '', when: '', where: '', who: '', what: '', result: '', budgetCode: '', method: '', budgetLeft: '', deadline: '', submit: '', relatedText: '', attachText: '', items: [], itemsFile: '', lineType: '내부결재', disclosure: 'partial6', titleEdit: null, bodyEdit: null, receiver: '', formId: '', formName: '', favId: '' });
  // 대국민 공개여부(2026-10-28 교사 기본 설정: 부분공개 6호, 붙임은 비공개)
  const DISCLOSURE = {
    partial6: { label: '부분공개 6호 (기본)', mode: 'partial', reasons: [6], props: { disclosure: '부분공개', disclosureReason: '6호' } },
    private6: { label: '비공개 6호', mode: 'private', reasons: [6], props: { disclosure: '비공개', disclosureReason: '6호' } },
    public: { label: '공개', mode: 'public', reasons: [], props: { disclosure: '공개' } },
  };
  const discOf = (s) => DISCLOSURE[s.disclosure] || DISCLOSURE.partial6;

  // ── 저장 ──
  const saveWork = () => D.store.setWork(WORK, st);
  async function loadLines() { return (await chrome.storage.local.get(LINES))[LINES] || {}; }
  async function saveLines(all) { await chrome.storage.local.set({ [LINES]: all }); }

  // '역할 직위 이름' 한 줄씩 → [{ role, position, name }]
  function parseLine(text) {
    return String(text || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
      const p = l.split(/\s+/);
      const role = ROLES.includes(p[0]) ? p.shift() : '검토';
      const name = p.pop() || '';
      return { role, position: p.join(' '), name };
    });
  }
  const lineText = (line) => (line || []).map((p) => [p.role, p.position, p.name].filter(Boolean).join(' ')).join('\n');

  // 관련 문서 한 줄: '충청남도교육청 진로교육과-12345 | 2026.10.1 | 제목'
  function parseRelated(text) {
    return String(text || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
      const [head, date, ...rest] = l.split('|').map((s) => s.trim());
      const toks = (head || '').split(/\s+/);
      const at = toks.findIndex((t) => DR.parseDocNo(t));
      const r = { title: rest.join(' | '), date: date ? D.normDate(date) || date : '' };
      if (at >= 0) Object.assign(r, DR.parseDocNo(toks[at]), { org: toks.slice(0, at).join(' ') });
      else r.title = r.title || head;
      return r;
    });
  }
  const parseAttach = (text) => String(text || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((name) => ({ name }));

  function draftOf(s) {
    return {
      kind: s.kind, subject: s.subject, when: s.when, where: s.where, who: s.who, what: s.what, result: s.result,
      budgetCode: s.budgetCode, method: s.method, budgetLeft: s.budgetLeft, deadline: s.deadline, submit: s.submit,
      items: s.items, related: parseRelated(s.relatedText), attachments: parseAttach(s.attachText),
      props: discOf(s).props,
    };
  }

  // 지금 문서 = 틀로 만든 글. 직접 고쳤거나 [고치기]를 눌렀으면 그 글
  function docOf(s = st) {
    const c = DR.compose(draftOf(s));
    const title = s.titleEdit ?? c.title;
    const body = s.bodyEdit ?? c.text;
    return { title, body, composed: c, lines: body.split(String.fromCharCode(10)).filter((l, i, a) => l.trim() || i < a.length - 1), text: body };
  }

  // ── 그리기 ──
  const field = (id, label, value, ph = '', wide = false) => `<label class="df${wide ? ' wide' : ''}"><span>${esc(label)}</span><input data-f="${id}" value="${esc(value)}" placeholder="${esc(ph)}"></label>`;
  const area = (id, label, value, ph, rows = 3) => `<label class="df wide"><span>${esc(label)}</span><textarea data-f="${id}" rows="${rows}" placeholder="${esc(ph)}">${esc(value)}</textarea></label>`;

  function kindFields(s, replyHtml = '') {
    if (s.kind === 'expense') {
      const items = s.items.length
        ? `<table class="grid dr-items"><thead><tr><th>품명</th><th>규격</th><th class="n">수량</th><th class="n">단가</th><th class="n">금액</th></tr></thead><tbody>${s.items.map((it) => `<tr><td>${esc(it.name)}</td><td>${esc(it.spec || '')}</td><td class="n">${esc(it.qty)}</td><td class="n">${Number.isNaN(it.price) ? '' : esc(it.price.toLocaleString('en-US'))}</td><td class="n">${Number.isNaN(it.amount) ? '' : esc(it.amount.toLocaleString('en-US'))}</td></tr>`).join('')}</tbody></table>`
        : '';
      return `
        ${field('budgetCode', '예산 과목', s.budgetCode, '예: 교수학습활동지원-교과활동-일반수용비', true)}
        ${field('method', '구입 방법', s.method, '예: 학교장터 2인 견적')}
        ${field('budgetLeft', '예산 잔액', s.budgetLeft, '원 (적으면 초과 검사)')}
        <div class="df wide"><span>견적서</span><label class="upload dr-drop" id="drDrop"><span class="upload-sub">${s.itemsFile ? `${esc(s.itemsFile)} · 품목 ${s.items.length}개` : '견적서(.xlsx·.csv·.hwpx)를 끌어다 놓거나 눌러서 고르기'}</span><input type="file" id="drFile" accept=".xlsx,.csv,.tsv,.txt,.hwpx" hidden></label></div>
        ${items}`;
    }
    if (s.kind === 'reply') {
      return `
        ${area('notice', '받은 공문 본문(붙여넣기)', s.notice || '', '결재함 [회신 기안 만들기]로 오면 저절로 채워져요. 직접 쓸 때만 공문 본문을 붙여 넣고 [요구사항 뽑기] — 기한·제출물만 뽑고 저장하지 않아요', 3)}
        <div class="row-btns"><button class="btn-text" id="drReq">요구사항 뽑기</button></div>
        ${field('deadline', '제출 기한', s.deadline, '예: 2026. 11. 7.(금)')}
        ${field('submit', '제출 자료', s.submit, '예: 운영 결과 보고서')}
        ${field('receiver', '수신자', s.receiver, '예: 충청남도교육청 교육감')}
        ${replyHtml}`;
    }
    return `
      ${field('when', '일시', s.when, '예: 2026. 11. 20.(금) 13:00~16:00')}
      ${field('where', '장소', s.where, '예: 시청각실')}
      ${field('who', '대상', s.who, '예: 2학년 180명')}
      ${field('what', '내용', s.what, '예: 직업 체험·진로 특강', true)}
      ${s.kind === 'result' ? field('result', '결과', s.result, '예: 참여율 96%, 만족도 4.5/5', true) : ''}`;
  }

  async function render() {
    const s = st;
    const all = await loadLines();
    const line = all[s.lineType] || [];
    const d = draftOf(s);
    const doc = docOf(s);
    const c = { title: doc.title, lines: doc.lines, text: doc.body };
    const checked = D.draftCheck.scan({ title: doc.title, body: doc.body });
    const issues = [...DR.check(d, c), ...DR.checkLine(line).map((x) => ({ ...x, text: `결재선(${s.lineType}): ${x.text}` }))];
    const errs = [...issues.filter((x) => x.level === 'err'), ...checked.issues.filter((x) => x.level === 'err')];
    const total = s.kind === 'expense' ? DR.checkItems(s.items).total : 0;
    const kinds = Object.entries(DR.KINDS).map(([k, v]) => `<label class="dr-kind"><input type="radio" name="drKind" value="${k}" ${s.kind === k ? 'checked' : ''}> ${esc(v.label)}</label>`).join('');
    el.dataset.state = 'draft';
    el.innerHTML = `
      <h2 class="sec">기안 준비</h2>
      ${D.draftFavs ? await D.draftFavs.html(s) : ''}
      <div class="dr-kinds">${kinds}</div>
      <div class="dr-form">
        <label class="df wide"><span>요청 문장</span><span class="dr-req"><input data-f="request" value="${esc(s.request)}" placeholder="예: 11월 과학실 소모품 구입 / 2학년 진로체험 결과 보고"><button class="btn-line small" id="drGuess">틀 채우기</button></span></label>
        ${field('subject', '주제', s.subject, '제목·본문에 들어갈 사업 이름', true)}
        ${kindFields(s, s.kind === 'reply' && D.draftFavs ? await D.draftFavs.replyBlock() : '')}
        ${area('relatedText', '관련 문서', s.relatedText, '한 줄에 하나: 충청남도교육청 진로교육과-12345 | 2026.10.1 | 제목', 2)}
        ${area('attachText', '붙임', s.attachText, '한 줄에 하나: 진로체험 계획서.hwpx', 2)}
        <label class="df"><span>대국민 공개여부</span><select data-f="disclosure">${Object.entries(DISCLOSURE).map(([k, v]) => `<option value="${k}" ${s.disclosure === k ? 'selected' : ''}>${esc(v.label)}</option>`).join('')}</select></label>
        <div class="df"><span>붙임 파일</span><span class="dim dr-static">비공개</span></div>
        <div class="df wide"><span>결재선</span><span class="dr-line">
          <select id="drLineType">${LINE_TYPES.map((t) => `<option ${t === s.lineType ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>
          <span class="dim">${line.length ? esc(line.map((p) => `${p.role} ${p.position} ${p.name}`.trim()).join(' → ')) : '저장된 결재선 없음'}</span>
          <button class="btn-text" id="drLineEdit">${line.length ? '고치기' : '만들기'}</button></span></div>
        <div id="drLineBox" ${lineOpen ? '' : 'hidden'}>
          <textarea id="drLineText" rows="4" placeholder="한 줄에 한 사람: 역할 직위 이름&#10;검토 교무부장 홍길동&#10;협조 행정실장 김철수&#10;결재 교장 이영희">${esc(lineDraft ?? lineText(line))}</textarea>
          <p class="hint">이 PC 브라우저에만 저장돼요(교직원 이름·직위). '저장된 자료 · 설정'에서 지울 수 있어요. 역할: ${ROLES.join('·')}</p>
          <div class="row-btns"><button class="btn-line small" id="drLineSave">결재선 저장</button><button class="btn-text" id="drLineCancel">닫기</button></div>
        </div>
      </div>

      <h2>미리보기</h2>
      <label class="df wide dr-edit"><span>제목</span><input id="drTitle" value="${esc(doc.title)}" placeholder="주제를 적으면 만들어져요"></label>
      <table class="info">
        ${s.kind === 'expense' ? `<tr><th>합계</th><td>${esc(DR.formatMoney(total))}</td></tr>` : ''}
        <tr><th>공개</th><td>${esc(discOf(s).label.replace(' (기본)', ''))} · 붙임 비공개</td></tr>
        ${s.receiver ? `<tr><th>수신자</th><td>${esc(s.receiver)}</td></tr>` : ''}</table>
      <label class="df wide dr-edit"><span>본문 <span class="dim">바로 고칠 수 있어요${s.bodyEdit != null ? ' · 틀과 달라졌어요' : ''}</span>${s.bodyEdit != null && s.kind !== 'free' ? ' <button class="btn-text" id="drBodyReset">틀로 다시 만들기</button>' : ''}</span><textarea id="drBody" class="dr-body" rows="12" spellcheck="false" placeholder="1. 본문을 적으세요">${esc(doc.body)}</textarea></label>
      ${issues.map((x) => `<p class="${x.level === 'err' ? 'err' : 'warn'}">${esc(x.text)}</p>`).join('')}
      <div class="dr-check" id="drCheck">
        ${checked.issues.length ? `<h3 class="sub">공문 형식·오타 <span class="dim">${checked.issues.length}곳</span>${checked.canFix ? ' <button class="btn-line small" id="drFixAll">모두 고치기</button>' : ''}</h3>
        <ul class="dr-fixes">${checked.issues.map((x) => `<li class="${x.level === 'err' ? 'err' : ''}"><span>${esc(x.text)}</span>${x.fix != null ? `<button class="link" data-fix="${x.id}">고치기</button>` : ''}</li>`).join('')}</ul>` : (issues.length ? '' : '<p class="ok">검사 통과 — 공문 형식·오타 문제를 찾지 못했어요. 내장 규칙으로만 봐서 다 찾지는 못해요.</p>')}
      </div>
      <div class="actions">
        <button class="btn-main" id="drCopyBody" ${c.lines.length ? '' : 'disabled'}>본문 복사</button>
        <button class="btn-line" id="drCopyTitle" ${c.title ? '' : 'disabled'}>제목 복사</button>
        <button class="btn-line" id="drFill" ${pc?.ok && !errs.length && c.lines.length ? '' : 'disabled'} title="${pc?.ok ? '열린 기안 창에 제목·본문을 넣어요' : 'PC 도우미 설치 뒤 켜져요'}">기안 창에 채우기</button>
        ${s.kind === 'expense' ? `<button class="btn-line" id="drExp" ${s.items.length && !DR.checkItems(s.items).issues.length ? '' : 'disabled'} title="학교회계 품의등록 화면에 제목·개요·품목을 넣어요(예산은 화면 [예산선택]에서 직접)">품의 등록 화면에 채우기</button>` : ''}
      </div>
      <p class="hint" id="drMsg">${errs.length ? `확인 필요 ${errs.length}건 — 고친 뒤 넣으세요. ` : ''}${pc?.ok ? '에듀파인에서 [기안] → 서식을 골라 기안 창을 열고 [기안 창에 채우기]를 누르세요. 제목·본문만 넣고 저장·결재올림은 하지 않아요.' : '기안 창(문서관리카드)은 에듀파인 별도 프로그램이라, PC 도우미가 없으면 복사해서 붙여 넣어요(Ctrl+V).'} 상신(결재올림)은 선생님이 직접 눌러요.</p>
      <p class="hint dr-pc" id="drPc">${pcLine()}</p>
      <div class="actions"><button class="btn-line small" id="drReset">새로 쓰기</button><button class="btn-line small" id="hmHome">처음으로</button></div>`;
  }

  // PC 도우미 상태 한 줄: 확인 중 / 연결됨 / 없음(설치 파일 받기)
  let pc = null;
  let pcChecking = false;
  function pcLine() {
    if (!pc) return 'PC 도우미 확인 중…';
    if (pc.ok) return `PC 도우미 연결됨${pc.old ? ' · <span class="err">새 판이 있어요</span> <button class="btn-text" id="drPcInstall">설치 파일 다시 받기</button>' : ''} · <button class="btn-text" id="drPcRemove">지우기 파일 받기</button>`;
    return `${esc(pc.text)} <button class="btn-line small" id="drPcInstall">PC 도우미 설치</button> <span class="dim">버튼 → 내려받은 파일 한 번 누르기 → 끝</span> · <button class="btn-text" id="drPcRecheck">다시 확인</button>`;
  }
  async function checkPc(force = false) {
    if (pcChecking || !D.pcHelper) return;
    pcChecking = true;
    try { pc = await D.pcHelper.status(force); } finally { pcChecking = false; }
    if (el?.dataset.state === 'draft') await render();
  }

  // 설치 파일을 받은 뒤 3분 동안 5초마다 연결을 확인한다 — 교사가 [다시 확인]을 누를 필요 없게
  let waitTimer = null;
  function waitInstall() {
    clearInterval(waitTimer);
    const until = Date.now() + 180000;
    waitTimer = setInterval(async () => {
      if (Date.now() > until || el?.dataset.state !== 'draft') { clearInterval(waitTimer); return; }
      const s = await D.pcHelper.status(true);
      if (s.ok) { clearInterval(waitTimer); pc = s; await render(); msg('PC 도우미가 연결됐어요. 이제 [기안 창에 채우기]를 쓸 수 있어요.'); }
    }, 5000);
  }

  async function fill() {
    const c = docOf();
    const btn = el.querySelector('#drFill');
    if (btn) btn.disabled = true;
    msg('기안 창에 넣는 중…');
    const disc = discOf(st);
    const r = await D.pcHelper.fillDraft({ title: c.title, body: c.body, disclosure: { mode: disc.mode, reasons: disc.reasons }, attachPrivate: true });
    if (r.disconnected) { pc = null; checkPc(true); }
    if (r.ok) msg(`기안 창에 넣었어요(제목·본문·${disc.label.replace(' (기본)', '')}·붙임 비공개). 화면에서 확인한 뒤 과제카드·결재경로를 정하고 [결재올림]은 직접 눌러 주세요. 붙임 파일을 나중에 넣었다면 [기안 창에 채우기]를 한 번 더 누르면 비공개로 맞춰요.`);
    else msg(`${D.pcHelper.explain(r)}${r.missing?.length ? ` (못 찾은 칸: ${r.missing.join(', ')})` : ''}`, true);
    if (btn) btn.disabled = false;
  }

  // 학교회계 품의등록(넥사크로 화면)에 제목·개요·품목. 예산은 교사가 화면 [예산선택]에서 고름. 저장·결재요청은 하지 않음
  async function fillExpense() {
    const c = { title: docOf().title, text: docOf().body };
    const btn = el.querySelector('#drExp');
    if (btn) btn.disabled = true;
    msg('에듀파인 품의등록 화면에 넣는 중…');
    let r;
    try { r = await D.edufineExpense.fill({ title: c.title, summary: c.text, items: st.items }); } catch { r = { ok: false, error: '에듀파인 화면에 넣지 못했어요. 에듀파인 탭을 확인해 주세요.' }; }
    if (btn) btn.disabled = false;
    if (r.needBudget) { msg(`${r.opened ? '에듀파인 품의등록 화면을 열었어요. ' : ''}품의 화면의 [예산선택]에서 세부사업·세부항목을 골라 [확인]을 누른 뒤, 여기서 [품의 등록 화면에 채우기]를 한 번 더 눌러 주세요.`); return; }
    if (!r.ok) { msg(r.error, true); return; }
    const over = r.budget && r.total > r.budget.left;
    msg([
      `품의 화면(${r.budget?.name || '고른 예산'})에 품목 ${r.n}개 · 합계 ${DR.formatMoney(r.total)}${r.done.includes('sj') ? ' · 제목' : ''}${r.done.includes('cnsulPurpsCn') ? ' · 개요' : ''}를 넣었어요.`,
      over ? `예산 잔액 ${DR.formatMoney(r.budget.left)}보다 많아요 — 결재요청 때 에듀파인이 막아요.` : '',
      r.cut.length ? `${r.cut.join('·')}는 한도가 넘어 줄였어요.` : '',
      r.missingUnits.length ? `단위(${r.missingUnits.join(', ')})는 에듀파인 코드표에 없어 비워 뒀어요 — 화면에서 골라 주세요.` : '',
      '화면에서 확인한 뒤 [저장]·[결재요청]은 선생님이 눌러 주세요.',
    ].filter(Boolean).join(' '), over);
  }

  // ── 동작 ──
  async function readTable(f) {
    if (/\.xlsx$/i.test(f.name)) return D.readXlsx(await f.arrayBuffer());
    if (/\.hwpx$/i.test(f.name)) return D.readHwpx(await f.arrayBuffer(), { all: true });
    if (/\.(csv|tsv|txt)$/i.test(f.name)) {
      const text = D.decodeText(await f.arrayBuffer());
      const lines = D.lines(text).map((l) => l.raw);
      const sep = lines.some((l) => l.includes('\t')) ? '\t' : ',';
      return lines.map((l) => D.splitCells(l, sep));
    }
    if (/\.hwp$/i.test(f.name)) throw new Error('한글 .hwp는 못 읽어요. 한글에서 "다른 이름으로 저장 → .hwpx"로 저장해 주세요.');
    throw new Error('견적서는 엑셀(.xlsx)·CSV·한글(.hwpx)로 넣어 주세요.');
  }

  async function takeEstimate(f) {
    if (!f) return;
    try {
      const r = DR.parseItems(await readTable(f));
      if (r.error) { st.items = []; st.itemsFile = ''; await render(); msg(r.error, true); return; }
      st.items = r.items; st.itemsFile = f.name;
      if (!st.attachText.includes(f.name)) st.attachText = [st.attachText, f.name].filter(Boolean).join('\n');
    } catch (e) { msg(e.message, true); return; }
    await saveWork(); await render();
  }

  function msg(text, bad) { const m = el.querySelector('#drMsg'); if (m) { m.textContent = text; m.className = bad ? 'err' : 'hint'; } }

  async function copy(text, what) {
    try { await navigator.clipboard.writeText(text); msg(`${what}을 복사했어요. 기안 창 칸을 누르고 Ctrl+V 하세요.`); } catch { msg('복사하지 못했어요. 미리보기 글을 직접 선택해 복사해 주세요.', true); }
  }

  let timer = null;
  function onInput(e) {
    if (e.target.id === 'drLineText') { lineDraft = e.target.value; return; }
    if (e.target.id === 'drTitle' || e.target.id === 'drBody') {
      if (e.target.id === 'drTitle') st.titleEdit = e.target.value; else st.bodyEdit = e.target.value;
      clearTimeout(timer);
      timer = setTimeout(async () => { await saveWork(); paintCheck(); }, 400);
      return;
    }
    const f = e.target.dataset?.f;
    if (!f) return;
    st[f] = e.target.value;
    clearTimeout(timer);
    // 입력 중엔 커서를 지키려고 미리보기만 늦게 다시 그린다
    timer = setTimeout(async () => { await saveWork(); const pos = [e.target.dataset.f, e.target.selectionStart]; await render(); const back = el.querySelector(`[data-f="${pos[0]}"]`); if (back) { back.focus(); try { back.setSelectionRange(pos[1], pos[1]); } catch { /* 선택 불가 칸 */ } } }, 500);
  }

  // 검사 칸만 다시 그린다(글자를 치는 칸의 커서를 지키려고)
  function paintCheck() {
    const box = el.querySelector('#drCheck');
    if (!box) return;
    const doc = docOf();
    const checked = D.draftCheck.scan({ title: doc.title, body: doc.body });
    box.innerHTML = checked.issues.length ? `<h3 class="sub">공문 형식·오타 <span class="dim">${checked.issues.length}곳</span>${checked.canFix ? ' <button class="btn-line small" id="drFixAll">모두 고치기</button>' : ''}</h3>
        <ul class="dr-fixes">${checked.issues.map((x) => `<li class="${x.level === 'err' ? 'err' : ''}"><span>${esc(x.text)}</span>${x.fix != null ? `<button class="link" data-fix="${x.id}">고치기</button>` : ''}</li>`).join('')}</ul>` : '<p class="ok">검사 통과 — 공문 형식·오타 문제를 찾지 못했어요. 내장 규칙으로만 봐서 다 찾지는 못해요.</p>';
  }

  async function onClick(e) {
    if (el.dataset.state !== 'draft') return;
    const t = e.target;
    if (t.name === 'drKind') { st.kind = t.value; st.lineType = lineTypeOf(st.kind); st.titleEdit = null; st.bodyEdit = null; await saveWork(); await render(); return; }
    if (t.dataset.fix != null) {
      const doc = docOf();
      const issue = D.draftCheck.scan({ title: doc.title, body: doc.body }).issues.find((x) => x.id === +t.dataset.fix);
      if (issue) { const next = D.draftCheck.applyOne(doc, issue); st.titleEdit = next.title; st.bodyEdit = next.body; await saveWork(); await render(); }
      return;
    }
    if (D.draftFavs && await D.draftFavs.onClick(e, ctx())) return;
    switch (t.id) {
      case 'drGuess': {
        const g = DR.guessFromRequest(st.request);
        Object.assign(st, { kind: g.kind, subject: g.subject, lineType: lineTypeOf(g.kind) });
        await saveWork(); await render(); return;
      }
      case 'drReq': {
        const r = DR.extractRequirements(st.notice || '');
        if (r.deadline) st.deadline = r.deadline;
        if (r.submits.length) st.submit = r.submits[0];
        await saveWork(); await render();
        msg(r.deadline || r.submits.length ? `기한 ${r.deadline || '-'} · 제출물 ${r.submits.join(', ') || '-'}` : '기한·제출물을 찾지 못했어요. 직접 적어 주세요.', !(r.deadline || r.submits.length));
        return;
      }
      case 'drLineEdit': lineOpen = true; lineDraft = null; el.querySelector('#drLineBox').hidden = false; return;
      case 'drLineCancel': lineOpen = false; lineDraft = null; el.querySelector('#drLineBox').hidden = true; return;
      case 'drLineSave': {
        // 글은 기다리기(await) 전에 읽는다 — 그 사이 미리보기가 다시 그려지면 칸이 새로 만들어진다
        const line = parseLine(lineDraft ?? el.querySelector('#drLineText').value);
        const type = st.lineType;
        lineOpen = false; lineDraft = null;
        const all = await loadLines();
        if (line.length) all[type] = line; else delete all[type];
        await saveLines(all); await render(); return;
      }
      case 'drCopyBody': copy(docOf().body, '본문'); return;
      case 'drCopyTitle': copy(docOf().title, '제목'); return;
      case 'drReset': st = blank(); await D.store.clearWork(WORK); await render(); return;
      case 'drMeSave': await D.draftFavs.meSave(el); await render(); msg('내 정보를 저장했어요(이 PC).'); return;
      case 'drBodyReset': st.bodyEdit = null; st.titleEdit = null; await saveWork(); await render(); return;
      case 'drFixAll': { const r = D.draftCheck.applyAll(docOf()); st.titleEdit = r.title; st.bodyEdit = r.body; await saveWork(); await render(); msg(`${r.changed}곳을 고쳤어요. 고칠 글을 알 수 없는 것은 남겨 두었어요.`); return; }
      case 'drFill': fill(); return;
      case 'drExp': fillExpense(); return;
      case 'drPcInstall': await D.pcHelper.downloadInstaller(); msg('브라우저 오른쪽 위에 내려받은 "PC도우미설치.cmd"를 한 번 누르세요. 설치되면 여기서 저절로 "연결됨"으로 바뀌어요. (Windows가 막으면 [추가 정보] → [실행])'); waitInstall(); return;
      case 'drPcRemove': D.pcHelper.downloadUninstaller(); pc = null; msg('받은 "PC도우미지우기.cmd"를 더블클릭하면 PC 도우미가 지워져요.'); return;
      case 'drPcRecheck': pc = null; await render(); checkPc(true); return;
      case 'drDrop': return;
      default:
    }
  }

  // 즐겨찾기 모듈(panel/draft-favs.js)이 쓰는 입구
  const ctx = () => ({ el, st, setState: (next) => { st = next; }, blank, saveWork, render, msg, docOf, DISCLOSURE, loadLines });

  D.draftView = {
    // init: 다른 화면에서 틀을 채워 열 때(회신 기안 등)
    async open(root, init = null) {
      el = root;
      st = init ? { ...blank(), ...init, lineType: lineTypeOf(init.kind) } : { ...blank(), ...((await D.store.getWork(WORK)) || {}) };
      if (init) await saveWork();
      lineOpen = false; lineDraft = null;
      if (!el.dataset.draftBound) {
        el.dataset.draftBound = '1';
        el.addEventListener('input', (e) => { if (el.dataset.state === 'draft') onInput(e); });
        el.addEventListener('change', (e) => {
          if (el.dataset.state !== 'draft') return;
          if (e.target.id === 'drFile') { takeEstimate(e.target.files[0]); e.target.value = ''; }
          if (e.target.id === 'drFormFile') { D.draftFavs.takeForm(e.target.files[0], el); e.target.value = ''; }
          if (e.target.id === 'drLineType') { st.lineType = e.target.value; lineDraft = null; saveWork().then(render); }
        });
        el.addEventListener('click', onClick);
        el.addEventListener('drop', (e) => {
          if (el.dataset.state !== 'draft') return;
          if (st.kind === 'expense') { e.preventDefault(); takeEstimate(e.dataTransfer.files[0]); }
          if (st.kind === 'reply') { e.preventDefault(); D.draftFavs.takeForm(e.dataTransfer.files[0], el); }
        });
      }
      await render();
      checkPc();
    },
    render: () => render(),
    // 테스트용
    state: () => st,
  };
})();
