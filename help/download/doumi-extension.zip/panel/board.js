// 결재 모아 보기 창(교사 요청 2026-11-05): 읽은 문서를 3×3으로 보고, 칸을 눌러 크게 보며 과제카드·공람자를 고른다. 결재 단추는 없다(결재는 문서 창에서 하나씩).
// 2026-11-09 교사 요청: 공람 체크 목록·전체 선택·즐겨찾기, 선생님께 보낼 쉬운 말 공지 멘트(내장 규칙), 버튼으로 여는 파일 창(메신저로 끌어다 놓기는 교사가).
// 자료는 패널(views/edufine-inbox.js)이 메시지로 준다. 이 창의 메모리에만 있고, 저장하는 것은 공람 즐겨찾기(storage.local 'cnrsFavs', 교직원 이름)뿐이다. 외부 통신 없음.
(() => {
  const D = globalThis.Doumi;
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (id) => document.getElementById(id);
  const send = (m) => new Promise((res) => { try { chrome.runtime.sendMessage(m, (r) => { void chrome.runtime.lastError; res(r || null); }); } catch { res(null); } });
  let data = { items: [], lists: { cards: [], people: [] }, running: false };
  let big = null; // 크게 보는 문서 ID
  let now = null; // 지금 문서 창이 열려 있는 문서
  // 공람 칸: 체크 목록·전체 선택·즐겨찾기(panel/cnrs-picker.js)
  const picker = D.cnrsPicker.create({
    get: () => item(big)?.pick.cnrs || [],
    set: (names) => { const x = item(big); if (x) { x.pick.cnrs = names; return setPick(x); } return undefined; },
    people: () => data.lists.people,
    rerender: () => openBig(big),
  });
  const notes = new Map(); // 문서 ID → 고친 공지 멘트(이 창 메모리만)
  const skip = new Set(); // [결재] 체크를 푼 문서(교사 결정 2026-11-10: 기본은 모두 체크)
  const fileBox = new Map(); // 문서 ID → { loading, error, note, files:[{ name, size, url, error }] }
  let filesOpen = false; // 파일 창은 버튼을 누를 때만 뜬다(교사 결정 2026-11-09)

  const say = (t, cls = 'hint') => { const m = $('bdMsg'); m.className = cls; m.textContent = t; };
  const item = (id) => data.items.find((x) => x.docId === id);
  // 칸에는 많아도 몇 명만(전체 선택이면 줄이 넘치므로)
  const cnrsShort = (names) => (names.length > 3 ? `${names.slice(0, 3).join(', ')} 외 ${names.length - 3}명` : names.join(', '));
  const pickLine = (x) => `<p class="bd-picks"><em>과제카드</em>${x.pick.tkcrd ? `<span class="chg">${esc(x.pick.tkcrd)}</span>` : '없음'} <em>공람</em>${x.pick.cnrs.length ? `<span class="chg">${esc(cnrsShort(x.pick.cnrs))}</span>` : '없음'}</p>`;

  function cardHtml(x) {
    const st = x.status ? `<span class="bd-status ${esc(x.status.cls)}">${esc(x.status.text)}</span> ` : '';
    const keys = x.unread ? `<p class="bd-keys ${x.error ? 'err' : 'dim'}">${esc(x.error || '아직 읽지 않았어요')}</p>`
      : `<p class="bd-keys">${x.deadline ? `기한 <b>${esc(x.deadline)}</b> ` : ''}${x.submits.length ? `제출 ${esc(x.submits.join(', '))} ` : ''}${x.files.length ? `<span class="dim">붙임 ${x.files.length}</span>` : ''}</p>`;
    const auto = !x.status?.final && !x.unread ? `<label class="bd-auto"><input type="checkbox" data-auto="${esc(x.docId)}" ${skip.has(x.docId) ? '' : 'checked'} ${data.running ? 'disabled' : ''}> 결재</label>` : '';
    return `<div class="bd-cell">${auto}<button class="bd-card${x.urgent ? ' urgent' : ''}${now === x.docId ? ' now' : ''}${x.status?.final ? ' finished' : ''}" data-doc="${esc(x.docId)}">
      <p class="bd-title">${x.urgent ? '<span class="tag err">긴급</span> ' : ''}${st}${esc(x.title)}</p>
      <p class="bd-meta">${esc([x.dept, x.drafter, x.wait].filter(Boolean).join(' · '))}</p>
      ${keys}
      <div class="bd-body">${esc(x.body)}</div>
      ${pickLine(x)}
    </button></div>`;
  }
  const autoIds = () => data.items.filter((x) => !x.unread && !x.status?.final && !skip.has(x.docId)).map((x) => x.docId);

  function paint() {
    $('bdCount').textContent = `${data.items.length}건`;
    $('bdGrid').innerHTML = data.items.map(cardHtml).join('') || '<p class="hint">읽은 문서가 없어요.</p>';
    const n = autoIds().length;
    $('bdStart').disabled = data.running || !data.items.length;
    $('bdStart').textContent = n ? `고른 ${n}건 결재` : '결재 시작';
    $('bdStop').hidden = !data.running;
  }

  // ── 공지 멘트 ──
  const noteOf = (x) => notes.get(x.docId) ?? D.edufineNotice.make(x);
  function noteWarn(text) {
    const mk = D.mask(text);
    return mk.total ? `${D.mask.summary(mk.kinds)}이 보여요. 보내도 되는지 확인해 주세요.` : '';
  }
  const noteMsg = (text) => { const w = noteWarn(text); return w ? `<span class="warn">${esc(w)}</span> ` : ''; };
  const NOTE_HINT = '공문 원문은 그대로예요. 쉬운 말로 바꾼 초안이니 학생 이름이 없는지 보고 고쳐 주세요.';

  // ── 파일 창 ──
  const sizeOf = (n) => (n >= 1048576 ? `${(n / 1048576).toFixed(1)}MB` : `${Math.max(1, Math.round((n || 0) / 1024))}KB`);
  function filesHtml(x) {
    const box = fileBox.get(x.docId);
    const rows = !box || box.loading ? '<p class="hint">붙임을 받는 중이에요. 문서 창이 잠깐 열렸다 닫혀요.</p>'
      : box.error ? `<p class="err">${esc(box.error)}</p>`
      : !box.files.length ? '<p class="hint">이 문서에는 붙임이 없어요.</p>'
      : `<p class="hint">파일을 메신저 창으로 끌어다 놓아 주세요. 하나씩 끌어요.</p>
        <ul class="bd-files">${box.files.map((f, i) => (f.url
    ? `<li class="bd-file" draggable="true" data-file="${i}" title="메신저 창으로 끌어다 놓기"><span class="bd-file-grip" aria-hidden="true">⠿</span><span class="bd-file-name">${esc(f.name)}</span><span class="dim">${esc(sizeOf(f.size))}</span><button class="btn-text" data-file-open="${i}">열기</button></li>`
    : `<li class="bd-file off"><span class="bd-file-name">${esc(f.name)}</span><span class="err">${esc(f.error || '받지 못했어요')}</span></li>`)).join('')}</ul>`;
    return `<div class="bd-filebox" id="bdFileBox">
      <div class="bd-sec-head"><h3>파일</h3><span class="sp"></span><button class="btn-text" id="bdFolder">폴더 열기</button>${box && !box.loading && (box.error || box.files.some((f) => !f.url)) ? ' <button class="btn-text" id="bdFileRetry">다시 받기</button>' : ''}</div>
      ${box?.note ? `<p class="warn">${esc(box.note)}</p>` : ''}
      ${rows}
    </div>`;
  }
  const toBlobUrl = (chunks) => {
    const parts = chunks.map((c) => { const s = atob(c); const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; });
    return URL.createObjectURL(new Blob(parts, { type: 'application/octet-stream' }));
  };
  async function fetchFiles(x) {
    const id = x.docId;
    fileBox.set(id, { loading: true, files: [] });
    if (big === id) openBig(id);
    const r = await send({ board: 'files', docId: id });
    const box = !r ? { error: '패널의 결재함을 다시 열어 주세요.', files: [] }
      : !r.ok ? { error: r.error, files: [] }
      : { note: r.note || '', files: r.files.map((f) => (f.chunks ? { name: f.name, size: f.size, url: toBlobUrl(f.chunks) } : { name: f.name, size: f.size, error: f.error })) };
    fileBox.set(id, box);
    if (big === id && filesOpen) openBig(id);
  }

  function bigHtml(x) {
    const i = data.items.indexOf(x);
    const { cards } = data.lists;
    const options = cards.includes(x.pick.tkcrd) || !x.pick.tkcrd ? cards : [x.pick.tkcrd, ...cards];
    const card = options.length
      ? `<select id="bdCard"><option value="">고르지 않음</option>${options.map((c) => `<option ${c === x.pick.tkcrd ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select>`
      : `<input id="bdCard" value="${esc(x.pick.tkcrd)}" placeholder="내 과제카드 이름 그대로">`;
    const rows = [['기한', x.deadline], ['제출', x.submits.join(', ')], ['대상', x.targets.join(', ')]].filter(([, v]) => v).map(([k, v]) => `<h3>${k}</h3><div>${esc(v)}</div>`).join('');
    const note = noteOf(x);
    return `<div class="bd-big-in">
      <div class="bd-big-body">
        <h2>${esc(x.title)}</h2>
        <p class="bd-meta">${esc([x.dept, x.drafter, x.docNo, x.wait].filter(Boolean).join(' · '))}</p>
        <pre>${esc(x.body || x.error || '아직 읽지 않았어요')}</pre>
        ${x.unread ? '' : `<section class="bd-notice">
          <div class="bd-sec-head"><h3>선생님께 보낼 공지</h3><span class="sp"></span>
            <button class="btn-text" id="bdNoteReset">처음 글로</button>
            <button class="btn-line small" id="bdFiles" aria-expanded="${filesOpen}">${filesOpen ? '파일 창 닫기' : '파일 창'}</button>
            <button class="btn-main small" id="bdCopy">복사</button></div>
          <div class="bd-notice-in${filesOpen ? ' with-files' : ''}">
            <textarea id="bdNote" spellcheck="false" aria-label="선생님께 보낼 공지 멘트">${esc(note)}</textarea>
            ${filesOpen ? filesHtml(x) : ''}
          </div>
          <p class="hint" id="bdNoteMsg">${noteMsg(note)}${esc(NOTE_HINT)}</p>
        </section>`}
      </div>
      <div class="bd-big-side">
        ${rows}
        ${x.files.length ? `<h3>붙임 ${x.files.length}</h3><ul>${x.files.map((f) => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}
        ${x.related.length ? `<h3>관련</h3><ul>${x.related.map((r) => `<li>${esc(r)}</li>`).join('')}</ul>` : ''}
        <h3>과제카드${x.rec?.tkcrd ? ' <span class="dim">전에 고른 것을 추천했어요</span>' : ''}</h3>
        ${card}
        ${picker.html()}
        <div class="bd-nav">
          <button class="btn-line small" id="bdPrev" ${i > 0 ? '' : 'disabled'}>이전</button>
          <button class="btn-line small" id="bdNext" ${i < data.items.length - 1 ? '' : 'disabled'}>다음</button>
          <span class="sp"></span>
          <button class="btn-main small" id="bdClose">닫기</button>
        </div>
      </div>
    </div>`;
  }
  const SCROLLS = ['.bd-big-side', '.bd-big-body', '.bd-big-body pre', '#bdNote'];
  function openBig(id) {
    const x = item(id);
    if (!x) return;
    const d = $('bdBig');
    // 같은 문서를 다시 그릴 때는 스크롤을 지킨다(체크 하나마다 목록이 맨 위로 가지 않게)
    const keep = big === id ? SCROLLS.map((s) => d.querySelector(s)?.scrollTop || 0) : null;
    if (big !== id) { filesOpen = false; picker.reset(); }
    big = id;
    d.innerHTML = bigHtml(x);
    if (!d.open) d.showModal();
    if (keep) SCROLLS.forEach((s, i) => { const e = d.querySelector(s); if (e) e.scrollTop = keep[i]; });
  }
  // 고른 값은 패널에 바로 알린다(이 창을 닫아도 남게)
  async function setPick(x) {
    await send({ board: 'pick', docId: x.docId, pick: x.pick });
    paint();
  }

  $('bdGrid').addEventListener('click', (e) => { if (e.target.closest('.bd-auto')) return; const c = e.target.closest('[data-doc]'); if (c) openBig(c.dataset.doc); });
  $('bdGrid').addEventListener('change', (e) => { const id = e.target.dataset?.auto; if (!id) return; if (e.target.checked) skip.delete(id); else skip.add(id); paint(); });
  $('bdBig').addEventListener('click', async (e) => {
    const x = item(big);
    if (e.target === $('bdBig')) { $('bdBig').close(); return; }
    const t = e.target.closest('button');
    if (!t) return;
    if (t.id === 'bdClose') { $('bdBig').close(); return; }
    if (!x) return;
    if (await picker.onClick(e)) return;
    if (t.id === 'bdPrev' || t.id === 'bdNext') { const i = data.items.indexOf(x) + (t.id === 'bdNext' ? 1 : -1); if (data.items[i]) openBig(data.items[i].docId); return; }
    if (t.id === 'bdNoteReset') { notes.delete(x.docId); openBig(x.docId); return; }
    if (t.id === 'bdCopy') {
      const m = $('bdNoteMsg');
      const text = $('bdNote').value;
      try {
        await navigator.clipboard.writeText(text);
        m.className = 'ok';
        m.textContent = `복사했어요. 메신저 창에 붙여 넣어 주세요. ${noteWarn(text)}`;
      } catch { m.className = 'err'; m.textContent = '복사하지 못했어요. 글을 직접 선택해 복사해 주세요.'; }
      return;
    }
    if (t.id === 'bdFiles') {
      filesOpen = !filesOpen;
      openBig(x.docId);
      if (filesOpen && !fileBox.has(x.docId)) fetchFiles(x);
      return;
    }
    if (t.id === 'bdFileRetry') { fetchFiles(x); return; }
    if (t.dataset.fileOpen != null) {
      const f = fileBox.get(x.docId)?.files?.[+t.dataset.fileOpen];
      const r = f ? await send({ board: 'open', docId: x.docId, name: f.name }) : null;
      const m = $('bdNoteMsg');
      if (m) { m.className = r?.ok ? 'ok' : 'err'; m.textContent = r?.ok ? `${f.name}을(를) 열었어요.` : (r?.error || '파일을 열지 못했어요.'); }
      return;
    }
    if (t.id === 'bdFolder') {
      const r = await send({ board: 'folder', docId: x.docId });
      const m = $('bdNoteMsg');
      if (m) { m.className = r?.ok ? 'ok' : 'err'; m.textContent = r?.ok ? '파일 탐색기에서 폴더를 열었어요. 거기서 끌어다 놓아도 돼요.' : (r?.error || '패널의 결재함을 다시 열어 주세요.'); }
    }
  });
  $('bdBig').addEventListener('change', (e) => {
    const x = item(big);
    if (!x) return;
    if (e.target.id === 'bdCard') { x.pick.tkcrd = String(e.target.value || '').trim(); setPick(x); }
    picker.onChange(e);
  });
  $('bdBig').addEventListener('input', (e) => {
    if (e.target.id !== 'bdNote' || !big) return;
    notes.set(big, e.target.value);
    const m = $('bdNoteMsg');
    if (m) { m.className = 'hint'; m.innerHTML = `${noteMsg(e.target.value)}${esc(NOTE_HINT)}`; }
  });
  $('bdBig').addEventListener('keydown', (e) => {
    picker.onKey(e);
  });
  // 파일 끌기: 브라우저가 놓는 곳으로 파일을 건넨다(이름의 ':'는 형식을 깨므로 바꿈)
  $('bdBig').addEventListener('dragstart', (e) => {
    const row = e.target.closest?.('[data-file]');
    if (!row) return;
    const f = fileBox.get(big)?.files?.[+row.dataset.file];
    if (!f?.url) { e.preventDefault(); return; }
    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setData('DownloadURL', `application/octet-stream:${f.name.replace(/[:\\/]/g, '_')}:${f.url}`);
  });
  $('bdStart').addEventListener('click', async () => {
    const auto = autoIds();
    // 처음부터 체크한 문서를 모두 결재한다(교사 결정 2026-11-11, 예전 '처음 1건 뒤 확인'을 없앰). 과제카드를 안 고른 문서는 에듀파인이 막을 수 있어 미리 알린다(실제 2026-11-11)
    const noCard = auto.filter((id) => !item(id)?.pick.tkcrd).length;
    if (auto.length && !confirm(`[결재]를 체크한 ${auto.length}건을 고른 과제카드·공람대로 넣고 모두 결재해요. 결재는 되돌릴 수 없어요.${noCard ? `\n\n과제카드를 고르지 않은 문서가 ${noCard}건 있어요. 에듀파인이 과제카드를 요구하면 그 문서에서 멈춰요.` : ''}`)) return;
    const r = await send({ board: 'start', auto });
    if (!r?.ok) { say(r?.error || '패널의 결재함을 다시 열어 주세요. 패널이 닫혀 있으면 문서를 열 수 없어요.', 'err'); return; }
    data.running = true;
    paint();
    say(auto.length ? '고른 문서를 하나씩 열어 과제카드·공람을 넣고 결재해요. 처음 보는 안내가 뜨면 멈추고 알려 드려요.' : '문서 창이 하나씩 열려요. 보고 [결재]를 직접 눌러 주세요. 창이 닫히면 다음 문서를 열어요.');
  });
  $('bdStop').addEventListener('click', () => { send({ board: 'stop' }); say('이 문서까지 하고 멈춰요…'); });

  chrome.runtime.onMessage.addListener((m) => {
    if (m?.boardRefresh) load();
    if (m?.boardNow !== undefined) { now = m.boardNow; if (m.note) say(m.note, 'chg'); paint(); }
    if (m?.boardStatus) { const x = item(m.boardStatus.docId); if (x) { x.status = m.boardStatus; paint(); } }
    if (m?.boardEnd) { data.running = false; now = null; say(m.boardEnd.text, m.boardEnd.cls || 'hint'); paint(); }
  });

  async function load() {
    await picker.load();
    const r = await send({ board: 'hello' });
    if (!r) { say('패널의 결재함을 다시 열어 주세요.', 'err'); return; }
    data = r;
    paint();
    if (big && $('bdBig').open) openBig(big);
  }
  load();
})();
