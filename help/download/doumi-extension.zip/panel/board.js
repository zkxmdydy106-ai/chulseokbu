// 결재 모아 보기 창(교사 요청 2026-11-05): 읽은 문서를 3×3으로 보고, 칸을 눌러 크게 보며 과제카드·공람자를 고른다. 결재 단추는 없다(결재는 문서 창에서 하나씩).
// 자료는 패널(views/edufine-inbox.js)이 메시지로 준다. 이 창의 메모리에만 있고 저장하지 않는다. 외부 통신 없음.
(() => {
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (id) => document.getElementById(id);
  const send = (m) => new Promise((res) => { try { chrome.runtime.sendMessage(m, (r) => { void chrome.runtime.lastError; res(r || null); }); } catch { res(null); } });
  let data = { items: [], lists: { cards: [], people: [] }, running: false };
  let big = null; // 크게 보는 문서 ID
  let now = null; // 지금 문서 창이 열려 있는 문서

  const say = (t, cls = 'hint') => { const m = $('bdMsg'); m.className = cls; m.textContent = t; };
  const item = (id) => data.items.find((x) => x.docId === id);
  const pickLine = (x) => `<p class="bd-picks"><em>과제카드</em>${x.pick.tkcrd ? `<span class="chg">${esc(x.pick.tkcrd)}</span>` : '없음'} <em>공람</em>${x.pick.cnrs.length ? `<span class="chg">${esc(x.pick.cnrs.join(', '))}</span>` : '없음'}</p>`;

  function cardHtml(x) {
    const st = x.status ? `<span class="bd-status ${esc(x.status.cls)}">${esc(x.status.text)}</span> ` : '';
    const keys = x.unread ? `<p class="bd-keys ${x.error ? 'err' : 'dim'}">${esc(x.error || '아직 읽지 않았어요')}</p>`
      : `<p class="bd-keys">${x.deadline ? `기한 <b>${esc(x.deadline)}</b> ` : ''}${x.submits.length ? `제출 ${esc(x.submits.join(', '))} ` : ''}${x.files.length ? `<span class="dim">붙임 ${x.files.length}</span>` : ''}</p>`;
    return `<button class="bd-card${x.urgent ? ' urgent' : ''}${now === x.docId ? ' now' : ''}${x.status?.final ? ' finished' : ''}" data-doc="${esc(x.docId)}">
      <p class="bd-title">${x.urgent ? '<span class="tag err">긴급</span> ' : ''}${st}${esc(x.title)}</p>
      <p class="bd-meta">${esc([x.dept, x.drafter, x.wait].filter(Boolean).join(' · '))}</p>
      ${keys}
      <div class="bd-body">${esc(x.body)}</div>
      ${pickLine(x)}
    </button>`;
  }

  function paint() {
    $('bdCount').textContent = `${data.items.length}건`;
    $('bdGrid').innerHTML = data.items.map(cardHtml).join('') || '<p class="hint">읽은 문서가 없어요.</p>';
    $('bdStart').disabled = data.running || !data.items.length;
    $('bdStop').hidden = !data.running;
  }

  function bigHtml(x) {
    const i = data.items.indexOf(x);
    const { cards, people } = data.lists;
    const options = cards.includes(x.pick.tkcrd) || !x.pick.tkcrd ? cards : [x.pick.tkcrd, ...cards];
    const card = options.length
      ? `<select id="bdCard"><option value="">고르지 않음</option>${options.map((c) => `<option ${c === x.pick.tkcrd ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select>`
      : `<input id="bdCard" value="${esc(x.pick.tkcrd)}" placeholder="내 과제카드 이름 그대로">`;
    const rows = [['기한', x.deadline], ['제출', x.submits.join(', ')], ['대상', x.targets.join(', ')]].filter(([, v]) => v).map(([k, v]) => `<h3>${k}</h3><div>${esc(v)}</div>`).join('');
    return `<div class="bd-big-in">
      <div class="bd-big-body">
        <h2>${esc(x.title)}</h2>
        <p class="bd-meta">${esc([x.dept, x.drafter, x.docNo, x.wait].filter(Boolean).join(' · '))}</p>
        <pre>${esc(x.body || x.error || '아직 읽지 않았어요')}</pre>
      </div>
      <div class="bd-big-side">
        ${rows}
        ${x.files.length ? `<h3>붙임 ${x.files.length}</h3><ul>${x.files.map((f) => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}
        ${x.related.length ? `<h3>관련</h3><ul>${x.related.map((r) => `<li>${esc(r)}</li>`).join('')}</ul>` : ''}
        <h3>과제카드${x.rec?.tkcrd ? ' <span class="dim">전에 고른 것을 추천했어요</span>' : ''}</h3>
        ${card}
        <h3>공람자</h3>
        <div class="bd-chips">${x.pick.cnrs.map((n) => `<span class="bd-chip">${esc(n)}<button data-cnrs-del="${esc(n)}" aria-label="${esc(n)} 빼기">×</button></span>`).join('') || '<span class="dim">없음</span>'}</div>
        <input id="bdCnrs" list="bdPeople" placeholder="이름을 적고 Enter">
        <datalist id="bdPeople">${[...new Set(people)].map((n) => `<option value="${esc(n)}">`).join('')}</datalist>
        <div class="bd-nav">
          <button class="btn-line small" id="bdPrev" ${i > 0 ? '' : 'disabled'}>이전</button>
          <button class="btn-line small" id="bdNext" ${i < data.items.length - 1 ? '' : 'disabled'}>다음</button>
          <span class="sp"></span>
          <button class="btn-main small" id="bdClose">닫기</button>
        </div>
      </div>
    </div>`;
  }
  function openBig(id) {
    const x = item(id);
    if (!x) return;
    big = id;
    const d = $('bdBig');
    d.innerHTML = bigHtml(x);
    if (!d.open) d.showModal();
  }
  // 고른 값은 패널에 바로 알린다(이 창을 닫아도 남게)
  async function setPick(x) {
    await send({ board: 'pick', docId: x.docId, pick: x.pick });
    paint();
  }
  function addCnrs(x, name) {
    const n = String(name || '').trim();
    if (!n || x.pick.cnrs.includes(n)) return;
    x.pick.cnrs = [...x.pick.cnrs, n];
    setPick(x);
    openBig(x.docId);
    $('bdCnrs').focus();
  }

  $('bdGrid').addEventListener('click', (e) => { const c = e.target.closest('[data-doc]'); if (c) openBig(c.dataset.doc); });
  $('bdBig').addEventListener('click', (e) => {
    const x = item(big);
    if (e.target.id === 'bdClose' || e.target === $('bdBig')) { $('bdBig').close(); return; }
    if (!x) return;
    if (e.target.id === 'bdPrev' || e.target.id === 'bdNext') { const i = data.items.indexOf(x) + (e.target.id === 'bdNext' ? 1 : -1); if (data.items[i]) openBig(data.items[i].docId); return; }
    if (e.target.dataset.cnrsDel) { x.pick.cnrs = x.pick.cnrs.filter((n) => n !== e.target.dataset.cnrsDel); setPick(x); openBig(x.docId); }
  });
  $('bdBig').addEventListener('change', (e) => {
    const x = item(big);
    if (!x) return;
    if (e.target.id === 'bdCard') { x.pick.tkcrd = String(e.target.value || '').trim(); setPick(x); }
    if (e.target.id === 'bdCnrs') addCnrs(x, e.target.value);
  });
  $('bdBig').addEventListener('keydown', (e) => {
    if (e.target.id === 'bdCnrs' && e.key === 'Enter') { e.preventDefault(); const x = item(big); if (x) addCnrs(x, e.target.value); }
  });
  $('bdStart').addEventListener('click', async () => {
    const r = await send({ board: 'start' });
    if (!r?.ok) { say(r?.error || '패널의 결재함을 다시 열어 주세요. 패널이 닫혀 있으면 문서를 열 수 없어요.', 'err'); return; }
    data.running = true;
    paint();
    say('문서 창이 하나씩 열려요. 보고 [결재]를 직접 눌러 주세요. 창이 닫히면 다음 문서를 열어요.');
  });
  $('bdStop').addEventListener('click', () => { send({ board: 'stop' }); say('이 문서까지 하고 멈춰요…'); });

  chrome.runtime.onMessage.addListener((m) => {
    if (m?.boardRefresh) load();
    if (m?.boardNow !== undefined) { now = m.boardNow; if (m.note) say(m.note, 'chg'); paint(); }
    if (m?.boardStatus) { const x = item(m.boardStatus.docId); if (x) { x.status = m.boardStatus; paint(); } }
    if (m?.boardEnd) { data.running = false; now = null; say(m.boardEnd.text, m.boardEnd.cls || 'hint'); paint(); }
  });

  async function load() {
    const r = await send({ board: 'hello' });
    if (!r) { say('패널의 결재함을 다시 열어 주세요.', 'err'); return; }
    data = r;
    paint();
    if (big && $('bdBig').open) openBig(big);
  }
  load();
})();
