// 공람자·과제카드: 전에 고른 대로 문서 창에 채우고(노랗게 표시), 선생님이 결재한 문서의 고른 값을 기억한다(교사 결정 2026-11-02).
// 기억은 storage.local 'eduPicks'(교직원 이름·과제카드 이름, 이 PC만, '저장된 자료'에서 지움). 저장·결재는 선생님이 문서 창에서 한다.
(() => {
  const D = globalThis.Doumi;
  const KEY = 'eduPicks';
  const L = () => D.edufinePickLogic;
  const load = async () => { const v = (await chrome.storage.local.get(KEY))[KEY]; return Array.isArray(v) ? v : []; };
  const last = new Map(); // 문서 ID → 창에 지금 고른 것(결재하면 기억)
  let lastRead = 0;

  // 과제카드·공람 후보 목록: 문서 창을 열어야 읽혀서 한 번 읽으면 이 PC에 남겨 다음에도 바로 고른다
  // (교사 결정 2026-11-11 '이 PC에 남겨 둠' — 2026-11-09 storage.session을 바꿈). 교직원 이름·과제카드 이름, '저장된 자료'에서 지움, [다시 읽기]로 새로
  const LISTS = 'eduLists';
  D.edufineLists = {
    async get() {
      try {
        const v = (await chrome.storage.local.get(LISTS))[LISTS];
        if (v) return v;
        // 옛 판이 브라우저 임시 저장에 둔 목록은 이 PC로 옮긴다
        const old = (await chrome.storage.session.get(LISTS))[LISTS];
        if (old) { await chrome.storage.local.set({ [LISTS]: { ...old, at: Date.now() } }); await chrome.storage.session.remove(LISTS); }
        return old || null;
      } catch { return null; }
    },
    async set(v) { try { await chrome.storage.local.set({ [LISTS]: { cards: v.cards || [], people: v.people || [], at: Date.now() } }); } catch { /* 메모리만으로도 됨 */ } },
  };

  // 결재할 때 에듀파인이 묻는 글 중 도우미가 [확인]을 눌러도 되는 것(교사 결정 2026-11-10: 실제 창에서 본 글만 더함). 그 밖의 물음은 교사가
  D.edufineApproveAsks = ['문서를 결재하시겠습니까?']; // 2026-11-10 실제 처리 창 [확인] 뒤(교사 제보). 그 뒤 '정상적으로 처리되었습니다.'는 [확인]뿐인 알림이라 도우미가 누름

  D.edufinePicks = {
    // 문서 창이 열렸을 때: 비슷한 문서에 고른 것이 있으면 채운다 → { text }
    async suggest(summary) {
      if (!summary) return null;
      return L().suggest(await load(), summary);
    },
    async fill(summary, win) {
      if (!summary) return null;
      const hit = L().suggest(await load(), summary);
      if (!hit) return { text: '' };
      return D.edufinePicks.fillWith(hit, win, '전에 고른 대로 ');
    },
    // 모아 보기에서 고른 값(또는 추천)을 문서 창에 넣는다. 결재는 교사가 창에서
    async fillWith(hit, win, how = '고른 대로 ') {
      if (!hit.tkcrd && !hit.cnrs?.length) return { text: '' };
      const r = await D.pcHelper.fillPicks({ pid: win.pid, tkcrd: hit.tkcrd || '', cnrs: hit.cnrs || [], front: true });
      // 자동 결재 전에 창에 들어갔는지 볼 값(이미 있던 것은 그대로 셈)
      const filled = { tkcrd: r.tkcrd?.ok ? hit.tkcrd || '' : '', cnrs: r.cnrs?.added || [] };
      const bits = [];
      if (r.tkcrd?.ok) bits.push('과제카드');
      if (r.cnrs?.added?.length) bits.push(`공람자 ${r.cnrs.added.length}명`);
      const miss = r.cnrs?.missing || [];
      const twin = r.cnrs?.twin || [];
      const notes = [];
      if (bits.length) notes.push(`${bits.join('·')}를 ${how}채웠어요. 문서 창에서 확인해 주세요.`);
      if (r.inLine?.length) notes.push(`결재선에 있는 ${r.inLine.length}명은 공람에서 뺐어요.`);
      if (miss.length) notes.push(`공람자 ${miss.length}명은 찾지 못했어요. 직접 골라 주세요.`);
      if (twin.length) notes.push(`공람자 ${twin.length}명은 같은 이름이 있어요. 직접 골라 주세요.`);
      if (r.tkcrd?.missing) notes.push('전에 고른 과제카드가 목록에 없어요. 직접 골라 주세요.');
      return { text: notes.join(' '), filled, short: r.ok === false || miss.length + twin.length > 0 || !!r.tkcrd?.missing || (!!r.tkcrd && !r.tkcrd.ok) || (!!r.cnrs && !r.cnrs.ok) };
    },
    // 문서가 열려 있는 동안 지금 고른 것을 읽어 둔다(너무 자주 읽지 않게 5초에 한 번)
    async watch(docId, win) {
      if (Date.now() - lastRead < 5000 || !win?.pid) return;
      lastRead = Date.now();
      const r = await D.pcHelper.readPicks({ pid: win.pid });
      if (r.ok) last.set(docId, { cnrs: r.cnrs || [], tkcrd: (r.tkcrd || [])[0] || '' });
    },
    // 결재했으면 기억
    async commit(docId, summary) {
      const p = last.get(docId);
      last.delete(docId);
      if (!p || !summary) return;
      await chrome.storage.local.set({ [KEY]: L().remember(await load(), summary, p) });
    },
    forget(docId) { last.delete(docId); },
  };
})();
