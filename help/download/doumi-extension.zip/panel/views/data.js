// 저장된 자료 보기 · 전체 자료 삭제 · 설정 · (개발자 모드) 나이스 화면 진단 · 에듀파인 화면 구조 기록
(() => {
  const D = globalThis.Doumi;
  let el, $;
  let armTimer = null;

  async function renderList() {
    const { session, local } = await D.store.overview();
    const items = [];
    for (const [k, v] of Object.entries(session)) {
      if (k === 'work.import') {
        items.push(['넣지 않은 파일', `${v.name} · ${D.lines(v.text).length}줄 · 브라우저를 닫으면 사라짐`, k]);
      } else if (k === 'work.draft') {
        items.push(['쓰던 기안', `${v.subject || '(주제 없음)'} · 브라우저를 닫으면 사라짐`, k]);
      } else if (k === 'guide.now') {
        items.push(['나이스 길잡이', `${(D.guides || []).find((g) => g.id === v.id)?.title || v.id} ${Number(v.i) + 1}단계 · 학생 자료 없음 · 브라우저를 닫으면 사라짐`, k]);
      } else items.push([k, '임시 자료', k]);
    }
    for (const [k, v] of Object.entries(local)) {
      if (k === 'settings') {
        const names = Object.keys(v.verified || {}).filter((id) => v.verified[id]).map((id) => D.screens.get(id)?.title || id);
        const rule = v.levelRule ? ` · 난이도 기준(배점 ${v.levelRule.hard}·${v.levelRule.normal}점)` : '';
        items.push(['설정', `시험 확인한 화면: ${names.join(', ') || '없음'}${rule}${v.dutyFavs?.length ? ` · 복무 즐겨찾기 ${v.dutyFavs.length}개(선생님 본인 복무 신청 내용)` : ''}${v.dutyPhone ? ' · 내 연락처' : ''}${v.devMode ? ' · 개발자 모드' : ''} · 학생 자료 없음`, null]);
      } else if (k === 'todo') {
        items.push(['할 일 목록', `${v.length}개 · 공문 제목·기한·메모 · 지울 때까지 남음`, 'local:todo']);
      } else if (k === 'log') {
        items.push(['입력 기록', `${v.length}번 · 화면 이름·시각만(학생 자료 없음)`, 'local:log']);
      } else if (k === 'draftLines') {
        const n = Object.values(v || {}).reduce((s, l) => s + l.length, 0);
        items.push(['기안 결재선', `${Object.keys(v || {}).join('·')} · 교직원 ${n}명의 이름·직위(학생 자료 없음)`, 'local:draftLines']);
      } else items.push([k, '보관 자료', null]);
    }
    $('#dtList').innerHTML = items.length
      ? `<ul class="stored">${items.map(([name, desc, key]) => `
          <li><div><b>${D.esc(name)}</b><div class="meta">${D.esc(desc)}</div></div>
          ${key ? `<button class="link" data-del="${D.esc(key)}">지우기</button>` : ''}</li>`).join('')}</ul>`
      : '<p class="muted">이 기기에 저장된 자료가 없어요.</p>';
  }

  async function renderSettings() {
    const s = await D.store.settings();
    $('#dtDev').checked = !!s.devMode;
    $('#dtDiag').hidden = !s.devMode;
    const verified = Object.keys(s.verified).filter((id) => s.verified[id]);
    $('#dtVerified').innerHTML = verified.length
      ? verified.map((id) => `<p>${D.esc(D.screens.get(id)?.title || id)} — 전체 입력 열림 <button class="link" data-unverify="${D.esc(id)}">시험 단계로 되돌리기</button></p>`).join('')
      : '<p class="muted">아직 시험 확인한 화면이 없어요. 처음에는 학생 1명만 넣을 수 있어요.</p>';
    $('#dtHard').value = s.levelRule?.hard ?? '';
    $('#dtAcc').value = s.googleAccount || '';
    $('#dtNormal').value = s.levelRule?.normal ?? '';
  }

  // 문항정보표: 파일에 난이도가 없을 때 배점으로 고르는 기준(교사가 정함). 둘 다 비우면 끔.
  async function saveLevelRule() {
    const hard = Number($('#dtHard').value), normal = Number($('#dtNormal').value);
    const on = hard > 0;
    await D.store.saveSettings({ levelRule: on ? { hard, normal: normal > 0 && normal < hard ? normal : 0 } : null });
    $('#dtLevelMsg').textContent = on ? `배점 ${hard}점 이상 어려움${normal > 0 && normal < hard ? `, ${normal}점 이상 보통` : ''}, 나머지 쉬움으로 골라요.` : '자동 선택을 껐어요. 파일의 난이도 칸을 그대로 써요.';
    renderList();
  }

  async function render() {
    await renderList();
    await renderSettings();
  }

  async function clearAll() {
    const btn = $('#dtClear');
    if (!btn.classList.contains('armed')) {
      btn.classList.add('armed');
      btn.textContent = '정말 지울까요? 한 번 더 누르기';
      armTimer = setTimeout(() => { btn.classList.remove('armed'); btn.textContent = '전체 자료 삭제'; }, 4000);
      return;
    }
    clearTimeout(armTimer);
    btn.classList.remove('armed');
    btn.textContent = '전체 자료 삭제';
    await D.store.clearAll();
    D.emit('cleared');
    $('#dtOut').textContent = '';
    $('#dtMsg').textContent = '모두 지웠어요. 나이스에 이미 저장된 자료는 나이스에서 고쳐야 해요.';
    await render();
  }

  // 칼럼 이름·버튼 상태·코드 값 종류만 담는다. 학생 이름·사유 등은 엔진 쪽에서 아예 읽지 않는다.
  async function diagnose() {
    const s = D.state;
    const screen = s.where === 'screen' ? s.screen : null;
    const args = screen
      ? {
        appId: screen.appId,
        datasets: screen.probe?.datasets || [screen.dataset, ...Object.values(screen.types || {}).map((t) => t.dataset)].filter(Boolean),
        probeColumns: screen.probe?.columns || [],
        buttons: screen.probe?.buttons || [screen.save?.button, screen.search?.button, screen.insert?.button, ...(screen.save?.forbidden || [])].filter(Boolean),
        grid: screen.grid || screen.types?.G?.grid,
      }
      : {};
    $('#dtOut').textContent = '진단하는 중…';
    const r = await D.neis.call('diagnose', args);
    const report = {
      도우미: chrome.runtime.getManifest().version,
      일시: new Date().toLocaleString('ko-KR'),
      인식한화면: screen?.id || null,
      결과: r,
    };
    show(report, '화면구조');
  }

  // 에듀파인: 열린 창(문서 새 창 포함)의 틀만. 제목·본문·이름·입력값 없이 본문은 글자 수만.
  async function recordEdufine() {
    $('#dtOut').textContent = '에듀파인 창을 읽는 중…';
    const r = await D.edufine.record();
    show({ 도우미: chrome.runtime.getManifest().version, 일시: new Date().toLocaleString('ko-KR'), 결과: r }, '에듀파인구조');
  }

  let reportName = '화면구조';
  function show(report, name) {
    reportName = name;
    $('#dtOut').textContent = JSON.stringify(report, null, 2);
    $('#dtCopy').hidden = $('#dtSave').hidden = false;
  }

  function saveReport() {
    const blob = new Blob([$('#dtOut').textContent], { type: 'application/json' });
    const a = document.createElement('a');
    const d = new Date();
    a.href = URL.createObjectURL(blob);
    a.download = `${reportName}_${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  D.views.data = {
    init(root) {
      el = root;
      $ = (s) => el.querySelector(s);
      el.innerHTML = `
        <h1 class="page-title">저장된 자료 · 설정</h1>

        <h2>이 기기에 저장된 자료</h2>
        <div id="dtList"></div>
        <button class="danger" id="dtClear">전체 자료 삭제</button>
        <p class="muted" id="dtMsg"></p>

        <h2>시험 단계</h2>
        <div id="dtVerified"></div>

        <h2>문항정보표 난이도</h2>
        <p class="muted">파일에 난이도 칸이 없으면 배점으로 골라요. 비우면 쓰지 않아요.</p>
        <div class="row-btns">배점 <input type="number" id="dtHard" min="0" step="0.5" class="num"> 점 이상 어려움 ·
          <input type="number" id="dtNormal" min="0" step="0.5" class="num"> 점 이상 보통</div>
        <p class="muted" id="dtLevelMsg"></p>

        <h2>구글 계정 (폰 출석부 연결 · 학생 서류 받는 곳 만들기)</h2>
        <p class="muted">이 브라우저에 여러 구글 계정이 로그인돼 있으면, 폰 출석부와 같은 교육청 계정 주소를 적어 두세요. 그 계정으로 열어요(로그인돼 있지 않으면 구글 로그인 화면이 먼저 떠요).</p>
        <div class="row-btns"><input type="email" id="dtAcc" class="txt" placeholder="예: teacher@school.cnehs.kr"></div>
        <p class="muted" id="dtAccMsg"></p>

        <h2>개발자</h2>
        <label class="check"><input type="checkbox" id="dtDev"> 개발자 모드 (화면 진단 버튼 보이기)</label>
        <div id="dtDiag" hidden>
          <p class="muted">지금 나이스 화면의 칼럼 이름, 버튼 상태, 코드 값 종류만 기록해요. 학생 이름·사유는 담지 않아요.</p>
          <div class="row-btns">
            <button class="secondary" id="dtRun">나이스 화면 진단</button>
            <button class="secondary" id="dtEdu">에듀파인 화면 구조 기록</button>
          </div>
          <p class="muted">에듀파인은 문서를 연 채로 누르세요. 열린 에듀파인 창(새 창 포함)의 칸·버튼 이름만 담고, 문서 제목·본문·사람 이름은 담지 않아요(본문은 글자 수만).</p>
          <pre class="diag" id="dtOut"></pre>
          <div class="row-btns">
            <button class="link" id="dtCopy" hidden>복사</button>
            <button class="link" id="dtSave" hidden>파일로 저장</button>
          </div>
        </div>

        <h2>개인정보</h2>
        <p class="muted">학생 자료는 이 컴퓨터의 브라우저 안에서만 다루고, 개발자 서버·AI 서비스 등 외부로 보내지 않아요.
        통신은 나이스·에듀파인, 그리고 선생님이 누를 때만 컴시간(빈 시간 찾기 — 학교 이름·코드만)과 선생님 구글 계정의 출석부 저장소(폰 출석부 — 폰에서 잠근 암호문을 받아 이 PC 메모리에서만 풀어요)·출석부 다리와 해요. 자세한 내용은 docs/개인정보처리방침.md.</p>`;

      $('#dtClear').addEventListener('click', clearAll);
      $('#dtDev').addEventListener('change', async (e) => { await D.store.saveSettings({ devMode: e.target.checked }); renderSettings(); renderList(); });
      $('#dtRun').addEventListener('click', diagnose);
      $('#dtEdu').addEventListener('click', recordEdufine);
      $('#dtHard').addEventListener('change', saveLevelRule);
      $('#dtAcc').addEventListener('change', async (e) => {
        const v = String(e.target.value || '').trim().toLowerCase();
        // 계정 주소 또는 크롬에 로그인한 순서 번호(1~4번째 → 0~3)
        if (v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && !/^[0-3]$/.test(v)) { $('#dtAccMsg').textContent = '계정 주소(또는 0~3 번호) 모양이 달라요.'; return; }
        await D.store.saveSettings({ googleAccount: v });
        if (D.formsMaker) D.formsMaker.account = v;
        $('#dtAccMsg').textContent = v ? (/^\d$/.test(v) ? `크롬 ${+v + 1}번째 계정에서 가져와요.` : `${v} 계정에서 가져와요.`) : '브라우저 기본 계정에서 가져와요.';
      });
      $('#dtNormal').addEventListener('change', saveLevelRule);
      $('#dtCopy').addEventListener('click', () => navigator.clipboard.writeText($('#dtOut').textContent));
      $('#dtSave').addEventListener('click', saveReport);
      el.addEventListener('click', async (e) => {
        const del = e.target.dataset.del;
        if (del?.startsWith('local:')) {
          await chrome.storage.local.remove(del.slice(6));
          D.emit('cleared');
          renderList();
        } else if (del) {
          await chrome.storage.session.remove(del);
          if (del === 'work.import') D.emit('cleared');
          renderList();
        }
        const un = e.target.dataset.unverify;
        if (un) {
          const s = await D.store.settings();
          await D.store.saveSettings({ verified: { ...s.verified, [un]: false } });
          render();
        }
      });
    },
    enter() { $('#dtMsg').textContent = ''; render(); },
  };
})();
