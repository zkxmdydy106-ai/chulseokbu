// F2 할 일 내보내기 화면: ① 적기·목록 → ② 보낼 곳 고르기 → ③ 미리보기(자동 가림, 고칠 수 있음) → [보내기] 한 번
// 목록은 chrome.storage.local(지울 때까지, 교사 결정). 보낼 곳은 extension/destinations/*.js.
(() => {
  const D = globalThis.Doumi;
  D.views = D.views || {};

  let el, $;
  let editing = null;          // 고치는 중인 할 일 id
  let picked = new Set();      // 보낼 할 일 id
  let dests = new Set(['copy']);
  let seen = new Set();        // 목록에 한 번이라도 보인 id(새로 들어온 것만 자동 체크)
  let preview = null;          // { prepared, outs: [{ dest, out }] }
  let results = null;
  let own = 0;                 // 이 화면이 목록을 바꾸는 중(바뀜 알림으로 또 그리지 않게)

  const esc = D.esc;
  const title = (t) => `<h2 class="sec">${esc(t)}</h2>`;
  const isoOf = (ymd) => (/^\d{8}$/.test(ymd) ? `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6)}` : '');
  const hm = (t) => { const d = new Date(t); return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const short = (s, n = 70) => { const t = String(s || '').replace(/\s+/g, ' ').trim(); return t.length > n ? `${t.slice(0, n)}…` : t; };

  function show(state, html) {
    el.dataset.state = state;
    el.innerHTML = html;
  }

  // ① 목록 화면
  async function renderList(msg = '') {
    const items = await D.todo.list();
    for (const it of items) if (!seen.has(it.id)) { seen.add(it.id); if (!it.sentAt) picked.add(it.id); }
    picked = new Set([...picked].filter((id) => items.some((it) => it.id === id)));
    const today = D.todo.todayYmd();
    const ed = editing ? items.find((it) => it.id === editing) : null;
    if (editing && !ed) editing = null;
    const rows = items.map((it) => {
      const when = it.due ? `${esc(D.showDay(it.due))}${it.time ? `<small>${esc(it.time)}</small>` : ''}${it.due < today ? '<small class="err">지났어요</small>' : it.due === today ? '<small class="ok">오늘</small>' : ''}` : '<span class="dim">없음</span>';
      const flags = D.mask(`${it.title}\n${it.memo}`).total;
      return `<tr class="${it.sentAt ? 'same' : ''}">
        <td class="c"><input type="checkbox" data-pick="${esc(it.id)}" ${picked.has(it.id) ? 'checked' : ''} aria-label="보낼 할 일 고르기"></td>
        <td>${when}</td>
        <td><b>${esc(it.title)}</b>${it.memo ? `<small>${esc(short(it.memo))}</small>` : ''}${it.source?.label ? `<small class="dim">${esc(it.source.label)}</small>` : ''}${flags ? `<small class="warn-inline">가릴 곳 ${flags}곳</small>` : ''}${it.sentAt ? `<small class="dim">보냄: ${esc((it.sentTo || []).join(', '))} · ${esc(hm(it.sentAt))}</small>` : ''}</td>
        <td class="c act"><button class="link" data-edit="${esc(it.id)}">고치기</button><button class="link" data-del="${esc(it.id)}">지우기</button></td>
      </tr>`;
    }).join('');
    const destBox = D.destinations.all().map((d) => `<label class="dest"><input type="checkbox" data-dest="${esc(d.id)}" ${dests.has(d.id) ? 'checked' : ''}><span><b>${esc(d.label)}</b><span>${esc(d.sub)}</span></span></label>`).join('');
    const can = picked.size && dests.size;
    show('list', `
      ${title('할 일 내보내기')}
      <form class="form" id="tdForm" autocomplete="off">
        <label for="tdTitle">제목</label><input id="tdTitle" maxlength="120" placeholder="예: 학교폭력 실태조사 결과 제출" value="${esc(ed?.title || '')}">
        <label for="tdDue">기한</label><div class="two"><input type="date" id="tdDue" value="${esc(isoOf(ed?.due || ''))}"><input type="time" id="tdTime" value="${esc(ed?.time || '')}" aria-label="기한 시각(선택)"></div>
        <label for="tdMemo">메모</label><textarea id="tdMemo" rows="3" maxlength="4000" placeholder="제출물·대상·담당 등 (학생 이름은 적지 마세요)">${esc(ed?.memo || '')}</textarea>
        <span></span><div class="two"><button class="btn-main small" id="tdAdd" type="button">${ed ? '고친 내용 저장' : '목록에 더하기'}</button>${ed ? '<button class="btn-line small" type="button" id="tdCancel">고치기 취소</button>' : ''}</div>
      </form>
      ${msg}
      <h3 class="sub">목록 ${items.length ? `<span class="dim">${items.length}개 · 고른 것 ${picked.size}개</span>` : ''}</h3>
      ${items.length ? `<table class="grid todo"><thead><tr><th class="c"><input type="checkbox" id="tdAll" ${picked.size === items.length ? 'checked' : ''} aria-label="모두 고르기"></th><th>기한</th><th>할 일</th><th class="c"></th></tr></thead><tbody>${rows}</tbody></table>`
        : '<p class="muted">아직 할 일이 없어요. 위에 적어 [목록에 더하기]를 누르세요.</p>'}
      <h3 class="sub">보낼 곳 <span class="dim">여러 곳 가능</span></h3>
      <div class="dests">${destBox}</div>
      <div class="actions"><button class="btn-main" id="tdPreview" ${can ? '' : 'disabled'}>미리보기</button><button class="btn-line" data-go="home">처음으로</button></div>
      <p class="hint">목록은 이 PC에 지울 때까지 남아요(저장된 자료 · 설정에서 지울 수 있음). 도우미는 어디로도 직접 보내지 않고, 복사하거나 파일로 받아 선생님이 붙여넣거나 가져와요.</p>`);
  }

  // [더하기]는 폼 제출이 아니라 버튼 누름으로 처리(폼 제출 단계에 기대지 않음). 두 번 눌러도 한 번만.
  let adding = false;
  async function submitForm() {
    if (adding) return;
    adding = true;
    try { await addFromForm(); } finally { adding = false; }
  }
  async function addFromForm() {
    const input = { title: $('#tdTitle').value, due: $('#tdDue').value, time: $('#tdTime').value, memo: $('#tdMemo').value };
    own++;
    const r = await (editing ? D.todo.update(editing, input) : D.todo.add({ ...input, source: '' })).finally(() => own--);
    if (!r.ok) {
      const keep = { ...input };
      await renderList(`<p class="err" id="tdMsg">${esc(r.error)}</p>`);
      $('#tdTitle').value = keep.title; $('#tdDue').value = keep.due; $('#tdTime').value = keep.time; $('#tdMemo').value = keep.memo;
      return;
    }
    if (!editing) picked.add(r.item.id);
    seen.add(r.item.id);
    editing = null;
    await renderList('<p class="ok" id="tdMsg">목록에 넣었어요.</p>');
    $('#tdTitle')?.focus();
  }

  // ③ 미리보기: 고른 할 일을 가린 뒤 보낼 곳마다 실제로 나갈 글
  async function renderPreview() {
    const items = (await D.todo.list()).filter((it) => picked.has(it.id));
    if (!items.length) { renderList(); return; }
    const prepared = D.destinations.prepare(items);
    const now = new Date();
    const outs = D.destinations.all().filter((d) => dests.has(d.id)).map((dest) => ({ dest, out: D.destinations.build(dest, prepared, { now }) }));
    preview = { prepared, outs, now };
    const any = outs.some((o) => !o.out.empty);
    const boxes = outs.map(({ dest, out }, i) => `
      <div class="group">
        <h4>${esc(dest.label)} ${out.empty ? '<span class="tag dim">보낼 것 없음</span>' : `<span class="tag">${out.ids.length}개</span>`}</h4>
        ${out.note ? `<p class="warn">${esc(out.note)}</p>` : ''}
        ${out.empty ? '' : dest.editable ? `<textarea class="out" data-out="${i}" rows="${Math.min(14, out.text.split('\n').length + 1)}" aria-label="${esc(dest.label)} 미리보기">${esc(out.text)}</textarea>` : `<pre class="diag">${esc(out.show || out.text)}</pre>`}
      </div>`).join('');
    show('preview', `
      ${title('미리보기')}
      <table class="info"><tr><th>할 일</th><td>${items.length}개</td></tr><tr><th>보낼 곳</th><td>${esc(outs.map((o) => o.dest.label).join(', '))}</td></tr>
        <tr><th>가린 것</th><td>${prepared.total ? `<span class="chg">${prepared.total}곳</span> <span class="dim">${esc(D.mask.summary(prepared.kinds))}</span>` : '<span class="dim">없음</span>'}</td></tr></table>
      <p class="warn">학생 이름·번호가 보이면 지우고 보내 주세요. 자동 가리기는 주민번호·전화·계좌처럼 모양이 정해진 것만 찾아요.</p>
      ${boxes}
      <div class="actions"><button class="btn-main" id="tdSend" ${any ? '' : 'disabled'}>보내기</button><button class="btn-line" id="tdBack">목록으로</button></div>`);
  }

  // 패널 안에서만: 클립보드 · 내려받기
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); return true; } catch { /* 아래 방법으로 */ }
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;left:-9999px;top:0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    ta.remove();
    return ok;
  }
  function download(name, text, mime) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: mime }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  }
  const ctx = () => ({ now: preview?.now || new Date(), copy, download });

  async function send() {
    if (!preview) return;
    $('#tdSend').disabled = true;
    // 교사가 고친 글을 반영
    for (const ta of el.querySelectorAll('textarea[data-out]')) preview.outs[+ta.dataset.out].out.text = ta.value;
    results = [];
    for (const { dest, out } of preview.outs) {
      if (out.empty) continue;
      let r;
      try { r = await dest.send(out, ctx()); } catch (e) { r = { ok: false, message: `보내지 못했어요: ${e?.message || e}` }; }
      results.push({ dest, out, ...r });
    }
    const sentIds = [...new Set(results.filter((r) => r.ok).flatMap((r) => r.out.ids))];
    if (sentIds.length) await D.todo.markSent(sentIds, results.filter((r) => r.ok).map((r) => r.dest.label));
    renderDone(sentIds);
  }

  function renderDone(sentIds) {
    const rows = results.map((r, i) => `<tr><td>${esc(r.dest.label)}</td><td>${r.ok ? '<span class="ok">완료</span>' : '<span class="err">안 됨</span>'} ${esc(r.message)}
      <button class="link" data-again="${i}">${r.dest.kind === 'copy' ? '다시 복사' : '다시 받기'}</button></td></tr>`).join('');
    const failed = results.filter((r) => !r.ok);
    show('done', `
      ${title('할 일 내보내기')}
      <table class="grid sent"><thead><tr><th>보낼 곳</th><th>결과</th></tr></thead><tbody>${rows}</tbody></table>
      ${failed.some((r) => r.dest.kind === 'copy') ? `<textarea class="out" id="tdFallback" rows="6" aria-label="복사할 글">${esc(failed.find((r) => r.dest.kind === 'copy').out.text)}</textarea>` : ''}
      ${sentIds.length ? `<div class="confirm"><p>보낸 할 일 ${sentIds.length}개를 목록에서 지울까요? 남겨 두면 '보냄' 표시가 붙어요.</p>
        <div class="actions"><button class="btn-main small" id="tdDropSent">목록에서 지우기</button><button class="btn-line small" id="tdKeep">남겨 두기</button></div></div>` : ''}
      <div class="actions"><button class="btn-line" id="tdBack">목록으로</button><button class="btn-line" data-go="home">처음으로</button></div>`);
    const fb = $('#tdFallback');
    if (fb) { fb.focus(); fb.select(); }
    el.dataset.sent = sentIds.join(',');
  }

  async function onClick(e) {
    const t = e.target;
    if (t.dataset.edit) { editing = t.dataset.edit; await renderList(); $('#tdTitle').focus(); return; }
    if (t.dataset.del) { own++; await D.todo.remove(t.dataset.del).finally(() => own--); picked.delete(t.dataset.del); if (editing === t.dataset.del) editing = null; renderList(); return; }
    if (t.dataset.again != null) {
      const r = results[+t.dataset.again];
      const again = await r.dest.send(r.out, ctx());
      t.textContent = again.ok ? (r.dest.kind === 'copy' ? '복사했어요' : '받았어요') : '안 됐어요';
      return;
    }
    switch (t.id) {
      case 'tdAdd': submitForm(); break;
      case 'tdCancel': editing = null; renderList(); break;
      case 'tdPreview': renderPreview(); break;
      case 'tdBack': preview = null; renderList(); break;
      case 'tdSend': send(); break;
      case 'tdDropSent': {
        const ids = (el.dataset.sent || '').split(',').filter(Boolean);
        await D.todo.remove(ids);
        ids.forEach((id) => picked.delete(id));
        renderList(`<p class="ok" id="tdMsg">보낸 할 일 ${ids.length}개를 지웠어요.</p>`);
        break;
      }
      case 'tdKeep': for (const id of (el.dataset.sent || '').split(',')) picked.delete(id); renderList(); break;
      default:
    }
  }

  async function onChange(e) {
    const t = e.target;
    if (t.dataset.pick) { t.checked ? picked.add(t.dataset.pick) : picked.delete(t.dataset.pick); }
    else if (t.id === 'tdAll') { const items = await D.todo.list(); picked = t.checked ? new Set(items.map((it) => it.id)) : new Set(); }
    else if (t.dataset.dest) {
      t.checked ? dests.add(t.dataset.dest) : dests.delete(t.dataset.dest);
      await D.store.saveSettings({ todoDests: [...dests] });
    } else return;
    const keep = { title: $('#tdTitle')?.value, due: $('#tdDue')?.value, time: $('#tdTime')?.value, memo: $('#tdMemo')?.value };
    await renderList();
    if (keep.title != null) { $('#tdTitle').value = keep.title; $('#tdDue').value = keep.due; $('#tdTime').value = keep.time; $('#tdMemo').value = keep.memo; }
  }

  D.views.todo = {
    helpId: () => 'todo',
    init(root) {
      el = root;
      $ = (s) => el.querySelector(s);
      el.addEventListener('click', onClick);
      el.addEventListener('change', onChange);
      el.addEventListener('submit', (e) => e.preventDefault());
      // 제목·기한 칸에서 Enter = [더하기](메모 칸은 줄 바꿈)
      el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing && e.target.matches?.('#tdForm input')) { e.preventDefault(); submitForm(); } });
      // 다른 기능이 Doumi.todo.add로 넣으면 목록 화면을 새로 그림(입력 중인 칸은 지키기)
      D.todo.onChange(() => { if (!own && !el.hidden && el.dataset.state === 'list' && !editing && !$('#tdTitle')?.value) renderList(); });
    },
    async enter() {
      show('loading', `${title('할 일 내보내기')}<p class="muted">목록 불러오는 중…</p>`);
      const s = await D.store.settings();
      const known = new Set(D.destinations.all().map((d) => d.id));
      if (Array.isArray(s.todoDests)) dests = new Set(s.todoDests.filter((id) => known.has(id)));
      preview = null;
      renderList();
    },
    on(type) { if (type === 'cleared' && !el.hidden) { picked = new Set(); seen = new Set(); editing = null; preview = null; renderList(); } },
  };
})();
