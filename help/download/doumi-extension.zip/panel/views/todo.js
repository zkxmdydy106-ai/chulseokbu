// F2 할 일 화면(교사 결정 2026-11-02: 밖으로 보내지 않고 패널에서 본다): 기한순 묶음 · 끝냄 체크 · 원문 문서 열기 · 붙임 받기/열기.
// 목록은 chrome.storage.local(지울 때까지, 교사 결정). 문서 본문은 들어 있지 않다.
(() => {
  const D = globalThis.Doumi;
  D.views = D.views || {};

  let el, $;
  let editing = null;   // 고치는 중인 할 일 id
  let adding = false;   // 적는 칸 열림
  let own = 0;          // 이 화면이 목록을 바꾸는 중(바뀜 알림으로 또 그리지 않게)
  const notes = {};     // 할 일 id → 줄 아래 안내(문서 찾기·파일 받기 결과)

  const esc = D.esc;
  const title = (t) => `<h2 class="sec">${esc(t)}</h2>`;
  const isoOf = (ymd) => (/^\d{8}$/.test(ymd) ? `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6)}` : '');

  function show(state, html) {
    el.dataset.state = state;
    el.innerHTML = html;
  }

  function fileHtml(it) {
    const files = it.files || [];
    if (!files.length) return '';
    const rows = files.map((f, i) => `<li><span class="td-fname">${esc(f.name)}</span>${f.path
      ? ` <button class="link" data-file-open="${esc(it.id)}|${i}">열기</button>`
      : ` <button class="link" data-file-get="${esc(it.id)}|${i}" title="받아서 바로 열어요">열기</button>`}</li>`).join('');
    const saved = files.some((f) => f.path);
    return `<ul class="td-files">${rows}</ul>
      <p class="td-link">${files.length > 1 && files.some((f) => !f.path) ? `<button class="link" data-file-all="${esc(it.id)}">모두 받기</button>` : ''}${saved ? `<button class="link" data-folder="${esc(it.id)}">폴더 열기</button>` : ''}</p>`;
  }

  function row(it, now, g) {
    const n = notes[it.id];
    const when = it.due
      ? `<b>${esc(D.showDay(it.due))}</b>${it.time ? ` ${esc(it.time)}` : ''} <span class="td-left ${g === 'late' ? 'err' : g === 'today' ? 'ok' : 'dim'}">${esc(D.todo.dayLabel(it.due, now))}</span>`
      : '<span class="dim">기한 없음</span>';
    const canOpen = it.source?.docId || it.source?.docNo;
    return `<li class="td${g === 'late' ? ' late' : ''}${it.doneAt ? ' seen' : ''}" data-id="${esc(it.id)}">
      <input type="checkbox" class="td-check" data-done="${esc(it.id)}" ${it.doneAt ? 'checked' : ''} aria-label="끝낸 일로 표시">
      <div class="td-main">
        <p class="td-when">${when}</p>
        <p class="td-title">${esc(it.title)}</p>
        ${it.memo ? `<p class="td-memo">${esc(it.memo)}</p>` : ''}
        ${fileHtml(it)}
        ${n ? `<p class="small ${n.cls}">${esc(n.text)}</p>` : ''}
        <p class="td-acts">${canOpen ? `<button class="link" data-doc-open="${esc(it.id)}">문서 열기</button>` : ''}<button class="link" data-edit="${esc(it.id)}">고치기</button><button class="link" data-del="${esc(it.id)}">지우기</button>${it.source?.label ? `<span class="dim small">${esc(it.source.label)}</span>` : ''}</p>
      </div>
    </li>`;
  }

  async function renderList(msg = '') {
    const items = await D.todo.list();
    const now = new Date();
    const g = D.todo.group(items, now);
    const c = D.todo.counts(items, now);
    const ed = editing ? items.find((it) => it.id === editing) : null;
    if (editing && !ed) editing = null;
    const open = adding || !!ed;
    const sections = D.todo.GROUPS.filter(([k]) => g[k].length).map(([k, name]) => `
      <h3 class="sub td-head ${k}">${esc(name)} <span class="dim">${g[k].length}</span></h3>
      <ul class="docs">${g[k].map((it) => row(it, now, k)).join('')}</ul>`).join('');
    const done = g.done.length ? `
      <details class="td-done"><summary>끝낸 일 <span class="dim">${g.done.length}</span></summary>
        <ul class="docs">${g.done.map((it) => row(it, now, 'done')).join('')}</ul>
        <p><button class="btn-line small" id="tdClearDone">끝낸 일 지우기</button></p>
      </details>` : '';
    show('list', `
      ${title('할 일')}
      <table class="info"><tr><th>남은 일</th><td>${c.open ? `<b>${c.open}개</b>${c.late ? ` · <span class="err">지남 ${c.late}</span>` : ''}${c.today ? ` · <span class="ok">오늘 ${c.today}</span>` : ''}${c.soon ? ` · 일주일 안 ${c.soon}` : ''}` : '없음'}</td></tr></table>
      ${msg}
      ${open ? `<form class="form td-form" id="tdForm" autocomplete="off">
        <label for="tdTitle">제목</label><input id="tdTitle" maxlength="120" placeholder="예: 학교폭력 실태조사 결과 제출" value="${esc(ed?.title || '')}">
        <label for="tdDue">기한</label><div class="two"><input type="date" id="tdDue" value="${esc(isoOf(ed?.due || ''))}"><input type="time" id="tdTime" value="${esc(ed?.time || '')}" aria-label="기한 시각(선택)"></div>
        <label for="tdMemo">메모</label><textarea id="tdMemo" rows="3" maxlength="4000" placeholder="제출물·대상·담당 등 (학생 이름은 적지 마세요)">${esc(ed?.memo || '')}</textarea>
        <span></span><div class="two"><button class="btn-main small" id="tdAdd" type="button">${ed ? '고친 내용 저장' : '목록에 더하기'}</button><button class="btn-line small" type="button" id="tdCancel">${ed ? '고치기 취소' : '닫기'}</button></div>
      </form>` : ''}
      ${sections || (g.done.length ? '<p class="muted">남은 일이 없어요.</p>' : '<p class="muted">아직 할 일이 없어요. 에듀파인 [결재함 보기 → 모두 읽기]로 공문을 읽으면 기한·제출·붙임이 정리되어 여기로 와요.</p>')}
      ${done}
      <div class="actions">${open ? '' : '<button class="btn-line" id="tdOpen">직접 더하기</button>'}<button class="btn-line" data-go="home">처음으로</button></div>
      <p class="hint">할 일은 이 PC에 지울 때까지 남고 어디로도 보내지 않아요(저장된 자료 · 설정에서 지울 수 있음).</p>`);
  }

  // [더하기]는 폼 제출이 아니라 버튼 누름으로 처리(폼 제출 단계에 기대지 않음). 두 번 눌러도 한 번만.
  let submitting = false;
  async function submitForm() {
    if (submitting) return;
    submitting = true;
    try { await addFromForm(); } finally { submitting = false; }
  }
  async function addFromForm() {
    const input = { title: $('#tdTitle').value, due: $('#tdDue').value, time: $('#tdTime').value, memo: $('#tdMemo').value };
    own++;
    const r = await (editing ? D.todo.update(editing, input) : D.todo.add({ ...input, source: '' })).finally(() => own--);
    if (!r.ok) {
      const keep = { ...input };
      await renderList(`<p class="err" id="tdMsg">${esc(r.error)}</p>`);
      $('#tdTitle').value = keep.title; $('#tdDue').value = keep.due; $('#tdTime').value = keep.time; $('#tdMemo').value = keep.memo;
      return;
    }
    const was = editing;
    editing = null;
    adding = !was;
    await renderList('<p class="ok" id="tdMsg">목록에 넣었어요.</p>');
    $('#tdTitle')?.focus();
  }

  // 원문 문서: 결재대기에 있으면 그 문서를 열고, 없으면 문서등록대장에서 찾아 준다(문서는 교사가 에듀파인에서 연다)
  async function openDoc(id) {
    const it = (await D.todo.list()).find((x) => x.id === id);
    if (!it) return;
    notes[id] = { cls: 'dim', text: '문서를 찾는 중…' };
    await renderList();
    let r;
    try { r = await D.edufineInbox.openFromTodo(it); } catch { r = { ok: false, error: '에듀파인 화면을 읽지 못했어요. 에듀파인 탭을 확인해 주세요.' }; }
    notes[id] = !r.ok ? { cls: 'err', text: r.error }
      : r.opened ? { cls: 'ok', text: '결재대기에서 이 문서를 열었어요.' }
      : r.total === 0 ? { cls: 'warn', text: '문서등록대장에 없어요(작년 3월보다 오래된 문서일 수 있어요).' }
      : r.total ? { cls: 'ok', text: `문서등록대장에서 ${r.total}건 찾았어요. 에듀파인 화면에서 제목을 눌러 열어 주세요.` }
      : { cls: 'dim', text: '문서등록대장에서 검색했어요. 에듀파인 화면에서 결과를 봐 주세요.' };
    renderList();
  }

  // 붙임 받기·열기: PC 도우미(panel/edufine-files.js). 도우미가 없으면 설치 안내
  async function fileAct(kind, key) {
    const [id, i] = key.split('|');
    const it = (await D.todo.list()).find((x) => x.id === id);
    if (!it) return;
    if (!D.edufineFiles) { notes[id] = { cls: 'err', text: '이 판에서는 아직 붙임을 받을 수 없어요.' }; renderList(); return; }
    notes[id] = { cls: 'dim', text: kind === 'open' ? '여는 중…' : '받는 중…' };
    await renderList();
    let r;
    try {
      if (kind === 'all') r = await D.edufineFiles.saveAll(it);
      else if (kind === 'get') r = await (D.edufineFiles.saveOpen ? D.edufineFiles.saveOpen(it, it.files[+i]) : D.edufineFiles.save(it, it.files[+i]));
      else if (kind === 'open') r = await D.edufineFiles.open(it.files[+i]);
      else r = await D.edufineFiles.folder(it);
    } catch { r = { ok: false, error: '파일을 다루지 못했어요.' }; }
    notes[id] = r.ok ? { cls: 'ok', text: r.text || '' } : { cls: 'err', text: r.error };
    renderList();
  }

  async function onClick(e) {
    const t = e.target;
    if (t.dataset.edit) { editing = t.dataset.edit; adding = false; await renderList(); $('#tdTitle').focus(); return; }
    if (t.dataset.del) { own++; await D.todo.remove(t.dataset.del).finally(() => own--); delete notes[t.dataset.del]; if (editing === t.dataset.del) editing = null; renderList(); return; }
    if (t.dataset.docOpen) { openDoc(t.dataset.docOpen); return; }
    if (t.dataset.fileGet) { fileAct('get', t.dataset.fileGet); return; }
    if (t.dataset.fileOpen) { fileAct('open', t.dataset.fileOpen); return; }
    if (t.dataset.fileAll) { fileAct('all', t.dataset.fileAll); return; }
    if (t.dataset.folder) { fileAct('folder', t.dataset.folder); return; }
    switch (t.id) {
      case 'tdOpen': adding = true; await renderList(); $('#tdTitle').focus(); break;
      case 'tdAdd': submitForm(); break;
      case 'tdCancel': editing = null; adding = false; renderList(); break;
      case 'tdClearDone': own++; await D.todo.clearDone().finally(() => own--); renderList('<p class="ok" id="tdMsg">끝낸 일을 지웠어요.</p>'); break;
      default:
    }
  }

  async function onChange(e) {
    const id = e.target.dataset.done;
    if (!id) return;
    own++;
    await D.todo.setDone(id, e.target.checked).finally(() => own--);
    renderList();
  }

  D.views.todo = {
    helpId: () => 'todo',
    init(root) {
      el = root;
      $ = (s) => el.querySelector(s);
      el.addEventListener('click', onClick);
      el.addEventListener('change', onChange);
      el.addEventListener('submit', (e) => e.preventDefault());
      // 제목·기한 칸에서 Enter = [더하기](메모 칸은 줄 바꿈)
      el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing && e.target.matches?.('#tdForm input')) { e.preventDefault(); submitForm(); } });
      // 다른 기능이 Doumi.todo.add로 넣으면 목록 화면을 새로 그림(입력 중인 칸은 지키기)
      D.todo.onChange(() => { if (!own && !el.hidden && el.dataset.state === 'list' && !editing && !$('#tdTitle')?.value) renderList(); });
    },
    async enter() {
      show('loading', `${title('할 일')}<p class="muted">목록 불러오는 중…</p>`);
      renderList();
    },
    on(type) { if (type === 'cleared' && !el.hidden) { editing = null; adding = false; renderList(); } },
  };
})();
