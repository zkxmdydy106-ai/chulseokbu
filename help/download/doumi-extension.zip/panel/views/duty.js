// 복무 신청 즐겨찾기(2026-10-30 교사 결정 — docs/specs/복무-신청-즐겨찾기.md)
// 목록(종류별 즐겨찾기 · 만들기 · [이 창 내용을 즐겨찾기로]) → 날짜 고르기(오늘 기본, 여러 날) → [나이스에 채우기] → 결과.
// 나이스는 [나이스에 채우기]를 누를 때만 움직이고, [승인요청]은 선생님이 나이스 창에서 누른다(도우미는 안 누름).
// 즐겨찾기는 이 PC 설정(chrome.storage.local dutyFavs)에만 — 선생님 본인 복무 신청 내용, 학생 자료 없음.
(() => {
  const D = globalThis.Doumi;
  D.views = D.views || {};
  const esc = (s) => D.esc(s);
  let el, $;
  let mode = 'list'; // list · edit · fill · busy · done
  let favs = [];
  let phone = ''; // 내 연락처(이 PC 설정에만) — 근무상황·출장 연락처 칸에 저절로
  let day = null; // 기본 근무 시각(이 PC 설정에만)
  let fillTime = { from: '', to: '' }; // 이번 신청에만 쓰는 시각
  let editing = null; // 고치는 즐겨찾기(새것은 _new)
  let current = null; // 채울 즐겨찾기
  let dates = [];
  let month = '';
  let result = null;
  let note = '';
  let busy = false;
  let pending = false; // open()으로 들어오는 중(enter가 목록으로 되돌리지 않게)

  const U = () => D.duty;
  const today = () => U().ymdOf(new Date());
  const screenOf = (kind) => D.screens.get(U().KINDS[kind].screenId);
  const md = (ymd) => `${+ymd.slice(4, 6)}/${+ymd.slice(6)}(${'일월화수목금토'[new Date(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6)).getDay()]})`;
  const title = (t) => `<h1 class="page-title">${esc(t)}</h1>`;
  async function load() { const s = await D.store.settings(); favs = (s.dutyFavs || []).filter((f) => f && U().KINDS[f.kind]); phone = s.dutyPhone || ''; day = s.dutyDay || U().DAY; }
  const withTime = (f) => ({ ...f, ...fillTime });
  // 시·분 고르는 칸(교사 요청 2026-11-04: 브라우저 시각 칸은 오전·오후를 넘겨야 해 불편). 분은 5분 단위, 이미 있는 값은 그대로 보임
  function timeSel(id, value) {
    const p = U().parseTime(value) || { h: '', m: '' };
    const two = (n) => String(n).padStart(2, '0');
    const hours = Array.from({ length: 18 }, (_, i) => two(i + 6)), mins = Array.from({ length: 12 }, (_, i) => two(i * 5));
    if (p.h && !hours.includes(p.h)) hours.push(p.h);
    if (p.m && !mins.includes(p.m)) mins.push(p.m);
    const list = (arr, cur) => arr.sort().map((v) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${v}</option>`).join('');
    return `<span class="dy-time"><select id="${id}H" aria-label="시">${list(hours, p.h)}</select><i>:</i><select id="${id}M" aria-label="분">${list(mins, p.m)}</select></span>`;
  }
  const timeOf = (id) => ($(`#${id}H`) ? `${$(`#${id}H`).value}:${$(`#${id}M`).value}` : undefined);
  const dayChip = () => `<button type="button" class="btn-text" data-day-time>근무 시간 ${esc(U().hm(day.from))}~${esc(U().hm(day.to))}</button>`;
  const saveFavs = () => D.store.saveSettings({ dutyFavs: favs });

  function render() {
    if (!el) return;
    if (mode === 'edit') return renderEdit();
    if (mode === 'fill') return renderFill();
    if (mode === 'done') return renderDone();
    if (mode === 'busy') return;
    renderList();
  }

  function renderList() {
    const K = U().KINDS;
    el.innerHTML = `
      ${title('복무 신청')}
      <p class="hint">자주 쓰는 신청을 즐겨찾기로 두면 날짜만 골라 나이스 신청 창을 그대로 채워요. <b>[승인요청]은 선생님이 나이스 창에서 확인하고 눌러요</b> — 도우미는 누르지 않아요.</p>
      ${note}
      <div class="dy-phone dy-day"><b>근무 시간</b>${timeSel('dyDayF', day.from)} ~ ${timeSel('dyDayT', day.to)}<button class="btn-line small" id="dyDaySave">저장</button><span class="dim">새 즐겨찾기의 시작·끝 기본 시각이에요. 이 PC에만 저장돼요.</span></div>
      <div class="dy-phone"><label for="dyPhone"><b>내 연락처</b></label><input id="dyPhone" inputmode="tel" value="${esc(phone)}" placeholder="010-0000-0000" autocomplete="off"><button class="btn-line small" id="dyPhoneSave">저장</button><span class="dim">출장·연가·조퇴 연락처 칸에 저절로 들어가요. 이 PC에만 저장돼요.</span></div>
      ${Object.entries(K).map(([kind, k]) => {
        const mine = favs.filter((f) => f.kind === kind);
        return `<div class="task-group"><h3>${esc(k.label)}</h3>
          ${mine.length ? `<div class="dy-list">${mine.map((f) => `<div class="dy-fav">
            <button class="task" data-fill="${esc(f.id)}"><b>${esc(U().nameOf(f))}</b><span>${esc(U().summary(f))}</span></button>
            <span class="dy-ops"><button class="btn-text" data-edit="${esc(f.id)}">고치기</button><button class="btn-text danger" data-del="${esc(f.id)}">지우기</button></span>
          </div>`).join('')}</div>` : ''}
          <div class="actions"><button class="btn-line small" data-new="${kind}">+ ${esc(k.label)} 즐겨찾기</button></div></div>`;
      }).join('')}
      <div class="dy-capture">
        <b>나이스 창 내용을 즐겨찾기로</b>
        <p class="dim">나이스 [기본 메뉴 → 복무]의 신청 창(초과근무·근무상황·출장)에 평소처럼 한 줄 적어 둔 채로 누르세요. 승인요청은 안 해도 돼요.</p>
        <button class="btn-line small" id="dyCapture">이 창 내용을 즐겨찾기로</button>
      </div>`;
  }

  // ── 만들기·고치기 ──
  const opt = (map, cur) => Object.entries(map).map(([v, l]) => `<option value="${esc(v)}" ${String(cur) === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('');
  function renderEdit(errs = []) {
    const f = editing;
    const K = U();
    const time = () => `<label>시각</label><div class="two dy-times">${timeSel('dyFrom', f.from || day.from)} ~ ${timeSel('dyTo', f.to || day.to)}${f.kind === 'overtime' ? '' : dayChip()}</div>`;
    const input = (id, label, v, ph = '') => `<label>${esc(label)}</label><input id="${id}" value="${esc(v || '')}" placeholder="${esc(ph)}" autocomplete="off">`;
    let body = '';
    if (f.kind === 'overtime') {
      const ded = K.parseTime(f.deduct) || { h: '00', m: '00' };
      body = `${time()}
        <label>방과후 차감</label><div class="two dy-ded"><input type="number" id="dyDedH" min="0" max="9" value="${+ded.h}"> 시간 <input type="number" id="dyDedM" min="0" max="59" step="10" value="${+ded.m}"> 분</div>
        <label>하여야 할 일</label><textarea id="dyTodo" rows="2" placeholder="예: 기숙사생 야간자율학습 감독">${esc(f.todo || '')}</textarea>
        ${f.typ && f.typ !== '1' ? `<label>종별</label><span class="dim">나이스 종별 코드 ${esc(f.typ)}(창에서 가져온 그대로)</span>` : ''}`;
    } else if (f.kind === 'leave') {
      const sub = K.LEAVE_SCLF[f.lclf] || {};
      const subs = f.sclf && !sub[f.sclf] ? { ...sub, [f.sclf]: `코드 ${f.sclf}` } : sub;
      const dtl = K.LEAVE_DTL[f.sclf];
      body = `<label>종류</label><div class="two"><select id="dyLclf">${opt(K.LEAVE_LCLF, f.lclf)}</select><select id="dySclf">${opt(subs, f.sclf)}</select></div>
        ${dtl ? `<label>세부 항목</label><select id="dyDtl"><option value="">골라 주세요</option>${opt(dtl, f.dtl || '')}</select>` : ''}
        ${time()}
        ${f.lclf === 'W01' ? `<label>연가 사유</label><select id="dyAvRsn">${opt(K.AV_RSN, f.avRsn || '')}</select>` : ''}
        ${input('dyReason', '사유', f.reason, K.isOutCode(f.sclf) ? '비우면 개인 용무' : '예: 병원 진료')}
        ${input('dyDesti', '목적지', f.desti)}
        ${input('dyEmg', '비상연락처', f.emg, phone ? `비우면 내 연락처 ${phone}` : '비우면 내 연락처(복무 신청 첫 화면)')}`;
    } else {
      body = `<label>구분</label><select id="dySc">${opt(K.TRIP_SC, f.sc)}</select>
        ${time()}
        ${input('dyPlace', '출장지', f.place, '예: 논산계룡교육지원청')}
        ${input('dyPurpose', '목적', f.purpose, '예: 교과협의회')}
        ${input('dyMove', '이동사항', f.move, '예: 자가용')}
        <label>선택</label><div class="two"><label class="check"><input type="checkbox" id="dyCar" ${f.car === 'Y' ? 'checked' : ''}> 공용차량 이용</label><label class="check"><input type="checkbox" id="dyPay" ${f.pay === 'Y' ? 'checked' : ''}> 여비 지급하지 않음</label></div>
        ${input('dyEmg', '연락처', f.emg, phone ? `비우면 내 연락처 ${phone}` : '비우면 내 연락처(복무 신청 첫 화면)')}`;
    }
    el.innerHTML = `
      ${title(`${K.KINDS[f.kind].label} 즐겨찾기`)}
      <div class="form dy-form">
        ${input('dyName', '이름', f.name, `예: ${f.kind === 'overtime' ? '야자 감독' : f.kind === 'leave' ? '병원 조퇴' : '교육청 회의'}`)}
        ${body}
      </div>
      <div class="form dy-form" style="margin-top:6px"><label>결재선</label><select id="dyLine">${opt(K.LINE_NAMES, f.line || 'auto')}</select></div>
      <p class="dim">자동: ${f.kind === 'overtime' ? '교감 → 교장' : f.kind === 'trip' ? '관내 교감 · 관외 교감 → 교장' : '선생님이 직접 골라요'}. [승인요청]을 누르면 뜨는 결재 창에 넣어 드려요. [상신]은 선생님이 눌러요.</p>
      ${f.kind === 'trip' ? '<p class="dim">여비 지급 기관·출장지 [찾기]·출장자(동행자)는 나이스 창 기본값 그대로예요. 바꿀 것이 있으면 창에서 직접 해 주세요.</p>' : ''}
      ${errs.map((e) => `<p class="err">${esc(e)}</p>`).join('')}
      <div class="actions"><button class="btn-main" id="dySave">저장</button><button class="btn-line" id="dyCancel">취소</button></div>`;
  }
  function readForm() {
    const f = { ...editing };
    const v = (id) => ($(`#${id}`) ? String($(`#${id}`).value || '').trim() : undefined);
    f.name = v('dyName') || '';
    f.line = v('dyLine') || 'auto';
    if ($('#dyFromH')) { f.from = timeOf('dyFrom'); f.to = timeOf('dyTo'); }
    if (f.kind === 'overtime') {
      f.todo = v('dyTodo');
      const h = Math.max(0, +v('dyDedH') || 0), m = Math.max(0, +v('dyDedM') || 0);
      f.deduct = h || m ? `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}` : '';
    }
    if (f.kind === 'leave') Object.assign(f, { lclf: v('dyLclf'), sclf: v('dySclf'), dtl: v('dyDtl') || '', avRsn: v('dyAvRsn') || '', reason: v('dyReason'), desti: v('dyDesti'), emg: v('dyEmg') });
    if (f.kind === 'trip') Object.assign(f, { sc: v('dySc'), place: v('dyPlace'), purpose: v('dyPurpose'), move: v('dyMove'), emg: v('dyEmg'), car: $('#dyCar').checked ? 'Y' : 'N', pay: $('#dyPay').checked ? 'Y' : 'N' });
    return f;
  }

  // ── 날짜 고르기 · 미리 보기 ──
  function calendar() {
    const y = +month.slice(0, 4), m = +month.slice(4, 6);
    const first = new Date(y, m - 1, 1), days = new Date(y, m, 0).getDate();
    const cells = [...Array(first.getDay()).fill(''), ...Array.from({ length: days }, (_, i) => `${month}${String(i + 1).padStart(2, '0')}`)];
    const t = today();
    return `<div class="dy-cal">
        <div class="dy-cal-head"><button class="btn-text" data-month="-1">◀</button><b>${y}년 ${m}월</b><button class="btn-text" data-month="1">▶</button></div>
        <div class="dy-cal-grid">${'일월화수목금토'.split('').map((w) => `<span class="dy-w">${w}</span>`).join('')}
          ${cells.map((d) => (d ? `<button type="button" class="dy-d${dates.includes(d) ? ' on' : ''}${U().weekend(d) ? ' we' : ''}${d === t ? ' today' : ''}" data-day="${d}">${+d.slice(6)}</button>` : '<span></span>')).join('')}</div>
      </div>`;
  }
  function renderFill() {
    const f = withTime(current);
    const K = U();
    const errs = K.check(f, { phone });
    const sorted = [...dates].sort();
    const notes = sorted.length ? K.notes(f, sorted) : [];
    const time = f.from && f.to ? `${K.hm(f.from)}~${K.hm(f.to)}` : '나이스 기본';
    const what = f.kind === 'overtime' ? f.todo : f.kind === 'leave' ? [K.leaveName(f), f.reason].filter(Boolean).join(' · ') : [f.place, f.purpose].filter(Boolean).join(' · ');
    el.innerHTML = `
      ${title(K.nameOf(f))}
      <p class="dim">${esc(K.KINDS[f.kind].label)} · ${esc(K.summary(f))}</p>
      <div class="dy-when"><b>시각</b>${timeSel('dyWhenF', f.from)} ~ ${timeSel('dyWhenT', f.to)}${f.kind === 'overtime' ? '' : dayChip()}<span class="dim">여기서 바꾸면 이번 신청에만 들어가요. 늘 쓰려면 [고치기].</span></div>
      ${calendar()}
      <div class="actions dy-quick"><button class="btn-line small" id="dyToday">오늘만</button><button class="btn-line small" id="dyClear">모두 지우기</button><span class="dim">날짜를 눌러 여러 날 고를 수 있어요</span></div>
      ${sorted.length ? `<table class="grid dy-prev"><thead><tr><th>날짜</th><th>시각</th><th>내용</th></tr></thead><tbody>
        ${sorted.map((d) => `<tr><td>${esc(md(d))}${f.kind === 'overtime' && K.weekend(d) ? ' <span class="tag">휴일</span>' : ''}</td><td>${esc(time)}</td><td>${esc(what)}</td></tr>`).join('')}</tbody></table>` : '<p class="warn">날짜를 골라 주세요.</p>'}
      ${notes.map((t) => `<p class="warn">${esc(t)}</p>`).join('')}
      ${errs.map((t) => `<p class="err">${esc(t)} — [고치기]에서 고쳐 주세요.</p>`).join('')}
      <p class="dim">결재선: ${esc(K.lineFor(f).join(' → ') || '선생님이 직접 골라요')}</p>
      ${note}
      <p class="hint">[나이스에 채우기]를 누르면 도우미가 나이스 [복무 → ${esc(screenOf(f.kind).title)}]를 열고 [신청] 창을 띄워 날짜마다 한 줄씩 채워요. 신청 창이 이미 열려 있으면 먼저 닫아 주세요.</p>
      <div class="actions"><button class="btn-main" id="dyGo" ${errs.length || !sorted.length ? 'disabled' : ''}>나이스에 채우기${sorted.length > 1 ? `(${sorted.length}일)` : ''}</button><button class="btn-line" data-edit="${esc(f.id)}">고치기</button><button class="btn-line" id="dyList">다른 즐겨찾기</button></div>`;
  }

  function progress(steps) {
    el.innerHTML = `${title(U().nameOf(current))}
      <ul class="progress">${steps.map((s, i) => `<li class="${i === steps.length - 1 ? 'now' : 'done'}"><span>${i === steps.length - 1 ? '진행 중' : '완료'}</span>${esc(s)}</li>`).join('')}</ul>`;
  }

  async function fill() {
    if (busy || !current) return;
    const f = withTime(current), screen = screenOf(f.kind), K = U();
    const sorted = [...dates].sort();
    if (K.check(f, { phone }).length || !sorted.length) return;
    const tab = await D.neis.activeTab();
    if (!D.neis.isNeis(tab)) { note = '<p class="err">나이스 탭을 열고 로그인한 뒤 다시 눌러 주세요.</p>'; render(); note = ''; return; }
    busy = true;
    mode = 'busy';
    const steps = [`나이스 [${screen.title}] 여는 중`];
    progress(steps);
    let res;
    try {
      const op = await D.neis.open(screen, tab.id);
      if (!op.ok) { res = { ok: false, error: op.error || '나이스 메뉴를 열지 못했어요.' }; }
      else {
        steps.push(`[신청] 창에 ${sorted.length}줄 채우는 중`);
        progress(steps);
        const A = screen.apply;
        res = await D.neis.call('dutyFill', { appId: screen.appId, open: A.open, dialog: A.dialog, dataset: A.dataset, grid: A.grid, addRow: A.addRow, rows: K.plan(f, sorted, screen, { phone }), read: A.read, line: K.lineFor(f) },
          { tabId: tab.id, timeout: 40000 + sorted.length * 8000 });
      }
    } finally { busy = false; }
    result = res.ok ? { ok: true, line: res.line || [], rows: res.rows.map((r) => ({ ...r, check: K.verify(f, r, screen) })) } : { ok: false, error: res.error };
    if (res.ok) await D.store.addLog?.({ screenId: screen.id, ok: true });
    mode = 'done';
    render();
  }

  function renderDone() {
    const f = withTime(current), K = U();
    const r = result || { ok: false, error: '결과가 없어요.' };
    const bad = r.ok ? r.rows.filter((x) => !x.check.ok) : [];
    el.innerHTML = `
      ${title(K.nameOf(f))}
      ${r.ok ? `<p class="${bad.length ? 'warn' : 'ok'}">나이스 신청 창에 ${r.rows.length}줄을 채웠어요${bad.length ? ` — ${bad.length}줄은 창에서 확인해 주세요` : ''}.</p>
        <table class="grid dy-prev"><thead><tr><th>날짜</th><th>들어간 시각</th><th>나이스 합계</th><th></th></tr></thead><tbody>
        ${r.rows.map((x) => { const v = x.values || {}; const a = v.aplyBgngHm || v.bgngHm || `${v.bgngH || v.bgngHh || ''}${v.bgngM || v.bgngMm || ''}`, b = v.aplyEndHm || v.endHm || `${v.endH || v.endHh || ''}${v.endM || v.endMm || ''}`; const t = (s) => (s.length === 4 ? `${s.slice(0, 2)}:${s.slice(2)}` : s); return `<tr class="${x.check.ok ? '' : 'bad'}"><td>${esc(md(x.date))}</td><td>${esc(a || b ? `${t(a)}~${t(b)}` : '-')}</td><td>${esc(x.check.total || '-')}</td><td>${x.check.ok ? '<span class="ok">맞음</span>' : `<span class="err">${esc(x.check.bad.join('·'))} 확인</span>`}</td></tr>`; }).join('')}</tbody></table>
        <p class="hint"><b>나이스 신청 창에서 내용을 확인하고 [승인요청]을 눌러 주세요.</b> 도우미는 승인요청을 누르지 않아요. 그만두려면 창의 [닫기]를 누르면 아무것도 저장되지 않아요.</p>
        ${r.line?.length ? `<p class="hint">[승인요청]을 누르면 뜨는 결재 창에 <b>${esc(r.line.join(' → '))}</b>을(를) 넣어 드려요. 나이스 화면 오른쪽 위에 진행 글이 떠요. 확인하고 <b>[상신]</b>을 눌러 주세요. 패널을 닫아도 돼요.</p>` : '<p class="hint">결재선은 결재 창에서 선생님이 골라 주세요.</p>'}
        ${f.kind === 'overtime' ? '<p class="dim">합계는 나이스가 계산한 값이에요(평일은 저녁 1시간을 빼고 하루 4시간까지).</p>' : ''}
        ${f.kind === 'trip' ? '<p class="dim">출장지 [찾기]·동행자는 창에서 직접 확인해 주세요.</p>' : ''}`
      : `<p class="err">${esc(r.error)}</p>`}
      <div class="actions">${r.ok ? '' : '<button class="btn-main" id="dyGo2">다시 하기</button>'}<button class="btn-line" id="dyList">처음으로</button></div>`;
  }

  async function capture() {
    const tab = await D.neis.activeTab();
    if (!D.neis.isNeis(tab)) { note = '<p class="err">나이스 탭에서 신청 창을 연 채로 눌러 주세요.</p>'; render(); note = ''; return; }
    const scr = Object.values(U().KINDS).map((k) => D.screens.get(k.screenId));
    const r = await D.neis.call('dutyRead', {
      dialogs: scr.map((s) => s.apply.dialog),
      dataset: Object.fromEntries(scr.map((s) => [s.apply.dialog, s.apply.dataset])),
      grid: 'grdMain',
      columns: Object.fromEntries(scr.map((s) => [s.apply.dialog, Object.values(s.apply.capture)])),
    }, { tabId: tab.id });
    if (!r.ok) { note = `<p class="err">${esc(r.error)}</p>`; render(); note = ''; return; }
    const kind = Object.keys(U().KINDS).find((k) => screenOf(k).apply.dialog === r.dialog);
    editing = { ...U().fromDialog(kind, r.values, screenOf(kind)), _new: true };
    if (editing.dtl === '00000') editing.dtl = '';
    mode = 'edit';
    render();
  }

  D.views.duty = {
    back() {
      if (mode === 'list' || busy) return busy;
      mode = 'list';
      render();
      return true;
    },
    init(root) {
      el = root;
      $ = (s) => el.querySelector(s);
      el.addEventListener('click', async (e) => {
        const t = e.target;
        const fill1 = t.closest('[data-fill]');
        if (fill1) { D.views.duty.open(fill1.dataset.fill); return; }
        const ed = t.closest('[data-edit]');
        if (ed) { const f = favs.find((x) => x.id === ed.dataset.edit); if (f) { editing = { ...f }; mode = 'edit'; render(); } return; }
        const del = t.closest('[data-del]');
        if (del) {
          const f = favs.find((x) => x.id === del.dataset.del);
          if (f && confirm(`'${U().nameOf(f)}' 즐겨찾기를 지울까요?`)) { favs = favs.filter((x) => x !== f); await saveFavs(); render(); }
          return;
        }
        const nw = t.closest('[data-new]');
        if (nw) { editing = { ...U().blank(nw.dataset.new, day), _new: true }; mode = 'edit'; render(); return; }
        if (t.id === 'dyDaySave') {
          const next = { from: timeOf('dyDayF'), to: timeOf('dyDayT') };
          if (U().hm(next.to) <= U().hm(next.from)) { note = '<p class="err">끝 시각이 시작보다 늦어야 해요.</p>'; render(); note = ''; return; }
          day = next;
          await D.store.saveSettings({ dutyDay: day });
          note = '<p class="ok">근무 시간을 저장했어요. 새 즐겨찾기부터 이 시각으로 시작해요.</p>'; render(); note = ''; return;
        }
        if (t.closest('[data-day-time]')) {
          if (mode === 'fill') { fillTime = { ...day }; render(); return; }
          editing = { ...readForm(), ...day }; renderEdit(); return;
        }
        if (t.id === 'dyPhoneSave') { phone = String($('#dyPhone').value || '').trim(); await D.store.saveSettings({ dutyPhone: phone }); note = '<p class="ok">내 연락처를 저장했어요.</p>'; render(); note = ''; return; }
        if (t.id === 'dyCapture') { capture(); return; }
        if (t.id === 'dyCancel' || t.id === 'dyList') { mode = 'list'; render(); return; }
        if (t.id === 'dySave') {
          const f = readForm();
          const errs = U().check(f, { phone });
          if (errs.length) { editing = f; renderEdit(errs); return; }
          const { _new, ...clean } = f;
          clean.name = clean.name || U().nameOf({ ...clean, name: '' });
          const i = favs.findIndex((x) => x.id === clean.id);
          if (i >= 0) favs[i] = clean; else favs.push(clean);
          await saveFavs();
          editing = null;
          if (current && current.id === clean.id) { current = clean; fillTime = { from: clean.from || day.from, to: clean.to || day.to }; mode = 'fill'; } else mode = 'list';
          render();
          return;
        }
        const mo = t.closest('[data-month]');
        if (mo) { const y = +month.slice(0, 4), m = +month.slice(4, 6) - 1 + +mo.dataset.month; const d = new Date(y, m, 1); month = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}`; render(); return; }
        const dayBtn = t.closest('[data-day]');
        if (dayBtn) { const d = dayBtn.dataset.day; dates = dates.includes(d) ? dates.filter((x) => x !== d) : [...dates, d]; render(); return; }
        if (t.id === 'dyToday') { dates = [today()]; month = today().slice(0, 6); render(); return; }
        if (t.id === 'dyClear') { dates = []; render(); return; }
        if (t.id === 'dyGo' || t.id === 'dyGo2') { fill(); }
      });
      el.addEventListener('change', (e) => {
        // 이번 신청 시각: 고르면 미리 보기·검사를 바로 고침(고르던 칸은 그대로)
        if (/^dyWhen[FT][HM]$/.test(e.target.id) && mode === 'fill') {
          const id = e.target.id;
          fillTime = { from: timeOf('dyWhenF'), to: timeOf('dyWhenT') };
          render();
          $(`#${id}`)?.focus();
          return;
        }
        // 종류를 바꾸면 세부 종류 목록도 그 종류 것으로, 세부 종류를 바꾸면 세부 항목도
        if (!editing) return;
        // '개인 용무'는 조퇴·외출의 기본 사유라 다른 종류로 바꾸면 비운다
        const keepReason = (f) => (f.reason === U().PERSONAL && !U().isOutCode(f.sclf) ? { ...f, reason: '' } : f);
        if (e.target.id === 'dyLclf') { editing = keepReason({ ...readForm(), sclf: Object.keys(U().LEAVE_SCLF[e.target.value] || {})[0] || '', dtl: '' }); renderEdit(); }
        if (e.target.id === 'dySclf') { editing = keepReason({ ...readForm(), dtl: '' }); renderEdit(); }
      });
    },
    // [복무 신청]으로 들어오면 목록, 첫 화면 즐겨찾기 단추(open)로 들어오면 그 즐겨찾기 채우기 화면
    async enter() { const keep = pending; pending = false; await load(); if (mode === 'busy') return; if (!keep) mode = 'list'; render(); },
    // 첫 화면 즐겨찾기 단추: 그 즐겨찾기로 오늘 날짜 채우기 화면
    async open(id) {
      pending = true;
      await load();
      const f = favs.find((x) => x.id === id);
      if (!f) { mode = 'list'; render(); return; }
      current = f;
      fillTime = { from: f.from || day.from, to: f.to || day.to };
      dates = [today()];
      month = today().slice(0, 6);
      result = null;
      mode = 'fill';
      render();
      if (el && !el.hidden) pending = false; // 이미 이 화면이면 enter가 안 불림
    },
    helpId: () => 'duty',
    // 첫 화면용
    async list() { await load(); return favs.slice(); },
  };
})();
