// 패널 첫 화면 = 하는 일 전부. 순서: ① 할 일 고르기 → ② 파일 놓기(엑셀·CSV·한글 hwpx) → ③ 자동 확인 → [입력 후 저장]
// 나이스 화면 열기·조회·수업 고르기는 도우미가 한다. 직접 입력 칸은 두지 않는다.
(() => {
  const D = globalThis.Doumi;
  D.views = D.views || {};
  const WORK = 'import';

  let el, $;
  let busy = false;
  let task = null;      // 고른 일(runner)
  let file = null;      // { name, text }
  let checked = null;

  const esc = D.esc;
  const cut = (s, n = 46) => (s.length > n ? `${s.slice(0, n)}…` : s);
  const valueLabel = (runner, codes, v) => (
    runner.id === 'subject' ? ({ '': '출석', '/': '결과', 'Ø': '출석인정' }[v] ?? v)
      : runner.id === 'daily' ? (v === '' ? '출석' : codes?.[v] || v)
        : runner.plain ? (v ? cut(v) : '(비어 있음)')
          : (v ? `${cut(v)} (${D.bytes(v)}B)` : '(비어 있음)'));

  const title = (t) => `<h2 class="sec">${esc(t)}</h2>`;
  const info = (rows) => `<table class="info">${rows.map(([k, v]) => `<tr><th>${esc(k)}</th><td>${v}</td></tr>`).join('')}</table>`;
  const back = (label = '처음으로') => `<button class="btn-line" id="hmHome">${esc(label)}</button>`;

  function show(state, html) {
    el.dataset.state = state;
    el.innerHTML = html;
    D.paintTop?.();
  }

  // ① 할 일 고르기
  const siteOf = (st) => (st?.where === 'edufine' ? 'edufine' : 'neis');
  let shownSite = 'neis';
  function choose() {
    task = null; file = null; checked = null;
    D.views.inbox?.clear();
    shownSite = siteOf(D.state);
    if (shownSite === 'edufine') { chooseEdufine(); return; }
    const row = (inner, help) => `<div class="task-row">${inner}${D.help.btn(help)}</div>`;
    const btn = (r) => row(`<button class="task" data-task="${esc(r.id)}"><b>${esc(r.label)}</b><span>${esc(r.sub || D.screens.get(r.screenId).title)}</span></button>`, r.id);
    const go = (v, b, sub) => row(`<button class="task" data-go="${v}"><b>${esc(b)}</b><span>${esc(sub)}</span></button>`, v);
    const G = (name) => D.runners.groups.find((g) => g.name.startsWith(name))?.items || [];
    // 첫 화면 묶음(교사 요청 2026-11-02): 묶음을 누르면 그 안의 일만 보여 한눈에. 일마다 [설명](영상)
    const cats = [
      ['att', '출결', G('출결').map(btn).join('')],
      ['rec', '생기부', G('생기부').map(btn).join('')],
      ['eval', '평가', G('평가').map(btn).join('')],
      ['duty', '복무', `<div id="hmDuty" class="task-rows">${go('duty', '복무 신청', '초과근무·연가·출장 즐겨찾기 만들기·고치기')}</div>`],
      ['meet', '회의', go('free', '빈 시간 찾기', '선생님들 수업·부재 → 모두 비는 교시')],
      ['app', '출석부 앱', `${row('<button class="task" data-roster="homeroom"><b>우리 반</b><span>담임 · 일일출결 명단으로 웹앱 만들기</span></button>', 'roster')}${row('<button class="task" data-roster="subjects"><b>내 수업 반</b><span>교과 · 정규 수업 반(최근 3주)으로 웹앱 만들기</span></button>', 'roster')}${row('<button class="task" data-box-open="1"><b>받은 서류함</b><span>학생이 낸 서류를 이 PC에서 보고 인쇄</span></button>', 'roster')}`],
      ['learn', '길잡이', go('guide', '나이스 길잡이', '출결·평가 순서 · 누를 곳을 나이스 위에 표시')],
    ];
    const on = cats.some((c) => c[0] === homeCat) ? homeCat : 'att';
    show('choose', `
      <div id="hmToday"></div>
      <nav class="cats" role="tablist" aria-label="기능 묶음">${cats.map(([id, name]) => `<button role="tab" data-cat="${id}" aria-selected="${id === on}" class="${id === on ? 'on' : ''}">${esc(name)}</button>`).join('')}</nav>
      ${cats.map(([id, , html]) => `<div class="task-rows cat-body" data-cat-body="${id}" ${id === on ? '' : 'hidden'}>${html}</div>`).join('')}
      <p class="hint" id="hmResume" hidden></p>`);
    resumeHint();
    today();
    paintDuty();
  }
  let homeCat = '';
  try { homeCat = localStorage.getItem('doumi.homeCat') || ''; } catch { homeCat = ''; }
  function pickCat(id) {
    homeCat = id;
    try { localStorage.setItem('doumi.homeCat', id); } catch { /* 기억 못 해도 괜찮음 */ }
    el.querySelectorAll('[data-cat]').forEach((b) => { const onNow = b.dataset.cat === id; b.classList.toggle('on', onNow); b.setAttribute('aria-selected', String(onNow)); });
    el.querySelectorAll('[data-cat-body]').forEach((d) => { d.hidden = d.dataset.catBody !== id; });
  }
  // 복무 즐겨찾기 단추(교사 결정 2026-10-30: 첫 화면에 바로) — 누르면 그 즐겨찾기로 오늘 날짜 채우기 화면
  async function paintDuty() {
    const favs = D.views.duty ? await D.views.duty.list() : [];
    const box = $('#hmDuty');
    if (!box || !favs.length) return;
    box.innerHTML = `${favs.map((f) => `<div class="task-row"><button class="task" data-duty-fav="${esc(f.id)}"><b>${esc(D.duty.nameOf(f))}</b><span>${esc(D.duty.summary(f))} · 오늘</span></button></div>`).join('')}
      <div class="task-row"><button class="task" data-go="duty"><b>복무 신청</b><span>즐겨찾기 만들기·고치기 · 다른 날</span></button>${D.help.btn('duty')}</div>`;
  }

  // H1 '오늘': 날짜, 마지막 입력, 아직 1건 시험 전인 화면 (학생 자료 없음). 출석부 웹앱 만들기는 아래 할 일 묶음 한 곳에만(2026-10-29)
  const hm = (t) => { const d = new Date(t); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const ymdOf = (t) => { const d = new Date(t); return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`; };
  // H1 '내 수업'(2026-10-29): 빈 시간 찾기에서 고른 학교의 컴시간 시간표에서, 처음 한 번 고른 내 이름(컴시간 가린 이름)의 오늘 수업.
  // 컴시간에 보내는 것은 학교 코드뿐(빈 시간 찾기와 같음). 10분 동안은 다시 읽지 않음
  let myCache = null;
  async function myWeek(sc, ymd) {
    const key = `${sc.code}|${ymd}`;
    if (myCache && myCache.key === key && Date.now() - myCache.at < 10 * 60000) return myCache;
    let cm = await D.comci.week(sc.code, 1);
    const no = D.freetime.weekFor(cm, ymd);
    if (no && no !== 1) cm = await D.comci.week(sc.code, no);
    myCache = { key, at: Date.now(), cm, inWeek: !!no };
    return myCache;
  }
  const lessonText = (l) => `<span class="my-l${l.changed ? ' chg' : ''}"><b>${l.p}교시</b> ${l.grade}-${l.ban} ${esc(l.subject)}${l.changed ? ' <small>바뀜</small>' : ''}</span>`;
  async function paintMy(settings, now) {
    const cell = $('#hmMy');
    if (!cell) return;
    const sc = settings.comciSchool, me = settings.comciMe;
    if (!sc) { cell.innerHTML = '<button class="link" data-go="free">학교 고르기</button> <span class="dim">빈 시간 찾기에서 학교를 고르면 오늘 수업이 보여요</span>'; return; }
    if (!me) { cell.innerHTML = '<button class="link" id="hmMePick">내 이름 고르기</button> <span class="dim">컴시간 시간표에서 처음 한 번</span>'; return; }
    const day = now.getDay();
    if (day === 0 || day === 6) { cell.innerHTML = '<span class="dim">주말이에요</span>'; return; }
    cell.innerHTML = '<span class="dim">컴시간에서 읽는 중…</span>';
    try {
      const w = await myWeek(sc, ymdOf(now));
      const t = w.cm.names[me.idx] === me.comci ? me.idx : w.cm.names.indexOf(me.comci);
      if (t < 1) { cell.innerHTML = `<span class="err">컴시간에서 '${esc(me.comci)}'을(를) 찾지 못했어요.</span> <button class="link" id="hmMeReset">다시 고르기</button>`; return; }
      if (!w.inWeek) { cell.innerHTML = '<span class="dim">컴시간에 이번 주 시간표가 아직 없어요</span>'; return; }
      const list = D.freetime.myDay(w.cm, t, day);
      cell.innerHTML = `${list.length ? `<span class="my-ls">${list.map(lessonText).join('')}</span>` : '<span class="dim">오늘 수업 없음</span>'} <button class="link" id="hmMeReset">${esc(me.comci)} 바꾸기</button>`;
    } catch (e) {
      cell.innerHTML = `<span class="dim">${esc(e.message)}</span>`;
    }
  }
  // 내 이름 고르기: 컴시간 교사 목록(가린 이름 '김요*')을 눌러서
  async function pickMe() {
    const cell = $('#hmMy');
    const settings = await D.store.settings();
    if (!cell || !settings.comciSchool) return;
    cell.innerHTML = '<span class="dim">컴시간 교사 목록 읽는 중…</span>';
    try {
      const w = await myWeek(settings.comciSchool, ymdOf(nowDate()));
      cell.innerHTML = `<div class="me-pick">${w.cm.names.map((n, i) => (i && n ? `<button class="fx" data-me="${i}" data-name="${esc(n)}">${esc(n)}</button>` : '')).join('')}</div><span class="dim">컴시간은 이름 끝을 가려서 보여 줘요</span>`;
    } catch (e) { cell.innerHTML = `<span class="err">${esc(e.message)}</span>`; }
  }
  // 시험이 날짜를 정할 수 있게(Doumi.clock)
  const nowDate = () => (typeof D.clock === 'function' ? D.clock() : new Date());
  async function today() {
    const box = $('#hmToday');
    if (!box) return;
    const [log, settings] = await Promise.all([D.store.log(), D.store.settings()]);
    const now = nowDate();
    const ymd = ymdOf(now);
    const isToday = (t) => new Date(t).toDateString() === now.toDateString();
    const titleOf = (id) => D.runners.all.find((r) => r.screenId === id)?.label || D.screens.get(id)?.title || '';
    const last = log[0];
    const waiting = D.runners.all.filter((r) => !r.checkOnly && !settings.verified[r.screenId]);
    const rows = [
      ['오늘', esc(D.showDay(ymd))],
      ['내 수업', '<span id="hmMy"></span>'],
      ['할 일', '<span id="hmTodo" class="dim">…</span>'],
      ...(shownSite !== 'edufine' ? [['폰 출석부', D.phoneSync?.conf() ? '<span id="hmPhone" class="dim">읽는 중…</span>' : '<span class="dim">연결 전 — [일일출결]에서 연결</span>']] : []),
      ...(last ? [['최근', `${esc(titleOf(last.screenId))} ${last.ok ? '저장' : '<span class="err">저장 후 중단</span>'} <span class="dim">${isToday(last.at) ? hm(last.at) : esc(D.showDay(ymdOf(last.at)))}</span>`]] : []),
      ['1건 시험', waiting.length ? `<span class="dim">남은 화면 ${waiting.length}개</span> · ${esc(waiting.slice(0, 3).map((r) => r.label).join(', '))}${waiting.length > 3 ? ' 외' : ''}` : '<span class="ok">모두 확인했어요</span>'],
      // 에듀파인 위쪽 알림 줄 숫자(결재·공람·문서진행, 2026-10-29 실제 칸) — 숫자만 읽고 저장하지 않음
      ...(shownSite === 'edufine' ? [['에듀파인', '<span id="hmEdu" class="dim">읽는 중…</span>']] : []),
      ...(shownSite === 'edufine' && D.edufineInbox?.last ? [['결재대기', `${D.edufineInbox.last.count}건${D.edufineInbox.last.urgent ? ` · <span class="err">긴급 ${D.edufineInbox.last.urgent}</span>` : ''} <span class="dim">${hm(D.edufineInbox.last.time)} 읽음</span>`]] : []),
    ];
    box.innerHTML = `${title('오늘')}${info(rows)}`;
    paintMy(settings, now);
    paintTodo(now);
    if (shownSite === 'edufine') paintEdu();
    else if (D.phoneSync?.conf()) paintPhone(now);
  }
  // '오늘' 할 일 줄: 지남·오늘·일주일 안 숫자(눌러서 할 일 화면으로)
  async function paintTodo(now) {
    const c = D.todo ? D.todo.counts(await D.todo.list(), now) : null;
    const cell = $('#hmTodo');
    if (!cell || !c) return;
    const parts = [c.late ? `<span class="err">지남 <b>${c.late}</b></span>` : '', c.today ? `오늘 <b>${c.today}</b>` : '', c.soon ? `일주일 안 <b>${c.soon}</b>` : ''].filter(Boolean);
    cell.className = '';
    cell.innerHTML = c.open ? `${parts.join(' · ') || `남은 일 <b>${c.open}</b>`} <button class="link" data-go="todo">보기</button>` : '<span class="dim">남은 일 없음</span>';
  }
  async function paintPhone(now) {
    const snap = await D.phoneSync.read();
    const cell = $('#hmPhone');
    if (!cell) return;
    if (!snap.ok) { cell.className = 'err'; cell.textContent = snap.error; return; }
    const count = async (kind) => { const r = await D.phoneSync.range(kind, ymdOf(now)); return D.phoneSync.rows(snap, kind, r.from, r.to).length - 1; };
    const [nd, ns] = await Promise.all([count('daily'), count('subject')]);
    const parts = [nd ? `일일출결 <b>${nd}</b>` : '', ns ? `과목별출결 <b>${ns}</b>` : ''].filter(Boolean);
    cell.className = '';
    cell.innerHTML = `${parts.length ? `안 넣은 출결 ${parts.join(' · ')}` : '새 출결 없음'} <span class="dim">· 저장소 ${esc(snap.tag)}${snap.at ? ` · 폰 저장 ${sameDay(snap.at, now) ? hm(snap.at) : esc(`${D.showDay(ymdOf(snap.at))} ${hm(snap.at)}`)}` : ''}</span>`;
  }
  const sameDay = (t, now) => new Date(t).toDateString() === now.toDateString();
  async function paintEdu() {
    const c = await D.edufineInbox?.counts?.();
    const cell = $('#hmEdu');
    if (!cell) return;
    if (!c) { cell.textContent = '에듀파인 첫 화면 탭에서 건수를 읽어요'; return; }
    const part = (label, x) => (x ? `${label} <b>${x.n}</b>${x.urgent ? ` <span class="err">긴급 ${x.urgent}</span>` : ''}` : '');
    cell.className = '';
    cell.innerHTML = [part('결재', c.sanctn), part('공람', c.cnrs), part('문서진행', c.progress)].filter(Boolean).join(' · ');
  }

  // 받은 서류함: 출석부 웹앱 [서류함]을 이 브라우저 탭으로(인쇄는 PC에서, 교사 요청 2026-11-02). 받는 곳을 모르면 만들기 창을 먼저
  async function openBox(btn) {
    const sub = btn.querySelector('span');
    const say = (t) => { if (sub) sub.textContent = t; };
    const waitMaker = !D.phoneSync?.conf() && !D.formsMaker?.known ? D.formsMaker?.open({ want: 'both' }) : null; // 버튼을 누른 순간에 열어야 팝업이 안 막힘
    if (waitMaker) {
      say('작은 창에서 계정 확인 → [이 계정에 만들기]');
      const r = await waitMaker;
      if (!r?.ok) { say(r?.msg || '받는 곳을 찾지 못했어요.'); return; }
    }
    say('여는 중…');
    let url = '';
    try { url = await D.rosterLink.boxUrl(); } catch { url = ''; }
    if (!url) { say("받는 곳을 찾지 못했어요. 먼저 [우리 반]으로 출석부 웹앱을 만들어 주세요."); return; }
    D.rosterLink.openTab(url);
    say('새 탭에 열었어요 · 학생이 낸 서류를 이 PC에서 보고 인쇄');
  }

  // 폰 출결 자동 연동(교사 결정 2026-10-30): [일일출결]·[과목별출결]을 누르면 출석부 웹앱 '구글 자동 저장' 저장소를 읽어 바로 '준비됨'.
  // [PC로 보내기]·[폰 출결 가져오기]는 없앰. 푼 출석부는 패널 메모리에만(D.phoneSync, 1분 동안은 다시 묻지 않음)
  const PH_RANGES = [['since', '안 넣은 날부터'], ['today', '오늘'], ['week', '이번 주'], ['month', '이번 달']];
  async function phoneRange(kind, which) {
    const now = nowDate(), today = ymdOf(now);
    if (which === 'today') return { from: today, to: today };
    if (which === 'month') return { from: `${today.slice(0, 6)}01`, to: today };
    if (which === 'week') { const mon = new Date(now); mon.setDate(now.getDate() - ((now.getDay() + 6) % 7)); return { from: ymdOf(mon), to: today }; }
    return D.phoneSync.range(kind, today); // 도우미가 나이스에 마지막으로 저장한 날 다음 ~ 오늘(기록 없으면 이번 달 1일부터)
  }
  async function phoneStart(kind, which = 'since', { fresh = false } = {}) {
    if (busy) return;
    busy = true;
    task = D.runners.byId(kind);
    file = null;
    progress(['폰 출석부 읽는 중']);
    let snap;
    try { snap = await D.phoneSync.read({ fresh }); } finally { busy = false; }
    if (!snap.ok) { askFile(`<p class="err">${esc(snap.error)}</p>`); return; }
    const r = await phoneRange(kind, which);
    const rows = D.phoneSync.rows(snap, kind, r.from, r.to);
    const phone = { which, from: r.from, to: r.to, at: snap.at ? `${D.showDay(ymdOf(snap.at))} ${hm(snap.at)}` : '', tag: snap.tag, n: rows.length - 1 };
    if (rows.length < 2) { askFile(phoneNote(phone, true)); return; }
    file = { name: `폰 출석부 · 저장 ${phone.at || '시각 모름'}`, text: D.phoneSync.text(rows), phone };
    ready(phoneNote(phone));
  }
  // 기간 칩 + 저장소 줄(출석부 웹앱 [설정 → 구글 자동 저장]의 저장소 번호와 같아야 같은 저장소)
  function phoneNote(p, empty = false) {
    const span = p.from === p.to ? D.showDay(p.from) : `${D.showDay(p.from)} ~ ${D.showDay(p.to)}`;
    return `<div class="phone-bar">
        <div class="phone-range">${PH_RANGES.map(([k, l]) => `<button class="btn-line small${p.which === k ? ' on' : ''}" data-ph-range="${k}">${l}</button>`).join('')}<button class="btn-text" data-ph-range="${esc(p.which)}" data-ph-fresh="1">다시 읽기</button></div>
        <p class="${empty ? 'warn' : 'dim'}">${empty ? `폰 출석부에 ${esc(span)} 출결이 없어요. 기간을 바꾸거나, 폰에서 체크한 뒤 [다시 읽기]를 눌러 주세요.` : `폰 출석부 ${esc(span)} · ${p.n}줄`} · 저장소 ${esc(p.tag)}${p.at ? ` · 폰 저장 ${esc(p.at)}` : ''}</p>
      </div>`;
  }

  function phoneLink() {
    const p = D.formsMaker?.open({ want: 'store' });
    if (!p) { askFile('<p class="err">출석부 저장소 연결 창을 열 수 없어요.</p>'); return; }
    const kind = task.id;
    const bar = $('#hmPhoneBar .dim');
    if (bar) bar.textContent = '작은 구글 창에서 계정을 확인하고 [이 계정에 켜기]를 눌러 주세요…';
    p.then((r) => {
      if (task?.id !== kind || el.dataset.state !== 'drop') return;
      if (r?.ok && r.store) { D.phoneSync.forget(); phoneStart(kind); return; }
      askFile(`<p class="err">${esc(r?.msg || '폰 출석부와 연결하지 못했어요.')}</p>`);
    });
  }

  // 파일·폰 출결을 받은 뒤: 나이스는 아직 그대로. [나이스에서 확인하기]를 눌러야 메뉴를 열고 조회한다(교사 결정 2026-10-28: 버튼을 눌러야만 나이스가 움직임)
  function ready(note = '') {
    const lines = file.text ? D.lines(file.text).length : 0;
    show('ready', `
      ${title(`${task.label} 입력`)}
      ${note}
      ${info([['파일', esc(file.name)], ...(file.phone ? [] : [['내용', `${lines ? `${lines}줄` : ''}${file.attach ? `${lines ? ' · ' : ''}채점기준표 ${esc(file.attach.name)}` : ''}`]]), ...(isItems() && picksLabel() ? [['조건', esc(picksLabel())]] : [])])}
      ${file.sheets ? `<div class="sheet-pick"><b>어느 과목 탭을 넣을까요?</b> <span class="dim">${task?.screenId === 'neis.assess.perf' ? '고른 탭의 학년·과목으로 나이스 조건을 맞춰요' : '나이스 화면에 고른 과목과 같은 탭'}</span><div>${file.sheets.map((s) => `<button class="btn-line small${s.name === file.sheet ? ' on' : ''}" data-sheet="${esc(s.name)}">${esc(s.name)}</button>`).join('')}</div></div>` : ''}
      <p class="hint">${task.checkOnly ? '아직 나이스는 그대로예요. <b>[나이스에서 확인하기]</b>를 누르면 도우미가 나이스 화면을 열고 조회만 해서 점검 결과를 보여 줘요. 나이스 값은 바꾸지 않아요.' : '아직 나이스는 그대로예요. <b>[나이스에서 확인하기]</b>를 누르면 도우미가 나이스 화면을 열고 조회만 해서(값은 안 바꿈) 넣을 값과 지금 값을 표로 보여 줘요. 실제로 넣는 것은 그다음 <b>[입력 후 저장]</b>이에요.'}</p>
      ${suggestNote()}
      <div class="actions"><button class="btn-main" id="hmCheck">나이스에서 확인하기</button>${back('다른 파일')}</div>
      ${otpBlock()}`);
  }

  // 에듀파인 탭: 에듀파인 일만. 지금 되는 것은 결재함 보기(views/edufine-inbox.js)·문서 화면 확인(구조 기록), 나머지는 준비 중
  const EDU_SOON = [
    ['협의록 기안', '회의 메모 → 협의록'],
    ['자료집계 회신', '공문 요구 항목 → 회신 틀'],
  ];
  function chooseEdufine() {
    show('choose', `
      <div id="hmToday"></div>
      ${title('에듀파인 — 무엇을 할까요?')}
      <div class="task-rows">
        <div class="task-row"><button class="task" data-edu="inbox"><b>결재함 보기</b><span>결재대기 문서 · 한 건씩 열기</span></button>${D.help.btn('inbox')}</div>
        <div class="task-row"><button class="task" data-edu="record"><b>문서 화면 확인</b><span>문서를 연 채로 누르면 본문이 읽히는지 봐요</span></button></div>
        <div class="task-row"><button class="task" data-edu="draft"><b>기안·품의 준비</b><span>공문 형식 본문·금액·붙임 검사 → 복사</span></button>${D.help.btn('draft')}</div>
        <div class="task-row"><button class="task" data-go="todo"><b>할 일</b><span>공문에서 정리한 일 · 기한순 · 붙임 받기·열기</span></button>${D.help.btn('todo')}</div>
      </div>
      <div class="task-group" style="margin-top:12px"><h3>준비 중</h3><div class="tasks">
        ${EDU_SOON.map(([b, sub]) => `<button class="task" disabled><b>${esc(b)}</b><span>${esc(sub)}</span></button>`).join('')}
      </div></div>
      <p class="hint">나이스 입력·출석부 웹앱 만들기는 나이스 탭으로 가면 나와요.</p>`);
    today();
  }

  // 문서 화면 확인: 열린 에듀파인 창(문서 새 창 포함)의 틀과 본문 글자 수만. 제목·본문·이름은 담지 않는다
  async function eduRecord() {
    busy = true;
    task = { label: '문서 화면 확인' };
    file = { name: '에듀파인 창' };
    progress(['열린 에듀파인 창 읽는 중']);
    let r;
    try { r = await D.edufine.record(); } finally { busy = false; }
    if (!r.ok) { fail(r.error); return; }
    const report = { 도우미: chrome.runtime.getManifest().version, 일시: new Date().toLocaleString('ko-KR'), 결과: r };
    const doc = r.windows.filter((w) => w.새창 || (w.종류 !== '에듀파인 본창' && w.종류 !== '기타 창'));
    const rows = r.windows.map((w) => {
      const text = w.프레임.reduce((n, f) => n + (f.textLength || 0), 0);
      const edit = w.프레임.reduce((n, f) => n + (f.editor?.contenteditable || 0), 0);
      const blocked = w.프레임.filter((f) => f.error).length;
      return `<tr><td>${esc(w.종류)}${w.새창 ? ' <span class="dim">새 창</span>' : ''}</td><td class="c">${w.프레임수}</td><td>${text.toLocaleString()}자${edit ? ` · 편집칸 ${edit}` : ''}${blocked ? ` · <span class="err">못 읽은 칸 ${blocked}</span>` : ''}</td></tr>`;
    }).join('');
    const verdict = !doc.length
      ? `<p class="warn">문서 창을 찾지 못했어요(에듀파인 창 ${r.windows.length}개). 문서 창을 닫지 말고 에듀파인 본창으로 돌아와 다시 눌러 주세요. 그래도 안 되면 [파일로 저장]한 파일을 알려 주세요.</p>`
      : doc.some((w) => w.프레임.some((f) => (f.textLength || 0) > 50))
        ? '<p class="ok">문서 창 글자가 읽혀요. 이 파일을 저장해 개발 대화에 알려 주세요.</p>'
        : '<p class="warn">문서 창은 찾았는데 글자가 거의 안 읽혀요(보안 프로그램이 막는 것일 수 있어요). 이 파일을 저장해 알려 주세요.</p>';
    show('done', `
      ${title('문서 화면 확인')}
      ${verdict}
      <table class="grid"><thead><tr><th>창</th><th class="c">칸</th><th>읽힌 글자</th></tr></thead><tbody>${rows}</tbody></table>
      <p class="hint">문서 제목·본문·사람 이름은 담지 않고, 칸·버튼 이름과 글자 수만 기록했어요.</p>
      <div class="actions"><button class="btn-main" id="hmEduSave">파일로 저장</button>${back('처음으로')}</div>`);
    $('#hmEduSave').addEventListener('click', () => {
      const a = document.createElement('a');
      const d = new Date();
      a.href = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }));
      a.download = `에듀파인구조_${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1500);
    });
  }

  // ② 파일 놓기
  const isItems = () => task?.screenId === 'neis.assess.items';
  // 일일출결·과목별출결 파일 놓는 곳 위: 폰 출석부와 연결 전이면 [폰 출석부 연결], 연결돼 있으면 [폰 출석부 읽기]
  function phoneBar() {
    const c = D.phoneSync?.conf();
    if (c) return `<div class="phone-bar"><div class="actions"><button class="btn-main small" data-ph-range="since">폰 출석부 읽기</button><span class="dim">저장소 ${esc(D.phoneSync.tag(c))} · 폰에서 체크한 출결</span></div></div>`;
    return `<div class="phone-bar" id="hmPhoneBar">
        <p><b>폰 출석부와 연결</b> — 폰 출석부 [설정 → 구글 자동 저장]을 교육청 계정으로 켜 두면, 여기서 [${esc(task.label)}]을 누를 때 폰에서 체크한 출결이 저절로 들어와요.</p>
        <div class="actions"><button class="btn-main small" id="hmPhoneLink">폰 출석부 연결</button><span class="dim">작은 구글 창에서 폰과 같은 교육청 계정 확인</span></div>
      </div>`;
  }
  function askFile(note = '') {
    show('drop', `
      ${title(`${task.label}${task.checkOnly ? '' : ' 입력'}`)}
      ${['daily', 'subject'].includes(task.id) && !String(note).includes('phone-bar') ? phoneBar() : ''}
      ${note}
      ${task.noFile ? '<div class="actions"><button class="btn-main" id="hmNoFile">나이스만 점검</button><span class="dim">파일 없이 — 아래에 평가기준안을 놓으면 계획과도 맞대어 봐요</span></div>' : ''}
      ${templateSteps(task)}
      <label class="upload" id="hmDrop">
        <input type="file" id="hmFile" accept=".xlsx,.hwp,.hwpx,.csv,.tsv,.txt${isItems() ? ',.pdf" multiple' : '"'} hidden>
        <span class="upload-main">파일을 여기로 끌어다 놓으세요</span>
        <span class="upload-sub">${isItems() ? '문항정보표 양식(.xlsx) · 서답형 채점기준표(.hwp·.hwpx·.pdf) — 같이 또는 따로' : '엑셀(.xlsx) · 한글(.hwp·.hwpx) · CSV'}</span>
        <span class="btn-line small">파일 선택</span>
      </label>
      <p class="hint">${esc(hintFor(task))}</p>
      ${otpBlock()}
      ${isItems() ? '<div class="picks" id="hmPicks"><p class="muted">나이스에서 학기·고사·학년·과목 목록을 읽는 중…(다 읽은 뒤 나이스 조건은 원래대로 돌아가요)</p></div>' : ''}
      ${isItems() ? `<div class="lvrule"><b>난이도 기준</b> 배점 <input type="number" id="hmLvHard" class="num" min="0" step="0.5"> 점 이상 상 · <input type="number" id="hmLvNormal" class="num" min="0" step="0.5"> 점 이상 중 · 그 아래 하<div class="dim">정해 두면 난이도를 배점으로 자동으로 넣어요(역배점 없음). 비우면 파일의 난이도를 써요.</div></div>` : ''}
      ${back('다른 일 고르기')}`);
    if (isItems()) {
      if (picksNow && picksNow.tree) paintPicks(picksNow); else loadItemPicks();
      D.store.settings().then((st) => { if ($('#hmLvHard')) { $('#hmLvHard').value = st.levelRule?.hard ?? ''; $('#hmLvNormal').value = st.levelRule?.normal ?? ''; } });
      const saveRule = async () => {
        const hard = Number($('#hmLvHard').value), normal = Number($('#hmLvNormal').value);
        await D.store.saveSettings({ levelRule: hard > 0 ? { hard, normal: normal > 0 && normal < hard ? normal : 0 } : null });
      };
      $('#hmLvHard').addEventListener('change', saveRule);
      $('#hmLvNormal').addEventListener('change', saveRule);
    }
  }
  // 문항정보표: 학기·고사·학년·과목(교사 결정 2026-10-28). [문항정보표]를 누르면 목록을 읽어 두고(고사×학년별 과목까지),
  // 패널에서 고를 때는 나이스를 안 움직임 → [나이스에서 확인하기]를 누르면 고른 조건으로 바꾸고 조회
  let picksBusy = false;
  let picksNow = null; // { picks, options, start, tree }
  let picksWant = null; // 패널에서 고른 값 { sem, exam, grade, subject }
  function paintPicks(res) {
    const box = $('#hmPicks');
    if (!box) return;
    if (res.error) { box.innerHTML = `<p class="err">${esc(res.error)}</p><button class="btn-line small" id="hmPicksLoad">다시 읽기</button>`; return; }
    picksNow = res;
    const U = Object.fromEntries(res.picks.map((p) => [p.key, p.udc]));
    picksWant = picksWant || Object.fromEntries(res.picks.map((p) => [p.key, res.options[p.udc]?.value || '']));
    const subjItems = res.tree?.[picksWant.exam]?.[picksWant.grade] ?? res.options[U.subject]?.items ?? [];
    if (!subjItems.some((it) => it.cd === picksWant.subject)) picksWant.subject = subjItems[0]?.cd || '';
    const sel = (p, items) => `<label class="pick"><span>${esc(p.label)}</span><select data-pick="${esc(p.key)}" ${items.length ? '' : 'disabled'}>${items.length ? items.map((it) => `<option value="${esc(it.cd)}" ${it.cd === picksWant[p.key] ? 'selected' : ''}>${esc(it.nm)}</option>`).join('') : '<option value="">(없음)</option>'}</select></label>`;
    box.innerHTML = `<div class="pick-row">${res.picks.map((p) => sel(p, p.key === 'subject' ? subjItems : res.options[p.udc]?.items || [])).join('')}</div>
      ${subjItems.length ? '<p class="muted">[나이스에서 확인하기]를 누르면 나이스 조건을 이대로 바꿔 조회해요. <button class="link" id="hmPicksLoad">목록 다시 읽기</button></p>' : '<p class="warn">이 학년·고사에는 문항정보표를 넣을 과목이 없어요. 학년이나 고사를 바꿔 보세요.</p>'}`;
  }
  // 고른 조건을 글로(준비됨 화면용)
  function picksLabel() {
    if (!picksNow || picksNow.error || !picksWant) return '';
    const U = Object.fromEntries(picksNow.picks.map((p) => [p.key, p.udc]));
    const nm = (key, items) => (items || []).find((it) => it.cd === picksWant[key])?.nm || '';
    return [nm('sem', picksNow.options[U.sem]?.items), nm('exam', picksNow.options[U.exam]?.items), `${nm('grade', picksNow.options[U.grade]?.items)}학년`, nm('subject', picksNow.tree?.[picksWant.exam]?.[picksWant.grade] || picksNow.options[U.subject]?.items)].filter((x) => x && x !== '학년').join(' · ');
  }
  async function loadItemPicks() {
    if (picksBusy) return;
    const tab = await D.neis.activeTab();
    if (!D.neis.isNeis(tab)) { paintPicks({ error: '나이스 탭에서 열어 주세요.' }); return; }
    picksBusy = true;
    if ($('#hmPicks')) $('#hmPicks').innerHTML = '<p class="muted">나이스에서 학기·고사·학년·과목 목록을 읽는 중…(다 읽은 뒤 나이스 조건은 원래대로 돌아가요)</p>';
    try { picksWant = null; paintPicks(await task.loadPicks(tab.id)); } finally { picksBusy = false; }
  }

  // 빈 양식이 있는 일: 파일 놓는 곳 바로 위에 '1 양식 받기 → 2 채우기 → 3 끌어다 놓기'
  const isRecord = (r) => /^neis\.record\./.test(r?.screenId || '');
  function templateSteps(r) {
    if (!r.template) return '';
    const url = chrome.runtime.getURL(`templates/${r.template}`);
    // 생기부: 명단(학번·이름)이 든 양식도(교사 요청 2026-10-29) — 우리 반 / 내 수업 반(과목마다 탭)
    const setuk = r.screenId === 'neis.record.setuk';
    // 동아리는 부서 학생이 여러 반이라 우리 반 명단 양식이 맞지 않음 → 빈 양식만
    const perfForm = r.screenId === 'neis.assess.perf';
    const named = perfForm ? '<button class="btn-tpl main" id="hmTplNamed">내 수업 명단 든 양식 · 과목별 탭</button>'
      : isRecord(r) && r.screenId !== 'neis.record.club' ? `<button class="btn-tpl main" id="hmTplNamed">${setuk ? '내 수업 명단 든 양식 · 과목별 탭' : '우리 반 명단 든 양식'}</button>` : '';
    return `
      <ol class="tpl" id="hmTpl">
        <li class="tpl-first"><span class="tpl-no">1</span><div class="tpl-text"><b>양식 받기</b><span>${perfForm ? '명단 든 양식은 나이스 수행평가 화면에서 과목마다 학번·이름·영역을 읽어 넣어요' : isRecord(r) && r.screenId !== 'neis.record.club' ? `명단 든 양식은 나이스에서 ${setuk ? '내 수업 반' : '우리 반'} 학번·이름을 읽어 넣어요 · 바이트 칸이 나이스처럼 세요` : '칸 이름이 맞춰진 엑셀 — 채워서 아래에 끌어다 놓기'}</span></div>
          <div class="tpl-btns">${named}<a class="btn-tpl" id="hmTplGet" href="${url}" download="${esc(r.template)}">빈 양식 받기 · 엑셀</a></div></li>
        <li><span class="tpl-no">2</span><div class="tpl-text"><b>채우기</b><span>${esc(r.fill || '머리줄 칸 이름은 그대로 두기')}</span></div></li>
        <li><span class="tpl-no">3</span><div class="tpl-text"><b>저장한 파일을 아래에 끌어다 놓기</b><span>확인 표를 보고 [입력 후 저장]</span></div></li>
      </ol>`;
  }

  function hintFor(r) {
    if (r.id === 'daily') return '칸 예시: 번호 · 이름 · 날짜 · 구분(질병결석·병결·미인정지각…) · 사유. 한 달치는 한 파일에 날짜별로 여러 줄 적으면 날짜마다 조회해 한 번에 저장해요. 날짜에 10/14~16처럼 기간을 적으면 평일마다 들어가요. 날짜가 비면 나이스 화면에 고른 날짜.';
    // 반은 담임 반(3-2)이 아니라 수업 반 — 선택과목은 '302'·'미래탐색실(C)'처럼 나이스 수업 반 이름이 따로 있다(교사 2026-10-29)
    if (r.id === 'subject') return '칸 예시: 날짜 · 교시 · 반 · 번호 · 이름 · 구분(결과·출석인정·출석) · 사유. 반은 담임 반이 아니라 나이스 수업 반 이름 그대로(예: 302, 미래탐색실(C)) — 출석부 웹앱 수업 출석부 파일이면 이미 그렇게 들어 있어요.';
    return r.hint || '칸 예시: 번호 · 이름 · 내용. 나이스 글자 수(바이트) 한도를 넘으면 알려 드려요.';
  }

  function progress(steps) {
    show('busy', `
      ${title(`${task.label} 입력`)}
      ${file ? info([['파일', esc(file.name)]]) : ''}
      <ul class="progress">${steps.map((s, i) => `<li class="${i === steps.length - 1 ? 'now' : 'done'}"><span>${i === steps.length - 1 ? '진행 중' : '완료'}</span>${esc(s)}</li>`).join('')}</ul>`);
  }

  // ── 확인 표에서 바로 고치기(일일출결): 종류·인정·교시·사유를 눌러서 고른다(교사 요청 2026-10-29: 직접 쓰지 않고 고르게).
  //    고른 값은 파일 글에 반영해 두고 [고친 값으로 다시 확인]을 눌러야 나이스에서 다시 비교 ──
  let fixes = {}; // { 줄 번호: { type, sub, ps:[교시], reason, own, kind, period } }
  const fixCtx = {}; // { 줄 번호: { base: 지금 구분 이름, reasons: [고를 사유], max: 마지막 교시 } }
  const FX_TYPES = ['결석', '지각', '조퇴', '결과'];
  const FX_SUBS = ['질병', '미인정', '기타', '출석인정'];
  const FX_REASONS = { 질병: ['감기', '몸살', '복통', '두통', '병원 진료'], 미인정: ['개인 사정'], 기타: ['가정 사정'], 출석인정: ['교외체험학습', '면접', '경조사', '대회 참가'] };
  const FX_RECOGNIZED = ['교외체험학습', '면접', '생리'];
  const splitKind = (n) => { const t = String(n || '').replace(/\s/g, ''); return { type: t === '출석' ? '출석' : FX_TYPES.find((x) => t.endsWith(x)) || '', sub: FX_SUBS.find((x) => t.startsWith(x)) || '' }; };
  const pName = (p) => (p === 0 ? '조회' : p === 99 ? '종례' : String(p));
  // 고른 것 + 지금 구분에서 모자란 쪽을 합쳐 구분 이름으로(예: 지금 '질병결석'에서 [지각]만 누르면 '질병지각')
  function fixKind(f, base) {
    const b = splitKind(base);
    const type = f.type || b.type, sub = f.sub || b.sub;
    if (type === '출석') return '출석';
    return type && sub ? `${sub}${type}` : '';
  }
  // 문항정보표: 성취기준 칩(나이스 목록 그대로, 여러 개 고를 수 있음 — 최대 6개)
  function stdBody(line) {
    const f = fixes[line] || {}, c = fixCtx[line];
    const on = f.std || c.now;
    const chip = (e) => `<button type="button" class="fx std${on.includes(e.code) ? (f.std ? ' on' : ' now') : ''}" data-fx="std" data-v="${esc(e.code)}" title="${esc(e.cn)}"><span class="cd">${esc(e.code)}</span><small>${esc(e.cn.length > 22 ? `${e.cn.slice(0, 22)}…` : e.cn)}</small></button>`;
    return `<div class="fx-line fx-std"><span>성취기준</span>${c.list.map(chip).join('')}</div>
      ${(f.std || []).length > 6 ? '<p class="err">성취기준은 문항마다 6개까지예요.</p>' : '<p class="dim">눌러서 고르고(여러 개 가능) 아래 [고친 값으로 다시 확인]을 눌러 주세요.</p>'}`;
  }
  function fixBody(line) {
    if (fixCtx[line]?.list) return stdBody(line);
    const f = fixes[line] || {}, c = fixCtx[line];
    const b = splitKind(c.base);
    const type = f.type || b.type, sub = f.sub || b.sub;
    // 고른 것은 채움, 지금 구분(고르지 않음)은 테두리만
    const chip = (k, v, picked, now, label = v) => `<button type="button" class="fx${picked ? ' on' : now ? ' now' : ''}" data-fx="${k}" data-v="${esc(String(v))}">${esc(label)}</button>`;
    const ps = f.ps || [];
    const periods = [0, ...Array.from({ length: c.max }, (_, i) => i + 1), 99];
    // 나이스 사유는 기타(적은 글)와 출석인정 교외체험학습·면접·생리만(교사 결정 2026-10-30) — 출석인정은 그 이름 버튼만
    const reasons = sub === '출석인정' ? FX_RECOGNIZED : [...new Set([...(c.reasons[sub] || []), ...(FX_REASONS[sub] || [])])].slice(0, 8);
    const half = (f.type || f.sub) && !fixKind(f, c.base);
    return `
      <div class="fx-line"><span>종류</span>${['출석', ...FX_TYPES].map((t) => chip('type', t, f.type === t, !f.type && b.type === t)).join('')}</div>
      ${type === '출석' ? '' : `<div class="fx-line"><span>인정</span>${FX_SUBS.map((x) => chip('sub', x, f.sub === x, !f.sub && b.sub === x)).join('')}</div>`}
      ${FX_TYPES.slice(1).includes(type) ? `<div class="fx-line"><span>교시</span>${periods.map((p) => chip('p', p, ps.includes(p), false, pName(p))).join('')}</div>
      ${f.autoPs && ps.length ? `<p class="ok small">나이스에 찍힌 교시(${(c.marks || []).map(pName).join(', ')})를 보고 ${pName(ps[0])}~${pName(ps[ps.length - 1])}를 골라 뒀어요.</p>` : ''}
      <p class="dim">${type === '지각' ? '마지막으로 빠진 교시를 누르면 조회부터 그 교시까지 한 번에 골라져요. ' : type === '조퇴' ? '처음 빠진 교시를 누르면 그 교시부터 종례까지 한 번에 골라져요. ' : ''}교시를 안 고르면 ${type === '지각' ? '조회부터 나이스에 찍힌 마지막 교시까지' : type === '조퇴' ? '나이스에 찍힌 첫 교시부터 종례까지' : '나이스에 찍힌 교시 그대로'}</p>` : ''}
      ${type === '출석' || !['기타', '출석인정'].includes(sub) ? '' : `<div class="fx-line"><span>사유</span>${reasons.map((r) => chip('reason', r, !f.own && f.reason === r, false)).join('')}${sub === '기타' ? `${chip('own', '', f.own, false, '직접 쓰기')}${f.own ? `<input data-fix="reason" value="${esc(f.reason || '')}" placeholder="사유">` : ''}` : ''}</div>`}
      ${half ? '<p class="err">종류와 인정을 함께 골라 주세요.</p>' : ''}`;
  }
  function fixHtml(g, r) {
    if (isItems() && r.line && r.stdPick && g.result.stdList?.length) {
      fixCtx[r.line] = { list: g.result.stdList, now: r.std?.codes || [] };
      const open = Object.keys(fixes[r.line] || {}).length;
      return `<details class="fix" ${open ? 'open' : ''}><summary>성취기준 고치기</summary><div class="fix-row" data-line="${r.line}">${fixBody(r.line)}</div></details>`;
    }
    if (task?.id !== 'daily' || !r.line || r.status === 'same') return '';
    const rows = g.result.rows;
    const short = (t) => String(t || '').trim().length <= 12;
    fixCtx[r.line] = {
      base: r.next ? valueLabel(task, g.codes, r.next.kind) : r.kindText || '',
      // 이 파일에 이미 쓴 사유를 먼저(짧은 것만, 같은 인정 구분끼리 — 질병 사유가 미인정 줄에 뜨지 않게)
      reasons: rows.reduce((m, x) => {
        const t = String(x.next?.reason || x.reason || '').trim();
        const k = splitKind(x.next ? valueLabel(task, g.codes, x.next.kind) : x.kindText).sub;
        if (t && k && short(t) && !(m[k] ||= []).includes(t) && m[k].length < 4) m[k].push(t);
        return m;
      }, {}),
      max: Math.max(7, ...rows.flatMap((x) => x.periods || []).filter((n) => n < 99)),
    };
    const f = fixes[r.line] || {};
    const open = r.status === 'error' || Object.keys(f).length;
    return `<details class="fix" ${open ? 'open' : ''}><summary>고치기</summary><div class="fix-row" data-line="${r.line}">${fixBody(r.line)}</div></details>`;
  }
  // 고친 값·다시 확인한 글을 이어서 하기 자료(chrome.storage.session — 브라우저를 닫거나 확장을 다시 읽으면 사라짐)에 함께 둔다
  // (교사 요청 2026-10-30: 한 달치를 열심히 고쳤는데 날아갈까 걱정 — 패널을 닫았다 열거나 [↻ 새로고침]해도 [이어서 하기]로 그대로)
  let keepTimer = null;
  function keepWork() {
    if (!file?.text || !task || !D.store) return;
    clearTimeout(keepTimer);
    // 지금 값으로 미리 묶어 둔다(0.3초 안에 [처음으로] 등으로 file이 비면 예외가 났음 — 2026-10-30 시험)
    const work = { name: file.name, text: file.trialFrom || file.text, task: task.id, fixes, choices: file.choices || {}, seen: file.seen || [] };
    keepTimer = setTimeout(() => { D.store.setWork(WORK, work).catch(() => {}); }, 300);
  }
  function setFix(ln, f) {
    if (fixCtx[ln]?.list) { if (f.std) fixes[ln] = f; else delete fixes[ln]; }
    else {
      f.kind = f.type || f.sub ? fixKind(f, fixCtx[ln].base) : '';
      f.period = f.type === '결석' || f.type === '출석' || !f.ps?.length ? '' : f.ps.map(pName).join(',');
      if (!f.type && !f.sub && !f.ps?.length && !f.reason && !f.own) delete fixes[ln]; else fixes[ln] = f;
    }
    const b = $('#hmRecheck'); if (b) b.hidden = !Object.keys(fixes).length;
    if ($('#hmGo') && Object.keys(fixes).length) $('#hmGo').disabled = true; // 고친 뒤에는 다시 확인해야 저장
    keepWork();
  }
  // 파일 글의 그 줄에 고친 값을 넣음(칸이 없으면 머리줄 끝에 '교시'·'사유' 칸을 더함)
  function applyFixes(text) {
    const lines = String(text).replace(/\r\n?/g, '\n').split('\n');
    const hi = lines.findIndex((l) => l.trim());
    if (hi < 0) return text;
    const sep = lines[hi].includes('\t') ? '\t' : ',';
    const cells = (l) => D.splitCells(l, sep);
    const join = (cs) => cs.map((c) => (sep === ',' && /[",\n]/.test(c) ? `"${String(c).replace(/"/g, '""')}"` : c)).join(sep);
    const head = cells(lines[hi]);
    const col = (names) => head.findIndex((h) => names.includes(D.squash(h)));
    const need = { kind: ['구분', '출결', '출결구분', '종류', '출결종류', '상태'], period: ['교시'], reason: ['사유', '비고', '메모', '내용', '출결사유'], std: ['성취기준', '성취기준코드'] };
    const NEW_HEAD = { kind: '구분', period: '교시', reason: '사유', std: '성취기준' };
    const idx = {};
    for (const [k, names] of Object.entries(need)) {
      idx[k] = col(names);
      if (idx[k] < 0 && Object.values(fixes).some((f) => f[k])) { head.push(NEW_HEAD[k]); idx[k] = head.length - 1; }
    }
    // 나이스에만 있던 학생을 새 줄로(교사 요청 2026-10-29)
    const adds = Object.entries(fixes).filter(([ln]) => ln.startsWith('add:'));
    if (adds.length) {
      const want = { no: ['번호', '번', '출석번호'], name: ['이름', '성명', '학생', '학생명'], date: ['날짜', '일자', '출결일', '출결일자'] };
      for (const [k, names] of Object.entries(want)) { idx[k] = col(names); if (idx[k] < 0) { head.push(k === 'no' ? '번호' : k === 'name' ? '이름' : '날짜'); idx[k] = head.length - 1; } }
      for (const k of ['kind', 'period', 'reason']) if (idx[k] < 0) { head.push(k === 'kind' ? '구분' : k === 'period' ? '교시' : '사유'); idx[k] = head.length - 1; }
      for (const [ln, f] of adds) {
        const a = fixCtx[ln]?.add;
        if (!a || !f.kind) continue;
        const cs = Array(head.length).fill('');
        cs[idx.no] = a.no; cs[idx.name] = a.name; cs[idx.date] = `${a.date.slice(0, 4)}-${a.date.slice(4, 6)}-${a.date.slice(6)}`;
        cs[idx.kind] = f.kind; if (f.period) cs[idx.period] = f.period; if (f.reason) cs[idx.reason] = f.reason;
        lines.push(join(cs));
      }
    }
    lines[hi] = join(head);
    for (const [ln, f] of Object.entries(fixes)) {
      if (ln.startsWith('add:')) continue;
      const i = +ln - 1;
      if (!lines[i]) continue;
      const cs = cells(lines[i]);
      while (cs.length < head.length) cs.push('');
      for (const k of ['kind', 'period', 'reason']) if (f[k]) cs[idx[k]] = f[k];
      if (f.std) cs[idx.std] = f.std.join(', ');
      lines[i] = join(cs);
    }
    return lines.join('\n');
  }

  // ── 직접 확인할 곳(교사 결정 2026-10-30) ─────────────────────
  // ① 나이스에 이미 넣은 출결 구분과 자료(폰) 구분이 다른 줄 — 기본은 자료 값으로, 줄마다 [나이스 그대로]
  // ② 나이스에만 있는 학생(일일출결) — 그대로 두되 색을 다르게. [다음 ▶]으로 하나씩 짚고 [확인]하면 초록
  // 고른 것(file.choices: '묶음|번호' → 'neis')·확인한 곳(file.seen)은 이어서 하기(storage.session)에 함께
  const srcWord = () => (file?.phone ? '폰' : '자료');
  const spotKey = (kind, g, no) => `${kind}:${g.key}|${no}`;
  const isSeen = (k) => (file?.seen || []).includes(k);
  let spotAt = '';
  function spotList(c) {
    const out = [];
    for (const g of c.groups) {
      if (!g.result) continue;
      for (const r of g.result.rows) if (r.conflict) out.push({ key: spotKey('c', g, r.neisNo || r.no), ck: `${g.key}|${r.neisNo || r.no}`, conflict: true });
      if (task?.id === 'daily') for (const n of g.result.neisOnly || []) out.push({ key: spotKey('n', g, n.no) });
    }
    return out;
  }
  function spotsHtml(c) {
    const list = spotList(c);
    if (!list.length) return '';
    const conf = list.filter((s) => s.conflict);
    const keep = conf.filter((s) => file.choices?.[s.ck] === 'neis').length;
    const done = list.filter((s) => isSeen(s.key)).length;
    const parts = [conf.length ? `나이스와 출결 구분이 다른 줄 <b>${conf.length}</b> (기본은 ${srcWord()} 값으로${keep ? ` · 나이스 그대로 ${keep}` : ''})` : '', list.length > conf.length ? `나이스에만 있는 학생 <b>${list.length - conf.length}</b>` : ''].filter(Boolean);
    return `<div class="spots"><span>직접 확인할 곳 ${list.length}곳 · ${done === list.length ? '모두 확인했어요' : `확인 ${done}`}</span>
        <p>${parts.join(' · ')}</p>
        <div class="actions"><button class="btn-main small" data-spot-next="1">${done ? '다음 ▶' : '처음부터 보기 ▶'}</button>${conf.length ? `<button class="btn-line small" data-pick-all="phone">모두 ${srcWord()} 값으로</button><button class="btn-line small" data-pick-all="neis">모두 나이스 그대로</button>` : ''}</div>
      </div>`;
  }
  // 아직 확인 안 한 다음 곳으로(from 다음부터 한 바퀴)
  function goSpot(from = '') {
    const list = [...el.querySelectorAll('tr[data-spot]')];
    if (!list.length) return;
    const d = el.querySelector('details.detail');
    if (d) d.open = true;
    const at = from ? list.findIndex((t) => t.dataset.spot === from) + 1 : 0;
    const next = [...list.slice(at), ...list.slice(0, at)].find((t) => !t.classList.contains('seen'));
    if (!next) { const s = el.querySelector('.spots > span'); if (s) s.textContent = `직접 확인할 곳 ${list.length}곳 · 모두 확인했어요`; return; }
    spotAt = next.dataset.spot;
    next.scrollIntoView({ block: 'center', behavior: 'smooth' });
    next.classList.add('flash');
    setTimeout(() => next.classList.remove('flash'), 1600);
  }
  function markSeen(k) { if (k && file) file.seen = [...new Set([...(file.seen || []), k])]; }
  // 고른 것만 바꿔 다시 계산(나이스에 다시 묻지 않음) → 그린 뒤 다음 곳으로
  function repick(from) {
    if (!checked || !task?.recompute) return;
    checked = task.recompute(checked, file.choices || {});
    keepWork();
    summary(checked);
    goSpot(from);
  }

  function tableHtml(g) {
    const rows = g.result.rows.map((r) => {
      const now = r.cur ? `${esc(valueLabel(task, g.codes, r.cur.kind))}${r.cur.reason ? `<small>${esc(r.cur.reason)}</small>` : ''}` : '-';
      const next = r.status === 'same' ? '<span class="dim">그대로</span>'
        : r.status === 'keep' ? `<span class="dim">나이스 그대로</span><small class="dim">${srcWord()}: ${esc(valueLabel(task, g.codes, r.next.kind))}</small>`
        : r.next ? `<span class="chg">${esc(valueLabel(task, g.codes, r.next.kind))}</span>${r.next.reason ? `<small>${esc(r.next.reason)}</small>` : ''}${r.markNote ? `<small class="dim">${esc(r.markNote)}</small>` : ''}`
          : esc(r.kindText || '-');
      const notes = [...r.issues.map((t) => `<p class="err">${esc(t)}</p>`), ...(r.checks || []).map((t) => `<p class="warn">${esc(t)}</p>`), ...r.warnings.map((t) => `<p class="dim">${esc(t)}</p>`)].join('');
      const fx = fixHtml(g, r);
      // 나이스 구분과 자료 구분이 다른 줄: 직접 확인할 곳 + [폰 값으로]·[나이스 그대로](교사 결정 2026-10-30, 기본은 폰 값으로)
      const no = r.neisNo || r.no || '';
      const sk = r.conflict ? spotKey('c', g, no) : '';
      const ck = `${g.key}|${no}`;
      const pick = r.conflict ? `<p class="spot-why">나이스와 구분이 달라요</p>` : '';
      const pickBtns = r.conflict ? `<div class="pick"><button class="btn-line small${r.status !== 'keep' ? ' on' : ''}" data-pick="phone" data-key="${esc(ck)}" data-spot="${esc(sk)}">${srcWord()} 값으로</button><button class="btn-line small${r.status === 'keep' ? ' on' : ''}" data-pick="neis" data-key="${esc(ck)}" data-spot="${esc(sk)}">나이스 그대로</button></div>` : '';
      return `<tr class="${r.status}${sk ? ` spot${isSeen(sk) ? ' seen' : ''}` : ''}"${sk ? ` data-spot="${esc(sk)}"` : ''}><td class="c">${esc(no)}</td><td>${esc(r.name || r.neisName || '')}${pick}${notes}</td><td>${now}</td><td>${next}${pickBtns}</td></tr>${fx ? `<tr class="fix-tr ${r.status}"><td colspan="4">${fx}</td></tr>` : ''}`;
    }).join('');
    // 나이스에만 있는 학생(자료에 없음): [추가해서 고치기]로 이 날짜 줄을 자료에 더함(일일출결)
    const extra = task?.id === 'daily' ? (g.result.neisOnly || []).map((n) => {
      const ln = `add:${g.date}:${n.no}`;
      const added = !!fixCtx[ln] || !!fixes[ln];
      const nMax = Math.max(7, n.tot || 0, ...(n.marks || []).filter((p) => p < 99));
      if (added) fixCtx[ln] = fixCtx[ln] || { base: n.kind ? valueLabel(task, g.codes, n.kind) : '', reasons: {}, max: nMax, marks: n.marks || [], add: { date: g.date, no: n.no, name: n.name } };
      const now = n.kind ? `${esc(valueLabel(task, g.codes, n.kind))}${n.reason ? `<small>${esc(n.reason)}</small>` : ''}` : '<span class="dim">교시 표시만</span>';
      // 직접 확인할 곳(교사 요청 2026-10-30: 나이스에만 있는 줄이 잘 안 보임 — 색을 다르게, [확인]하면 초록·다음 곳으로)
      const nk = spotKey('n', g, n.no);
      const seenBtn = isSeen(nk) ? '<span class="ok-mark">확인함</span>' : `<button class="btn-text" data-seen="${esc(nk)}">확인</button>`;
      return `<tr class="neis-only spot${isSeen(nk) ? ' seen' : ''}" data-spot="${esc(nk)}"><td class="c">${esc(n.no)}</td><td>${esc(n.name)}<p class="spot-why">나이스에만 있어요(자료에 없음)</p></td><td>${now}</td><td>${added ? '<span class="dim">아래에서 고르기</span>' : `<button class="btn-line small" data-add-neis="${esc(ln)}" data-kind="${esc(n.kind)}" data-name="${esc(n.name)}" data-marks="${esc((n.marks || []).join(','))}" data-max="${nMax}">추가해서 고치기</button>`} ${seenBtn}</td></tr>
        ${added ? `<tr class="fix-tr"><td colspan="4"><details class="fix" open><summary>고치기</summary><div class="fix-row" data-line="${esc(ln)}">${fixBody(ln)}</div></details></td></tr>` : ''}`;
    }).join('') : '';
    const [c1, c2] = task.cols || ['번호', '성명'];
    return `<table class="grid"><thead><tr><th class="c">${esc(c1)}</th><th>${esc(c2)}</th><th>현재</th><th>입력</th></tr></thead><tbody>${rows}${extra}</tbody></table>`;
  }

  // 날짜 묶음 하나에 고칠 곳이 몇인지(바로 가기 목록용): 날짜 안내(빨간 글) + 빨간 학생 줄
  const groupProblems = (g) => (g.error ? { notes: 1, rows: 0 } : { notes: g.result.issues.length, rows: g.result.summary.error });
  function groupHtml(g, withNotes = true, i = -1) {
    const p = groupProblems(g);
    const state = g.error || p.notes || p.rows ? `<span class="tag err">확인 필요${p.rows ? ` · ${p.rows}줄` : ''}</span>` : g.result.summary.change ? `<span class="tag">${g.result.summary.change}건</span>` : '<span class="tag dim">변경 없음</span>';
    const head = `<h4>${esc(g.title)} ${state}</h4>`;
    const id = i >= 0 ? ` id="grp-${i}"` : '';
    if (g.error) return `<div class="group"${id}>${head}<p class="err">${esc(g.error)}</p></div>`;
    const msgs = [...g.result.issues.map((t) => `<p class="err">${esc(t)}</p>`), ...(withNotes ? g.result.notes || [] : []).map((t) => `<p class="warn">${esc(t)}</p>`)].join('');
    return `<div class="group"${id}>${head}${msgs}${tableHtml(g)}</div>`;
  }
  // 확인 필요한 날짜로 바로 가기(교사 요청 2026-10-30: 18일치에서 빨간 곳을 찾기 어려움)
  function jumpHtml(c) {
    if (c.groups.length < 2) return '';
    const spots = c.groups.map((g, i) => ({ i, g, p: groupProblems(g) })).filter((x) => x.p.notes || x.p.rows);
    if (!spots.length) return '';
    return `<div class="jump"><span>확인 필요한 곳 — 눌러서 바로 가기</span>${spots.map((x) => `<button type="button" class="fx" data-jump="${x.i}">${esc(x.g.title)}<small>${[x.p.notes ? `안내 ${x.p.notes}` : '', x.p.rows ? `학생 ${x.p.rows}줄` : ''].filter(Boolean).join(' · ')}</small></button>`).join('')}</div>`;
  }

  // ③ 확인 결과
  function summary(c) {
    const problems = c.groups.reduce((n, g) => n + (g.error ? 1 : g.result.summary.error + g.result.issues.length), 0) + c.issues.length;
    const days = new Set(c.groups.map((g) => g.date).filter(Boolean)).size;
    const scope = task.id === 'subject' ? `${c.groups.length}개 수업` : task.groupWord ? `${c.groups.length}개 ${task.groupWord}` : days ? `${days}일` : '';
    // 화면 하나짜리 일(생기부·평가)은 안내를 맨 위에 — 고른 고사·생기부 점검처럼 꼭 봐야 하는 것
    const one = c.groups.length === 1 && c.groups[0].result ? c.groups[0] : null;
    const top = one || task.notesOnTop ? c.groups.flatMap((g) => g.result?.notes || []) : [];
    const flagged = c.groups.reduce((n, g) => n + (g.result?.summary.flagged || 0), 0);
    const status = problems ? `<span class="err">확인 필요 ${problems}건</span>` : task.checkOnly ? '<b>모두 맞아요</b>' : c.change ? `<b>${c.change}건</b> 입력 예정${scope ? ` (${scope})` : ''}` : '변경할 내용 없음 (나이스와 같음)';
    // 처음 한 번 1건 시험: 다른 문제가 없으면 [먼저 1건 넣어 보기](파일 첫 변경 줄만) → 나이스에서 확인 → [나머지 넣기]
    const first = c.needTrial && problems === 1 ? c.groups.flatMap((g) => g.result?.rows || []).find((r) => r.status === 'change' && r.line) : null;
    const trialBtn = first ? `<button class="btn-main" id="hmTrialGo" data-line="${first.line}">먼저 1건(${esc(first.neisNo || first.no || '')} ${esc(String(first.neisName || first.name || '').slice(0, 8))}${String(first.neisName || first.name || '').length > 8 ? '…' : ''}) 넣어 보기</button>` : '';
    show('checked', `
      ${title(`${task.label}${task.checkOnly ? '' : ' 입력'}`)}
      ${info([['파일', esc(file.name)], ['결과', first ? `<b>${c.change}건</b> 입력 예정${scope ? ` (${scope})` : ''}` : status]])}
      ${c.issues.map((t) => `<p class="${first && c.needTrial && t.startsWith('이 화면은 처음이라') ? 'warn' : 'err'}">${esc(t)}</p>`).join('')}
      ${jumpHtml(c)}
      ${task.checkOnly ? '' : spotsHtml(c)}
      ${top.map((t) => `<p class="${task.checkOnly && !problems && /합계 100%/.test(t) ? 'ok' : 'warn'}">${esc(t)}</p>`).join('')}
      ${suggestNote()}
      <div class="actions">${task.checkOnly ? '<button class="btn-main" id="hmCheck">다시 점검</button>' : trialBtn || `<button class="btn-main" id="hmGo" ${c.canApply ? '' : 'disabled'}>입력 후 저장</button>`}<button class="btn-line" id="hmRecheck" ${Object.keys(fixes).length ? '' : 'hidden'}>고친 값으로 다시 확인</button>${back('취소')}</div>
      ${task.checkOnly || task.noFile ? '' : '<p class="hint dim save-now">고친 자료를 이 PC에 남겨 두려면 <button class="btn-text" id="hmSaveNow">지금 자료 엑셀로 받기</button> — 다시 끌어다 놓으면 이어서 해요(학생 이름이 들어 있어요).</p>'}
      <details class="detail" ${problems || flagged ? 'open' : ''}><summary>상세 내역</summary>${c.groups.map((g, i) => groupHtml(g, !top.length, i)).join('')}</details>`);
  }

  // 고른 일과 파일이 안 맞아 보일 때
  function suggestNote() {
    if (task?.checkOnly) return ''; // 점검 화면은 평가계획 파일을 그대로 받으니 다른 화면을 권하지 않음(2026-11-02 실제)
    const s = D.runners.suggest(file.text, task);
    if (!s || s === task) return '';
    return `<p class="warn">이 파일은 <b>${esc(s.label)}</b> 파일처럼 보여요. <button class="btn-text" data-switch="${esc(s.id)}">${esc(s.label)}(으)로 바꾸기</button></p>`;
  }

  // ── 흐름 ──────────────────────────────────────────────
  const verifiedFor = async (r) => !!(await D.store.settings()).verified[r.screenId];

  // resume: OTP 인증을 마치고 [OTP 인증 완료 — 이어서]를 누름 → 파일은 다시 넣지 않고 화면이 열렸는지부터 본다
  async function check({ resume = false } = {}) {
    if (busy || !task || !file) return;
    busy = true;
    const steps = [resume ? 'OTP 인증 완료' : '파일 읽기'];
    const step = (t) => { steps.push(t); progress(steps); };
    progress(steps);
    try {
      if (picksBusy) {
        step('나이스 조건 목록을 다 읽을 때까지 기다리는 중');
        for (const end = Date.now() + 40000; picksBusy && Date.now() < end;) await new Promise((r) => setTimeout(r, 200));
      }
      const tab = await D.neis.activeTab();
      if (!D.neis.isNeis(tab)) { fail('나이스 탭을 열고 로그인한 뒤 다시 해 주세요.'); return; }
      file.tabId = tab.id;
      // 문항정보표: 패널에서 고른 학기·고사·학년·과목으로 나이스 조건을 바꾼 뒤 조회
      if (isItems() && picksWant && task.applyPicks) {
        step('나이스 조건(학기·고사·학년·과목) 바꾸는 중');
        const ap = await task.applyPicks(tab.id, picksWant);
        if (ap.error) { fail(ap.error); return; }
      }
      const c = await task.check(file.text, { tabId: tab.id, step, verified: await verifiedFor(task), attach: file.attach || null, resume, choices: file.choices || {}, sheet: file.sheet || '', trialFrom: file.trialFrom || '' });
      if (c.fatal && c.otp) { otpWait(c, resume); return; }
      if (c.fatal) { fail(c.fatal); return; }
      checked = c;
      summary(c);
    } finally {
      busy = false;
    }
  }

  function fail(msg) {
    show('error', `
      ${title(`${task?.label || ''} 입력`)}
      <p class="err big">${esc(msg)}</p>
      <div class="actions">${file ? '<button class="btn-main" id="hmRetry">다시 확인</button>' : ''}${back()}</div>`);
  }

  // 생기부(screen.otp): 파일 놓기 전에도 [OTP 인증] — 누를 때만 도우미가 그 생기부 메뉴를 열어 나이스 OTP 창이 뜨게 한다(조회·입력 없음)
  const needsOtp = () => !!(task?.screenId && D.screens.get(task.screenId)?.otp);
  function otpBlock() {
    if (!needsOtp()) return '';
    return `<div class="otp-pre"><button class="btn-line small" id="hmOtpOpen">OTP 인증</button>
      <span class="dim">나이스 ${esc(task.label)} 메뉴를 열어 OTP 인증 창을 띄워요(조회·입력은 안 해요). 인증을 먼저 마쳐 두면 확인이 바로 이어져요.</span></div>`;
  }
  async function otpOpen({ resume = false } = {}) {
    if (busy || !task?.openOnly) return;
    busy = true;
    const steps = [resume ? 'OTP 인증 완료' : 'OTP 인증 준비'];
    const step = (t) => { steps.push(t); progress(steps); };
    progress(steps);
    let r;
    try {
      const tab = await D.neis.activeTab();
      if (!D.neis.isNeis(tab)) { busy = false; fail('나이스 탭을 열고 로그인한 뒤 다시 해 주세요.'); return; }
      r = await task.openOnly({ tabId: tab.id, step, resume });
    } finally { busy = false; }
    if (r.otp) { otpWait(r, resume); return; }
    if (r.fatal) { fail(r.fatal); return; }
    // 화면이 열림 — 조회는 교사가 [나이스에서 확인하기]를 누를 때(버튼을 눌러야만 나이스가 움직임)
    if (file) { ready(`<p class="ok">나이스 ${esc(task.label)} 화면이 열렸어요. [나이스에서 확인하기]를 누르세요.</p>`); return; }
    askFile(`<p class="ok">나이스 ${esc(task.label)} 화면이 열렸어요. 이제 파일을 놓으세요.</p>`);
  }

  // 생기부 메뉴의 OTP(2차 인증): 파일은 이 패널에 그대로 두고, 교사가 나이스에서 인증을 마친 뒤 [OTP 인증 완료 — 이어서]
  // c.otpApps: 그때 새로 뜬 나이스 앱 ID(값 없음) — 실제 OTP 창 이름을 알아내려고 접어서 보여 줌
  function otpWait(c, again) {
    show('otp', `
      ${title(`${task.label} 입력`)}
      <div class="otp">
        <p class="otp-lead">나이스에서 <b>OTP 인증</b>을 마친 뒤 <b>[OTP 인증 완료 — 이어서]</b>를 눌러 주세요.</p>
        <ol class="howto">
          <li>나이스 화면에 뜬 OTP(2차 인증) 창에 번호를 넣고 확인을 누릅니다.</li>
          <li>${esc(task.label)} 화면이 열렸든 안 열렸든, 이 패널로 돌아와 아래 버튼을 누릅니다.</li>
        </ol>
        ${info([['파일', file ? `${esc(file.name)} <span class="dim">그대로 기억하고 있어요 — 다시 넣지 않아도 돼요</span>` : '<span class="dim">아직 없음 — 인증을 마치면 파일 놓는 곳으로 돌아가요</span>']])}
        ${again ? `<p class="warn">${esc(c.fatal)} OTP 창이 닫혔는지 확인하고 다시 눌러 주세요.</p>` : ''}
      </div>
      <div class="actions"><button class="btn-main" id="hmOtpGo">OTP 인증 완료 — 이어서</button>${back('그만두기')}</div>
      <details class="detail"><summary>자세히</summary>
        <p class="hint">${esc(c.fatal)}</p>
        ${c.otpAlert ? `<p class="hint">나이스 안내: ${esc(c.otpAlert)}</p>` : ''}
        ${c.otpApps?.length ? `<p class="hint">새로 뜬 나이스 창: <code>${c.otpApps.map(esc).join(', ')}</code></p>` : ''}
      </details>`);
  }

  async function apply() {
    if (busy || !checked?.canApply) return;
    busy = true;
    const steps = ['확인 완료'];
    const step = (t) => { steps.push(t); progress(steps); };
    let out;
    try {
      out = await task.apply(checked, { tabId: file.tabId, step });
    } finally {
      busy = false;
    }
    const good = !out.stop && out.saved.length === out.total;
    const total = out.saved.reduce((n, s) => n + s.count, 0);
    if (['daily', 'subject'].includes(task.id) && !file.trialFrom && out.saved.length) await D.phoneSync?.saved(task.id, out.saved.map((x) => x.date));
    if (file.phone) D.phoneSync?.forget();
    if (good) await D.store.clearWork(WORK);
    if (total || !good) await D.store.addLog({ screenId: task.screenId, ok: good });
    const verified = await verifiedFor(task);
    show('done', `
      ${title(`${task.label} 입력`)}
      ${info([['파일', esc(file.name)], ['결과', good ? `<span class="ok">${total}건 저장 완료</span>` : `<span class="err">${total}건 저장 후 중단</span>`]])}
      <table class="grid"><thead><tr><th>대상</th><th class="c">건수</th></tr></thead><tbody>${out.saved.map((s) => `<tr><td>${esc(s.title)}</td><td class="c">${s.count}</td></tr>`).join('') || '<tr><td colspan="2" class="dim">없음</td></tr>'}</tbody></table>
      ${out.stop ? `<p class="err">${esc(out.stop)}</p><p class="hint">자료는 그대로 있어요. 막힌 곳을 고친 뒤 [남은 것 다시 확인]을 누르면 이미 저장된 것은 '그대로'로 나오고 남은 것만 넣어요. [다른 일 하기]를 누르면 이 자료는 지워지니, 걱정되면 먼저 [지금 자료 엑셀로 받기]로 이 PC에 남겨 두세요.</p>` : ''}
      ${good && !verified ? `
        <div class="confirm" id="hmTrial">
          <p><b>처음 한 번만 확인해 주세요.</b> 나이스에서 그 학생을 조회해 맞게 들어갔는지 봐 주세요. 확인 전에는 1건씩만 입력돼요.</p>
          <div class="actions"><button class="btn-main small" id="hmOk">맞게 들어갔어요</button><button class="btn-line small" id="hmNo">다르게 들어갔어요</button></div>
        </div>` : ''}
      <div class="actions">${out.stop ? '<button class="btn-main" id="hmRetry">남은 것 다시 확인</button><button class="btn-line" id="hmSaveNow">지금 자료 엑셀로 받기</button>' : ''}${back('다른 일 하기')}</div>`);
  }

  // 지금 자료(고친 값까지)를 엑셀로 이 PC에 — 다시 끌어다 놓으면 그대로 이어서(교사 요청 2026-10-30: 고친 자료가 날아갈까 걱정)
  function saveNow() {
    if (!file?.text) return;
    const pending = Object.keys(fixes).length;
    const text = pending ? applyFixes(file.text) : (file.trialFrom || file.text);
    const lines = D.lines(text).map((l) => l.raw);
    const sep = lines.some((l) => l.includes('\t')) ? '\t' : ',';
    const blob = D.writeXlsx([{ name: task?.label || '자료', rows: lines.map((l) => D.splitCells(l, sep)) }]);
    const d = new Date();
    const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${(task?.label || '자료').replace(/\s+/g, '')}_고친자료_${ymd}.xlsx`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
    D.views.home.lastSaved = { name: a.download, lines: lines.length }; // 시험용(학생 이름 없음)
  }

  async function readFile(f) {
    if (/\.xlsx$/i.test(f.name)) return D.rowsToTsv(await D.readXlsx(await f.arrayBuffer()));
    if (/\.hwpx$/i.test(f.name)) return D.rowsToTsv(await D.readHwpx(await f.arrayBuffer(), { all: !!task?.allTables }));
    if (/\.(csv|tsv|txt)$/i.test(f.name)) return D.decodeText(await f.arrayBuffer());
    if (/\.xls$/i.test(f.name)) throw new Error('옛 엑셀(.xls)은 못 읽어요. 엑셀에서 .xlsx로 저장해 주세요.');
    if (/\.hwp$/i.test(f.name)) return D.rowsToTsv(await D.readHwp(await f.arrayBuffer(), { all: !!task?.allTables }));
    throw new Error('엑셀(.xlsx)·한글(.hwp·.hwpx)·CSV 파일을 넣어 주세요.');
  }

  // 문항정보표: 이름에 '채점'이 있거나 .hwp·.pdf면 서답형 채점기준표(나이스 첨부로 그대로 올림, 읽지 않음)
  const isScoringSheet = (f) => isItems() && (/채점/.test(f.name) || /\.(hwp|pdf)$/i.test(f.name));
  async function fileB64(f) {
    const bytes = new Uint8Array(await f.arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  }

  async function load(list) {
    const files = [...(list || [])].filter(Boolean);
    if (!files.length || busy || !task) return;
    const sheet = files.find(isScoringSheet);
    const table = files.find((f) => f !== sheet);
    let text = '';
    let sheets = null;
    if (table) {
      try {
        // 세특 명단 양식은 과목마다 탭 → 탭이 여럿이면 고르게(나이스에서 고른 과목 탭)
        if ((isRecord(task) || task?.screenId === 'neis.assess.perf') && /\.xlsx$/i.test(table.name)) {
          const all = (await D.readXlsxSheets(await table.arrayBuffer())).filter((s) => s.name !== '쓰는 법' && s.rows.length > 1);
          if (all.length > 1) sheets = all.map((s) => ({ name: s.name, text: D.rowsToTsv(s.rows) }));
        }
        text = sheets ? sheets[0].text : await readFile(table);
      } catch (e) { file = null; fail(e.message); return; }
      if (!D.lines(text).length) { file = null; fail('파일에 내용이 없어요.'); return; }
    }
    // 채점기준표는 이 패널 메모리에만(교사 시험 자료, 학생 정보 없음) — 이어서 하기에는 남기지 않음
    const attach = sheet ? { name: sheet.name, size: sheet.size, type: sheet.type, b64: await fileB64(sheet) } : null;
    file = { name: [table?.name, sheet?.name].filter(Boolean).join(' + '), text, attach, sheets, sheet: sheets ? sheets[0].name : '' };
    if (table) await D.store.setWork(WORK, { name: table.name, text, task: task.id });
    ready();
  }

  // 생기부 명단 양식: 나이스에서 명단을 읽어(버튼을 누를 때만, 조회만) 엑셀을 만들어 내려받기 → 파일 놓는 곳으로 돌아옴
  // 수행평가 성적 명단 양식: 나이스 조건을 돌며 읽고 원래대로 되돌린다(누를 때만)
  async function makePerfForm() {
    if (busy) return;
    const back = task;
    busy = true;
    const steps = ['나이스 확인'];
    const step = (t) => { steps.push(t); progress(steps); };
    progress(steps);
    let out;
    try {
      const tab = await D.neis.activeTab();
      if (!D.neis.isNeis(tab)) { busy = false; fail('나이스 탭을 열고 로그인한 뒤 다시 해 주세요.'); return; }
      out = await back.formData({ tabId: tab.id, step });
    } finally { busy = false; }
    task = back;
    if (out.fatal) { fail(out.fatal); return; }
    const made = D.recordForms.buildPerf(out);
    D.recordForms.last = { fileName: made.fileName, sheets: made.sheets }; // 시험용(학생 이름 없음)
    const a = document.createElement('a');
    a.href = URL.createObjectURL(made.blob);
    a.download = made.fileName;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 3000);
    const n = made.sheets.reduce((k, s) => k + s.count, 0);
    askFile(`<p class="ok">명단 든 양식을 받았어요: ${esc(made.fileName)} — 탭 ${made.sheets.length}개(${made.sheets.map((s) => esc(s.name)).join(', ')}) · 학생 ${n}명. 영역 칸에 점수를 적어 아래에 놓아 주세요.</p>`);
  }

  async function makeRecordForm() {
    if (busy || !isRecord(task)) return;
    const setuk = task.screenId === 'neis.record.setuk';
    const back = task;
    busy = true;
    const steps = ['나이스 확인'];
    const step = (t) => { steps.push(t); progress(steps); };
    progress(steps);
    let out;
    try {
      const tab = await D.neis.activeTab();
      if (!D.neis.isNeis(tab)) { busy = false; fail('나이스 탭을 열고 로그인한 뒤 다시 해 주세요.'); return; }
      out = await D.runners.roster[setuk ? 'subjects' : 'homeroom']({ tabId: tab.id, step });
    } finally { busy = false; }
    task = back;
    if (out.fatal) { fail(out.fatal); return; }
    step('엑셀 만드는 중');
    const made = D.recordForms.build(task, out);
    D.recordForms.last = { fileName: made.fileName, sheets: made.sheets }; // 시험용(학생 이름 없음)
    const a = document.createElement('a');
    a.href = URL.createObjectURL(made.blob);
    a.download = made.fileName;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 3000);
    const n = made.sheets.reduce((k, s) => k + s.count, 0);
    askFile(`<p class="ok">명단 든 양식을 받았어요: ${esc(made.fileName)} — ${made.sheets.length > 1 ? `탭 ${made.sheets.length}개(${made.sheets.map((s) => esc(s.name)).join(', ')}) · ` : ''}학생 ${n}명. 내용을 채운 뒤 아래에 끌어다 놓으세요.</p>`);
  }

  // 출석부 웹앱 만들기: 나이스 명단(번호·이름)이 든 웹앱 링크를 QR로 — 폰 카메라로 찍어 열고 홈 화면에 추가
  let rosterInclude = [];
  // mk: 버튼을 누른 순간 연 '학생 서류 받는 곳 만들기' 창의 결과(Promise) 또는 null(만들기 다리 주소가 아직 없음)
  // include: 교체·보강으로 보여 뺐다가 교사가 [넣기]로 다시 넣은 반
  async function makeRoster(kind, mk = null, include = []) {
    if (busy) return;
    busy = true;
    task = { label: '출석부 명단' };
    file = { name: kind === 'homeroom' ? '우리 반' : '내 수업 반' };
    const steps = ['나이스 확인'];
    const step = (t) => { steps.push(t); progress(steps); };
    progress(steps);
    let out;
    try {
      const tab = await D.neis.activeTab();
      if (!D.neis.isNeis(tab)) { fail('나이스 탭을 열고 로그인한 뒤 다시 해 주세요.'); return; }
      rosterInclude = include;
      out = await D.runners.roster[kind]({ tabId: tab.id, step, include });
    } finally {
      busy = false;
    }
    if (out.fatal) { fail(out.fatal); return; }
    const data = { kind: 'chulseokbu-roster', v: 1, made: new Date().toISOString().slice(0, 10), classes: out.classes };
    const base = await D.rosterLink.links(out.classes, kind);
    // QR은 바로 보여 준다. 받는 곳(학생 서류)은 기다리지 않고, 준비되면 QR에 서류함 주소를 붙여 다시 그림
    // (교사 제보 2026-10-29: 크롬 기본 계정이 개인 계정이라 받는 곳 창이 멈추면 QR까지 막혔음)
    const M = D.formsMaker;
    const ready = M && M.store && (kind !== 'homeroom' || M.known);
    const known = ready ? { ok: true, url: kind === 'homeroom' ? M.known : '', store: M.store, email: M.knownAccount || '', cached: true } : null;
    roster = { kind, out, data, base, forms: known, waiting: !!mk && !known };
    paintRoster();
    if (mk && !known) {
      mk.then((r) => {
        if (roster?.data !== data) return;
        roster.forms = r; roster.waiting = false;
        if ($('#hmRosterQrs')) paintRoster();
      });
    }
  }

  // 출석부 QR 화면(받는 곳 결과가 오면 다시 그림)
  let roster = null;
  function paintRoster() {
    const { kind, out, data, base, forms, waiting } = roster;
    const links = forms?.ok ? D.rosterLink.withForms(base, kind === 'homeroom' ? forms.url : '', forms.store) : base;
    D.rosterLink.last = links;
    const students = out.classes.reduce((n, c) => n + c.students.length, 0);
    const qrs = links.map((l, i) => {
      const q = D.rosterLink.qr(l.url);
      return `<figure class="qr"><img src="${q.src}" width="${q.size}" height="${q.size}" alt="출석부 웹앱 링크 QR ${i + 1}">
        <figcaption>${links.length > 1 ? `<b>${i + 1}/${links.length}</b> ` : ''}${esc(l.names.join(', '))}</figcaption></figure>`;
    }).join('');
    const home = kind === 'homeroom';
    const formsRow = waiting ? [[home ? '자동 저장·서류' : '자동 저장', `<b>기다리는 중</b> <span class="dim">작은 창에서 계정을 확인하고 [이 계정에 만들기]를 누르면 이 QR에 ${home ? '구글 자동 저장과 서류함이' : '구글 자동 저장이'} 붙어요. 안 해도 QR은 지금 써도 돼요(폰 웹앱 [설정]에서 나중에 켤 수 있어요).</span>`]]
      : forms?.ok ? [
        ['자동 저장', forms.store ? `<span class="ok">켜짐</span> <span class="dim">QR로 연 폰은 출석부가 선생님 구글 계정에 저절로 저장돼요(암호로 잠가서)${forms.email ? ` · ${esc(forms.email)}` : ''}</span>` : '<span class="dim">꺼짐 — 폰 웹앱 [설정 → 구글 자동 저장]에서 켤 수 있어요</span>'],
        ...(home ? [['학생 서류', forms.url ? `<span class="ok">받는 곳 연결</span> <span class="dim">${forms.cached ? '이미 만든 것' : forms.updated ? '새 버전' : '선생님 구글 계정에 만듦'} · QR에 서류함 주소가 들어 있어요</span> <button class="link" data-forms="update">받는 곳 업데이트</button>` : '<span class="dim">없음</span>']] : []),
      ]
      : forms ? [[home ? '자동 저장·서류' : '자동 저장', `<span class="err">${esc(forms.msg || '만들지 못했어요')}</span> <button class="link" data-forms="make">다시 만들기</button> <span class="dim">QR은 그대로 써도 돼요 · 폰 웹앱에서도 켤 수 있어요</span>`]]
      : [];
    show('done', `
      ${title('출석부 웹앱 만들기')}
      ${info([['명단', `<span class="ok">반 ${out.classes.length}개 · 학생 ${students}명</span> <span class="dim">번호·이름만</span>`], ...formsRow])}
      <ol class="howto">
        <li><b>폰 카메라로 아래 QR을 찍어</b> 뜨는 링크를 엽니다. 명단이 들어간 출석부 웹앱이 열려요.${links.length > 1 ? ' 반이 많아 QR이 여러 개예요. 하나씩 찍으면 같은 웹앱에 차례로 더해져요.' : ''}</li>
        <li><b>홈 화면에 추가</b> — 아이폰: Safari 아래 공유(□↑) → '홈 화면에 추가' · 안드로이드: Chrome 오른쪽 위 ⋮ → '홈 화면에 추가'.</li>
        <li>다음부터는 <b>홈 화면 아이콘</b>으로 여세요. 출석 기록은 그 폰에만 저장돼요.</li>
      </ol>
      <div class="qrs" id="hmRosterQrs">${qrs}</div>
      ${out.skipped?.length ? `<p class="hint">교체·보강으로 보여 뺀 반(최근 3주에 한 주만 나옴): ${out.skipped.map((s) => `${esc(s.name)} ${esc(s.subject)} <button class="link" data-roster-add="${esc(s.key)}">넣기</button>`).join(' · ')}</p>` : ''}
      <p class="hint">링크 안에 학생 번호·이름${forms?.store ? '과 출석부 열쇠가' : '이'} 들어 있어요. 카톡·메일로 보내지 말고 선생님 폰 카메라로만 찍어 주세요. 카톡 안에서 열렸다면 'Safari(다른 브라우저)로 열기'를 누른 뒤 홈 화면에 추가하세요.</p>
      <details class="detail"><summary>반별 학생 수 · 파일로 받기</summary>
        <table class="grid"><thead><tr><th>반</th><th>과목</th><th class="c">학생</th></tr></thead><tbody>${out.classes.map((c) => `<tr><td>${esc(c.name)}</td><td>${esc(c.subject)}</td><td class="c">${c.students.length}</td></tr>`).join('')}</tbody></table>
        <p class="hint">QR이 안 되면 <button class="link" id="hmRosterFile">명단 파일 받기</button> → 폰으로 옮겨 웹앱 [설정 → 명단 파일 넣기].</p>
      </details>
      <div class="actions">${back('다른 일 하기')}</div>`);
    $('#hmRosterFile').addEventListener('click', () => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
      a.download = `출석부_명단_${data.made}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1500);
    });
  }

  async function markVerified(ok) {
    if (ok) {
      const s = await D.store.settings();
      await D.store.saveSettings({ verified: { ...s.verified, [task.screenId]: true } });
      $('#hmTrial').outerHTML = file?.trialFrom
        ? '<p class="ok">확인했어요. 이제 여러 건을 한 번에 입력할 수 있어요.</p><div class="actions"><button class="btn-main" id="hmRest">나머지도 확인하고 넣기</button></div>'
        : '<p class="ok">확인했어요. 이제 여러 건을 한 번에 입력할 수 있어요.</p>';
    } else {
      $('#hmTrial').outerHTML = '<p class="err">여러 건 입력은 계속 막아 둘게요. 나이스에서 직접 바로잡고, 설정의 [화면 진단] 결과를 개발 대화에 붙여 주세요(학생 이름은 들어가지 않아요).</p>';
    }
  }

  async function resumeHint() {
    const w = await D.store.getWork(WORK);
    const r = $('#hmResume');
    if (!r || !w || !D.runners.byId(w.task)) return;
    r.hidden = false;
    const nFix = Object.keys(w.fixes || {}).length;
    r.innerHTML = `입력하지 않은 파일이 있어요: ${esc(w.name)}${nFix ? ` · 고친 곳 ${nFix}곳(아직 다시 확인 전)` : ''} <button class="btn-text" id="hmResumeGo">이어서 하기</button> <button class="btn-text" id="hmResumeDrop">지우기</button>`;
  }

  D.views.home = {
    helpId: () => (task?.id ? task.id : el?.dataset.state === 'roster' ? 'roster' : ''),
    // 위쪽 [← 이전](교사 요청 2026-10-29): 한 단계 앞으로. 처음 화면이면 false
    back() {
      if (busy) return true;
      const st = el.dataset.state;
      if (st === 'choose') return false;
      if (st === 'ready' && task?.screenId) { askFile(); return true; }
      if (['checked', 'error', 'otp', 'done'].includes(st) && task?.screenId && file?.text) { ready(); return true; }
      choose();
      return true;
    },
    atStart: () => el.dataset.state === 'choose',
    init(root) {
      el = root;
      $ = (s) => el.querySelector(s);
      choose();
      D.onState((st) => { if (!busy && !el.hidden && el.dataset.state === 'choose' && siteOf(st) !== shownSite) choose(); });
      el.addEventListener('change', (e) => { if (e.target.id === 'hmFile') { load(e.target.files); e.target.value = ''; } });
      el.addEventListener('change', (e) => {
        const fx = e.target.closest('[data-fix]');
        if (!fx) return;
        const ln = fx.closest('[data-line]').dataset.line;
        setFix(ln, { ...(fixes[ln] || {}), reason: fx.value.trim(), own: true });
      });
      el.addEventListener('click', (e) => {
        const ad = e.target.closest('[data-add-neis]');
        if (ad) {
          const [, date, no] = ad.dataset.addNeis.split(':');
          const base = ad.dataset.kind ? valueLabel(task, checked?.groups?.find((x) => x.date === date)?.codes || {}, ad.dataset.kind) : '';
          fixCtx[ad.dataset.addNeis] = { base, reasons: {}, max: +ad.dataset.max || 7, marks: (ad.dataset.marks || '').split(',').filter((x) => x !== '').map(Number), add: { date, no, name: ad.dataset.name } };
          const tr = ad.closest('tr');
          ad.outerHTML = '<span class="dim">아래에서 고르기</span>';
          tr.insertAdjacentHTML('afterend', `<tr class="fix-tr"><td colspan="4"><details class="fix" open><summary>고치기</summary><div class="fix-row" data-line="${esc(ad.dataset.addNeis)}">${fixBody(ad.dataset.addNeis)}</div></details></td></tr>`);
          return;
        }
        const jp = e.target.closest('[data-jump]');
        if (jp) {
          const d = el.querySelector('details.detail'); if (d) d.open = true;
          const grp = el.querySelector(`#grp-${jp.dataset.jump}`);
          if (grp) { grp.scrollIntoView({ block: 'start', behavior: 'smooth' }); grp.classList.add('flash'); setTimeout(() => grp.classList.remove('flash'), 1600); }
          return;
        }
        // 직접 확인할 곳: [폰 값으로]·[나이스 그대로]·모두·[확인]·[다음 ▶]
        const pk = e.target.closest('[data-pick]');
        if (pk && checked && file) {
          file.choices = { ...(file.choices || {}) };
          if (pk.dataset.pick === 'neis') file.choices[pk.dataset.key] = 'neis'; else delete file.choices[pk.dataset.key];
          markSeen(pk.dataset.spot);
          repick(pk.dataset.spot);
          return;
        }
        const pall = e.target.closest('[data-pick-all]');
        if (pall && checked && file) {
          file.choices = { ...(file.choices || {}) };
          for (const s of spotList(checked).filter((x) => x.conflict)) {
            if (pall.dataset.pickAll === 'neis') file.choices[s.ck] = 'neis'; else delete file.choices[s.ck];
            markSeen(s.key);
          }
          repick();
          return;
        }
        const sn = e.target.closest('[data-seen]');
        if (sn && file) {
          markSeen(sn.dataset.seen);
          const tr = [...el.querySelectorAll('tr[data-spot]')].find((t) => t.dataset.spot === sn.dataset.seen);
          if (tr) { tr.classList.add('seen'); sn.outerHTML = '<span class="ok-mark">확인함</span>'; }
          const box = el.querySelector('.spots');
          if (box && checked) box.outerHTML = spotsHtml(checked);
          keepWork();
          goSpot(sn.dataset.seen);
          return;
        }
        if (e.target.closest('[data-spot-next]')) { goSpot(spotAt); return; }
        const bt = e.target.closest('[data-fx]');
        if (!bt) return;
        const box = bt.closest('[data-line]'), ln = box.dataset.line;
        const f = { ...(fixes[ln] || {}) };
        const k = bt.dataset.fx, v = bt.dataset.v;
        if (k === 'type') {
          f.type = f.type === v ? '' : v;
          const marks = fixCtx[ln].marks || [];
          if ((f.type === '지각' || f.type === '조퇴') && marks.length && (!f.ps?.length || f.autoPs)) {
            const all = [0, ...Array.from({ length: fixCtx[ln].max }, (_, i) => i + 1), 99];
            f.ps = f.type === '지각' ? all.filter((x) => x <= Math.max(...marks)) : all.filter((x) => x >= Math.min(...marks));
            f.autoPs = true;
          } else if (f.autoPs) { f.ps = []; f.autoPs = false; }
        }
        if (k === 'sub') f.sub = f.sub === v ? '' : v;
        if (k === 'p') {
          const n = +v;
          const type = f.type || splitKind(fixCtx[ln].base).type;
          f.autoPs = false;
          if (type === '지각' || type === '조퇴') {
            // 교사 요청(2026-10-30): 지각은 누른 교시까지 조회부터, 조퇴는 누른 교시부터 종례까지 한 번에. 같은 범위를 다시 누르면 지움
            const all = [0, ...Array.from({ length: fixCtx[ln].max }, (_, i) => i + 1), 99];
            const want = type === '지각' ? all.filter((x) => x <= n) : all.filter((x) => x >= n);
            f.ps = (f.ps || []).join() === want.join() ? [] : want;
          } else { const ps = new Set(f.ps || []); if (ps.has(n)) ps.delete(n); else ps.add(n); f.ps = [...ps].sort((a, b) => a - b); }
        }
        if (k === 'reason') { f.reason = f.reason === v && !f.own ? '' : v; f.own = false; }
        if (k === 'own') { f.own = !f.own; if (!f.own) f.reason = ''; }
        if (k === 'std') {
          const cur = new Set(f.std || fixCtx[ln].now);
          if (cur.has(v)) cur.delete(v); else cur.add(v);
          f.std = fixCtx[ln].list.map((e) => e.code).filter((c) => cur.has(c));
          if (!f.std.length || f.std.join() === fixCtx[ln].now.join()) delete f.std;
        }
        setFix(ln, f);
        box.innerHTML = fixBody(ln);
        if (k === 'own' && f.own) box.querySelector('[data-fix="reason"]')?.focus();
      });
      el.addEventListener('change', (e) => { const p = e.target.closest('[data-pick]'); if (p && isItems() && picksNow && !picksNow.error) { picksWant[p.dataset.pick] = p.value; paintPicks(picksNow); } });
      document.addEventListener('dragover', (e) => { e.preventDefault(); $('#hmDrop')?.classList.add('over'); });
      document.addEventListener('dragleave', (e) => { if (!e.relatedTarget) $('#hmDrop')?.classList.remove('over'); });
      document.addEventListener('drop', (e) => {
        e.preventDefault();
        $('#hmDrop')?.classList.remove('over');
        if (!el.hidden && el.dataset.state === 'drop') load(isItems() ? e.dataTransfer.files : [e.dataTransfer.files[0]]);
      });
      el.addEventListener('click', async (e) => {
        if (busy) return;
        const ra = e.target.closest('[data-roster-add]');
        if (e.target.id === 'hmPicksLoad') { loadItemPicks(); return; }
        if (ra) { makeRoster('subjects', null, [...rosterInclude, ra.dataset.rosterAdd]); return; }
        const bo = e.target.closest('[data-box-open]');
        if (bo) { openBox(bo); return; }
        const ro = e.target.closest('[data-roster]');
        // 학생 서류 받는 곳은 담임 반에만(교사 결정 2026-10-28: 수업 반은 서류를 받지 않음)
        if (ro) { makeRoster(ro.dataset.roster, D.formsMaker ? D.formsMaker.start({ want: ro.dataset.roster === 'homeroom' ? 'both' : 'store' }) : null); return; }
        const fm = e.target.closest('[data-forms]');
        if (fm && D.formsMaker) {
          const p = D.formsMaker.open({ update: fm.dataset.forms === 'update', want: roster?.kind === 'homeroom' ? 'both' : 'store' });
          if (!p) return;
          fm.textContent = '작은 창에서 계정 확인 → [이 계정에 만들기]';
          p.then((r) => {
            if (roster && $('#hmRosterQrs')) { roster.forms = r.ok || !roster.forms?.ok ? r : roster.forms; roster.waiting = false; paintRoster(); return; }
            fm.textContent = r.ok ? (r.updated ? '새 버전으로 올렸어요' : '받는 곳 준비됨') : r.msg || '실패했어요';
          });
          return;
        }
        if (e.target.closest('[data-edu="record"]')) { eduRecord(); return; }
        if (e.target.closest('[data-edu="draft"]')) { D.draftView.open(el); return; }
        if (e.target.closest('[data-edu="inbox"]')) { D.views.inbox.start(el); return; }
        const pr = e.target.closest('[data-ph-range]');
        if (pr && task) { phoneStart(task.id, pr.dataset.phRange, { fresh: !!pr.dataset.phFresh }); return; }
        if (e.target.id === 'hmPhoneLink') { phoneLink(); return; }
        const sp = e.target.closest('[data-sheet]');
        if (sp && file?.sheets) {
          const s = file.sheets.find((x) => x.name === sp.dataset.sheet);
          if (s) { file.text = s.text; file.sheet = s.name; ready(); }
          return;
        }
        if (e.target.id === 'hmTplNamed') { if (task?.screenId === 'neis.assess.perf') makePerfForm(); else makeRecordForm(); return; }
        const mp = e.target.closest('[data-me]');
        if (mp) { await D.store.saveSettings({ comciMe: { comci: mp.dataset.name, idx: +mp.dataset.me } }); today(); return; }
        if (e.target.id === 'hmMePick' || e.target.id === 'hmMeReset') { pickMe(); return; }
        const cat = e.target.closest('[data-cat]');
        if (cat) { pickCat(cat.dataset.cat); return; }
        const df = e.target.closest('[data-duty-fav]');
        if (df) { await D.views.duty.open(df.dataset.dutyFav); D.go('duty'); return; }
        const t = e.target.closest('[data-task]');
        if (t) {
          task = D.runners.byId(t.dataset.task);
          // 폰 출석부와 연결돼 있으면 [일일출결]·[과목별출결]을 누르자마자 폰 출결로 '준비됨'(교사 결정 2026-10-30)
          if (['daily', 'subject'].includes(task.id) && D.phoneSync?.conf()) { phoneStart(task.id); return; }
          askFile();
          return;
        }
        const sw = e.target.closest('[data-switch]');
        if (sw) { task = D.runners.byId(sw.dataset.switch); ready(); return; }
        const op = e.target.closest('[data-open]');
        if (op) { window.open(op.dataset.open, 'doumi-bridge-auth', 'width=520,height=680'); return; }
        const id = e.target.id;
        if (id === 'hmGo') apply();
        if (id === 'hmCheck') check();
        if (id === 'hmNoFile') { file = { name: '없음 — 나이스만 점검', text: '' }; check(); }
        if (id === 'hmRecheck' && file) { file.text = applyFixes(file.text); fixes = {}; keepWork(); check(); }
        if (id === 'hmSaveNow' && file) saveNow();
        if (id === 'hmRetry' && file) { if (file.trialFrom) { file.text = file.trialFrom; delete file.trialFrom; } check(); }
        if (id === 'hmRetry') check();
        if (id === 'hmOtpGo') { if (file) check({ resume: true }); else otpOpen({ resume: true }); }
        if (id === 'hmOtpOpen') otpOpen();
        if (id === 'hmHome') { await D.store.clearWork(WORK); choose(); }
        if (id === 'hmOk') markVerified(true);
        // 1건 시험: 파일의 머리줄 + 그 줄만으로 다시 확인 → [입력 후 저장]. 원래 파일은 기억해 두었다가 [나머지도 확인하고 넣기]
        if (id === 'hmTrialGo' && file) {
          const lines = String(file.text).replace(/\r\n?/g, '\n').split('\n');
          const hi = lines.findIndex((l) => l.trim());
          const ln = +e.target.dataset.line;
          if (hi >= 0 && lines[ln - 1] != null && ln - 1 !== hi) {
            file.trialFrom = file.trialFrom || file.text; // 다시 눌려도 원본(나머지 넣기에 쓸 전체)을 잃지 않게
            file.text = [lines[hi], ...(task.trialBlock ? task.trialBlock(lines, ln - 1) : [lines[ln - 1]])].join('\n');
            check();
          }
        }
        if (id === 'hmRest' && file?.trialFrom) { file.text = file.trialFrom; delete file.trialFrom; check(); }
        if (id === 'hmNo') markVerified(false);
        if (id === 'hmResumeGo') {
          const w = await D.store.getWork(WORK);
          if (w) { task = D.runners.byId(w.task); file = { name: w.name, text: w.text, choices: w.choices || {}, seen: w.seen || [] }; fixes = w.fixes || {}; check(); }
        }
        if (id === 'hmResumeDrop') { await D.store.clearWork(WORK); choose(); }
      });
    },
    enter() { if (!busy && el.dataset.state === 'choose') { if (siteOf(D.state) !== shownSite) choose(); else { resumeHint(); today(); paintDuty(); } } },
    on(type) { if (type === 'cleared') D.edufineInbox?.clear(); if (type === 'cleared' && !busy) choose(); },
    // 테스트용: 할 일을 고르고 글을 파일처럼 넣는다
    // 시험용: 엑셀 등 파일 그대로
    loadFiles(taskId, files) { task = D.runners.byId(taskId); return load(files); },
    loadText(taskId, text, name = '시험.csv', attachName = '') {
      task = D.runners.byId(taskId);
      const files = text ? [new File([text], name, { type: 'text/csv' })] : [];
      if (attachName) files.push(new File(['HWP 시험 파일'], attachName, { type: 'application/octet-stream' }));
      return load(files);
    },
  };
})();
