// 패널 '결재함 보기' 화면: 결재대기 문서 목록 + 한 건씩 [열기]. 첫 화면(home)의 자리를 빌려 그린다.
// 결재·전자서명은 문서 창에서 교사가 한다. 목록은 이 화면이 떠 있는 동안만 메모리에 있다.
// 2단계(2026-10-29): [본문 읽기] — 열린 문서 창(WXSClient)의 본문을 PC 도우미가 읽어 규칙으로 정리(features/edufine-doc.js)
//   → [할 일로 넣기](F2 할 일 목록) · 관련 문서 줄마다 [에듀파인에서 찾기](문서등록대장 검색까지). 본문은 메모리에서만 쓰고 저장하지 않는다.
(() => {
  const D = globalThis.Doumi;
  const esc = D.esc;
  let el = null;
  let busy = false;
  let cards = [];
  let openedAt = {}; // 문서ID → 연 시각(이 화면에서만)
  let docs = {}; // 문서ID → 본문 정리(이 화면에서만, 본문 원문은 담지 않음)
  let run = null; // 차례 진행 중: { kind: 'read'|'approve', stop }
  let done = {}; // 문서ID → 결재 진행 결과 글(이 화면에서만)
  let bodies = {}; // 문서ID → 본문 원문(메모리만, 모아 보기 창에 주려고. 저장하지 않음)
  let chosen = {}; // 문서ID → 모아 보기에서 고른 과제카드·공람자(메모리만)
  let pickLists = null; // 과제카드 목록·공람 후보 이름(메모리만, 한 번 읽음)
  let boardWin = null;
  let boardBound = false;

  const hm = (t) => { const d = new Date(t); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const head = '<h2 class="sec">결재함</h2>';
  const back = '<button class="btn-line" id="hmHome">처음으로</button>';

  function show(state, html) {
    el.dataset.state = state;
    el.innerHTML = html;
  }

  function progress(steps) {
    show('busy', `${head}<ul class="progress">${steps.map((s, i) => `<li class="${i === steps.length - 1 ? 'now' : 'done'}"><span>${i === steps.length - 1 ? '진행 중' : '완료'}</span>${esc(s)}</li>`).join('')}</ul>`);
  }

  // 본문 정리 칸: 기한·제출·대상·붙임·관련(줄마다 [에듀파인에서 찾기]) + [할 일로 넣기]
  function summaryHtml(c) {
    const s = docs[c.docId];
    if (!s) return '';
    if (s.error) return `<div class="doc-sum"><p class="err">${esc(s.error)}</p>${s.install ? '<p><button class="btn-line small" data-ib-install="1">PC 도우미 설치 파일 받기</button></p>' : ''}</div>`;
    if (s.empty) return '<div class="doc-sum"><p class="warn">본문이 비어 있어요. 문서 창이 다 열린 뒤 [본문 읽기]를 다시 눌러 주세요.</p></div>';
    const row = (k, v) => (v ? `<tr><th>${k}</th><td>${v}</td></tr>` : '');
    const rel = s.related.map((r, i) => `<li><span>${esc(`${r.org ? `${r.org} ` : ''}${r.dept}-${r.docNo}`)}${r.ymd ? ` <span class="dim">(${esc(D.draft.formatDate(r.ymd))})</span>` : ''}</span> <button class="link" data-rel="${esc(c.docId)}|${i}">에듀파인에서 찾기</button> <button class="link" data-rel-open="${esc(c.docId)}|${i}">정보공개포털</button>${s.relNote?.[i] ? `<span class="small ${s.relNote[i].cls}">${esc(s.relNote[i].text)}</span>` : ''}</li>`).join('');
    return `<div class="doc-sum">
      ${s.mismatch ? `<p class="warn">열린 문서 창의 제목이 이 카드와 달라요: ${esc(s.title)}</p>` : ''}
      <table class="info">
        ${row('기한', s.deadline.text ? `<b>${esc(s.deadline.text)}</b>` : '<span class="dim">본문에서 못 찾음</span>')}
        ${row('제출', esc(s.submits.join(', ')))}
        ${row('대상', esc(s.targets.join(', ')))}
        ${s.files?.length ? `<tr><th>붙임</th><td><ul class="td-files">${s.files.map((f, i) => `<li><span class="td-fname">${esc(f.name)}</span> ${s.saved?.[f.name] ? `<button class="link" data-att-open="${esc(c.docId)}|${i}">열기</button>` : `<button class="link" data-att-get="${esc(c.docId)}|${i}" title="받아서 바로 열어요">열기</button>`}</li>`).join('')}</ul>${s.fileNote ? `<p class="small ${s.fileNote.cls}">${esc(s.fileNote.text)}</p>` : ''}</td></tr>` : row('붙임', esc(s.attachments.join(', ')))}
        ${s.related.length ? `<tr><th>관련</th><td><ul class="doc-rel">${rel}</ul></td></tr>` : ''}
      </table>
      <p class="doc-sum-act"><button class="btn-line small" data-todo="${esc(c.docId)}"${s.todoDone ? ' disabled' : ''}>${s.todoDone ? '할 일에 넣었어요' : '할 일로 넣기'}</button>${s.todoDone ? ' <button class="link" data-go="todo">할 일 보기</button>' : ''}${s.submits.length || s.attachments.length ? ` <button class="link" data-reply="${esc(c.docId)}">회신 기안 만들기</button>` : ''}${s.todoError ? ` <span class="err small">${esc(s.todoError)}</span>` : ''}</p>
    </div>`;
  }

  function card(c) {
    const meta = [c.dept, c.drafter, c.date].filter(Boolean).map(esc).join(' · ');
    const sub = [c.status, c.kind].filter(Boolean).map(esc).join(' · ');
    const opened = openedAt[c.docId];
    return `<li class="doc${c.urgent ? ' urgent' : ''}${opened ? ' seen' : ''}" data-doc="${esc(c.docId)}">
      <div class="doc-main">
        <p class="doc-flags">${c.urgent ? '<span class="tag err">긴급</span>' : ''}${c.wait ? `<span class="doc-wait${c.waitDays >= 3 ? ' late' : ''}">${esc(c.wait)}</span>` : ''}${sub ? `<span class="dim">${sub}</span>` : ''}</p>
        <p class="doc-title">${esc(c.title)}</p>
        <p class="doc-meta">${meta}</p>
        ${opened ? `<p class="doc-note ok">${esc(opened)}</p>` : ''}
        ${done[c.docId] ? `<p class="doc-note ${done[c.docId].cls}">${esc(done[c.docId].text)}</p>` : ''}
        ${summaryHtml(c)}
      </div>
      ${c.canOpen ? `<div class="doc-btns"><button class="btn-line small" data-open="${esc(c.docId)}">열기</button><button class="btn-line small" data-read="${esc(c.docId)}">본문 읽기</button></div>` : '<span class="dim small">열 수 없음</span>'}
    </li>`;
  }
  const repaint = (docId) => {
    const li = [...el.querySelectorAll('.doc')].find((x) => x.dataset.doc === docId);
    const c = cards.find((x) => x.docId === docId);
    if (li && c) li.outerHTML = card(c);
  };

  // 열린 문서 창 하나를 PC 도우미가 읽는다(문서 창은 에듀파인 문서 프로그램이라 확장이 직접 못 읽음)
  async function read(docId, btn) {
    if (busy) return;
    busy = true;
    btn.disabled = true;
    btn.textContent = '읽는 중';
    const c = cards.find((x) => x.docId === docId);
    try {
      const st = await D.pcHelper.status(true);
      if (!st.ok) {
        docs[docId] = { error: st.missing ? 'PC 도우미가 있어야 문서 창 본문을 읽을 수 있어요. 설치 파일을 받아 한 번 더블클릭해 주세요.' : st.text, install: !!st.missing };
      } else {
        const r = await D.pcHelper.readDoc({ attach: true });
        if (!r.ok || !r.fields) docs[docId] = { error: /no-window/.test(r.error || '') ? '열린 문서 창이 없어요. [열기]로 문서 창을 연 뒤 다시 눌러 주세요.' : D.pcHelper.explain(r) };
        else {
          const s = D.edufineDoc.summarize(r.fields);
          const sq = (t) => String(t || '').replace(/\s+/g, '');
          s.mismatch = !!(c && s.title && sq(c.title) !== sq(s.title) && !sq(c.title).includes(sq(s.title)) && !sq(s.title).includes(sq(c.title)));
          s.relNote = [];
          s.files = r.files || null;
          docs[docId] = s;
          bodies[docId] = String(r.fields['본문'] || '');
        }
      }
    } catch {
      docs[docId] = { error: '본문을 읽지 못했어요. 문서 창이 열려 있는지 확인해 주세요.' };
    } finally { busy = false; }
    repaint(docId);
  }

  // 붙임 받기·열기: 문서 창에서 PC 도우미가(누른 파일만, 다운로드\공문 정리)
  async function attGet(key) {
    if (busy) return;
    const [docId, i] = key.split('|');
    const s = docs[docId];
    const f = s?.files?.[+i];
    if (!f) return;
    busy = true;
    s.fileNote = { cls: 'dim', text: '받는 중…' };
    repaint(docId);
    let r;
    try {
      r = await D.edufineFiles.fromDoc({ docId, title: s.title }, [f.name], (name, path) => { s.saved = { ...(s.saved || {}), [name]: path }; });
      // 받기와 열기를 한 번에(교사 요청 2026-11-10)
      if (r.ok && s.saved?.[f.name]) r = await D.edufineFiles.open({ name: f.name, path: s.saved[f.name] });
    } catch { r = { ok: false, error: '파일을 받지 못했어요.' }; }
    busy = false;
    s.fileNote = r.ok ? { cls: 'ok', text: r.text } : { cls: 'err', text: r.error };
    repaint(docId);
  }
  async function attOpen(key) {
    const [docId, i] = key.split('|');
    const s = docs[docId];
    const f = s?.files?.[+i];
    if (!f) return;
    const r = await D.edufineFiles.open({ name: f.name, path: s.saved?.[f.name] });
    s.fileNote = r.ok ? { cls: 'ok', text: r.text } : { cls: 'err', text: r.error };
    repaint(docId);
  }

  // 할 일 후보: 기한이나 제출할 것이 있는 문서(넣지 않은 것)
  const todoCands = () => cards.filter((c) => { const s = docs[c.docId]; return s && !s.error && !s.empty && !s.todoDone && (s.deadline.due || s.submits.length); });

  function runBar(html, cls = 'hint') {
    const bar = el.querySelector('#ibBar');
    if (bar) { bar.className = cls; bar.innerHTML = html; }
  }
  function afterRun(text, cls = 'ok') {
    const n = todoCands().length;
    runBar(`${esc(text)}${n ? ` <button class="btn-main small" id="ibTodoAll">기한·제출이 있는 ${n}건 할 일에 넣기</button>` : ''}`, cls);
  }

  // [모두 읽기]: 문서를 하나씩 열어 본문·붙임을 읽고 닫는다(결재 안 함). 본문은 메모리에서만
  async function readAll() {
    if (busy || !cards.length) return;
    busy = true;
    run = { kind: 'read', stop: false };
    setRunning(true);
    const list = cards.filter((c) => c.canOpen && !docs[c.docId]?.deadline);
    const stop = () => run?.stop;
    let r;
    try {
      r = await D.edufineRead.readAll(list, {
        stop,
        on: {
          step: (i, c) => runBar(`문서 읽는 중 <b>${i + 1}/${list.length}</b> · ${esc(c.title)} <button class="btn-line small" id="ibStop">멈춤</button>`),
          doc: (c, res) => {
            docs[c.docId] = res.error ? { error: res.error } : matched(c, res);
            if (res.body) bodies[c.docId] = res.body;
            repaint(c.docId);
          },
          // 첫 문서가 열려 있는 동안 고를 목록을 한 번 읽는다(못 읽어도 글로 적으면 됨)
          opened: async (c, win) => {
            if (pickLists) return;
            pickLists = { cards: [], people: [] };
            const had = await D.edufineLists?.get();
            if (had?.people?.length || had?.cards?.length) { pickLists = had; return; }
            const l = await D.pcHelper.readPickLists?.({ pid: win.pid });
            if (l?.ok) { pickLists = { cards: l.cards || [], people: l.people || [] }; await D.edufineLists?.set(pickLists); }
          },
        },
      });
    } catch (e) { r = { ok: false, error: e?.message || '문서를 읽지 못했어요.' }; }
    busy = false;
    run = null;
    setRunning(false);
    if (!r.ok) { runBar(`${esc(r.error)}${r.needHelper ? ' <button class="btn-line small" data-ib-install="1">PC 도우미 설치 파일 받기</button>' : ''}`, 'err'); return false; }
    afterRun(`${r.read}건 읽었어요${r.skipped ? ` · 건너뜀 ${r.skipped}` : ''}${r.stopped ? ' · 멈춤' : ''}.`);
    return !r.stopped;
  }

  // ── 모아 보기(3×3): 안 읽은 문서는 먼저 읽고 넓은 창을 연다. 결재는 창마다 교사가(일괄 결재 없음) ──
  const boardSend = (m) => { try { chrome.runtime.sendMessage(m).catch?.(() => {}); } catch { /* 창이 닫힘 */ } };
  async function boardItems() {
    const out = [];
    for (const c of cards) {
      const s = docs[c.docId];
      const rec = s && !s.error && !s.empty ? await D.edufinePicks?.suggest?.(s) : null;
      const st = done[c.docId];
      out.push(D.edufineDoc.boardItem(c, s, bodies[c.docId], { rec, pick: chosen[c.docId] || null, status: st ? { docId: c.docId, ...st, final: true } : null }));
    }
    return out;
  }
  // 파일 창(교사 요청 2026-11-09): 붙임을 공문 정리 폴더에 받아 내용을 모아 보기 창 메모리로 건넨다. 메신저로 끌어다 놓기는 교사가
  async function boardFiles(docId) {
    const s = docs[docId];
    if (!s || s.error) return { ok: false, error: '아직 읽지 않은 문서예요.' };
    // 읽을 때 붙임 목록을 못 받았으면 문서 창에서 다시 본다
    const known = s.files ? s.files.map((f) => f.name) : null;
    const need = known ? known.filter((n) => !s.saved?.[n]) : null;
    let note = '';
    if (!known || need.length) {
      // 결재 중에는 지금 열린 그 문서만(다른 창을 새로 열면 결재 차례가 꼬인다)
      const here = run?.kind === 'approve' && run.docId === docId;
      if (busy && !here) return { ok: false, error: run?.kind === 'approve' ? '지금 결재 중인 문서의 파일만 받을 수 있어요.' : '패널에서 다른 일을 하는 중이에요. 끝난 뒤 다시 눌러 주세요.' };
      if (!here) busy = true;
      try {
        const r = await D.edufineFiles.fromDoc({ docId, title: s.title }, need, (name, path) => { s.saved = { ...(s.saved || {}), [name]: path }; });
        if (!r.ok) note = r.error;
      } finally { if (!here) busy = false; }
      repaint(docId);
    }
    const files = [];
    for (const name of known || Object.keys(s.saved || {})) {
      const path = s.saved?.[name];
      if (!path) { files.push({ name, error: '받지 못했어요' }); continue; }
      const r = await D.edufineFiles.read(path);
      files.push(r.ok ? { name, size: r.size, chunks: r.chunks } : { name, size: r.size, tooBig: !!r.tooBig, error: r.tooBig ? '파일이 커서 [폴더 열기]에서 끌어다 놓아 주세요' : r.error });
    }
    return { ok: true, files, note };
  }
  function bindBoard() {
    if (boardBound) return;
    boardBound = true;
    chrome.runtime.onMessage.addListener((m, _sender, reply) => {
      if (!m?.board) return undefined;
      if (m.board === 'hello') { boardItems().then((items) => { for (const x of items) if (!chosen[x.docId]) chosen[x.docId] = x.pick; reply({ items, lists: pickLists || { cards: [], people: [] }, running: run?.kind === 'approve' }); }); return true; }
      if (m.board === 'pick') { chosen[m.docId] = { tkcrd: String(m.pick?.tkcrd || ''), cnrs: Array.isArray(m.pick?.cnrs) ? m.pick.cnrs.map(String) : [] }; reply({ ok: true }); return undefined; }
      if (m.board === 'start') {
        if (busy) { reply({ ok: false, error: '패널에서 다른 일을 하는 중이에요. 끝난 뒤 다시 눌러 주세요.' }); return undefined; }
        startApprove(Array.isArray(m.auto) ? m.auto.map(String) : null);
        reply({ ok: true });
        return undefined;
      }
      // 처음 1건을 결재한 뒤 교사가 에듀파인에서 확인하고 누름 → 다음부터 고른 문서는 모두
      if (m.board === 'trust') { D.store.settings().then((s) => D.store.saveSettings({ verified: { ...(s.verified || {}), 'edufine.approve': true } })).then(() => reply({ ok: true })); return true; }
      if (m.board === 'stop') { if (run) { run.stop = true; runBar('이 문서까지 하고 멈춰요…'); } reply({ ok: true }); return undefined; }
      if (m.board === 'files') { boardFiles(m.docId).then(reply, () => reply({ ok: false, error: '파일을 받지 못했어요.' })); return true; }
      // 파일 창 [열기]: 받아 둔 붙임을 PC 도우미가 연다(문서 종류만, 실행 파일은 안 엶)
      if (m.board === 'open') { const s = docs[m.docId]; D.edufineFiles.open({ name: m.name, path: s?.saved?.[m.name] }).then(reply, () => reply({ ok: false, error: '파일을 열지 못했어요.' })); return true; }
      if (m.board === 'folder') { D.edufineFiles.folder({ title: docs[m.docId]?.title || cards.find((c) => c.docId === m.docId)?.title }).then(reply, () => reply({ ok: false, error: '폴더를 열지 못했어요.' })); return true; }
      return undefined;
    });
  }
  async function openBoard() {
    if (busy || !cards.length) return;
    bindBoard();
    const unread = cards.filter((c) => c.canOpen && !docs[c.docId]);
    if (unread.length && !(await readAll())) return;
    const url = chrome.runtime.getURL('panel/board.html');
    if (boardWin != null) {
      try { await chrome.windows.update(boardWin, { focused: true }); boardSend({ boardRefresh: true }); return; } catch { boardWin = null; }
    }
    try {
      const w = await chrome.windows.create({ url, type: 'popup', width: Math.min(1500, screen.availWidth), height: Math.min(960, screen.availHeight), focused: true });
      boardWin = w?.id ?? null;
    } catch { window.open(url, '_blank'); }
  }
  const matched = (c, res) => {
    const s = res.summary;
    const sq = (t) => String(t || '').replace(/\s+/g, '');
    s.mismatch = !!(s.title && sq(c.title) !== sq(s.title) && !sq(c.title).includes(sq(s.title)) && !sq(s.title).includes(sq(c.title)));
    s.relNote = [];
    s.files = res.files;
    return s;
  };

  // [결재 시작]: 문서를 차례로 열어 둔다. 결재·전자서명은 교사가 문서 창에서. 창이 닫히면 다음 문서
  // auto: 모아 보기에서 [결재]를 체크한 문서(교사 결정 2026-11-09·10). 그 문서만 열고, 고른 과제카드·공람을 넣은 뒤 도우미가 결재한다.
  // 처음에는 1건만 하고 멈춘다(교사가 에듀파인에서 확인한 뒤 [나머지도 결재]). auto가 없으면 예전처럼 창을 열어 두고 교사가 결재
  async function startApprove(auto = null) {
    if (busy || !cards.length) return;
    busy = true;
    const trusted = !!(await D.store.settings()).verified?.['edufine.approve'];
    run = { kind: 'approve', stop: false, auto: auto && auto.length ? new Set(auto) : null, trusted, autoDone: 0 };
    setRunning(true);
    const list = cards.filter((c) => c.canOpen && (!run.auto || run.auto.has(c.docId)));
    let i = 0;
    let r;
    let latest = null;
    try {
      r = await D.edufineRead.approveLoop(list, {
        stop: () => run?.stop,
        reload: async () => { const x = await D.edufineInbox.load({ search: true }); if (!x.ok) return null; latest = x; return x.cards; },
        on: {
          opened: async (c, { summary, win }) => {
            i++;
            if (run) run.docId = c.docId;
            if (summary) { docs[c.docId] = matched(c, { summary }); repaint(c.docId); }
            let note = '';
            // 모아 보기에서 본(고른) 문서는 그 값으로, 아니면 추천으로
            let fill = null;
            try { fill = chosen[c.docId] ? await D.edufinePicks?.fillWith(chosen[c.docId], win) : await D.edufinePicks?.fill(summary, win); note = fill?.text || ''; } catch { note = '공람자·과제카드를 채우지 못했어요. 직접 골라 주세요.'; fill = { short: true }; }
            if (run?.auto?.has(c.docId)) {
              if (fill?.short) { boardSend({ boardNow: c.docId, note: `${note} 고른 값이 다 들어가지 않아 결재하지 않았어요. 창에서 직접 결재해 주세요.` }); return; }
              boardSend({ boardNow: c.docId, note: `${i}/${list.length} 고른 대로 넣고 결재하는 중…` });
              runBar(`<b>${i}/${list.length}</b> · ${esc(c.title)} — 고른 대로 넣고 결재하는 중이에요. <button class="btn-line small" id="ibStop">멈춤</button>`);
              let a;
              try { a = await D.pcHelper.approveDoc({ pid: win.pid, expect: fill?.filled || {}, allow: D.edufineApproveAsks }); } catch { a = { ok: false, error: 'timeout' }; }
              if (a.ok) {
                run.autoDone++;
                if (!run.trusted) run.stop = true; // 처음 1건은 교사가 확인
                return;
              }
              const why = a.error === 'unknown-ask' ? `에듀파인이 이렇게 물어요: "${a.ask}" — 문서 창에서 직접 골라 주세요.` : D.pcHelper.explain(a);
              boardSend({ boardNow: c.docId, note: why });
              runBar(`<b>${i}/${list.length}</b> · ${esc(c.title)} — <span class="warn">${esc(why)}</span> 창이 닫히면 다음 문서를 열어요. <button class="btn-line small" id="ibStop">멈춤</button>`);
              return;
            }
            boardSend({ boardNow: c.docId, note: note || `${i}/${list.length} 문서 창을 보고 [결재]를 눌러 주세요.` });
            runBar(`<b>${i}/${list.length}</b> · ${esc(c.title)} — 문서 창을 보고 <b>[결재]</b>를 눌러 주세요. 창이 닫히면 다음 문서를 열어요.${note ? ` <span class="chg">${esc(note)}</span>` : ''} <button class="btn-line small" id="ibStop">멈춤</button>`);
          },
          watching: async (c, win) => { await D.edufinePicks?.watch?.(c.docId, win); },
          result: async (c, res) => {
            if (res.approved) await D.edufinePicks?.commit?.(c.docId, docs[c.docId]); else D.edufinePicks?.forget?.(c.docId);
            done[c.docId] = res.approved ? { cls: 'ok', text: '결재했어요' } : res.gone ? { cls: 'dim', text: '목록에 없어요' } : res.skipped ? { cls: 'warn', text: '창이 열리지 않아 건너뛰었어요' } : { cls: 'dim', text: '결재하지 않고 닫았어요' };
            repaint(c.docId);
            boardSend({ boardStatus: { docId: c.docId, ...done[c.docId], final: true } });
          },
        },
      });
    } catch (e) { r = { ok: false, error: e?.message || '문서를 열지 못했어요.' }; }
    const firstOnly = r?.ok && run?.auto && !run.trusted && run.autoDone === 1;
    if (firstOnly) boardSend({ boardFirst: true });
    boardSend({ boardEnd: firstOnly ? { text: '처음 1건을 결재했어요. 에듀파인 결재함·문서에서 결재가 맞게 됐는지 확인한 뒤 [확인했어요 — 나머지도 결재]를 눌러 주세요.', cls: 'ok' } : r?.ok ? { text: `결재 ${r.approved}건${r.passed ? ` · 그냥 닫음 ${r.passed}건` : ''}${r.stopped ? ' · 멈춤' : ''}.`, cls: 'ok' } : { text: r?.error || '문서를 열지 못했어요.', cls: 'err' } });
    busy = false;
    run = null;
    setRunning(false);
    if (!r.ok) { runBar(`${esc(r.error)}${r.needHelper ? ' <button class="btn-line small" data-ib-install="1">PC 도우미 설치 파일 받기</button>' : ''}`, 'err'); return; }
    if (latest) { cards = latest.cards; render(latest); }
    afterRun(`결재 ${r.approved}건${r.passed ? ` · 그냥 닫음 ${r.passed}건` : ''}${r.stopped ? ' · 멈춤' : ''}.${r.leftOpen ? ' 열려 있는 문서 창은 그대로 두었어요.' : ''}`);
  }
  function setRunning(on) {
    for (const id of ['ibBoard', 'ibReadAll', 'ibApprove', 'ibReload']) { const b = el.querySelector(`#${id}`); if (b) b.disabled = on; }
  }

  async function todoAll() {
    if (busy) return;
    const list = todoCands();
    let n = 0;
    for (const c of list) {
      const r = await D.todo.add(D.edufineDoc.todoInput(docs[c.docId], c.docId));
      if (r.ok || r.duplicate) { docs[c.docId].todoDone = true; n++; repaint(c.docId); }
    }
    runBar(`할 일에 ${n}건 넣었어요. <button class="link" data-go="todo">할 일 보기</button>`, 'ok');
  }

  function replyDraft(docId) {
    const s = docs[docId];
    if (s && !s.error) D.draftView.open(el, D.edufineDoc.replyInput(s), { backTo: () => load(false) }); // [← 이전]은 결재함으로
  }

  async function toTodo(docId) {
    const s = docs[docId];
    if (!s || s.error || !D.todo) return;
    const r = await D.todo.add(D.edufineDoc.todoInput(s, docId));
    if (r.ok || r.duplicate) { s.todoDone = true; s.todoError = ''; } else s.todoError = r.error;
    repaint(docId);
  }

  // 관련 문서 찾기: 문서등록대장 검색 기간은 작년 3월 1일부터 오늘까지
  // 에듀파인에 안 보이는 다른 기관 공문: 정보공개포털 원문정보를 새 창으로 열고 검색어만 복사한다(교사 결정 2026-11-05). 도우미는 그 사이트와 통신하지 않고, 검색어는 교사가 붙여 넣을 때만 간다
  async function openPortal(key) {
    const [docId, i] = key.split('|');
    const s = docs[docId];
    const ref = s?.related?.[+i];
    if (!ref) return;
    const query = `${ref.org ? `${ref.org} ` : ''}${ref.dept}-${ref.docNo}`;
    let copied = true;
    try { await navigator.clipboard.writeText(query); } catch { copied = false; }
    window.open(D.edufineScreens.openPortal, '_blank', 'noopener');
    s.relNote = s.relNote || {};
    s.relNote[+i] = { cls: 'dim', text: copied ? ' 정보공개포털을 열고 검색어를 복사했어요. 검색 칸에 붙여 넣어 주세요(공개된 문서만 보여요).' : ` 정보공개포털을 열었어요. 검색어: ${query}` };
    repaint(docId);
  }

  async function findRel(key) {
    if (busy) return;
    const [docId, i] = key.split('|');
    const s = docs[docId];
    const ref = s?.related?.[+i];
    if (!ref) return;
    busy = true;
    s.relNote[+i] = { cls: 'dim', text: ' 찾는 중…' };
    repaint(docId);
    const now = new Date();
    const p2 = (n) => String(n).padStart(2, '0');
    const today = `${now.getFullYear()}${p2(now.getMonth() + 1)}${p2(now.getDate())}`;
    const from = `${now.getFullYear() - 1}0301`;
    const dash = (y) => `${y.slice(0, 4)}-${y.slice(4, 6)}-${y.slice(6)}`;
    let r;
    try { r = await D.edufineInbox.findRelated({ ...D.edufineDoc.searchPlan(ref), from, to: today, basicFrom: dash(from), basicTo: dash(today) }); } catch { r = { ok: false, error: '문서등록대장을 열지 못했어요.' }; } finally { busy = false; }
    s.relNote[+i] = !r.ok ? { cls: 'err', text: ` ${r.error}` }
      : r.total == null ? { cls: 'dim', text: ' 에듀파인 문서등록대장에서 검색했어요. 에듀파인 화면에서 결과를 봐 주세요.' }
      : r.total === 0 ? { cls: 'warn', text: ' 문서등록대장에 없어요(우리 학교가 받은 공문이 아니거나 작년 3월보다 오래된 문서일 수 있어요).' }
      : { cls: 'ok', text: ` 문서등록대장에서 ${r.total}건 찾았어요. 에듀파인 화면에서 제목을 눌러 열어 보세요.` };
    repaint(docId);
  }

  function render(r) {
    const urgent = cards.filter((c) => c.urgent).length;
    show('inbox', `
      ${head}
      <table class="info">
        <tr><th>결재대기</th><td>${cards.length ? `<b>${r.total}건</b>${urgent ? ` · <span class="err">긴급 ${urgent}</span>` : ''}` : '없음'}</td></tr>
        <tr><th>읽음</th><td>${hm(D.edufineInbox.last.time)}${r.opened ? ' <span class="dim">결재대기 화면을 열었어요</span>' : ''}</td></tr>
      </table>
      ${r.more ? `<p class="warn">에듀파인 목록의 지금 쪽(${cards.length}건)만 읽었어요. 다음 쪽은 에듀파인에서 넘긴 뒤 [새로 읽기]를 눌러 주세요.</p>` : ''}
      <p class="hint" id="ibMsg">${cards.length ? '[모아 보기]는 문서를 하나씩 열어 읽고(결재 안 함, 에듀파인에 선생님이 연 것과 같은 열람 기록이 남아요) 넓은 창에 3×3으로 보여 드려요. 결재는 문서 창에서 하나씩 직접 눌러 주세요.' : '결재할 문서가 없어요.'}</p>
      <p class="hint" id="ibBar"></p>
      ${cards.length ? `<div class="actions"><button class="btn-main" id="ibBoard">모아 보기</button><button class="btn-line" id="ibReadAll">모두 읽기</button><button class="btn-line" id="ibApprove">결재 시작</button></div>` : ''}
      ${cards.length ? `<ul class="docs">${cards.map(card).join('')}</ul>` : ''}
      <div class="actions"><button class="btn-line" id="ibReload">새로 읽기</button>${back}</div>`);
  }

  function fail(r) {
    show('error', `
      ${head}
      <p class="err big">${esc(r.error)}</p>
      ${r.needMenu ? '<p class="hint">에듀파인 메뉴에서 <b>업무관리 → 결재 → 결재대기</b>를 연 뒤 [다시 읽기]를 눌러 주세요.</p>' : ''}
      <div class="actions"><button class="btn-main" id="ibReload">다시 읽기</button>${back}</div>`);
  }

  async function load(search) {
    if (busy) return;
    busy = true;
    const steps = ['에듀파인 창 찾기'];
    progress(steps);
    let r;
    try {
      r = await D.edufineInbox.load({ search, step: (t) => { steps.push(t); progress(steps); } });
    } catch (e) {
      r = { ok: false, error: '에듀파인 화면을 읽지 못했어요. 에듀파인 탭을 새로고침한 뒤 다시 눌러 주세요.' };
    } finally {
      busy = false;
    }
    if (!r.ok) { fail(r); return; }
    cards = r.cards;
    render(r);
  }

  async function open(docId, btn) {
    if (busy) return;
    busy = true;
    btn.disabled = true;
    btn.textContent = '여는 중';
    const msg = el.querySelector('#ibMsg');
    let r;
    try { r = await D.edufineInbox.open(docId); } catch { r = { ok: false, error: '문서를 열지 못했어요. 에듀파인에서 직접 눌러 주세요.' }; } finally { busy = false; }
    btn.disabled = false;
    btn.textContent = '열기';
    if (!r.ok) {
      msg.className = 'err';
      msg.textContent = r.error;
      return;
    }
    openedAt[docId] = `${hm(Date.now())} ${r.opened ? '열었어요' : '열기 누름'} — 결재한 뒤 [새로 읽기]`;
    const li = btn.closest('.doc');
    const c = cards.find((x) => x.docId === docId);
    if (li && c) li.outerHTML = card(c);
    if (r.opened) {
      msg.className = 'hint';
      msg.textContent = '문서 창을 열었어요. 결재·전자서명은 문서 창에서 직접 해 주세요.';
    } else {
      // 엣지에서는 문서가 브라우저 창이 아니라 에듀파인 문서 프로그램(WXSClient)으로 열린다(2026-10-28 확인) → 도우미는 그 창을 볼 수 없다
      msg.className = 'warn';
      msg.textContent = '문서는 에듀파인 문서 프로그램 창으로 열려요. 에듀파인 탭에 \'앱을 열까요?\' 확인이 뜨면 \'항상 허용\'에 체크하고 [열기]를 눌러 주세요. 문서 창이 끝내 안 뜨면 에듀파인 목록에 노랗게 표시한 제목을 직접 눌러 주세요.';
    }
  }

  D.views.inbox = {
    // home의 자리(root)에 그린다. [처음으로](#hmHome)는 home이 처리한다
    start(root) {
      if (el !== root) {
        el = root;
        el.addEventListener('click', (e) => {
          if (!el.dataset.state || !['inbox', 'error'].includes(el.dataset.state) || !el.querySelector('#ibReload')) return;
          if (e.target.id === 'ibStop') { if (run) { run.stop = true; runBar('이 문서까지 하고 멈춰요…'); } return; }
          if (e.target.id === 'ibReload') { load(true); return; }
          if (e.target.id === 'ibReadAll') { readAll(); return; }
          if (e.target.id === 'ibBoard') { openBoard(); return; }
          if (e.target.id === 'ibApprove') { startApprove(); return; }
          if (e.target.id === 'ibTodoAll') { todoAll(); return; }
          const ag = e.target.closest('[data-att-get]');
          if (ag) { attGet(ag.dataset.attGet); return; }
          const ao = e.target.closest('[data-att-open]');
          if (ao) { attOpen(ao.dataset.attOpen); return; }
          const rp = e.target.closest('[data-reply]');
          if (rp) { replyDraft(rp.dataset.reply); return; }
          const b = e.target.closest('[data-open]');
          if (b) { open(b.dataset.open, b); return; }
          const rd = e.target.closest('[data-read]');
          if (rd) { read(rd.dataset.read, rd); return; }
          const td = e.target.closest('[data-todo]');
          if (td) { toTodo(td.dataset.todo); return; }
          const rl = e.target.closest('[data-rel]');
          if (rl) { findRel(rl.dataset.rel); return; }
          const ro = e.target.closest('[data-rel-open]');
          if (ro) { openPortal(ro.dataset.relOpen); return; }
          if (e.target.closest('[data-ib-install]')) D.pcHelper.downloadInstaller();
        });
      }
      openedAt = {};
      docs = {};
      done = {};
      bodies = {};
      chosen = {};
      bindBoard();
      load(true);
    },
    isBusy: () => busy,
    // 처음으로 돌아갈 때: 목록은 지우고 '오늘'의 건수·시각만 남긴다(전체 자료 삭제 때는 home이 건수도 지움)
    clear() { cards = []; openedAt = {}; docs = {}; done = {}; bodies = {}; chosen = {}; pickLists = null; },
  };
})();
