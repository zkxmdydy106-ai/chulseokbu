// 패널 '결재함 보기' 화면: 결재대기 문서 목록 + 한 건씩 [열기]. 첫 화면(home)의 자리를 빌려 그린다.
// 결재·전자서명은 문서 창에서 교사가 한다. 목록은 이 화면이 떠 있는 동안만 메모리에 있다.
// 2단계(2026-10-29): [본문 읽기] — 열린 문서 창(WXSClient)의 본문을 PC 도우미가 읽어 규칙으로 정리(features/edufine-doc.js)
//   → [할 일로 넣기](F2 할 일 목록) · 관련 문서 줄마다 [에듀파인에서 찾기](문서등록대장 검색까지). 본문은 메모리에서만 쓰고 저장하지 않는다.
(() => {
  const D = globalThis.Doumi;
  const esc = D.esc;
  let el = null;
  let busy = false;
  let cards = [];
  let openedAt = {}; // 문서ID → 연 시각(이 화면에서만)
  let docs = {}; // 문서ID → 본문 정리(이 화면에서만, 본문 원문은 담지 않음)

  const hm = (t) => { const d = new Date(t); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const head = '<h2 class="sec">결재함</h2>';
  const back = '<button class="btn-line" id="hmHome">처음으로</button>';

  function show(state, html) {
    el.dataset.state = state;
    el.innerHTML = html;
  }

  function progress(steps) {
    show('busy', `${head}<ul class="progress">${steps.map((s, i) => `<li class="${i === steps.length - 1 ? 'now' : 'done'}"><span>${i === steps.length - 1 ? '진행 중' : '완료'}</span>${esc(s)}</li>`).join('')}</ul>`);
  }

  // 본문 정리 칸: 기한·제출·대상·붙임·관련(줄마다 [에듀파인에서 찾기]) + [할 일로 넣기]
  function summaryHtml(c) {
    const s = docs[c.docId];
    if (!s) return '';
    if (s.error) return `<div class="doc-sum"><p class="err">${esc(s.error)}</p>${s.install ? '<p><button class="btn-line small" data-ib-install="1">PC 도우미 설치 파일 받기</button></p>' : ''}</div>`;
    if (s.empty) return '<div class="doc-sum"><p class="warn">본문이 비어 있어요. 문서 창이 다 열린 뒤 [본문 읽기]를 다시 눌러 주세요.</p></div>';
    const row = (k, v) => (v ? `<tr><th>${k}</th><td>${v}</td></tr>` : '');
    const rel = s.related.map((r, i) => `<li><span>${esc(`${r.org ? `${r.org} ` : ''}${r.dept}-${r.docNo}`)}${r.ymd ? ` <span class="dim">(${esc(D.draft.formatDate(r.ymd))})</span>` : ''}</span> <button class="link" data-rel="${esc(c.docId)}|${i}">에듀파인에서 찾기</button>${s.relNote?.[i] ? `<span class="small ${s.relNote[i].cls}">${esc(s.relNote[i].text)}</span>` : ''}</li>`).join('');
    return `<div class="doc-sum">
      ${s.mismatch ? `<p class="warn">열린 문서 창의 제목이 이 카드와 달라요: ${esc(s.title)}</p>` : ''}
      <table class="info">
        ${row('기한', s.deadline.text ? `<b>${esc(s.deadline.text)}</b>` : '<span class="dim">본문에서 못 찾음</span>')}
        ${row('제출', esc(s.submits.join(', ')))}
        ${row('대상', esc(s.targets.join(', ')))}
        ${row('붙임', esc(s.attachments.join(', ')))}
        ${s.related.length ? `<tr><th>관련</th><td><ul class="doc-rel">${rel}</ul></td></tr>` : ''}
      </table>
      <p class="doc-sum-act"><button class="btn-line small" data-todo="${esc(c.docId)}"${s.todoDone ? ' disabled' : ''}>${s.todoDone ? '할 일에 넣었어요' : '할 일로 넣기'}</button>${s.todoDone ? ' <button class="link" data-go="todo">할 일 보기</button>' : ''}${s.todoError ? ` <span class="err small">${esc(s.todoError)}</span>` : ''}</p>
    </div>`;
  }

  function card(c) {
    const meta = [c.dept, c.drafter, c.date].filter(Boolean).map(esc).join(' · ');
    const sub = [c.status, c.kind].filter(Boolean).map(esc).join(' · ');
    const done = openedAt[c.docId];
    return `<li class="doc${c.urgent ? ' urgent' : ''}${done ? ' seen' : ''}" data-doc="${esc(c.docId)}">
      <div class="doc-main">
        <p class="doc-flags">${c.urgent ? '<span class="tag err">긴급</span>' : ''}${c.wait ? `<span class="doc-wait${c.waitDays >= 3 ? ' late' : ''}">${esc(c.wait)}</span>` : ''}${sub ? `<span class="dim">${sub}</span>` : ''}</p>
        <p class="doc-title">${esc(c.title)}</p>
        <p class="doc-meta">${meta}</p>
        ${done ? `<p class="doc-note ok">${esc(done)}</p>` : ''}
        ${summaryHtml(c)}
      </div>
      ${c.canOpen ? `<div class="doc-btns"><button class="btn-line small" data-open="${esc(c.docId)}">열기</button><button class="btn-line small" data-read="${esc(c.docId)}">본문 읽기</button></div>` : '<span class="dim small">열 수 없음</span>'}
    </li>`;
  }
  const repaint = (docId) => {
    const li = [...el.querySelectorAll('.doc')].find((x) => x.dataset.doc === docId);
    const c = cards.find((x) => x.docId === docId);
    if (li && c) li.outerHTML = card(c);
  };

  // 열린 문서 창 하나를 PC 도우미가 읽는다(문서 창은 에듀파인 문서 프로그램이라 확장이 직접 못 읽음)
  async function read(docId, btn) {
    if (busy) return;
    busy = true;
    btn.disabled = true;
    btn.textContent = '읽는 중';
    const c = cards.find((x) => x.docId === docId);
    try {
      const st = await D.pcHelper.status(true);
      if (!st.ok) {
        docs[docId] = { error: st.missing ? 'PC 도우미가 있어야 문서 창 본문을 읽을 수 있어요. 설치 파일을 받아 한 번 더블클릭해 주세요.' : st.text, install: !!st.missing };
      } else {
        const r = await D.pcHelper.readDoc({});
        if (!r.ok || !r.fields) docs[docId] = { error: /no-window/.test(r.error || '') ? '열린 문서 창이 없어요. [열기]로 문서 창을 연 뒤 다시 눌러 주세요.' : D.pcHelper.explain(r) };
        else {
          const s = D.edufineDoc.summarize(r.fields);
          const sq = (t) => String(t || '').replace(/\s+/g, '');
          s.mismatch = !!(c && s.title && sq(c.title) !== sq(s.title) && !sq(c.title).includes(sq(s.title)) && !sq(s.title).includes(sq(c.title)));
          s.relNote = [];
          docs[docId] = s;
        }
      }
    } catch {
      docs[docId] = { error: '본문을 읽지 못했어요. 문서 창이 열려 있는지 확인해 주세요.' };
    } finally { busy = false; }
    repaint(docId);
  }

  async function toTodo(docId) {
    const s = docs[docId];
    if (!s || s.error || !D.todo) return;
    const r = await D.todo.add(D.edufineDoc.todoInput(s, docId));
    if (r.ok || r.duplicate) { s.todoDone = true; s.todoError = ''; } else s.todoError = r.error;
    repaint(docId);
  }

  // 관련 문서 찾기: 문서등록대장 검색 기간은 작년 3월 1일부터 오늘까지
  async function findRel(key) {
    if (busy) return;
    const [docId, i] = key.split('|');
    const s = docs[docId];
    const ref = s?.related?.[+i];
    if (!ref) return;
    busy = true;
    s.relNote[+i] = { cls: 'dim', text: ' 찾는 중…' };
    repaint(docId);
    const now = new Date();
    const p2 = (n) => String(n).padStart(2, '0');
    const today = `${now.getFullYear()}${p2(now.getMonth() + 1)}${p2(now.getDate())}`;
    const from = `${now.getFullYear() - 1}0301`;
    const dash = (y) => `${y.slice(0, 4)}-${y.slice(4, 6)}-${y.slice(6)}`;
    let r;
    try { r = await D.edufineInbox.findRelated({ ...D.edufineDoc.searchPlan(ref), from, to: today, basicFrom: dash(from), basicTo: dash(today) }); } catch { r = { ok: false, error: '문서등록대장을 열지 못했어요.' }; } finally { busy = false; }
    s.relNote[+i] = !r.ok ? { cls: 'err', text: ` ${r.error}` }
      : r.total == null ? { cls: 'dim', text: ' 에듀파인 문서등록대장에서 검색했어요. 에듀파인 화면에서 결과를 봐 주세요.' }
      : r.total === 0 ? { cls: 'warn', text: ' 문서등록대장에 없어요(우리 학교가 받은 공문이 아니거나 작년 3월보다 오래된 문서일 수 있어요).' }
      : { cls: 'ok', text: ` 문서등록대장에서 ${r.total}건 찾았어요. 에듀파인 화면에서 제목을 눌러 열어 보세요.` };
    repaint(docId);
  }

  function render(r) {
    const urgent = cards.filter((c) => c.urgent).length;
    show('inbox', `
      ${head}
      <table class="info">
        <tr><th>결재대기</th><td>${cards.length ? `<b>${r.total}건</b>${urgent ? ` · <span class="err">긴급 ${urgent}</span>` : ''}` : '없음'}</td></tr>
        <tr><th>읽음</th><td>${hm(D.edufineInbox.last.time)}${r.opened ? ' <span class="dim">결재대기 화면을 열었어요</span>' : ''}</td></tr>
      </table>
      ${r.more ? `<p class="warn">에듀파인 목록의 지금 쪽(${cards.length}건)만 읽었어요. 다음 쪽은 에듀파인에서 넘긴 뒤 [새로 읽기]를 눌러 주세요.</p>` : ''}
      <p class="hint" id="ibMsg">${cards.length ? '[열기]를 누르면 그 문서 창만 열려요. 결재·전자서명은 문서 창에서 직접 해 주세요.' : '결재할 문서가 없어요.'}</p>
      ${cards.length ? `<ul class="docs">${cards.map(card).join('')}</ul>` : ''}
      <div class="actions"><button class="btn-main" id="ibReload">새로 읽기</button>${back}</div>`);
  }

  function fail(r) {
    show('error', `
      ${head}
      <p class="err big">${esc(r.error)}</p>
      ${r.needMenu ? '<p class="hint">에듀파인 메뉴에서 <b>업무관리 → 결재 → 결재대기</b>를 연 뒤 [다시 읽기]를 눌러 주세요.</p>' : ''}
      <div class="actions"><button class="btn-main" id="ibReload">다시 읽기</button>${back}</div>`);
  }

  async function load(search) {
    if (busy) return;
    busy = true;
    const steps = ['에듀파인 창 찾기'];
    progress(steps);
    let r;
    try {
      r = await D.edufineInbox.load({ search, step: (t) => { steps.push(t); progress(steps); } });
    } catch (e) {
      r = { ok: false, error: '에듀파인 화면을 읽지 못했어요. 에듀파인 탭을 새로고침한 뒤 다시 눌러 주세요.' };
    } finally {
      busy = false;
    }
    if (!r.ok) { fail(r); return; }
    cards = r.cards;
    render(r);
  }

  async function open(docId, btn) {
    if (busy) return;
    busy = true;
    btn.disabled = true;
    btn.textContent = '여는 중';
    const msg = el.querySelector('#ibMsg');
    let r;
    try { r = await D.edufineInbox.open(docId); } catch { r = { ok: false, error: '문서를 열지 못했어요. 에듀파인에서 직접 눌러 주세요.' }; } finally { busy = false; }
    btn.disabled = false;
    btn.textContent = '열기';
    if (!r.ok) {
      msg.className = 'err';
      msg.textContent = r.error;
      return;
    }
    openedAt[docId] = `${hm(Date.now())} ${r.opened ? '열었어요' : '열기 누름'} — 결재한 뒤 [새로 읽기]`;
    const li = btn.closest('.doc');
    const c = cards.find((x) => x.docId === docId);
    if (li && c) li.outerHTML = card(c);
    if (r.opened) {
      msg.className = 'hint';
      msg.textContent = '문서 창을 열었어요. 결재·전자서명은 문서 창에서 직접 해 주세요.';
    } else {
      // 엣지에서는 문서가 브라우저 창이 아니라 에듀파인 문서 프로그램(WXSClient)으로 열린다(2026-10-28 확인) → 도우미는 그 창을 볼 수 없다
      msg.className = 'warn';
      msg.textContent = '문서는 에듀파인 문서 프로그램 창으로 열려요. 에듀파인 탭에 \'앱을 열까요?\' 확인이 뜨면 \'항상 허용\'에 체크하고 [열기]를 눌러 주세요. 문서 창이 끝내 안 뜨면 에듀파인 목록에 노랗게 표시한 제목을 직접 눌러 주세요.';
    }
  }

  D.views.inbox = {
    // home의 자리(root)에 그린다. [처음으로](#hmHome)는 home이 처리한다
    start(root) {
      if (el !== root) {
        el = root;
        el.addEventListener('click', (e) => {
          if (!el.dataset.state || !['inbox', 'error'].includes(el.dataset.state) || !el.querySelector('#ibReload')) return;
          if (e.target.id === 'ibReload') { load(true); return; }
          const b = e.target.closest('[data-open]');
          if (b) { open(b.dataset.open, b); return; }
          const rd = e.target.closest('[data-read]');
          if (rd) { read(rd.dataset.read, rd); return; }
          const td = e.target.closest('[data-todo]');
          if (td) { toTodo(td.dataset.todo); return; }
          const rl = e.target.closest('[data-rel]');
          if (rl) { findRel(rl.dataset.rel); return; }
          if (e.target.closest('[data-ib-install]')) D.pcHelper.downloadInstaller();
        });
      }
      openedAt = {};
      docs = {};
      load(true);
    },
    isBusy: () => busy,
    // 처음으로 돌아갈 때: 목록은 지우고 '오늘'의 건수·시각만 남긴다(전체 자료 삭제 때는 home이 건수도 지움)
    clear() { cards = []; openedAt = {}; docs = {}; },
  };
})();
