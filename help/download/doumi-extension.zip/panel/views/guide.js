// 나이스 길잡이(신규 교사용, 2026-10-30): 목록 → [시작] → 나이스 화면 위 테두리·말풍선 + 패널에 지금 단계
// - 테두리 친 곳을 교사가 누르면 다음 단계로(엔진 guideState의 met). 알아챌 수 없는 단계는 [다음].
// - 메뉴도 하나씩 직접 누르게: 업무 탭 → 메뉴 묶음 → 화면. 급하면 [메뉴 바로 열기](누를 때만, 조회 안 함).
// - 나이스 값을 바꾸거나 버튼을 누르지 않는다. 학생 값은 읽지 않는다(엔진은 화면 위치·앱 이름·표 줄 수만).
(() => {
  const D = globalThis.Doumi;
  D.views = D.views || {};
  const KEY = 'guide.now'; // 지금 길잡이·단계(학생 정보 없음) — storage.session
  const TABS = { '002001': '학급담임', '002002': '교과담임' };

  let el, $;
  let run = null;   // { g, steps, i, menuN, tabId, found, total, opening }
  let timer = 0;
  let busy = false;

  const esc = (s) => D.esc(s);
  const guides = () => D.guides || [];
  const byId = (id) => guides().find((g) => g.id === id);

  function show(state, html) {
    el.dataset.state = state;
    el.innerHTML = html;
  }

  function renderList(note = '') {
    stopPoll();
    run = null;
    const groups = D.guideGroups || [];
    show('list', `
      <h2 class="sec">나이스 길잡이</h2>
      <p class="hint">나이스가 처음이어도 순서대로 따라 할 수 있게, 나이스 화면 위에 누를 곳을 테두리로 보여 드려요. 테두리 친 곳을 누르면 다음 단계로 넘어가요. 길잡이는 나이스 값을 바꾸지 않아요.</p>
      ${note}
      ${groups.map((gr) => `<div class="task-group"><h3>${esc(gr.name)}</h3><p class="g-intro">${esc(gr.intro)}</p><div class="tasks">${guides().filter((g) => g.group === gr.name).map((g) => `<button class="task" data-guide="${esc(g.id)}"><b>${esc(g.title)}</b><span>${esc(g.who)} · ${g.steps.length}단계</span></button>`).join('')}</div></div>`).join('')}
      <div class="actions"><button class="btn-line" id="gdManual">인쇄용 매뉴얼 열기</button></div>`);
  }

  // 메뉴 단계: 업무 탭 → (메뉴 목록에서 읽은) 묶음 → 화면. 메뉴 목록을 못 읽으면 길잡이에 적힌 이름
  function menuSteps(g, names) {
    const tab = TABS[g.menu.prefer] || g.menu.path[0];
    let path = (names && names.length ? names : g.menu.path.slice(1)).filter(Boolean);
    if (path[0] === tab) path = path.slice(1);
    const leaf = path[path.length - 1] || g.title;
    const mid = path.slice(0, -1);
    const out = [{ title: `업무 탭 [${tab}]`, targets: [{ menu: tab, pick: 'top' }], when: { clicked: true }, menu: true,
      body: `나이스 위쪽 업무 탭에서 [${tab}]을 누르세요. ${tab === '학급담임' ? '담임 업무(출결·생기부)' : '교과 업무(과목별출결·평가·성적)'}는 이 탭 안에 있어요.` }];
    for (const nm of mid) out.push({ title: `메뉴 [${nm}]`, targets: [{ menu: nm }], when: { clicked: true }, menu: true, body: `메뉴에서 [${nm}]을 눌러 펼치세요.` });
    out.push({ title: `메뉴 [${leaf}] — 화면 열기`, targets: [{ menu: leaf }], when: { app: g.menu.apps }, menu: true,
      body: `[${leaf}]을 누르면 화면이 열려요.${mid.includes(leaf) ? ' 같은 이름이 두 번 보이면 아래쪽(안쪽)이에요.' : ''}${names ? '' : ' 메뉴 묶음이 접혀 있으면 펼쳐서 찾아 주세요.'}` });
    return out;
  }

  async function start(id) {
    const g = byId(id);
    if (!g || busy) return;
    busy = true;
    try {
      const tab = await D.neis.activeTab();
      if (!D.neis.isNeis(tab)) { renderList('<p class="err">나이스 탭을 앞에 두고, 로그인한 뒤 시작해 주세요.</p>'); return; }
      const st = await D.neis.call('guideState', {}, { tabId: tab.id });
      if (!st.ok) { renderList(`<p class="err">${esc(st.error || '나이스 화면이 응답하지 않아요.')} 나이스에 로그인한 뒤 다시 해 주세요.</p>`); return; }
      const mp = await D.neis.call('menuPath', { menuId: g.menu.menuId, prefer: g.menu.prefer }, { tabId: tab.id });
      const ms = menuSteps(g, mp.ok && mp.deep ? mp.names : null);
      const steps = [...ms, ...g.steps];
      const opened = (st.apps || []).some((a) => g.menu.apps.includes(a));
      run = { g, steps, i: opened ? ms.length : 0, menuN: ms.length, tabId: tab.id, found: 0, total: 0, opening: false };
      await D.neis.call('guideClear', {}, { tabId: tab.id });
      await begin();
      startPoll();
    } finally {
      busy = false;
    }
  }

  // 길잡이 진행은 엔진이 맡는다 → 패널을 닫아도 나이스 위 테두리·말풍선만으로 끝까지 간다(교사 제보 2026-11-02)
  function runData() {
    const o = run.g.open;
    const scr = typeof o === 'string' ? D.screens.get(o) : o;
    return {
      id: run.g.id, i: run.i, menuN: run.menuN, apps: run.g.menu.apps,
      open: scr ? { menu: scr.menu, appId: scr.appId, step: scr.step || null, tab: scr.tab || null } : null,
      steps: run.steps.map((s) => ({ title: s.title, body: s.body || '', caution: s.caution || '', look: s.look || 'press', when: s.when || null, targets: s.targets || [] })),
    };
  }
  function note(r) {
    if (!run) return;
    run.found = r.ok ? r.found : 0;
    run.total = r.ok ? r.total : 0;
    run.covered = r.ok ? r.covered || 0 : 0;
    run.err = r.ok ? '' : (r.error || '나이스 화면이 응답하지 않아요.');
  }
  async function begin() {
    chrome.storage.session.set({ [KEY]: { id: run.g.id, i: run.i } }).catch(() => {});
    note(await D.neis.call('guideStart', { run: runData() }, { tabId: run.tabId }));
    paint();
  }
  async function go(i) {
    if (!run) return;
    const r = await D.neis.call('guideGo', { i }, { tabId: run.tabId });
    if (!run) return;
    if (r.ok && r.shown) { run.i = r.i; note(r); chrome.storage.session.set({ [KEY]: { id: run.g.id, i: run.i } }).catch(() => {}); paint(); }
    else await begin();
  }
  // 패널을 다시 열었을 때: 나이스에서 도는 길잡이가 있으면 그 화면으로 이어 붙는다
  async function reattach() {
    if (run) return false;
    const tab = await D.neis.activeTab().catch(() => null);
    if (!tab || !D.neis.isNeis(tab)) return false;
    const st = await D.neis.call('guideState', { full: true }, { tabId: tab.id, timeout: 3000 });
    if (!st.ok || !st.run) return false;
    const g = byId(st.run.id);
    if (!g) return false;
    run = { g, steps: st.run.steps, i: st.run.i, menuN: st.run.menuN, tabId: tab.id, found: st.found, total: st.total, covered: st.covered, opening: false };
    paint();
    startPoll();
    return true;
  }

  async function finish() {
    const g = run?.g;
    await stop(false);
    renderList(g ? `<p class="ok">[${esc(g.title)}] 길잡이를 마쳤어요. 다른 길잡이를 고르거나 [인쇄용 매뉴얼]로 다시 볼 수 있어요.</p>` : '');
  }

  async function stop(list = true) {
    stopPoll();
    const tabId = run?.tabId;
    run = null;
    chrome.storage.session.remove(KEY).catch(() => {});
    if (tabId != null) await D.neis.call('guideClear', {}, { tabId }).catch(() => {});
    if (list) renderList();
  }

  const CIRCLED = '①②③④⑤⑥⑦⑧';
  const legend = (s) => ((s.targets || []).length > 1 && s.targets.some((t) => t.label) && s.look !== 'nopress' ? s.targets.map((t, i) => `${CIRCLED[i]} ${t.label || ''}`.trim()).join(' · ') : '');
  function paint() {
    if (!run) return;
    const s = run.steps[run.i];
    const inMenu = run.i < run.menuN;
    const status = run.err ? `<p class="err">${esc(run.err)}</p>`
      : !(s.targets || []).length ? ''
      : run.found ? `<p class="g-status ok">나이스 화면에 테두리를 띄웠어요.${s.when ? ' 테두리 친 곳을 누르면 다음으로 넘어가요.' : ' 읽고 [다음]을 누르세요.'} 패널을 닫아도 나이스 위 말풍선으로 이어져요.</p>`
      : run.covered ? '<p class="g-status warn">나이스 창이 이 칸을 가리고 있어요. 나이스에 떠 있는 창(공지·안내)을 먼저 닫아 주세요.</p>'
      : `<p class="g-status warn">이 칸을 나이스 화면에서 찾지 못했어요. 아래 설명대로 찾아 ${s.when ? '눌러' : '봐'} 주세요.${inMenu ? ' 급하면 [메뉴 바로 열기].' : ''}</p>`;
    const list = run.steps.map((x, k) => `<li class="${k < run.i ? 'done' : k === run.i ? 'now' : ''}">${esc(x.title)}${x.look === 'nopress' ? ' <small class="err">누르지 않음</small>' : ''}</li>`).join('');
    show('run', `
      <h2 class="sec">${esc(run.g.title)} <small class="dim">${esc(run.g.who)}</small></h2>
      <div class="g-now ${esc(s.look || 'press')}">
        <p class="g-head"><span class="g-n">${run.i + 1} / ${run.steps.length}</span><b>${esc(s.title)}</b></p>
        ${s.body ? `<p class="g-body">${esc(s.body)}</p>` : ''}
        ${legend(s) ? `<p class="g-legend">${esc(legend(s))}</p>` : ''}
        ${s.caution ? `<p class="g-caution">${esc(s.caution)}</p>` : ''}
      </div>
      ${status}
      <div class="actions">
        <button class="btn-line small" id="gdPrev" ${run.i ? '' : 'disabled'}>이전</button>
        <button class="btn-main small" id="gdNext">${run.i === run.steps.length - 1 ? '마치기' : '다음'}</button>
        ${inMenu ? `<button class="btn-line small" id="gdOpen" ${run.opening ? 'disabled' : ''}>${run.opening ? '여는 중…' : '메뉴 바로 열기'}</button>` : ''}
        <button class="btn-text" id="gdStop">그만</button>
      </div>
      <ol class="g-steps">${list}</ol>`);
  }

  // 0.4초마다: 단계 조건이 맞으면 다음, 말풍선 단추, 엔진이 바뀌었으면(나이스 탭 새로고침·도우미 업데이트) 다시 그림
  function startPoll() {
    stopPoll();
    timer = setInterval(poll, 400);
  }
  function stopPoll() { clearInterval(timer); timer = 0; }
  let polling = false;
  async function poll() {
    if (!run || polling) return;
    polling = true;
    try {
      const r = await D.neis.call('guideState', {}, { tabId: run.tabId, timeout: 3000 });
      if (!run) return;
      if (!r.ok) { if (run.err !== r.error) { run.err = r.error || '나이스 화면이 응답하지 않아요.'; paint(); } return; }
      if (run.err) { run.err = ''; paint(); }
      // 엔진이 끝냈으면(말풍선 [그만]·[마치기]) 목록으로, 엔진이 잃었으면(나이스 탭이 새로 열림 등) 지금 단계부터 다시
      if (!r.run) {
        if (r.ended?.how === 'done') await finish();
        else if (r.ended?.how === 'stop') await stop();
        else await begin();
        return;
      }
      if (r.run.i !== run.i) { run.i = r.run.i; run.found = r.found; run.covered = r.covered; paint(); chrome.storage.session.set({ [KEY]: { id: run.g.id, i: run.i } }).catch(() => {}); return; }
      if (r.found !== run.found || (r.covered || 0) !== (run.covered || 0)) { run.found = r.found; run.covered = r.covered; paint(); }
    } finally {
      polling = false;
    }
  }

  async function openMenu() {
    if (!run || run.opening) return;
    const o = run.g.open;
    const screen = typeof o === 'string' ? D.screens.get(o) : o;
    if (!screen) return;
    run.opening = true;
    paint();
    const r = await D.neis.open(screen, run.tabId);
    if (!run) return;
    run.opening = false;
    if (!r.ok) run.err = `메뉴를 열지 못했어요. ${r.error || ''}${run.g.menu.prefer === '002002' ? ' [교과담임] 탭을 먼저 누른 뒤 다시 해 보세요.' : ''}`;
    paint();
  }

  function openManual() {
    const url = chrome.runtime.getURL('panel/manual.html');
    if (chrome.tabs?.create) chrome.tabs.create({ url }); else window.open(url, '_blank');
  }

  D.views.guide = {
    init(root) {
      el = root;
      $ = (s) => el.querySelector(s);
      renderList();
      // 패널을 다시 열었는데 나이스에서 길잡이가 돌고 있으면 그 화면으로
      setTimeout(async () => { if (await reattach()) D.go('guide'); }, 400);
      el.addEventListener('click', async (e) => {
        const b = e.target.closest('button');
        if (!b) return;
        if (b.dataset.guide) { await start(b.dataset.guide); return; }
        if (b.id === 'gdManual') openManual();
        if (!run) return;
        if (b.id === 'gdNext') { if (run.i === run.steps.length - 1) await finish(); else await go(run.i + 1); }
        if (b.id === 'gdPrev') await go(run.i - 1);
        if (b.id === 'gdStop') await stop();
        if (b.id === 'gdOpen') await openMenu();
      });
    },
    enter() { if (!run) renderList(); },
    helpId: () => 'guide',
    // 다른 화면으로 가면 나이스 위 테두리도 거둔다
    leave() { if (run) stop(false); },
    back() { if (run) { stop(); return true; } return false; },
    // 시험용: 지금 단계(학생 정보 없음)
    now: () => (run ? { id: run.g.id, i: run.i, total: run.steps.length, menuN: run.menuN, title: run.steps[run.i].title, found: run.found } : null),
  };
})();
