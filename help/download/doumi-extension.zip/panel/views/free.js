// 빈 시간 찾기(S1): 컴시간 시간표 + 나이스 일일근무상황(성명·기간) → 교시마다 수업/부재/비어 있음 색 표, 모두 비는 교시
// 저장하는 것: 학교(컴시간 코드·이름), 그룹(컴시간 가린 이름 '김요*'·번호, 교사가 적은 나이스 이름) — chrome.storage.local
// 저장하지 않는 것: 근무상황(성명·기간)은 표를 그리는 동안 메모리에만. 근무상황 종류·목적지는 읽지 않는다.
(() => {
  const D = globalThis.Doumi;
  const F = D.freetime;
  const esc = (s) => D.esc(s);
  let el, $;
  let busy = false;
  let cache = {};       // 컴시간 주별 자료 { 'code|no': parsed }
  let result = null;    // 마지막 표
  let last = null;      // { members, dates, weekData, duties }
  let fixes = {};       // 칸 고침
  let editing = null;   // 그룹 고치는 중 { i, name, members }

  const today = () => { const d = new Date(); return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`; };
  const iso = (ymd) => `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6)}`;
  const title = (t) => `<h1 class="page-title">${esc(t)}</h1>`;
  const settings = () => D.store.settings();
  const save = (p) => D.store.saveSettings(p);

  async function week(code, no) {
    const k = `${code}|${no}`;
    if (!cache[k]) cache[k] = await D.comci.week(code, no);
    return cache[k];
  }

  async function render(msg = '') {
    const s = await settings();
    if (editing) { renderEditor(s); return; }
    if (!s.comciSchool) {
      el.innerHTML = `${title('빈 시간 찾기')}
        <p class="hint">처음 한 번: 우리 학교를 컴시간에서 찾아요. 선생님들 수업은 컴시간(학생용 시간표, 변경 반영), 부재는 나이스 복무에서 읽어요.</p>
        <div class="row-btns"><input id="ftSchool" class="txt" placeholder="학교 이름 (예: ○○고)" maxlength="20"><button class="btn-main small" id="ftFind">찾기</button></div>
        <div id="ftSchools"></div><p class="err" id="ftMsg">${esc(msg)}</p>`;
      return;
    }
    const groups = s.freeGroups || [];
    const g = Math.min(+(s.freeGroup || 0), Math.max(0, groups.length - 1));
    el.innerHTML = `${title('빈 시간 찾기')}
      <p class="hint">${esc(s.comciSchool.name)} · 수업은 컴시간, 부재는 나이스 복무 <button class="link" id="ftReset">학교 바꾸기</button></p>
      ${groups.length ? `
        <div class="ft-form">
          <label>그룹 <select id="ftGroup">${groups.map((x, i) => `<option value="${i}" ${i === g ? 'selected' : ''}>${esc(x.name)} (${x.members.length}명)</option>`).join('')}</select></label>
          <span><button class="link" id="ftEdit">고치기</button> · <button class="link" id="ftNew">새 그룹</button></span>
          <label>날짜 <input type="date" id="ftDate" value="${iso(s.freeDate && s.freeDate >= today() ? s.freeDate : today())}"></label>
          <span class="seg"><button data-range="day" class="${s.freeRange === 'week' ? '' : 'on'}">하루</button><button data-range="week" class="${s.freeRange === 'week' ? 'on' : ''}">그 주</button></span>
        </div>
        <div class="actions"><button class="btn-main" id="ftGo">찾기</button></div>`
        : `<p class="hint">먼저 볼 선생님 묶음(그룹)을 만들어요. 예: 1학년 담임, 수학과.</p><div class="actions"><button class="btn-main" id="ftNew">그룹 만들기</button></div>`}
      <p class="err" id="ftMsg">${esc(msg)}</p>
      <div id="ftOut"></div>`;
    if (result) paint();
  }

  // 그룹 만들기·고치기: 컴시간 교사 목록(가린 이름)에서 고르기 + (복무 맞추기용) 나이스 이름
  async function renderEditor(s) {
    let cm;
    try { cm = await week(s.comciSchool.code, 1); } catch (e) { editing = null; render(e.message); return; }
    const chosen = new Map(editing.members.map((m) => [m.comci + '|' + m.idx, m]));
    const list = cm.names.map((n, i) => ({ n, i })).filter((x) => x.i && x.n);
    el.innerHTML = `${title(editing.i === null ? '그룹 만들기' : '그룹 고치기')}
      <label class="ft-name">그룹 이름 <input id="ftGName" class="txt" maxlength="20" value="${esc(editing.name)}" placeholder="예: 1학년 담임"></label>
      <p class="hint">컴시간에는 이름이 '김요*'처럼 가려져 있어요. 나이스 복무와 이름이 헷갈릴 때만 옆 칸에 실제 이름을 적어 주세요.</p>
      <div class="ft-bulk"><button class="btn-line small" id="ftAll">전체 선택</button><button class="btn-line small" id="ftNone">전체 해제</button><span class="dim">${chosen.size}명 골랐어요 · 전체 ${list.length}명</span></div>
      <div class="ft-pick">${list.map(({ n, i }) => { const m = chosen.get(n + '|' + i); return `<label class="ft-t ${m ? 'on' : ''}"><input type="checkbox" data-t="${i}" data-n="${esc(n)}" ${m ? 'checked' : ''}> <b>${esc(n)}</b>${m ? `<input class="txt ft-full" data-full="${i}" maxlength="10" placeholder="나이스 이름" value="${esc(m.full || '')}">` : ''}</label>`; }).join('')}</div>
      <div class="actions"><button class="btn-main" id="ftGSave">저장</button><button class="btn-line" id="ftGCancel">취소</button>${editing.i !== null ? '<button class="danger" id="ftGDel">그룹 지우기</button>' : ''}</div>
      <p class="err" id="ftMsg"></p>`;
  }
  function editorMembers() {
    return [...el.querySelectorAll('[data-t]')].filter((c) => c.checked).map((c) => ({ comci: c.dataset.n, idx: +c.dataset.t, full: (el.querySelector(`[data-full="${c.dataset.t}"]`)?.value || '').trim() || undefined }));
  }

  // 나이스 복무: 일일근무상황조회를 날짜마다 조회해 성명·기간만 읽는다.
  // 화면이 안 열려 있으면 [찾기]를 누른 김에 도우미가 메뉴를 연다(조회만, 값은 안 바꿈 — 2026-10-29 교사: 복무가 빠져 있음)
  async function readDuties(dates) {
    const tab = await D.neis.activeTab();
    if (!D.neis.isNeis(tab)) return { duties: null, note: '나이스 탭이 아니라서 복무(부재)를 못 읽었어요. 나이스 탭에서 다시 [찾기]를 누르세요.' };
    const screen = D.screens.get('neis.duty.daily');
    const det = await D.neis.call('detect', {}, { tabId: tab.id });
    if (!det.ok || !(det.apps || []).includes(screen.appId)) {
      $('#ftOut').innerHTML = '<p class="hint">나이스 복무(일일근무상황조회) 화면을 여는 중…</p>';
      const o = await D.neis.open(screen, tab.id);
      if (!o.ok) return { duties: null, note: `나이스 복무 화면을 열지 못했어요(${o.error}). 나이스 왼쪽 [기본 메뉴 → 복무 → 일일근무상황조회]를 한 번 열어 두고 다시 [찾기]를 누르세요.` };
    }
    const S = screen.search, C = screen.columns;
    const duties = {};
    for (const ymd of dates) {
      const r1 = await D.neis.call('search', { appId: screen.appId, dataMap: S.dataMap, values: { [S.date]: ymd, [S.staff]: S.teacher }, button: S.button, dataset: screen.dataset }, { tabId: tab.id, timeout: 25000 });
      if (!r1.ok) return { duties: null, note: `나이스 복무를 읽지 못했어요(${r1.error}). 수업만 봤어요.` };
      const r2 = await D.neis.call('read', { appId: screen.appId, dataset: screen.dataset, columns: [C.name, C.period] }, { tabId: tab.id });
      if (!r2.ok) return { duties: null, note: '나이스 복무를 읽지 못했어요. 수업만 봤어요.' };
      duties[ymd] = r2.rows.map((x) => ({ name: D.squash(x[C.name]), prd: String(x[C.period] || '') }));
    }
    return { duties, note: '' };
  }

  async function run() {
    if (busy) return;
    const s = await settings();
    const group = (s.freeGroups || [])[+$('#ftGroup').value];
    const ymd = ($('#ftDate').value || '').replace(/-/g, '') || today();
    const range = el.querySelector('[data-range].on')?.dataset.range || 'day';
    await save({ freeGroup: +$('#ftGroup').value, freeDate: ymd, freeRange: range });
    busy = true;
    $('#ftOut').innerHTML = '<p class="hint">컴시간 시간표와 나이스 복무를 읽는 중…</p>';
    try {
      const dates = F.datesFor(ymd, range);
      const first = await week(s.comciSchool.code, 1);
      const weekData = {};
      const notes = [];
      for (const d of dates) {
        const no = F.weekFor(first, d);
        if (no) weekData[d] = await week(s.comciSchool.code, no);
      }
      if (dates.some((d) => !weekData[d])) notes.push('컴시간에는 이번 주와 다음 주 시간표만 있어요. 그 밖의 날은 수업을 알 수 없어요.');
      // 컴시간 교사 번호가 학기 중 바뀌면 이름으로 다시 찾는다
      const members = group.members.map((m) => (first.names[m.idx] === m.comci ? m : { ...m, idx: first.names.indexOf(m.comci) })).filter((m) => m.idx > 0);
      if (members.length < group.members.length) notes.push('컴시간 교사 목록에서 못 찾은 선생님이 있어요. 그룹을 고쳐 주세요.');
      const { duties, note } = await readDuties(dates);
      fixes = {};
      last = { members, dates, weekData, duties, dutyNote: note, notes, group: group.name };
      result = F.build({ members, dates, weekData, duties, fixes });
      paint();
    } catch (e) {
      $('#ftOut').innerHTML = `<p class="err">${esc(e.message || '시간표를 읽지 못했어요.')}</p>`;
    } finally {
      busy = false;
    }
  }

  const CELL = { class: '수업', away: '부재', free: '' };
  function paint() {
    const out = $('#ftOut');
    if (!out || !result) return;
    const head = Array.from({ length: F.LAST + 1 }, (_, p) => `<th>${p === 0 ? '조회' : p}</th>`).join('');
    const notes = [...(last.notes || []), ...result.notes];
    // 복무(부재)를 반영했는지 표 위에 크게
    const awayN = new Set(result.days.flatMap((d) => d.rows.filter((r) => r.cells.includes('away')).map((r) => r.idx))).size;
    const duty = last.duties
      ? `<p class="ft-duty ok">복무 반영함 · 나이스 일일근무상황조회 · 이 그룹에서 부재 ${awayN}명</p>`
      : `<p class="ft-duty bad">복무를 빼고 수업만 봤어요 — ${esc(last.dutyNote || '')}</p>`;
    const days = F.freeDays(result);
    out.innerHTML = `
      ${duty}
      <div class="ft-legend"><span class="ft-c class">수업</span><span class="ft-c away">부재</span><span class="ft-c free">비어 있음</span><span class="dim">칸을 누르면 수업↔비어 있음을 고쳐요(이 화면에서만)</span></div>
      ${result.days.map((d) => `
        <h3 class="ft-day">${esc(d.label)}${d.noTable ? ' <span class="dim">시간표 없음</span>' : ''}</h3>
        <table class="ft"><thead><tr><th class="ft-n">선생님</th>${head}</tr></thead><tbody>
          ${d.rows.map((r) => `<tr><td class="ft-n">${esc(r.name)}</td>${r.cells.map((c, p) => `<td class="${c}" data-fix="${d.ymd}|${r.idx}|${p}">${CELL[c]}</td>`).join('')}</tr>`).join('')}
          <tr class="ft-all"><td class="ft-n">모두 빔</td>${d.allFree.map((v) => `<td class="${v ? 'yes' : ''}">${v ? '✓' : ''}</td>`).join('')}</tr>
        </tbody></table>`).join('')}
      <div class="ft-sum" id="ftSum"><h3>모두 비는 시간</h3>
        ${days.length ? `<table class="ft-sumt"><tbody>${days.map((x) => `<tr><th>${esc(x.label)}</th><td>${x.ps.map((p) => `<span class="ft-p">${esc(p)}</span>`).join('')}</td></tr>`).join('')}</tbody></table>` : '<p class="dim">모두 비는 시간이 없어요.</p>'}
      </div>
      <div class="row-btns"><button class="btn-line small" id="ftCopy">요약 복사</button></div>
      ${notes.map((n) => `<p class="warn">${esc(n)}</p>`).join('')}`;
  }

  D.views.free = {
    helpId: () => 'free',
    // 위쪽 [← 이전]: 그룹 고치는 중이면 그만두기, 아니면 처음 화면으로
    back() { if (editing) { editing = null; render(); return true; } return false; },
    init(root) {
      el = root;
      $ = (s) => el.querySelector(s);
      el.addEventListener('click', async (e) => {
        const t = e.target;
        if (t.dataset.range) { el.querySelectorAll('[data-range]').forEach((b) => b.classList.toggle('on', b === t)); return; }
        if (t.id === 'ftFind') {
          const name = $('#ftSchool').value.trim();
          if (!name) return;
          $('#ftSchools').innerHTML = '<p class="hint">찾는 중…</p>';
          try {
            const list = await D.comci.searchSchool(name);
            $('#ftSchools').innerHTML = list.length ? `<div class="tasks">${list.map((x) => `<button class="task" data-school="${esc(x.code)}" data-sname="${esc(x.name)}"><b>${esc(x.name)}</b><span>${esc(x.region)}</span></button>`).join('')}</div>` : '<p class="hint">컴시간에서 찾지 못했어요. 이름을 줄여서 다시 찾아 보세요.</p>';
          } catch (err) { $('#ftSchools').innerHTML = `<p class="err">${esc(err.message)}</p>`; }
          return;
        }
        const sc = t.closest('[data-school]');
        if (sc) { await save({ comciSchool: { code: sc.dataset.school, name: sc.dataset.sname } }); cache = {}; render(); return; }
        if (t.id === 'ftReset') { await save({ comciSchool: null }); cache = {}; result = null; render(); return; }
        if (t.id === 'ftNew') { editing = { i: null, name: '', members: [] }; render(); return; }
        if (t.id === 'ftEdit') { const s = await settings(); const i = +$('#ftGroup').value; const g = s.freeGroups[i]; editing = { i, name: g.name, members: g.members }; render(); return; }
        if (t.id === 'ftGCancel') { editing = null; render(); return; }
        if (t.id === 'ftGSave' || t.id === 'ftGDel') {
          const s = await settings();
          const groups = [...(s.freeGroups || [])];
          if (t.id === 'ftGDel') groups.splice(editing.i, 1);
          else {
            const g = { name: $('#ftGName').value.trim() || '그룹', members: editorMembers() };
            if (!g.members.length) { $('#ftMsg').textContent = '선생님을 한 명 이상 골라 주세요.'; return; }
            if (editing.i === null) groups.push(g); else groups[editing.i] = g;
          }
          await save({ freeGroups: groups, freeGroup: t.id === 'ftGDel' ? 0 : (editing.i ?? groups.length - 1) });
          editing = null;
          result = null;
          render();
          return;
        }
        if (t.id === 'ftGo') { run(); return; }
        if (t.id === 'ftCopy') { navigator.clipboard.writeText(`[${last?.group || ''}] ${F.summary(result)}`).then(() => { t.textContent = '복사했어요'; }); return; }
        if ((t.id === 'ftAll' || t.id === 'ftNone') && editing) {
          editing.name = $('#ftGName').value;
          const had = new Map(editorMembers().map((m) => [m.idx, m]));
          editing.members = t.id === 'ftNone' ? [] : [...el.querySelectorAll('[data-t]')].map((c) => had.get(+c.dataset.t) || { comci: c.dataset.n, idx: +c.dataset.t });
          render();
          return;
        }
        const fx = t.closest('[data-fix]');
        if (fx && last) {
          const [ymd, idx, p] = fx.dataset.fix.split('|');
          const cur = result.days.find((d) => d.ymd === ymd)?.rows.find((r) => String(r.idx) === idx)?.cells[+p];
          if (cur === 'away') return;
          fixes[fx.dataset.fix] = cur === 'class' ? 'free' : 'class';
          result = F.build({ ...last, fixes });
          paint();
        }
      });
      el.addEventListener('change', (e) => {
        const c = e.target.closest('[data-t]');
        if (!c || !editing) return;
        editing.name = $('#ftGName').value;
        editing.members = editorMembers();
        if (c.checked) editing.members.push({ comci: c.dataset.n, idx: +c.dataset.t });
        editing.members = [...new Map(editing.members.map((m) => [m.idx, m])).values()].filter((m) => el.querySelector(`[data-t="${m.idx}"]`)?.checked);
        render();
      });
      el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.id === 'ftSchool') $('#ftFind').click(); });
    },
    enter() { render(); },
    // 시험용
    run,
  };
})();
