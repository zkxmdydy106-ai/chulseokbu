// 빈 시간 찾기(S1): 나이스 시간표(그날 실제 수업, 바뀐 수업 포함) + 나이스 일일근무상황(성명·기간) → 교시마다 수업/부재/비어 있음 색 표, 모두 비는 교시
// 2026-11-06 교사 결정: 컴시간 대신 나이스 [전체시간표조회 → 강의실별](panel/timetable.js). 나이스는 [찾기]·[가져오기]를 누를 때만 움직인다.
// 저장하는 것: 그룹(가린 이름 '김요*' + 이름 확인값), 교시 시각 — chrome.storage.local
// 세트 교체(2026-11-11): 세트·고른 시간은 저장하지 않음. 나이스는 [세트 찾기]를 누를 때 조회만.
// 저장하지 않는 것: 선생님 이름·수업 글은 작업 중 자료(chrome.storage.session, 브라우저를 닫으면 지워짐). 근무상황은 표를 그리는 동안 메모리에만.
(() => {
  const D = globalThis.Doumi;
  const F = D.freetime;
  const T = () => D.neisTimetable;
  const esc = (s) => D.esc(s);
  let el, $;
  let busy = false;
  let result = null;    // 마지막 표
  let last = null;      // { members, dates, days, names, duties, bells }
  let fixes = {};       // 칸 고침
  let editing = null;   // 그룹 고치는 중 { i, name, members: [{ mask, key }] }
  let mode = 'free';    // 'free' 모두 비는 시간 | 'set' 세트 교체(2026-11-11 교사 결정, 설계 12절)
  let sets = null;      // { dates, grid, duties, dutyNote, bells, list, isPast }
  let pick = null;      // { ymd, p, grade, skip: [수업 글] }

  const now = () => (typeof D.clock === 'function' ? D.clock() : new Date()); // 시험이 날짜를 정할 수 있게
  const today = () => { const d = now(); return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`; };
  const iso = (ymd) => `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6)}`;
  const title = (t) => `<h1 class="page-title">${esc(t)}</h1>`;
  const settings = () => D.store.settings();
  const save = (p) => D.store.saveSettings(p);
  const isNew = (m) => m && m.key; // 컴시간 때 만든 그룹 선생님에는 확인값이 없음

  async function render(msg = '') {
    const s = await settings();
    if (editing) { renderEditor(s, msg); return; }
    if (mode === 'set') { renderSet(s, msg); return; }
    const groups = s.freeGroups || [];
    const g = Math.min(+(s.freeGroup || 0), Math.max(0, groups.length - 1));
    const old = groups[g] && !groups[g].members.some(isNew);
    el.innerHTML = `${title('빈 시간 찾기')}
      ${modeTabs()}
      <p class="hint">수업은 나이스 [전체시간표조회](그날 바뀐 수업 포함), 부재는 나이스 복무에서 읽어요. 나이스 탭에서 눌러 주세요.</p>
      ${groups.length ? `
        <div class="ft-form">
          <label>그룹 <select id="ftGroup">${groups.map((x, i) => `<option value="${i}" ${i === g ? 'selected' : ''}>${esc(x.name)} (${x.members.length}명)</option>`).join('')}</select></label>
          <span><button class="link" id="ftEdit">고치기</button> · <button class="link" id="ftNew">새 그룹</button></span>
          <label>날짜 <input type="date" id="ftDate" value="${iso(s.freeDate && s.freeDate >= today() ? s.freeDate : today())}"></label>
          <span class="seg"><button data-range="day" class="${s.freeRange === 'week' ? '' : 'on'}">하루</button><button data-range="week" class="${s.freeRange === 'week' ? 'on' : ''}">그 주</button></span>
        </div>
        ${old ? '<p class="warn">컴시간으로 만든 그룹이에요. [고치기]에서 나이스 선생님 목록으로 다시 골라 주세요.</p>' : ''}
        <div class="actions"><button class="btn-main" id="ftGo" ${old ? 'disabled' : ''}>찾기</button></div>`
        : `<p class="hint">먼저 볼 선생님 묶음(그룹)을 만들어요. 예: 1학년 담임, 수학과.</p><div class="actions"><button class="btn-main" id="ftNew">그룹 만들기</button></div>`}
      <p class="err" id="ftMsg">${esc(msg)}</p>
      <div id="ftOut"></div>
      <details class="ft-bells"><summary>우리 학교 교시 시각 <span class="dim">(복무 부재를 교시로 바꿀 때 써요)</span></summary>
        <textarea id="ftBells" rows="8">${esc(s.bells || F.BELLS_TEXT)}</textarea>
        <div class="row-btns"><button class="btn-line small" id="ftBellSave">저장</button><button class="btn-line small" id="ftBellReset">처음 시각으로</button><span class="dim" id="ftBellMsg"></span></div>
      </details>`;
    if (result) paint();
  }

  const modeTabs = () => `<div class="seg ft-mode"><button data-mode="free" class="${mode === 'free' ? 'on' : ''}">모두 비는 시간</button><button data-mode="set" class="${mode === 'set' ? 'on' : ''}">세트 교체</button></div>`;

  // 세트 교체: 그 주 시간표에서 세트를 찾아 보여 주고, 고른 한 시간을 맞바꿀 수 있는 시간을 찾는다(찾기만, 나이스 값은 안 바꿈)
  function renderSet(s, msg = '') {
    el.innerHTML = `${title('빈 시간 찾기')}
      ${modeTabs()}
      <p class="hint">선택과목 세트(같은 시간에 여러 교실로 함께 도는 수업) 한 시간을 통째로 맞바꿀 수 있는 시간을 찾아요. 고른 날짜가 든 주(월~금)를 나이스에서 조회만 해요.</p>
      <div class="ft-form">
        <label>날짜 <input type="date" id="ftSetDate" value="${iso(s.freeDate && s.freeDate >= today() ? s.freeDate : today())}"></label>
      </div>
      <div class="actions"><button class="btn-main" id="ftSetGo">세트 찾기</button></div>
      <p class="err" id="ftMsg">${esc(msg)}</p>
      <div id="ftSetOut"></div>`;
    if (sets) paintSets();
  }

  async function runSets() {
    if (busy) return;
    const s = await settings();
    const ymd = ($('#ftSetDate').value || '').replace(/-/g, '') || today();
    await save({ freeDate: ymd });
    busy = true;
    const step = (t) => { const o = $('#ftSetOut'); if (o) o.innerHTML = `<p class="hint">${esc(t)}</p>`; };
    try {
      const dates = F.datesFor(ymd, 'week');
      const got = await D.timetable.fetch(dates, { force: true, onStep: step });
      if (!got.ok) { sets = null; pick = null; $('#ftSetOut').innerHTML = `<p class="err">${esc(got.error)}</p>`; return; }
      const grid = {};
      for (const d of dates) { const g = await D.timetable.grid(d); if (g) grid[d] = g; }
      const { duties, note } = await readDuties(dates, step);
      const bells = F.bellsFrom(s.bells || F.BELLS_TEXT);
      const isPast = F.pastFn(now(), bells);
      sets = { dates, grid, duties, dutyNote: note, bells, isPast, list: F.setList(grid, dates, isPast) };
      pick = null;
      paintSets();
    } catch (e) {
      $('#ftSetOut').innerHTML = `<p class="err">${esc(e.message || '시간표를 읽지 못했어요.')}</p>`;
    } finally {
      busy = false;
    }
  }

  function paintSets() {
    const out = $('#ftSetOut');
    if (!out || !sets) return;
    const duty = sets.duties
      ? '<p class="ft-duty ok">복무 반영함 · 나이스 일일근무상황조회</p>'
      : `<p class="ft-duty bad">복무를 빼고 수업만 봤어요 — ${esc(sets.dutyNote || '')}</p>`;
    if (!sets.list.length) {
      out.innerHTML = `${duty}<p class="warn">이 주 시간표에서 세트를 찾지 못했어요. 나이스 강의실 칸 이름 끝에 (A)처럼 글자가 붙은 시간을 세트로 봐요.</p>`;
      return;
    }
    const grades = [...new Set(sets.list.map((x) => x.grade))];
    const chip = (t, x) => { const on = pick && pick.ymd === t.ymd && pick.p === t.p && pick.grade === x.grade; return `<button class="ft-chip ${on ? 'on' : ''}" data-ss="${t.ymd}|${t.p}|${x.grade}" ${t.past ? 'disabled title="지난 시간"' : ''}>${esc(t.day)} ${t.p}</button>`; };
    out.innerHTML = `${duty}
      <p class="hint ft-pickhint">옮길 시간을 누르세요.</p>
      ${grades.map((g) => `<table class="ft-sets"><caption>${esc(g)}학년</caption><tbody>
        ${sets.list.filter((x) => x.grade === g).map((x) => `<tr><th>${esc(x.letter)}세트</th><td>${x.times.map((t) => chip(t, x)).join('')}</td></tr>`).join('')}
      </tbody></table>`).join('')}
      <div id="ftSwap"></div>`;
    if (pick) paintSwap();
  }

  const swapNow = () => F.swapCheck({ grid: sets.grid, dates: sets.dates, duties: sets.duties, bells: sets.bells, from: pick, skip: pick.skip, isPast: sets.isPast });
  const setNameOf = () => sets.list.find((x) => x.grade === pick.grade && x.times.some((t) => t.ymd === pick.ymd && t.p === pick.p))?.label || `${pick.grade}학년 세트`;
  const lessonRows = (ls) => ls.map((l) => `<tr><td>${esc(l.text)}</td><td class="dim">${esc(F.roomOf(l.place))}</td></tr>`).join('');
  // 막는 까닭: 복무는 '부재'만
  function blockText(b) {
    const where = b.side === 'there' ? '그 시간' : '세트 시간';
    return `${b.name} ${where} ${b.kind === 'away' ? '부재' : `${b.grade}학년 수업 중`}`;
  }

  function paintSwap() {
    const out = $('#ftSwap');
    if (!out || !pick) return;
    const all = (sets.grid[pick.ymd]?.[pick.grade]?.[pick.p]) || [];
    const r = swapNow();
    const open = (s) => `<details class="ft-opt"><summary><b>${esc(s.label)}</b> <span class="dim">그 시간 수업 ${s.lessons.length}개</span>${s.rooms.length ? ` <span class="ft-room">교실 겹침 ${esc(s.rooms.join(', '))}</span>` : ''}</summary>
      <table class="ft-les"><thead><tr><th colspan="2">${esc(r.label)} → ${esc(s.label)}로</th></tr></thead><tbody>${lessonRows(r.moved)}</tbody></table>
      <table class="ft-les"><thead><tr><th colspan="2">${esc(s.label)} → ${esc(r.label)}로</th></tr></thead><tbody>${lessonRows(s.lessons)}</tbody></table>
      ${s.unread ? `<p class="warn">선생님을 읽지 못한 수업이 ${s.unread}개 있어요. 이 수업은 직접 확인해 주세요.</p>` : ''}</details>`;
    out.innerHTML = `
      <div class="ft-swap"><h3>${esc(setNameOf())} · ${esc(r.label)}</h3>
        <table class="ft-les ft-mine"><tbody>${all.map((l) => `<tr><td><label><input type="checkbox" data-skip="${esc(l.text)}" ${pick.skip.includes(l.text) ? '' : 'checked'}> ${esc(l.text)}</label></td><td class="dim">${esc(F.roomOf(l.place))}</td></tr>`).join('')}</tbody></table>
        ${pick.skip.length ? '<p class="warn">뺀 수업은 그 시간에 그대로 남아요. 학생이 겹치지 않는지는 선생님이 봐 주세요.</p>' : ''}
        ${r.unread ? `<p class="warn">선생님을 읽지 못한 수업이 ${r.unread}개 있어요. 이 수업은 직접 확인해 주세요.</p>` : ''}
      </div>
      ${r.moved.length ? `
      <div class="ft-sum" id="ftSwapOk"><h3>맞바꿀 수 있는 시간 ${r.ok.length}곳</h3>
        ${r.ok.length ? r.ok.map(open).join('') : '<p class="dim">이 주에는 맞바꿀 수 있는 시간이 없어요.</p>'}
      </div>
      ${r.empty.length ? `<details class="ft-more" id="ftSwapEmpty"><summary>이 학년 수업이 없는 시간 ${r.empty.length}곳 <span class="dim">세트 선생님이 비어 있어 옮길 수 있지만 학생 일과가 달라져요</span></summary><p class="ft-list">${r.empty.map((s) => `<span class="ft-p">${esc(s.label)}</span>`).join('')}</p></details>` : ''}
      ${r.no.length ? `<details class="ft-more" id="ftSwapNo"><summary>안 되는 시간 ${r.no.length}곳</summary><table class="ft-sumt ft-why"><tbody>${r.no.map((s) => `<tr><th>${esc(s.label)}</th><td>${s.blocks.map((b) => esc(blockText(b))).join(' · ')}</td></tr>`).join('')}</tbody></table></details>` : ''}
      <div class="row-btns"><button class="btn-line small" id="ftSwapCopy">요약 복사</button></div>
      <p class="hint">도우미는 찾기만 해요. 실제 교체는 나이스 시간표관리에서 선생님이 넣어 주세요.</p>` : '<p class="warn">옮길 수업을 하나 이상 골라 주세요.</p>'}`;
  }

  // 그룹 만들기·고치기: 나이스 시간표에 나온 선생님 이름에서 고르기(이름은 화면에만, 저장은 가린 이름 + 확인값)
  async function renderEditor(s, msg = '') {
    const names = await D.timetable.names();
    const chosen = new Set(editing.members.filter(isNew).map((m) => m.key));
    el.innerHTML = `${title(editing.i === null ? '그룹 만들기' : '그룹 고치기')}
      <label class="ft-name">그룹 이름 <input id="ftGName" class="txt" maxlength="20" value="${esc(editing.name)}" placeholder="예: 1학년 담임"></label>
      ${names.length ? `
        <div class="ft-bulk"><button class="btn-line small" id="ftAll">전체 선택</button><button class="btn-line small" id="ftNone">전체 해제</button><span class="dim">${chosen.size}명 골랐어요 · 전체 ${names.length}명</span> <button class="link" id="ftLoad">목록 다시 가져오기</button></div>
        <div class="ft-pick">${names.map((n) => { const k = T().nameKey(n); return `<label class="ft-t ${chosen.has(k) ? 'on' : ''}"><input type="checkbox" data-k="${k}" data-n="${esc(n)}" ${chosen.has(k) ? 'checked' : ''}> <b>${esc(n)}</b></label>`; }).join('')}</div>
        <p class="hint">그룹에는 이름 끝을 가린 글('김요*')만 저장돼요. 이름은 나이스 시간표를 받을 때마다 다시 맞춰요.</p>`
        : `<p class="hint">선생님 목록은 나이스 시간표에서 가져와요. 나이스 탭에서 아래 단추를 누르면 이번 주 시간표를 조회만 해요.</p>
           <div class="actions"><button class="btn-main" id="ftLoad">나이스에서 선생님 목록 가져오기</button></div>`}
      <div class="actions"><button class="btn-main" id="ftGSave" ${names.length ? '' : 'disabled'}>저장</button><button class="btn-line" id="ftGCancel">취소</button>${editing.i !== null ? '<button class="danger" id="ftGDel">그룹 지우기</button>' : ''}</div>
      <p class="err" id="ftMsg">${esc(msg)}</p>`;
  }
  function editorMembers() {
    return [...el.querySelectorAll('[data-k]')].filter((c) => c.checked).map((c) => ({ mask: T().maskName(c.dataset.n), key: c.dataset.k }));
  }

  // 나이스 복무: 일일근무상황조회를 날짜마다 조회해 성명·기간만 읽는다(조회만, 값은 안 바꿈 — 2026-10-29 교사: 복무가 빠져 있음)
  async function readDuties(dates, step) {
    const tab = await D.neis.activeTab();
    if (!D.neis.isNeis(tab)) return { duties: null, note: '나이스 탭이 아니라서 복무(부재)를 못 읽었어요. 나이스 탭에서 다시 [찾기]를 누르세요.' };
    const screen = D.screens.get('neis.duty.daily');
    const det = await D.neis.call('detect', {}, { tabId: tab.id });
    if (!det.ok || !(det.apps || []).includes(screen.appId)) {
      step('나이스 복무(일일근무상황조회) 화면을 여는 중…');
      const o = await D.neis.open(screen, tab.id);
      if (!o.ok) return { duties: null, note: `나이스 복무 화면을 열지 못했어요(${o.error}). 나이스 왼쪽 [기본 메뉴 → 복무 → 일일근무상황조회]를 한 번 열어 두고 다시 [찾기]를 누르세요.` };
    }
    const S = screen.search, C = screen.columns;
    const duties = {};
    for (const ymd of dates) {
      step(`나이스 복무 읽는 중… ${+ymd.slice(4, 6)}/${+ymd.slice(6)}`);
      const r1 = await D.neis.call('search', { appId: screen.appId, dataMap: S.dataMap, values: { [S.date]: ymd, [S.staff]: S.teacher }, button: S.button, dataset: screen.dataset }, { tabId: tab.id, timeout: 25000 });
      if (!r1.ok) return { duties: null, note: `나이스 복무를 읽지 못했어요(${r1.error}). 수업만 봤어요.` };
      const r2 = await D.neis.call('read', { appId: screen.appId, dataset: screen.dataset, columns: [C.name, C.period] }, { tabId: tab.id });
      if (!r2.ok) return { duties: null, note: '나이스 복무를 읽지 못했어요. 수업만 봤어요.' };
      duties[ymd] = r2.rows.map((x) => ({ name: D.squash(x[C.name]), prd: String(x[C.period] || '') }));
    }
    return { duties, note: '' };
  }

  async function run() {
    if (busy) return;
    const s = await settings();
    const group = (s.freeGroups || [])[+$('#ftGroup').value];
    const ymd = ($('#ftDate').value || '').replace(/-/g, '') || today();
    const range = el.querySelector('[data-range].on')?.dataset.range || 'day';
    await save({ freeGroup: +$('#ftGroup').value, freeDate: ymd, freeRange: range });
    busy = true;
    const step = (t) => { const o = $('#ftOut'); if (o) o.innerHTML = `<p class="hint">${esc(t)}</p>`; };
    try {
      const dates = F.datesFor(ymd, range);
      const members = group.members.filter(isNew);
      // 시간표는 [찾기]를 누를 때마다 새로(그사이 바뀐 수업이 있을 수 있음)
      const got = await D.timetable.fetch(dates, { force: true, onStep: step });
      if (!got.ok) { $('#ftOut').innerHTML = `<p class="err">${esc(got.error)}</p>`; return; }
      const days = {};
      for (const d of dates) days[d] = await D.timetable.day(d);
      const names = await D.timetable.names();
      const { duties, note } = await readDuties(dates, step);
      const bells = F.bellsFrom(s.bells || F.BELLS_TEXT);
      fixes = {};
      last = { members, dates, days, names, duties, dutyNote: note, bells, group: group.name };
      result = F.build({ ...last, fixes });
      paint();
    } catch (e) {
      $('#ftOut').innerHTML = `<p class="err">${esc(e.message || '시간표를 읽지 못했어요.')}</p>`;
    } finally {
      busy = false;
    }
  }

  const CELL = { class: '수업', away: '부재', free: '' };
  function paint() {
    const out = $('#ftOut');
    if (!out || !result) return;
    const head = Array.from({ length: F.LAST + 1 }, (_, p) => `<th>${p === 0 ? '조회' : p}</th>`).join('');
    const notes = result.notes;
    const awayN = new Set(result.days.flatMap((d) => d.rows.filter((r) => r.cells.includes('away')).map((r) => r.key))).size;
    const duty = last.duties
      ? `<p class="ft-duty ok">복무 반영함 · 나이스 일일근무상황조회 · 이 그룹에서 부재 ${awayN}명</p>`
      : `<p class="ft-duty bad">복무를 빼고 수업만 봤어요 — ${esc(last.dutyNote || '')}</p>`;
    const days = F.freeDays(result);
    out.innerHTML = `
      ${duty}
      <div class="ft-legend"><span class="ft-c class">수업</span><span class="ft-c away">부재</span><span class="ft-c free">비어 있음</span><span class="dim">수업 칸에 손을 올리면 과목이 보여요 · 칸을 누르면 수업↔비어 있음을 고쳐요(이 화면에서만)</span></div>
      ${result.days.map((d) => `
        <h3 class="ft-day">${esc(d.label)}${d.noTable ? ' <span class="dim">시간표 없음</span>' : ''}</h3>
        <table class="ft"><thead><tr><th class="ft-n">선생님</th>${head}</tr></thead><tbody>
          ${d.rows.map((r) => `<tr><td class="ft-n">${esc(r.name)}</td>${r.cells.map((c, p) => `<td class="${c}" data-fix="${d.ymd}|${r.key}|${p}"${r.what[p] ? ` title="${esc(r.what[p])}"` : ''}>${CELL[c]}</td>`).join('')}</tr>`).join('')}
          <tr class="ft-all"><td class="ft-n">모두 빔</td>${d.allFree.map((v) => `<td class="${v ? 'yes' : ''}">${v ? '✓' : ''}</td>`).join('')}</tr>
        </tbody></table>`).join('')}
      <div class="ft-sum" id="ftSum"><h3>모두 비는 시간</h3>
        ${days.length ? `<table class="ft-sumt"><tbody>${days.map((x) => `<tr><th>${esc(x.label)}</th><td>${x.ps.map((p) => `<span class="ft-p">${esc(p)}</span>`).join('')}</td></tr>`).join('')}</tbody></table>` : '<p class="dim">모두 비는 시간이 없어요.</p>'}
      </div>
      <div class="row-btns"><button class="btn-line small" id="ftCopy">요약 복사</button></div>
      ${notes.map((n) => `<p class="warn">${esc(n)}</p>`).join('')}`;
  }

  // 선생님 목록: 이번 주(월~금) 시간표를 나이스에서 받아 이름을 모음
  async function loadNames() {
    if (busy) return;
    busy = true;
    const msg = $('#ftMsg');
    try {
      const got = await D.timetable.fetch(F.datesFor(today(), 'week'), { force: true, onStep: (t) => { if (msg) { msg.className = 'hint'; msg.textContent = t; } } });
      if (editing) editing.name = $('#ftGName')?.value ?? editing.name;
      busy = false;
      render(got.ok ? '' : got.error);
    } finally { busy = false; }
  }

  D.views.free = {
    helpId: () => 'free',
    // 위쪽 [← 이전]: 그룹 고치는 중이면 그만두기, 아니면 처음 화면으로
    back() {
      if (editing) { editing = null; render(); return true; }
      if (mode === 'set' && pick) { pick = null; paintSets(); return true; }
      return false;
    },
    init(root) {
      el = root;
      $ = (s) => el.querySelector(s);
      el.addEventListener('click', async (e) => {
        const t = e.target;
        if (t.dataset.range) { el.querySelectorAll('[data-range]').forEach((b) => b.classList.toggle('on', b === t)); return; }
        if (t.dataset.mode) { if (!busy && mode !== t.dataset.mode) { mode = t.dataset.mode; render(); } return; }
        if (t.id === 'ftSetGo') { runSets(); return; }
        if (t.dataset.ss) {
          const [ymd, p, grade] = t.dataset.ss.split('|');
          pick = { ymd, p: +p, grade, skip: [] };
          paintSets();
          return;
        }
        if (t.id === 'ftSwapCopy') { navigator.clipboard.writeText(F.swapSummary(setNameOf(), swapNow())).then(() => { t.textContent = '복사했어요'; }); return; }
        if (t.id === 'ftNew') { editing = { i: null, name: '', members: [] }; render(); return; }
        if (t.id === 'ftEdit') { const s = await settings(); const i = +$('#ftGroup').value; const g = s.freeGroups[i]; editing = { i, name: g.name, members: g.members }; render(); return; }
        if (t.id === 'ftLoad') { loadNames(); return; }
        if (t.id === 'ftGCancel') { editing = null; render(); return; }
        if (t.id === 'ftGSave' || t.id === 'ftGDel') {
          const s = await settings();
          const groups = [...(s.freeGroups || [])];
          if (t.id === 'ftGDel') groups.splice(editing.i, 1);
          else {
            const g = { name: $('#ftGName').value.trim() || '그룹', members: editorMembers() };
            if (!g.members.length) { $('#ftMsg').textContent = '선생님을 한 명 이상 골라 주세요.'; return; }
            if (editing.i === null) groups.push(g); else groups[editing.i] = g;
          }
          await save({ freeGroups: groups, freeGroup: t.id === 'ftGDel' ? 0 : (editing.i ?? groups.length - 1) });
          editing = null;
          result = null;
          render();
          return;
        }
        if (t.id === 'ftGo') { run(); return; }
        if (t.id === 'ftCopy') { navigator.clipboard.writeText(`[${last?.group || ''}] ${F.summary(result)}`).then(() => { t.textContent = '복사했어요'; }); return; }
        if (t.id === 'ftBellSave' || t.id === 'ftBellReset') {
          const text = t.id === 'ftBellReset' ? F.BELLS_TEXT : $('#ftBells').value;
          const n = F.bellsFrom(text).length;
          if (!n) { $('#ftBellMsg').textContent = "'1교시 08:50-09:40'처럼 한 줄에 하나씩 적어 주세요."; return; }
          await save({ bells: text });
          if (t.id === 'ftBellReset') $('#ftBells').value = text;
          $('#ftBellMsg').textContent = `저장했어요(${n}줄)`;
          return;
        }
        if ((t.id === 'ftAll' || t.id === 'ftNone') && editing) {
          editing.name = $('#ftGName').value;
          el.querySelectorAll('[data-k]').forEach((c) => { c.checked = t.id === 'ftAll'; });
          editing.members = editorMembers();
          render();
          return;
        }
        const fx = t.closest('[data-fix]');
        if (fx && last) {
          const [ymd, key, p] = fx.dataset.fix.split('|');
          const cur = result.days.find((d) => d.ymd === ymd)?.rows.find((r) => r.key === key)?.cells[+p];
          if (cur === 'away') return;
          fixes[fx.dataset.fix] = cur === 'class' ? 'free' : 'class';
          result = F.build({ ...last, fixes });
          paint();
        }
      });
      el.addEventListener('change', (e) => {
        const sk = e.target.closest('[data-skip]');
        if (sk && pick) {
          const v = sk.dataset.skip;
          pick.skip = sk.checked ? pick.skip.filter((x) => x !== v) : [...pick.skip, v];
          paintSwap();
          return;
        }
        const c = e.target.closest('[data-k]');
        if (!c || !editing) return;
        editing.name = $('#ftGName').value;
        editing.members = editorMembers();
        render();
      });
    },
    enter() { render(); },
    // 시험용
    run,
    runSets,
  };
})();
