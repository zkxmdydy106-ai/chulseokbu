// 패널 뼈대: 지금 화면 알아보기, 화면 전환, 상태 알림
(() => {
  const D = globalThis.Doumi;
  // 화면 = views/<이름>.js + panel.html의 section#view-<이름>. 자기 칸이 없는 것(결재함처럼 첫 화면 안에 그리는 것)은 따로 시작하지 않는다
  const views = Object.fromEntries(Object.entries(D.views).filter(([name]) => document.getElementById(`view-${name}`)));
  const listeners = new Set();
  const LOGIN_APP = 'app/com/inc/login'; // 나이스 첫 화면(로그인 전). 2026-10-27 실제 확인
  let current = 'home';

  D.state = { tab: null, where: 'checking', screen: null, apps: [] };
  D.onState = (fn) => listeners.add(fn);
  D.emit = (type) => { for (const v of Object.values(views)) v.on?.(type); };

  D.go = (name) => {
    if (!views[name] || name === current) return;
    views[current].leave?.();
    document.getElementById(`view-${current}`).hidden = true;
    current = name;
    document.getElementById(`view-${name}`).hidden = false;
    views[name].enter?.();
    const foot = document.getElementById('footLink');
    foot.textContent = name === 'home' ? '저장된 자료 · 설정' : '← 처음으로';
    foot.dataset.go = name === 'home' ? 'data' : 'home';
    D.paintTop();
    window.scrollTo(0, 0);
  };
  // 위쪽 [← 이전]·[↻ 새로고침](교사 요청 2026-10-29)
  D.paintTop = () => {
    const b = document.getElementById('topBack');
    if (b) b.hidden = current === 'home' && (views.home.atStart?.() ?? true);
  };
  D.back = () => {
    if (views[current].back?.()) { D.paintTop(); return; }
    if (current !== 'home') D.go('home');
  };
  document.getElementById('topBack')?.addEventListener('click', () => D.back());
  document.getElementById('topReload')?.addEventListener('click', () => location.reload());
  // 새 판이 있으면 아래쪽에 알림
  D.help.checkUpdate().then((v) => {
    if (!v) return;
    const f = document.getElementById('footVer');
    if (f) f.innerHTML = `<button class="link" data-help-install>새 판 ${D.esc(v)} 받기</button>`;
  });
  // [설명]: 지금 보는 화면·일의 사용 방법 영상으로(교사 요청 2026-11-02). 일 옆 작은 [설명]은 그 일로
  document.getElementById('topHelp')?.addEventListener('click', () => D.help.open(views[current]?.helpId?.() || current));
  document.addEventListener('click', (e) => {
    const h = e.target.closest('[data-help]');
    if (h) { e.stopPropagation(); D.help.open(h.dataset.help); }
    if (e.target.closest('[data-help-install]')) D.help.open('install');
  });
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-go]');
    if (t) D.go(t.dataset.go);
  });

  const WHERE = {
    checking: ['', '화면 확인 중'],
    'not-neis': ['', '나이스 탭이 아니에요'],
    'no-script': ['warn', '나이스 탭을 새로고침해 주세요'],
    'no-response': ['warn', '나이스 화면이 응답하지 않아요'],
    'no-framework': ['', '나이스 메뉴 화면을 열어 주세요'],
    login: ['', '나이스에 로그인해 주세요'],
    'unknown-screen': ['on', '나이스 연결됨'],
    'neis-home': ['on', '나이스 연결됨'],
    wrapper: ['', '출결관리 — 일일출결 단계로 들어가 주세요'],
    edufine: ['on', '에듀파인 연결됨'],
  };

  function paintWhere(s) {
    const el = document.getElementById('where');
    const [cls, text] = s.where === 'screen' ? ['on', `나이스 · ${s.screen.title}`]
      : s.where === 'edufine' && s.kind !== '에듀파인 본창' && s.kind !== '기타 창' ? ['on', `에듀파인 · ${s.kind}`]
      : WHERE[s.where] || WHERE.checking;
    el.className = `where ${cls}`;
    // 패널 색: 지금 보는 사이트의 결로(나이스·에듀파인이 아닌 탭에서는 직전 것 유지)
    if (D.neis.isNeis(s.tab)) document.body.dataset.site = 'neis';
    else if (s.where === 'edufine') document.body.dataset.site = 'edufine';
    document.getElementById('whereText').textContent = text;
  }

  let busy = false;
  // force: 창이 가려져 패널이 '안 보임'이어도 확인(시험·다시 확인 버튼용). 평소에는 보일 때만 확인해 가볍게
  async function refreshWhere(force = false) {
    if (busy || (document.hidden && force !== true)) return;
    busy = true;
    try {
      const tab = await D.neis.activeTab();
      let next = { tab, where: 'not-neis', screen: null, apps: [] };
      if (D.edufine.isEdufine(tab?.url)) {
        let path = '';
        try { path = new URL(tab.url).pathname; } catch { /* 주소 없음 */ }
        next = { ...next, where: 'edufine', kind: D.edufine.kindOf(path) };
      } else if (D.neis.isNeis(tab)) {
        const r = await D.neis.call('detect', {}, { tabId: tab.id, timeout: 3000 });
        if (!r.ok) next.where = r.code === 'no-script' ? 'no-script' : 'no-response';
        else if (!r.framework) next.where = 'no-framework';
        else {
          next.apps = r.apps;
          // 여러 화면이 열려 있으면 가장 나중에 연 것(나이스 앱 목록은 연 순서)
          const s = D.screens.match(r.apps).sort((x, y) => r.apps.lastIndexOf(y.appId) - r.apps.lastIndexOf(x.appId))[0];
          if (s) Object.assign(next, { where: 'screen', screen: s });
          else if (r.apps.includes(LOGIN_APP)) next.where = 'login';
          else if (D.screens.wrapperOnly(r.apps).length) next.where = 'wrapper';
          else next.where = r.apps.some((a) => a.startsWith('edu/')) ? 'unknown-screen' : 'neis-home';
        }
      }
      const sig = (s) => `${s.tab?.id}|${s.where}|${s.kind || ''}|${s.screen?.id}|${s.apps.join(',')}`;
      const changed = sig(next) !== sig(D.state);
      D.state = next;
      if (changed) {
        paintWhere(next);
        for (const fn of listeners) fn(next);
      }
    } finally {
      busy = false;
    }
  }

  for (const [name, v] of Object.entries(views)) v.init(document.getElementById(`view-${name}`));
  views.home.enter?.();

  // 지금 도는 판 번호(교사가 ↻ 했는지 바로 알 수 있게, 2026-10-28)
  const fv = document.getElementById('footVer'); if (fv) fv.textContent = `도우미 ${chrome.runtime.getManifest().version}`;
  D.refreshWhere = refreshWhere;
  refreshWhere();
  setInterval(refreshWhere, 2500);
  chrome.tabs.onActivated.addListener(() => refreshWhere());
  chrome.tabs.onUpdated.addListener((_id, info) => { if (info.status === 'complete') refreshWhere(); });
  document.addEventListener('visibilitychange', () => refreshWhere());
})();
