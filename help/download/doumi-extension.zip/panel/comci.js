// 컴시간 학생용 웹(comci.net:4082)에서 우리 학교 시간표를 읽는다. 공식 연동이 없어 학생용 페이지가 쓰는 주소를 그대로 쓴다.
// - 주소 숫자(예: ./36179?17384l)는 컴시간이 가끔 바꾸므로 매번 첫 페이지(/st)에서 찾아낸다.
// - 보내는 것은 학교 이름(검색)과 학교 코드뿐. 학생 정보는 오가지 않는다(2026-10-28 교사 요청으로 연동).
(() => {
  const D = globalThis.Doumi;
  const BASE = 'http://comci.net:4082';

  // EUC-KR(CP949) 글자표: 브라우저의 TextDecoder로 거꾸로 만든다(처음 한 번)
  let table = null;
  function eucMap() {
    if (table) return table;
    table = new Map();
    const dec = new TextDecoder('euc-kr');
    for (let a = 0x81; a <= 0xfe; a++) {
      for (let b = 0x41; b <= 0xfe; b++) {
        const ch = dec.decode(new Uint8Array([a, b]));
        if (ch.length === 1 && ch !== '�' && !table.has(ch)) table.set(ch, [a, b]);
      }
    }
    return table;
  }
  function eucUrl(text) {
    let out = '';
    for (const ch of String(text)) {
      if (ch.charCodeAt(0) < 0x80) { out += encodeURIComponent(ch); continue; }
      const b = eucMap().get(ch);
      if (!b) throw new Error(`'${ch}' 글자를 컴시간에서 찾을 수 없어요.`);
      out += b.map((x) => `%${x.toString(16).toUpperCase()}`).join('');
    }
    return out;
  }
  const jsonOf = (text) => JSON.parse(text.slice(0, text.lastIndexOf('}') + 1));

  async function get(url, enc = 'utf-8') {
    return new TextDecoder(enc).decode(await bytes(url));
  }
  async function bytes(url) {
    let res;
    try { res = await fetch(url, { cache: 'no-store', credentials: 'omit' }); } catch {
      throw new Error('컴시간에 연결하지 못했어요. 인터넷 연결을 확인해 주세요(학교망에서 막혔을 수도 있어요).');
    }
    if (!res.ok) throw new Error(`컴시간이 응답하지 않아요(${res.status}).`);
    return new Uint8Array(await res.arrayBuffer());
  }
  // 검색 결과 글자는 UTF-8로 온다(2026-10-28 실제 확인 — 예전 EUC-KR로 읽어 '찾을 수 없음'이 났음). 혹시 EUC-KR이면 그것으로
  const textOf = (u8) => { const u = new TextDecoder('utf-8').decode(u8); return u.includes('학교검색') ? u : new TextDecoder('euc-kr').decode(u8); };

  // 컴시간 첫 페이지 스크립트가 글자를 감싸 둠(2026-11-04 실제, 'hour-obfuscated-v2': 4자리 16진수 ^ ((k + 순번*13) & 255)).
  // 받은 글자만 풀어 주소 숫자를 읽고, 스크립트를 실행하지는 않는다
  function unwrap(page) {
    let out = page;
    for (const m of page.matchAll(/\)\((\[\[[\s\S]*?\]\]),(\d+)\);?\s*<\/script>/g)) {
      let parts;
      try { parts = JSON.parse(m[1]); } catch { continue; }
      for (const [plain, b] of parts) {
        if (plain) { out += b; continue; }
        for (let j = 0; j < b.length; j += 4) out += String.fromCharCode(parseInt(b.substr(j, 4), 16) ^ ((+m[2] + (j / 4) * 13) & 255));
      }
    }
    return out;
  }

  let routes = null;
  async function findRoutes() {
    if (routes) return routes;
    const page = unwrap(await get(`${BASE}/st`, 'euc-kr'));
    const s = /\.\/(\d+)\?(\d+)l/.exec(page);
    const d = /sc_data\('(\d+)_/.exec(page);
    if (!s || !d) throw new Error('컴시간 화면이 바뀌어 주소를 찾지 못했어요. 도우미를 고쳐야 해요.');
    routes = { path: s[1], search: s[2], prefix: d[1] };
    return routes;
  }

  // 주소 숫자가 바뀌었을 수 있으니 실패하면 첫 페이지에서 다시 찾아 한 번 더
  async function retry(fn) {
    try { return await fn(await findRoutes()); } catch (e) {
      routes = null;
      const r = await findRoutes();
      try { return await fn(r); } catch { throw e; }
    }
  }

  D.comci = {
    BASE,
    eucUrl,
    unwrap,
    // → [{ code, name, region }]
    async searchSchool(name) {
      const d = await retry(async (r) => jsonOf(textOf(await bytes(`${BASE}/${r.path}?${r.search}l${eucUrl(String(name).trim())}`))));
      return (d.학교검색 || []).map((x) => ({ region: String(x[1] || ''), name: String(x[2] || ''), code: String(x[3] || '') })).filter((x) => /^\d+$/.test(x.code));
    },
    // 그 주(no: 일자자료 번호, 1=이번 주) 시간표 → Doumi.freetime.parseComci 결과
    async week(code, no = 1) {
      return retry(async (r) => D.freetime.parseComci(jsonOf(await get(`${BASE}/${r.path}?${btoa(`${r.prefix}_${code}_0_${no}`)}`))));
    },
    reset() { routes = null; },
  };
})();
