// 컴시간 학생용 웹(comci.net:4082)에서 우리 학교 시간표를 읽는다. 공식 연동이 없어 학생용 페이지가 쓰는 주소를 그대로 쓴다.
// - 주소 숫자(예: ./36179?17384l)는 컴시간이 가끔 바꾸므로 매번 첫 페이지(/st)에서 찾아낸다.
// - 보내는 것은 학교 이름(검색)과 학교 코드뿐. 학생 정보는 오가지 않는다(2026-10-28 교사 요청으로 연동).
(() => {
  const D = globalThis.Doumi;
  const BASE = 'http://comci.net:4082';

  // EUC-KR(CP949) 글자표: 브라우저의 TextDecoder로 거꾸로 만든다(처음 한 번)
  let table = null;
  function eucMap() {
    if (table) return table;
    table = new Map();
    const dec = new TextDecoder('euc-kr');
    for (let a = 0x81; a <= 0xfe; a++) {
      for (let b = 0x41; b <= 0xfe; b++) {
        const ch = dec.decode(new Uint8Array([a, b]));
        if (ch.length === 1 && ch !== '�' && !table.has(ch)) table.set(ch, [a, b]);
      }
    }
    return table;
  }
  function eucUrl(text) {
    let out = '';
    for (const ch of String(text)) {
      if (ch.charCodeAt(0) < 0x80) { out += encodeURIComponent(ch); continue; }
      const b = eucMap().get(ch);
      if (!b) throw new Error(`'${ch}' 글자를 컴시간에서 찾을 수 없어요.`);
      out += b.map((x) => `%${x.toString(16).toUpperCase()}`).join('');
    }
    return out;
  }
  const jsonOf = (text) => JSON.parse(text.slice(0, text.lastIndexOf('}') + 1));

  async function get(url, enc = 'utf-8') {
    return new TextDecoder(enc).decode(await bytes(url));
  }
  async function bytes(url) {
    let res;
    try { res = await fetch(url, { cache: 'no-store', credentials: 'omit' }); } catch {
      throw new Error('컴시간에 연결하지 못했어요. 인터넷 연결을 확인해 주세요(학교망에서 막혔을 수도 있어요).');
    }
    if (!res.ok) throw new Error(`컴시간이 응답하지 않아요(${res.status}).`);
    return new Uint8Array(await res.arrayBuffer());
  }
  // 검색 결과 글자는 UTF-8로 온다(2026-10-28 실제 확인 — 예전 EUC-KR로 읽어 '찾을 수 없음'이 났음). 혹시 EUC-KR이면 그것으로
  const textOf = (u8) => { const u = new TextDecoder('utf-8').decode(u8); return u.includes('학교검색') ? u : new TextDecoder('euc-kr').decode(u8); };

  let routes = null;
  async function findRoutes() {
    if (routes) return routes;
    const page = await get(`${BASE}/st`, 'euc-kr');
    const s = /\.\/(\d+)\?(\d+)l/.exec(page);
    const d = /sc_data\('(\d+)_/.exec(page);
    if (!s || !d) throw new Error('컴시간 화면이 바뀌어 주소를 찾지 못했어요. 도우미를 고쳐야 해요.');
    routes = { path: s[1], search: s[2], prefix: d[1] };
    return routes;
  }

  D.comci = {
    BASE,
    eucUrl,
    // → [{ code, name, region }]
    async searchSchool(name) {
      const r = await findRoutes();
      const d = jsonOf(textOf(await bytes(`${BASE}/${r.path}?${r.search}l${eucUrl(String(name).trim())}`)));
      return (d.학교검색 || []).map((x) => ({ region: String(x[1] || ''), name: String(x[2] || ''), code: String(x[3] || '') })).filter((x) => /^\d+$/.test(x.code));
    },
    // 그 주(no: 일자자료 번호, 1=이번 주) 시간표 → Doumi.freetime.parseComci 결과
    async week(code, no = 1) {
      const r = await findRoutes();
      const q = btoa(`${r.prefix}_${code}_0_${no}`);
      return D.freetime.parseComci(jsonOf(await get(`${BASE}/${r.path}?${q}`)));
    },
    reset() { routes = null; },
  };
})();
