// 에듀파인 화면 구조 기록(개발자 모드). 열린 에듀파인 창 전부(문서 새 창 포함)의 틀만 읽는다.
// 문서 제목·본문·사람 이름·입력값은 담지 않는다: 칸은 이름과 '채워짐' 여부, 본문은 글자 수만.
// 문서 창은 window.open이 아니라 이름 붙은 새 창으로 열리므로(docs/selectors.md) 패널이 에듀파인 탭을 모두 찾아 각 프레임에 넣어 읽는다.
(() => {
  const D = globalThis.Doumi;
  // 시도마다 주소가 달라 목록으로(shared/sites.js). MATCHES는 chrome.tabs.query용
  const MATCHES = globalThis.DoumiSites.edufineMatches;

  // 각 프레임 안에서 도는 함수(페이지 쪽, 따로 직렬화되므로 바깥 변수를 쓰지 않는다)
  function probeFrame() {
    const doc = document;
    const cut = (s, n) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
    const pathOf = (u) => {
      if (!u) return '';
      try { const x = new URL(u, location.href); return x.origin === location.origin ? x.pathname : x.origin + x.pathname; } catch { return '?'; }
    };
    const fnName = (s) => (/^\s*(?:javascript:)?\s*([\w$.]+)\s*\(/.exec(s || '') || [])[1] || '';
    const size = (e) => `${e.offsetWidth}x${e.offsetHeight}`;
    const field = (e) => ({ tag: e.tagName.toLowerCase(), type: e.type || '', id: e.id || '', name: e.name || '', filled: !!(e.value && e.type !== 'button' && e.type !== 'submit') });
    const count = (list) => list.reduce((m, k) => { if (k) m[k] = (m[k] || 0) + 1; return m; }, {});

    const fields = [...doc.querySelectorAll('input, select, textarea')].filter((e) => e.type !== 'hidden' || e.name || e.id);
    const buttons = [...doc.querySelectorAll('button, input[type=button], input[type=submit], a[class*=btn], span[class*=btn], a[class*=Btn]')];
    return {
      path: location.pathname,
      top: window === window.top,
      libs: {
        jquery: typeof window.jQuery === 'function', nexacro: typeof window.nexacro === 'object', Capi: typeof window.Capi === 'object',
        HwpCtrl: typeof window.HwpCtrl !== 'undefined', BuildWebHwpCtrl: typeof window.BuildWebHwpCtrl === 'function',
      },
      globals: Object.keys(window).filter((k) => /hwp|editor|hctrl|webdrm|markany|apprclient|docview/i.test(k)).slice(0, 40),
      frames: [...doc.querySelectorAll('iframe, frame, object, embed')].map((e) => ({ tag: e.tagName.toLowerCase(), id: cut(e.id, 120), name: cut(e.name, 60), src: pathOf(e.getAttribute('src') || e.getAttribute('data')), size: size(e) })),
      forms: [...doc.forms].map((f) => ({
        id: f.id || f.getAttribute('name') || '', action: pathOf(f.getAttribute('action')), target: (f.getAttribute('target') || '').replace(/\d/g, '9'),
        fields: [...new Map([...f.elements].filter((e) => e.name).map((e) => [e.name, field(e)])).values()].slice(0, 120),
      })),
      loose: fields.filter((e) => !e.form).map(field).slice(0, 120),
      buttons: buttons.map((b) => ({ id: b.id || '', label: cut(b.innerText || b.value, 15), on: fnName(b.getAttribute('onclick')) || fnName(b.getAttribute('href')) })).slice(0, 120),
      clicks: count([...doc.querySelectorAll('[onclick], a[href^="javascript"]')].filter((e) => !buttons.includes(e)).map((e) => fnName(e.getAttribute('onclick')) || fnName(e.getAttribute('href')))),
      tables: [...doc.querySelectorAll('table[id]')].map((t) => ({ id: t.id, cls: cut(t.className, 40), head: [...t.querySelectorAll('thead th')].map((th) => cut(th.innerText, 15)), rows: t.tBodies[0]?.rows.length ?? 0 })).slice(0, 40),
      editor: {
        contenteditable: doc.querySelectorAll('[contenteditable=""], [contenteditable=true]').length,
        textarea: doc.querySelectorAll('textarea').length, canvas: doc.querySelectorAll('canvas').length, svg: doc.querySelectorAll('svg').length,
      },
      // 기안·품의 화면 조사용(F3): 화면 고정 글자(칸 머리말)·선택 칸 코드·페이지가 만든 함수 이름만. 값은 담지 않는다
      // (기안·문서 창 자체는 WXSClient 프로그램이라 여기서 못 읽는다 — docs/selectors.md)
      // 머리말은 th·dt만(문서 제목·사람 이름이 들어갈 수 있는 label·.title은 담지 않음)
      labels: [...new Set([...doc.querySelectorAll('th, dt')].map((e) => cut(e.innerText, 15)).filter(Boolean))].slice(0, 120),
      selects: [...doc.querySelectorAll('select')].map((s) => ({ id: s.id || s.name || '', n: s.options.length, codes: [...s.options].slice(0, 20).map((o) => cut(o.value, 12)) })).slice(0, 40),
      fns: Object.keys(window).filter((k) => {
        try { return typeof window[k] === 'function' && !/\[native code\]/.test(Function.prototype.toString.call(window[k])); } catch { return false; }
      }).filter((k) => /fnc|fn_|hwp|sanct|appr|drft|draft|recv|rcv|doc|line|path|attach|file|save|submit|sign|edit|body|title|sj|open|popup|search|retrieve|set|get|insert|chk|check/i.test(k)).slice(0, 300),
      textLength: doc.body ? doc.body.innerText.length : 0,
      userSelect: doc.body ? getComputedStyle(doc.body).userSelect : '',
      ready: doc.readyState,
    };
  }

  const pathOf = (u) => { try { return new URL(u).pathname; } catch { return ''; } };

  D.edufine = {
    MATCHES,
    isEdufine(url) { return globalThis.DoumiSites.isEdufine(url); },
    // 창 종류: 결재(prc) · 조회(viw/retrieveDoccrd…) · 작성(wrt) · 그 밖
    kindOf(path) {
      if (/\/cz\/cb\/prc\//.test(path)) return '결재 창';
      if (/\/cz\/cb\/wrt\//.test(path)) return '작성 창';
      if (/\/cz\/cb\/viw\/retrieveDoccrd/.test(path)) return '조회 창';
      if (/\/keris_ui\/main\.do/.test(path)) return '에듀파인 본창';
      return '기타 창';
    },

    async record() {
      const tabs = await chrome.tabs.query({ url: MATCHES });
      if (!tabs.length) return { ok: false, error: '열린 에듀파인 창이 없어요. 에듀파인에 로그인하고 문서를 연 뒤 다시 눌러 주세요.' };
      const windows = [];
      for (const t of tabs) {
        let type = '';
        try { type = (await chrome.windows.get(t.windowId)).type; } catch { /* 닫히는 중 */ }
        let frames;
        try {
          const res = await chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, world: 'MAIN', func: probeFrame });
          frames = res.map((r) => ({ frameId: r.frameId, ...(r.result || { error: '읽지 못함' }) }));
        } catch (e) {
          frames = [{ error: String(e?.message || e).slice(0, 120) }];
        }
        const path = pathOf(t.url);
        // 문서 창은 중간 페이지(/bms/modalRedirectPage.jsp 등) 안 프레임에 문서가 들어가기도 한다 → 프레임 주소로도 종류를 본다
        let kind = this.kindOf(path);
        if (kind === '기타 창') kind = frames.map((f) => this.kindOf(f.path || '')).find((k) => k !== '기타 창' && k !== '에듀파인 본창') || (type === 'popup' ? '새 창(종류 모름)' : kind);
        // 창 제목은 문서 제목이 들어 있을 수 있어 담지 않는다
        windows.push({ 종류: kind, 주소: path, 새창: type === 'popup', 프레임수: frames.length, 프레임: frames });
      }
      return { ok: true, windows };
    },
  };
})();
