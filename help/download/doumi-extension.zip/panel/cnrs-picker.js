// 공람자 고르기 칸(교사 요청 2026-11-09): 체크 목록·전체 선택·즐겨찾기. 모아 보기 창과 기안 화면이 함께 쓴다.
// 즐겨찾기는 storage.local 'cnrsFavs'(교직원 이름, 이 PC만, '저장된 자료'에서 지움). 후보 이름은 메모리·storage.session만.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const KEY = 'cnrsFavs';
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const newId = () => `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;

  // opt: { get(): 지금 고른 이름들, set(names), people(): 후보 이름들(겹침 그대로), rerender(): 다시 그리기(Promise 가능), allHint: 전체 선택 뒤 안내 }
  function create(opt) {
    const P = D.edufinePickLogic;
    let favs = [];
    let saving = false;
    let note = null;
    const list = () => P.uniq(opt.people());

    async function load() {
      try { const v = (await chrome.storage.local.get(KEY))[KEY]; favs = Array.isArray(v) ? v : []; } catch { favs = []; }
    }
    async function saveFavs(next) {
      favs = next;
      if (next.length) await chrome.storage.local.set({ [KEY]: next }); else await chrome.storage.local.remove(KEY);
    }
    // 체크 하나마다 목록이 맨 위로 가지 않게 스크롤을 지킨다
    async function redraw(focus) {
      const box = document.querySelector('.cp-people');
      const top = box ? box.scrollTop : 0;
      await opt.rerender();
      const now = document.querySelector('.cp-people');
      if (now) now.scrollTop = top;
      if (focus) document.querySelector(focus)?.focus();
    }
    async function setNames(names, n = null, focus = null) {
      note = n;
      await opt.set(names);
      await redraw(focus);
    }
    async function favOk() {
      const name = document.getElementById('cpFavName')?.value;
      const r = P.favSave(favs, name, opt.get(), newId());
      if (r.error) { note = { cls: 'err', text: r.error }; await redraw('#cpFavName'); return; }
      await saveFavs(r.list);
      saving = false;
      note = { cls: 'ok', text: `'${String(name).trim().slice(0, 20)}' 즐겨찾기를 ${r.replaced ? '바꿔 ' : ''}저장했어요(이 PC).` };
      await redraw();
    }

    return {
      load,
      reset() { saving = false; note = null; },
      setNote(n) { note = n; },
      html() {
        const cnrs = opt.get();
        const names = list();
        const counts = {};
        for (const n of opt.people()) counts[n] = (counts[n] || 0) + 1;
        const extra = cnrs.filter((n) => !names.includes(n));
        return `<div class="cp">
          <div class="cp-head"><h3>공람자 <span class="dim">${cnrs.length}명</span></h3><span class="cp-sp"></span>
            ${names.length ? '<button type="button" class="btn-text" id="cpAll">전체 선택</button> <button type="button" class="btn-text" id="cpNone">전체 해제</button>' : ''}</div>
          <div class="cp-favs">
            ${favs.map((f) => { const on = P.favOn(cnrs, f, names); return `<span class="cp-fav${on ? ' on' : ''}"><button type="button" data-cp-fav="${esc(f.id)}" aria-pressed="${on}" title="${P.favNames(f, names).length}명">${esc(f.name)}</button><button type="button" class="cp-fav-del" data-cp-fav-del="${esc(f.id)}" aria-label="${esc(f.name)} 즐겨찾기 지우기">×</button></span>`; }).join('')}
            ${saving ? '' : `<button type="button" class="btn-text" id="cpFavNew" ${cnrs.length ? '' : 'disabled'}>지금 고른 ${cnrs.length}명 즐겨찾기로</button>`}
          </div>
          ${saving ? '<div class="cp-save"><input id="cpFavName" maxlength="20" placeholder="이름(예: 1학년 담임)"><button type="button" class="btn-line small" id="cpFavOk">저장</button><button type="button" class="btn-text" id="cpFavNo">닫기</button></div>' : ''}
          ${names.length ? `<div class="cp-people">${names.map((n) => `<label class="cp-person${cnrs.includes(n) ? ' on' : ''}"><input type="checkbox" data-cp-person="${esc(n)}" ${cnrs.includes(n) ? 'checked' : ''}><span class="cp-name">${esc(n)}</span>${counts[n] > 1 ? `<span class="dim" title="같은 이름 ${counts[n]}명: 문서 창에서 직접 골라 주세요">${counts[n]}</span>` : ''}</label>`).join('')}</div>` : '<p class="hint">후보 목록이 아직 없어요. 이름을 적어 주세요.</p>'}
          ${extra.length ? `<div class="cp-chips">${extra.map((n) => `<span class="cp-chip">${esc(n)}<button type="button" data-cp-del="${esc(n)}" aria-label="${esc(n)} 빼기">×</button></span>`).join('')}</div>` : ''}
          <input id="cpName" list="cpPeople" placeholder="이름을 적고 Enter" aria-label="공람자 이름">
          <datalist id="cpPeople">${names.map((n) => `<option value="${esc(n)}">`).join('')}</datalist>
          ${note ? `<p class="${esc(note.cls)}">${esc(note.text)}</p>` : ''}
        </div>`;
      },
      // 처리했으면 true
      async onClick(e) {
        const t = e.target.closest?.('button');
        if (!t) return false;
        const cnrs = opt.get();
        if (t.id === 'cpAll') { const names = list(); await setNames(P.selectAll(cnrs, names), { cls: 'hint', text: `${names.length}명을 모두 골랐어요. ${opt.allHint || '결재선에 있는 분은 문서 창에 넣을 때 빠져요.'}` }); return true; }
        if (t.id === 'cpNone') { await setNames([]); return true; }
        if (t.dataset.cpDel) { await setNames(cnrs.filter((n) => n !== t.dataset.cpDel)); return true; }
        if (t.dataset.cpFav) {
          const f = favs.find((v) => v.id === t.dataset.cpFav);
          if (!f) return true;
          const r = P.favToggle(cnrs, f, list());
          await setNames(r.cnrs, r.skipped ? { cls: 'warn', text: `${r.skipped}명은 지금 목록에 없어 뺐어요.` } : null);
          return true;
        }
        if (t.dataset.cpFavDel) { await saveFavs(favs.filter((f) => f.id !== t.dataset.cpFavDel)); await redraw(); return true; }
        if (t.id === 'cpFavNew') { saving = true; note = null; await redraw('#cpFavName'); return true; }
        if (t.id === 'cpFavNo') { saving = false; note = null; await redraw(); return true; }
        if (t.id === 'cpFavOk') { await favOk(); return true; }
        return false;
      },
      async onChange(e) {
        const n = e.target.dataset?.cpPerson;
        if (n) { const cnrs = opt.get(); await setNames(e.target.checked ? P.uniq([...cnrs, n]) : cnrs.filter((v) => v !== n), null, `[data-cp-person="${CSS.escape(n)}"]`); return true; }
        if (e.target.id === 'cpName') { await add(e.target.value); return true; }
        return false;
      },
      async onKey(e) {
        if (e.target.id === 'cpName' && e.key === 'Enter') { e.preventDefault(); await add(e.target.value); return true; }
        if (e.target.id === 'cpFavName' && e.key === 'Enter') { e.preventDefault(); await favOk(); return true; }
        return false;
      },
    };
    async function add(name) {
      const n = String(name || '').trim();
      const cnrs = opt.get();
      if (!n || cnrs.includes(n)) return;
      await setNames([...cnrs, n], null, '#cpName');
    }
  }

  D.cnrsPicker = { create };
})();
