// 결재선 즐겨찾기(교사 요청 2026-11-11): 자주 쓰는 결재선에 이름을 붙여 두고 칩 하나로 넣는다.
// 저장: chrome.storage.local 'draftLineFavs'(교직원 직위·이름, 이 PC만, '저장된 자료'에서 지움). 결재·상신은 하지 않는다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const KEY = 'draftLineFavs';
  const MAX = 20;
  const newId = () => `l${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
  const clean = (line) => (line || []).filter((p) => p && p.name).map((p) => ({ role: p.role || '검토', position: p.position || '', name: p.name }));

  // 순수 함수(단위 시험): 같은 이름이면 바꿔 저장, 개수 제한, 빈 결재선은 안 됨
  function save(list, name, line, id = newId()) {
    const n = String(name || '').trim().slice(0, 20);
    const l = clean(line);
    if (!n) return { error: '이름을 적어 주세요.' };
    if (!l.length) return { error: '결재선이 비어 있어요. 사람을 먼저 더해 주세요.' };
    const at = list.findIndex((f) => f.name === n);
    if (at >= 0) { const next = [...list]; next[at] = { ...list[at], line: l }; return { list: next, replaced: true }; }
    if (list.length >= MAX) return { error: `결재선 즐겨찾기는 ${MAX}개까지예요. 안 쓰는 것을 지워 주세요.` };
    return { list: [...list, { id, name: n, line: l }] };
  }
  // 목록(이 PC에 읽어 둔 선생님 이름)에 없는 사람: 전보 등. 목록이 없으면 검사하지 않음
  function missing(line, people) {
    const have = new Set((people || []).map((x) => String(x).trim()));
    if (!have.size) return [];
    return clean(line).filter((p) => !have.has(p.name) && ![...have].some((h) => h.startsWith(`${p.name}(`) || h.endsWith(` ${p.name}`))).map((p) => p.name);
  }
  // 같은 결재선인지(칩을 '지금 쓰는 것'으로 표시)
  const same = (a, b) => JSON.stringify(clean(a)) === JSON.stringify(clean(b));

  async function load() { try { const v = (await chrome.storage.local.get(KEY))[KEY]; return Array.isArray(v) ? v : []; } catch { return []; } }
  async function store(list) { if (list.length) await chrome.storage.local.set({ [KEY]: list }); else await chrome.storage.local.remove(KEY); }

  D.lineFavs = { KEY, MAX, save, missing, same, clean, load, store };
})();
