// 출석부 웹앱 만들기: 나이스에서 읽은 명단(번호·이름)을 웹앱 링크 뒤쪽(#)에 줄여 담는다.
// '#' 뒤는 브라우저가 서버로 보내지 않으므로 명단은 웹앱 주소(깃허브)로 가지 않고 폰 안에서만 풀린다.
// 링크가 길면 QR이 빽빽해져 폰 카메라가 못 읽으므로 반 단위로 나눠 여러 링크로 만든다.
(() => {
  const D = globalThis.Doumi;
  const WEBAPP = 'https://zkxmdydy106-ai.github.io/chulseokbu/';
  const MAX = 1100; // 링크 뒤쪽 글자 수 한도(QR이 폰 카메라로 읽히는 크기)

  // 줄 글: v1 / @반|과목 / 번호 이름 …
  const textOf = (classes) => ['v1', ...classes.flatMap((c) => [`@${c.name}|${c.subject || ''}`, ...c.students.map((s) => `${s.no} ${s.name}`)])].join('\n');

  async function pack(text) {
    const s = new Blob([new TextEncoder().encode(text)]).stream().pipeThrough(new CompressionStream('deflate-raw'));
    const u8 = new Uint8Array(await new Response(s).arrayBuffer());
    let bin = '';
    for (const b of u8) bin += String.fromCharCode(b);
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  D.rosterLink = {
    WEBAPP,
    textOf,
    pack,
    // → [{ url, names: ['1-3 수학', …] }]
    // kind: 'subjects'면 수업 출석부(?app=class — 담임 출석부와 따로 저장·따로 홈 화면 아이콘), 아니면 담임 출석부
    async links(classes, kind = 'homeroom') {
      const out = [];
      let cur = [];
      const base = kind === 'subjects' ? `${WEBAPP}?app=class` : WEBAPP;
      const flush = async () => { if (cur.length) out.push({ url: `${base}#cb=${await pack(textOf(cur))}`, names: cur.map((c) => `${c.name}${c.subject ? ` ${c.subject}` : ''}`) }); cur = []; };
      for (const c of classes) {
        if (cur.length && (await pack(textOf([...cur, c]))).length > MAX) await flush();
        cur.push(c);
      }
      await flush();
      this.last = out; // 시험용
      return out;
    },
    // 학생 서류 받는 곳 주소를 링크 뒤쪽에 같이 담는다(#cb=…&sf=…) → 폰 웹앱 [서류함]이 저절로 연결됨. 주소에 학생 정보 없음
    // store: 출석부 자동 저장(2026-10-29) — '배포ID.열쇠'로 짧게(&sy=…). 열쇠가 들어 있으니 선생님 폰 카메라로만
    // fk: 로그인 없는 교사 연결 { d, t, derived }(2026-11-09) — 저장소 열쇠에서 만든 열쇠면 QR을 짧게 하려고 뺀다. account: 폰에 따로 저장하지 않게 함께
    withForms(links, formsUrl, store = null, fk = null, account = '') {
      const pack = { u: formsUrl, ...(fk?.d ? { d: fk.d } : {}), ...(fk?.t && !(fk.derived && store) ? { t: fk.t } : {}), ...(/@/.test(account) ? { a: account } : {}) };
      const sf = formsUrl ? `&sf=${btoa(unescape(encodeURIComponent(JSON.stringify(pack)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')}` : '';
      const sy = store ? D.rosterLink.syOf(store) : '';
      if (!sf && !sy) return links;
      return links.map((l) => ({ ...l, url: `${l.url}${sf}${sy ? `&sy=${sy}` : ''}` }));
    },
    syOf(store) {
      const m = /^https:\/\/script\.google\.com\/macros\/s\/([\w-]{20,})\/exec$/.exec(String(store?.u || ''));
      return m && /^[0-9a-f]{64}$/.test(String(store.t)) ? `${m[1]}.${store.t}` : '';
    },
    // PC에서 받은 서류함 열기(교사 요청 2026-11-02 — 인쇄는 PC에서): 받는 곳 주소만 담은 링크(#sf=)로 출석부 웹앱 [서류함]을 연다.
    // 명단·출결은 이 PC로 오지 않고, 서류는 선생님 구글 계정으로만 열린다. a: 패널에 정한 구글 계정(여러 계정이 로그인된 PC에서 그 계정으로)
    boxLink(u, account = '', fk = null) {
      const json = JSON.stringify({ u, ...(account ? { a: account } : {}), ...(fk?.d && fk?.t ? { d: fk.d, t: fk.t } : {}) });
      return `${WEBAPP}#sf=${btoa(unescape(encodeURIComponent(json))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')}`;
    },
    // 폰 출석부 저장소에 든 받는 곳 주소를 먼저(학생들이 쓰는 그 주소), 없으면 이 PC가 기억한 주소. 모르면 ''
    async boxUrl() {
      let u = '';
      if (D.phoneSync?.conf()) {
        const snap = await D.phoneSync.read();
        u = snap.ok ? String(snap.slots.h?.S?.cfg?.sf?.u || '') : '';
      }
      if (!FORMS_RE.test(u)) u = D.formsMaker.known;
      const fk = u === D.formsMaker.known ? D.formsMaker.fk : null;
      return FORMS_RE.test(u) ? D.rosterLink.boxLink(u, D.formsMaker.account || D.formsMaker.knownAccount || '', fk) : '';
    },
    openTab: (url) => chrome.tabs.create({ url }),
    // QR 그림(data URL). 칸 크기는 큰 쪽 한도에 맞춘다.
    qr(url, max = 240) {
      const q = globalThis.qrcode(0, 'L');
      q.addData(url);
      q.make();
      const n = q.getModuleCount();
      const cell = Math.max(2, Math.floor(max / (n + 8)));
      return { src: q.createDataURL(cell, cell * 4), size: (n + 8) * cell };
    },
  };

  // ── 학생 서류 받는 곳 자동 만들기(교사 결정 2026-10-28): 공용 '만들기 다리'(gas/forms-maker, 선생님 본인 계정으로 실행)를
  // 작은 창으로 열면 선생님 구글 계정에 받는 곳(gas/student-forms)을 만들고(이미 있으면 그대로) 주소를 이 패널로 보낸다.
  // 받은 주소(학생 정보 없음)만 이 PC 설정(storage.local)에 둔다. 만들기 다리 주소는 배포 뒤 채운다(비어 있으면 건너뜀).
  const MAKER_URL = 'https://script.google.com/macros/s/AKfycbwirnDn9IGP4Ebaew2HZ2RTQsKFklc_CGVc1IiTXcUt3gcWxoAn4AF2NjhVFeTI1xR0/exec'; // gas/forms-maker 배포(2026-10-28)
  const GOOGLE = /^https:\/\/([a-z0-9-]+-script\.googleusercontent\.com|script\.google\.com)$/;
  const FORMS_RE = /^https:\/\/script\.google\.com\/(macros|a\/macros\/[\w.-]+)\/s\/[\w-]{20,}\/exec$/;
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // 학교 업무에 쓰면 안 되는 개인 메일 주소(만들기 다리와 같은 목록)
  const PERSONAL = /@(gmail\.com|googlemail\.com|naver\.com|daum\.net|hanmail\.net|kakao\.com|nate\.com|icloud\.com|me\.com|outlook\.com|hotmail\.com|live\.com|yahoo\.com|yahoo\.co\.kr)$/i;
  const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // 구글 창 앞에 뜨는 작은 칸(교사 결정 2026-11-09 '계정 한 번'): 주소를 묻고, 창을 연 뒤에는 되풀이될 때 쓸 번호를 보여 준다
  function box(html) {
    let d = document.getElementById('dmAcc');
    if (!d) { d = document.createElement('dialog'); d.id = 'dmAcc'; d.className = 'dm-acc'; document.body.append(d); }
    d.innerHTML = html;
    if (!d.open) d.showModal();
    return d;
  }
  const boxClose = () => { const d = document.getElementById('dmAcc'); if (d?.open) d.close(); };

  D.formsMaker = {
    url: () => D.formsMaker.override || MAKER_URL,
    known: '', // 이미 만든 받는 곳 주소(패널을 열 때 설정에서 읽어 둠 — 버튼 누른 순간 바로 판단하려고)
    store: null, // 출석부 자동 저장 { u, t }(2026-10-29)
    // 버튼을 누른 순간(사용자 동작 안)에 동기로 불러야 팝업이 막히지 않는다. 필요한 것이 이미 있으면 창을 열지 않는다
    // want: 'both'(우리 반: 받는 곳 + 저장소) · 'store'(내 수업 반: 저장소만)
    start({ update = false, want = 'both' } = {}) {
      const M = D.formsMaker;
      // 받는 곳이 있어도 로그인 없는 교사 연결(fk)이 없으면 한 번 열어 새 판으로
      const haveForms = want === 'store' || (!!M.known && !!M.fk?.d);
      if (haveForms && M.store && !update) return Promise.resolve({ ok: true, url: want === 'store' ? '' : M.known, store: M.store, fk: want === 'store' ? null : M.fk, email: M.knownAccount || '', cached: true });
      return M.open({ update, want });
    },
    // 학교 계정 주소를 한 번 묻는다. [연결]을 누른 순간 창을 연다(팝업이 막히지 않게)
    askAccount(args) {
      return new Promise((done) => {
        const d = box(`<h3>학교 구글 계정</h3>
          <p>출석부 저장소와 학생 서류 받는 곳을 만들 <b>학교 계정 주소</b>를 한 번만 적어 주세요. 크롬에 다른 계정이 로그인돼 있어도 이 계정으로 이어져요. 로그인 전이면 구글 로그인 창이 먼저 떠요.</p>
          <input type="email" id="dmAccInput" placeholder="예: teacher@school.cnehs.kr" autocomplete="email" aria-label="학교 구글 계정 주소">
          <p class="hint" id="dmAccMsg"></p>
          <div class="dm-acc-act"><button class="btn-main small" id="dmAccGo">연결</button><button class="btn-line small" id="dmAccNo">닫기</button></div>`);
        const input = d.querySelector('#dmAccInput');
        const msg = d.querySelector('#dmAccMsg');
        let warned = '';
        const go = async () => {
          const v = String(input.value || '').trim().toLowerCase();
          if (!EMAIL.test(v)) { msg.className = 'err'; msg.textContent = '계정 주소 모양이 달라요.'; return; }
          if (PERSONAL.test(v) && warned !== v) { warned = v; msg.className = 'warn'; msg.textContent = '학교 계정이 아닌 것 같아요. 학생 자료는 학교 계정에 두어야 해요. 그래도 쓰려면 [연결]을 한 번 더 눌러 주세요.'; return; }
          D.formsMaker.account = v;
          D.store.saveSettings({ googleAccount: v }); // 기다리지 않는다: 창은 이 누름 안에서 연다
          done(D.formsMaker.open(args));
        };
        d.querySelector('#dmAccGo').addEventListener('click', go);
        d.querySelector('#dmAccNo').addEventListener('click', () => { boxClose(); done({ ok: false, msg: '학교 계정 주소를 적으면 연결할 수 있어요.' }); });
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
        input.focus();
      });
    },
    // 폰을 잃어버렸을 때(교사 결정 2026-11-09): 옛 열쇠를 아는 패널만 바꾼다. 저장소 자료는 옛 열쇠로 풀어 새 열쇠로 다시 잠근다. 받는 곳 서류는 그대로
    async rekey() {
      const M = D.formsMaker;
      const old = M.store;
      if (!old?.t) return { ok: false, msg: '아직 연결된 출석부가 없어요.' };
      const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`rekey|${old.t}`));
      const proof = [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, '0')).join('');
      const r = await M.open({ want: M.known ? 'both' : 'store', extra: { rekey: '1', proof } });
      if (!r?.ok || !r.store) return r || { ok: false, msg: '연결 열쇠를 바꾸지 못했어요.' };
      await D.phoneSync.reseal(old.t, r.store);
      return { ok: true, store: r.store };
    },
    open({ update = false, want = 'forms', extra = {} } = {}) {
      const base = D.formsMaker.url();
      if (!base) return null;
      if (!D.formsMaker.account) return D.formsMaker.askAccount({ update, want, extra });
      // 패널 설정의 구글 계정으로(여러 계정이 로그인된 브라우저에서 엉뚱한 계정으로 만들지 않게, 2026-10-28).
      // 구글 '계정 고르기' 화면은 Apps Script에 안 먹혀서(2026-10-29) authuser만 붙이고, 그 창 안에서 계정 번호로 바꾼다
      const acc = D.formsMaker.account || '';
      const params = { origin: location.origin, ...(update ? { update: '1' } : {}), ...(want !== 'forms' ? { w: want } : {}), ...extra };
      const target = `${base}?${new URLSearchParams({ ...params, authuser: acc })}`;
      // 주소로 고른 계정: 구글 계정 선택을 거쳐(로그인 전이면 로그인) 그 계정으로 연다
      const first = EMAIL.test(acc) ? `https://accounts.google.com/AccountChooser?${new URLSearchParams({ Email: acc, continue: target })}` : target;
      const win = window.open(first, 'doumi-forms-maker', 'width=460,height=600');
      if (!win) { boxClose(); return Promise.resolve({ ok: false, msg: '팝업이 막혔어요. 주소창의 팝업 허용을 누른 뒤 다시 해 주세요.' }); }
      const d = box(`<h3>구글 창을 봐 주세요</h3>
        <p>${esc(acc)} 계정으로 로그인하고 [허용]을 눌러 주세요. '확인되지 않은 앱'이 보이면 [고급] → [이동] → [허용]이에요.</p>
        <p class="hint">같은 허락 화면이 계속 되풀이되면 크롬에 로그인한 순서로 열어 보세요.</p>
        <div class="dm-acc-act">${[0, 1, 2, 3].map((n) => `<button class="btn-line small" data-acc-n="${n}">${n + 1}번째 계정</button>`).join('')}</div>
        <div class="dm-acc-act"><button class="btn-text" id="dmAccOther">다른 계정 주소 적기</button><button class="btn-text" id="dmAccHide">이 칸 닫기</button></div>`);
      d.querySelectorAll('[data-acc-n]').forEach((b) => b.addEventListener('click', () => window.open(`${base}?${new URLSearchParams({ ...params, authuser: b.dataset.accN })}`, 'doumi-forms-maker', 'width=460,height=600')));
      d.querySelector('#dmAccHide').addEventListener('click', boxClose);
      d.querySelector('#dmAccOther').addEventListener('click', () => { boxClose(); D.formsMaker.account = ''; D.store.saveSettings({ googleAccount: '' }); });
      return new Promise((ok) => {
        // 계정 확인·바꾸기·권한 허락까지 교사가 누르는 시간을 넉넉히(5분)
        const t = setTimeout(() => { removeEventListener('message', on); boxClose(); ok({ ok: false, msg: '구글 창이 대답하지 않아요(구글 로그인·권한 허락을 확인해 주세요).' }); }, 300000);
        function on(e) {
          if (!GOOGLE.test(e.origin) || !e.data || e.data.type !== 'sf-made') return;
          const r = e.data.res || {};
          if (!r.ok && r.err !== 'api-off') { clearTimeout(t); removeEventListener('message', on); boxClose(); ok(r); return; }
          if (!r.ok) return; // Apps Script API 켜고 [켜고 다시]를 기다림
          clearTimeout(t); removeEventListener('message', on);
          boxClose();
          if (r.url && !FORMS_RE.test(String(r.url))) { ok({ ok: false, msg: '받는 곳 주소 모양이 달라요.' }); return; }
          const store = r.store && D.rosterLink.syOf(r.store) ? { u: r.store.u, t: r.store.t } : null;
          const patch = { formsAccount: r.email || '' };
          if (r.url) { D.formsMaker.known = r.url; patch.formsUrl = r.url; }
          if (r.fk?.d && /^[0-9a-f]{32,}$/.test(String(r.fk.t))) { D.formsMaker.fk = { d: r.fk.d, t: r.fk.t, derived: !!r.fk.derived }; patch.formsKey = D.formsMaker.fk; }
          // 실제로 만든 계정을 기억한다(다음부터 묻지 않음)
          if (r.email && !EMAIL.test(D.formsMaker.account || '')) { D.formsMaker.account = String(r.email).toLowerCase(); patch.googleAccount = D.formsMaker.account; }
          if (store) { D.formsMaker.store = store; patch.syncStore = store; }
          D.formsMaker.knownAccount = r.email || '';
          D.store.saveSettings(patch).then(() => ok({ ...r, ok: true, store }));
        }
        addEventListener('message', on);
      });
    },
  };
  if (D.store) D.store.settings().then((s) => { D.formsMaker.known = s.formsUrl || ''; D.formsMaker.store = s.syncStore || null; D.formsMaker.knownAccount = s.formsAccount || ''; D.formsMaker.account = s.googleAccount || ''; D.formsMaker.fk = s.formsKey || null; }).catch(() => {});
})();
