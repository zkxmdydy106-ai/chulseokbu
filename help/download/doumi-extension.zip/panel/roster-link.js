// 출석부 웹앱 만들기: 나이스에서 읽은 명단(번호·이름)을 웹앱 링크 뒤쪽(#)에 줄여 담는다.
// '#' 뒤는 브라우저가 서버로 보내지 않으므로 명단은 웹앱 주소(깃허브)로 가지 않고 폰 안에서만 풀린다.
// 링크가 길면 QR이 빽빽해져 폰 카메라가 못 읽으므로 반 단위로 나눠 여러 링크로 만든다.
(() => {
  const D = globalThis.Doumi;
  const WEBAPP = 'https://zkxmdydy106-ai.github.io/chulseokbu/';
  const MAX = 1100; // 링크 뒤쪽 글자 수 한도(QR이 폰 카메라로 읽히는 크기)

  // 줄 글: v1 / @반|과목 / 번호 이름 …
  const textOf = (classes) => ['v1', ...classes.flatMap((c) => [`@${c.name}|${c.subject || ''}`, ...c.students.map((s) => `${s.no} ${s.name}`)])].join('\n');

  async function pack(text) {
    const s = new Blob([new TextEncoder().encode(text)]).stream().pipeThrough(new CompressionStream('deflate-raw'));
    const u8 = new Uint8Array(await new Response(s).arrayBuffer());
    let bin = '';
    for (const b of u8) bin += String.fromCharCode(b);
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  D.rosterLink = {
    WEBAPP,
    textOf,
    pack,
    // → [{ url, names: ['1-3 수학', …] }]
    // kind: 'subjects'면 수업 출석부(?app=class — 담임 출석부와 따로 저장·따로 홈 화면 아이콘), 아니면 담임 출석부
    async links(classes, kind = 'homeroom') {
      const out = [];
      let cur = [];
      const base = kind === 'subjects' ? `${WEBAPP}?app=class` : WEBAPP;
      const flush = async () => { if (cur.length) out.push({ url: `${base}#cb=${await pack(textOf(cur))}`, names: cur.map((c) => `${c.name}${c.subject ? ` ${c.subject}` : ''}`) }); cur = []; };
      for (const c of classes) {
        if (cur.length && (await pack(textOf([...cur, c]))).length > MAX) await flush();
        cur.push(c);
      }
      await flush();
      this.last = out; // 시험용
      return out;
    },
    // 학생 서류 받는 곳 주소를 링크 뒤쪽에 같이 담는다(#cb=…&sf=…) → 폰 웹앱 [서류함]이 저절로 연결됨. 주소에 학생 정보 없음
    // store: 출석부 자동 저장(2026-10-29) — '배포ID.열쇠'로 짧게(&sy=…). 열쇠가 들어 있으니 선생님 폰 카메라로만
    withForms(links, formsUrl, store = null) {
      const sf = formsUrl ? `&sf=${btoa(unescape(encodeURIComponent(JSON.stringify({ u: formsUrl })))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')}` : '';
      const sy = store ? D.rosterLink.syOf(store) : '';
      if (!sf && !sy) return links;
      return links.map((l) => ({ ...l, url: `${l.url}${sf}${sy ? `&sy=${sy}` : ''}` }));
    },
    syOf(store) {
      const m = /^https:\/\/script\.google\.com\/macros\/s\/([\w-]{20,})\/exec$/.exec(String(store?.u || ''));
      return m && /^[0-9a-f]{64}$/.test(String(store.t)) ? `${m[1]}.${store.t}` : '';
    },
    // QR 그림(data URL). 칸 크기는 큰 쪽 한도에 맞춘다.
    qr(url, max = 240) {
      const q = globalThis.qrcode(0, 'L');
      q.addData(url);
      q.make();
      const n = q.getModuleCount();
      const cell = Math.max(2, Math.floor(max / (n + 8)));
      return { src: q.createDataURL(cell, cell * 4), size: (n + 8) * cell };
    },
  };

  // ── 학생 서류 받는 곳 자동 만들기(교사 결정 2026-10-28): 공용 '만들기 다리'(gas/forms-maker, 선생님 본인 계정으로 실행)를
  // 작은 창으로 열면 선생님 구글 계정에 받는 곳(gas/student-forms)을 만들고(이미 있으면 그대로) 주소를 이 패널로 보낸다.
  // 받은 주소(학생 정보 없음)만 이 PC 설정(storage.local)에 둔다. 만들기 다리 주소는 배포 뒤 채운다(비어 있으면 건너뜀).
  const MAKER_URL = 'https://script.google.com/macros/s/AKfycbwirnDn9IGP4Ebaew2HZ2RTQsKFklc_CGVc1IiTXcUt3gcWxoAn4AF2NjhVFeTI1xR0/exec'; // gas/forms-maker 배포(2026-10-28)
  const GOOGLE = /^https:\/\/([a-z0-9-]+-script\.googleusercontent\.com|script\.google\.com)$/;
  const FORMS_RE = /^https:\/\/script\.google\.com\/(macros|a\/macros\/[\w.-]+)\/s\/[\w-]{20,}\/exec$/;
  D.formsMaker = {
    url: () => D.formsMaker.override || MAKER_URL,
    known: '', // 이미 만든 받는 곳 주소(패널을 열 때 설정에서 읽어 둠 — 버튼 누른 순간 바로 판단하려고)
    store: null, // 출석부 자동 저장 { u, t }(2026-10-29)
    // 버튼을 누른 순간(사용자 동작 안)에 동기로 불러야 팝업이 막히지 않는다. 필요한 것이 이미 있으면 창을 열지 않는다
    // want: 'both'(우리 반: 받는 곳 + 저장소) · 'store'(내 수업 반: 저장소만)
    start({ update = false, want = 'both' } = {}) {
      const M = D.formsMaker;
      const haveForms = want === 'store' || !!M.known;
      if (haveForms && M.store && !update) return Promise.resolve({ ok: true, url: want === 'store' ? '' : M.known, store: M.store, email: M.knownAccount || '', cached: true });
      return M.open({ update, want });
    },
    open({ update = false, want = 'forms' } = {}) {
      const base = D.formsMaker.url();
      if (!base) return null;
      // 패널 설정의 구글 계정으로(여러 계정이 로그인된 브라우저에서 엉뚱한 계정으로 만들지 않게, 2026-10-28).
      // 구글 '계정 고르기' 화면은 Apps Script에 안 먹혀서(2026-10-29) authuser만 붙이고, 그 창 안에서 계정 번호로 바꾼다
      const acc = D.formsMaker.account || '';
      const q = new URLSearchParams({ origin: location.origin, ...(update ? { update: '1' } : {}), ...(want !== 'forms' ? { w: want } : {}), ...(acc ? { authuser: acc } : {}) });
      const win = window.open(`${base}?${q}`, 'doumi-forms-maker', 'width=460,height=600');
      if (!win) return Promise.resolve({ ok: false, msg: '팝업이 막혔어요. 주소창의 팝업 허용을 누른 뒤 다시 해 주세요.' });
      return new Promise((ok) => {
        // 계정 확인·바꾸기·권한 허락까지 교사가 누르는 시간을 넉넉히(5분)
        const t = setTimeout(() => { removeEventListener('message', on); ok({ ok: false, msg: '받는 곳 만들기 창이 대답하지 않아요(구글 로그인·권한 허락·[이 계정에 만들기]를 확인해 주세요).' }); }, 300000);
        function on(e) {
          if (!GOOGLE.test(e.origin) || !e.data || e.data.type !== 'sf-made') return;
          const r = e.data.res || {};
          if (!r.ok && r.err !== 'api-off') { clearTimeout(t); removeEventListener('message', on); ok(r); return; }
          if (!r.ok) return; // Apps Script API 켜고 [켜고 다시]를 기다림
          clearTimeout(t); removeEventListener('message', on);
          if (r.url && !FORMS_RE.test(String(r.url))) { ok({ ok: false, msg: '받는 곳 주소 모양이 달라요.' }); return; }
          const store = r.store && D.rosterLink.syOf(r.store) ? { u: r.store.u, t: r.store.t } : null;
          const patch = { formsAccount: r.email || '' };
          if (r.url) { D.formsMaker.known = r.url; patch.formsUrl = r.url; }
          if (store) { D.formsMaker.store = store; patch.syncStore = store; }
          D.formsMaker.knownAccount = r.email || '';
          D.store.saveSettings(patch).then(() => ok({ ...r, ok: true, store }));
        }
        addEventListener('message', on);
      });
    },
  };
  if (D.store) D.store.settings().then((s) => { D.formsMaker.known = s.formsUrl || ''; D.formsMaker.store = s.syncStore || null; D.formsMaker.knownAccount = s.formsAccount || ''; D.formsMaker.account = s.googleAccount || ''; }).catch(() => {});
})();
