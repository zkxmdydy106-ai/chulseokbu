// 저장 위치 구분 (개인정보 처리 원칙 4)
// - 작업 중 자료(학생 이름·사유가 든 입력 자료): chrome.storage.session → 브라우저를 닫으면 사라짐
// - 설정(시험 단계 통과 여부, 개발자 모드)·입력 기록(화면·건수·시각만): chrome.storage.local → 학생 자료 없음
// - storage.sync는 쓰지 않는다.
(() => {
  const D = globalThis.Doumi;
  const SETTINGS = 'settings';

  D.store = {
    async getWork(name) {
      const k = `work.${name}`;
      return (await chrome.storage.session.get(k))[k] || null;
    },
    async setWork(name, value) {
      await chrome.storage.session.set({ [`work.${name}`]: { ...value, savedAt: Date.now() } });
    },
    async clearWork(name) {
      await chrome.storage.session.remove(`work.${name}`);
    },

    async settings() {
      const s = (await chrome.storage.local.get(SETTINGS))[SETTINGS] || {};
      return { verified: {}, devMode: false, ...s };
    },
    async saveSettings(patch) {
      const s = await this.settings();
      await chrome.storage.local.set({ [SETTINGS]: { ...s, ...patch } });
    },

    // 입력 기록: 언제 어느 화면에 넣었는지만(건수·학생 이름·값·나이스 안내 문구는 남기지 않음). 최근 30번
    async log() {
      return (await chrome.storage.local.get('log')).log || [];
    },
    async addLog({ screenId, ok }) {
      const list = await this.log();
      list.unshift({ screenId, ok: !!ok, at: Date.now() });
      await chrome.storage.local.set({ log: list.slice(0, 30) });
    },

    // '저장된 자료 보기'용: 값 그대로가 아니라 무엇이 얼마나 있는지만
    async overview() {
      const session = await chrome.storage.session.get(null);
      const local = await chrome.storage.local.get(null);
      return { session, local };
    },
    async clearAll() {
      await chrome.storage.session.clear();
      await chrome.storage.local.clear();
    },
  };
})();
