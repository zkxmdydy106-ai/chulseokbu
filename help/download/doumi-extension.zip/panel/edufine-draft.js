// 기안 서식 열기: 공용서식 목록(업무관리 → 문서관리 → 기안 → 공용서식)을 읽고, 고른 서식의 제목 링크(fncFormDraft)를 눌러 기안 창을 연다.
// 기안 창은 WXSClient 프로그램이라 뜨는지는 PC 도우미로 본다. 누르는 것은 서식 이름 링크뿐(저장·상신 없음).
(() => {
  const D = globalThis.Doumi;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const OPEN_WAIT = 15000;
  const CFG = () => D.edufineScreens.forms;

  // ── 페이지 안 ──
  function pageForms(c) {
    const out = [];
    for (const e of document.querySelectorAll('[onclick], a[href^="javascript"]')) {
      const src = e.getAttribute('onclick') || e.getAttribute('href') || '';
      const m = new RegExp(`${c.openFn}\\s*\\(\\s*['"]([^'"]*)['"]\\s*,\\s*['"]([^'"]*)['"]\\s*,\\s*['"]([^'"]*)['"]`).exec(src);
      if (!m || out.some((x) => x.formId === m[1])) continue;
      out.push({ formId: m[1], cat: m[2], name: m[3] || String(e.innerText || '').trim() });
    }
    return out;
  }
  function pageFormClick(c, formId) {
    for (const e of document.querySelectorAll('[onclick], a[href^="javascript"]')) {
      const src = e.getAttribute('onclick') || e.getAttribute('href') || '';
      if (src.includes(c.openFn) && src.includes(formId)) { e.click(); return true; }
    }
    return false;
  }

  const run = async (target, func, args = []) => (await chrome.scripting.executeScript({ target, world: 'MAIN', func, args }))[0]?.result;

  async function formsFrame() {
    const f = await D.edufineInbox.openFrame(CFG());
    if (!f.ok) return f;
    return f;
  }

  D.edufineDraft = {
    async listForms() {
      const f = await formsFrame();
      if (!f.ok) return f;
      const forms = await run(f.target, pageForms, [CFG()]);
      return { ok: true, forms: forms || [] };
    },
    async openForm(formId) {
      const f = await formsFrame();
      if (!f.ok) return f;
      let before = [];
      if (D.pcHelper) { try { const w = await D.pcHelper.windows(); before = w.ok ? w.windows.filter((x) => x.kind === 'draft') : []; } catch { before = []; } }
      if (before.length) return { ok: false, error: '이미 열린 기안 창이 있어요. 그 창에 채우려면 [기안 창에 채우기]를, 새로 열려면 그 창을 닫아 주세요.' };
      const clicked = await run(f.target, pageFormClick, [CFG(), formId]);
      if (!clicked) return { ok: false, error: '공용서식 목록에서 이 서식을 찾지 못했어요. 에듀파인에서 직접 열어 주세요.' };
      if (!D.pcHelper || !(await D.pcHelper.status()).ok) return { ok: true, opened: false };
      const end = Date.now() + OPEN_WAIT;
      while (Date.now() < end) {
        const w = await D.pcHelper.windows();
        if (w.ok && w.windows.some((x) => x.kind === 'draft')) return { ok: true, opened: true };
        await sleep(400);
      }
      return { ok: true, opened: false };
    },
  };
})();
