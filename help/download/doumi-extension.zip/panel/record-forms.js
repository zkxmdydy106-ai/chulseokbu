// 생기부 명단 양식(교사 요청 2026-10-29): 나이스에서 명단(학번·이름)을 읽어 넣은 엑셀 양식을 그 자리에서 만든다.
// - 자율·진로·행동특성: 우리 반(일일출결 명단) → 탭 하나
// - 교과 세특: 내 수업 반(과목별출결 최근 3주 정규 수업 — 출석부 '내 수업 반'과 같은 명단) → 과목마다 탭 하나
// 칸: 학번 · 이름 · 내용 · 바이트(수식 — 나이스와 같은 셈: 한글 3, 영문·숫자·띄어쓰기 1) · 최대(나이스 한도). 넘으면 그 줄이 빨개짐.
//   칸 안 줄바꿈(Alt+Enter)은 패널이 띄어쓰기로 바꿔 넣으므로 1바이트로 센다.
// 학번·이름은 선생님 PC에 내려받는 이 파일에만 들어간다(어디로도 보내지 않음). 빈 양식은 따로(학생 정보 없음).
(() => {
  const D = globalThis.Doumi;
  const p2 = (n) => String(+n || 0).padStart(2, '0');
  const TEXT_HEAD = {
    'neis.record.jayul': '자율활동', 'neis.record.jinro': '진로활동',
    'neis.record.haengteuk': '행동특성 및 종합의견', 'neis.record.setuk': '세부능력 및 특기사항',
    'neis.record.personal': '개인별 세부능력 및 특기사항', 'neis.record.reading': '도서명',
  };
  // 바이트 = 글자마다 1 + (코드 128 이상 +1) + (2048 이상 +1) → 한글 3·영문·숫자·띄어쓰기·줄바꿈 1 (패널이 실제로 넣는 글의 D.neisBytes와 같음)
  const each = (ref) => `MID(${ref},ROW(INDIRECT("1:"&LEN(${ref}))),1)`;
  // 파일 안 수식에서 UNICODE는 엑셀 2013에 생긴 함수라 '_xlfn.'을 붙여야 엑셀이 알아봄(없으면 #NAME? — 실제 엑셀 확인 2026-10-29)
  const bytesFormula = (ref) => `IF(LEN(${ref})=0,0,SUMPRODUCT(1+(_xlfn.UNICODE(${each(ref)})>=128)+(_xlfn.UNICODE(${each(ref)})>=2048)))`;

  function dataSheet(name, students, textHead, max, kind = '') {
    // 독서: 책 한 권에 한 줄(도서명·저자) — 한도는 나이스가 정해 바이트 칸 없음. 학생마다 한 줄씩 넣어 두고 책이 더 있으면 줄을 더함
    if (kind === 'reading') {
      const head = ['학번', '이름', '도서명', '저자'].map((v) => ({ v, s: 'head' }));
      return { name, rows: [head, ...students.map((st) => [{ v: st.sid, s: 'center' }, { v: st.name, s: 'center' }, { v: '', s: 'text' }, { v: '', s: 'text' }])], widths: [8, 10, 50, 24], freeze: 1 };
    }
    // 진로: 희망분야 칸 — 바이트는 특기사항 + 희망분야 합(나이스 저장 검사와 같음)
    if (kind === 'jinro') {
      const head = ['학번', '이름', textHead, '희망분야', '바이트', '최대'].map((v) => ({ v, s: 'head' }));
      const rows = [head, ...students.map((st, i) => [
        { v: st.sid, s: 'center' }, { v: st.name, s: 'center' }, { v: '', s: 'text' }, { v: '', s: 'text' },
        { f: `${bytesFormula(`C${i + 2}`)}+${bytesFormula(`D${i + 2}`)}`, s: 'num' }, { v: max, s: 'num' },
      ])];
      return { name, rows, widths: [8, 10, 80, 24, 8, 8], freeze: 1, cf: [{ range: `A2:F${Math.max(2, students.length + 1)}`, formula: '$E2>$F2' }] };
    }
    const head = ['학번', '이름', textHead, '바이트', '최대'].map((v) => ({ v, s: 'head' }));
    const rows = [head, ...students.map((st, i) => [
      { v: st.sid, s: 'center' }, { v: st.name, s: 'center' }, { v: '', s: 'text' },
      { f: bytesFormula(`C${i + 2}`), s: 'num' }, { v: max, s: 'num' },
    ])];
    return { name, rows, widths: [8, 10, 90, 8, 8], freeze: 1, cf: [{ range: `A2:E${Math.max(2, students.length + 1)}`, formula: '$D2>$E2' }] };
  }
  const howSheet = (lines) => ({ name: '쓰는 법', rows: lines.map((t, i) => [{ v: t, s: i ? 'note' : 'title' }]), widths: [120] });
  const today = () => { const d = new Date(); return `${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}`; };

  // 우리 반 명단 → 학번(학년+반+번호 두 자리, 예: 3201)
  function homeroomStudents(cls) {
    const m = /(\d+)\s*-\s*(\d+)/.exec(cls.name || '');
    return cls.students.map((s) => ({ sid: m ? `${+m[1]}${+m[2]}${p2(s.no)}` : String(s.no), name: s.name }));
  }
  // 내 수업 반들 → 과목마다 [{ subject, students }](학번 순, 같은 학생 한 번)
  function bySubject(classes) {
    const map = new Map();
    for (const c of classes) {
      const key = String(c.subject || c.name || '과목').trim();
      if (!map.has(key)) map.set(key, new Map());
      for (const s of c.students) {
        const sid = String(s.sid || s.no);
        if (!map.get(key).has(sid)) map.get(key).set(sid, { sid, name: s.name });
      }
    }
    return [...map.entries()].map(([subject, m]) => ({ subject, students: [...m.values()].sort((a, b) => a.sid.localeCompare(b.sid, 'ko', { numeric: true })) }));
  }

  // task: 생기부 러너, data: roster 결과({ classes }) → { blob, fileName, sheets: [{ name, count }] }
  function build(task, data) {
    const screen = D.screens.get(task.screenId);
    const max = screen.maxBytes;
    const textHead = TEXT_HEAD[task.screenId] || '내용';
    const setuk = task.screenId === 'neis.record.setuk';
    const groups = setuk ? bySubject(data.classes).map((g) => ({ name: g.subject, students: g.students }))
      : [{ name: task.short || task.label, students: homeroomStudents(data.classes[0]) }];
    const kind = task.screenId === 'neis.record.reading' ? 'reading' : task.screenId === 'neis.record.jinro' ? 'jinro' : '';
    const sheets = groups.map((g) => dataSheet(g.name, g.students, textHead, max, kind));
    const how = howSheet([
      `${screen.title} 명단 양식 — 나이스·에듀파인 도우미`,
      `학번·이름은 나이스에서 읽은 ${setuk ? '내 수업 반(최근 3주 정규 수업) 명단을 과목마다 탭으로' : '우리 반 명단'} 넣었어요. '${textHead}' 칸${kind === 'jinro' ? '·희망분야 칸' : kind === 'reading' ? '·저자 칸' : ''}만 채우세요. 비워 둔 학생은 넣지 않아요.`,
      ...(kind === 'reading' ? ['책이 여러 권이면 그 학생 줄을 복사해 아래에 더 넣으세요(학번·이름 같게). 도우미가 "도서명(저자), 도서명(저자)" 한 칸으로 모아요. 글자 수 한도는 나이스가 정해요.']
        : [`바이트: 나이스와 같은 셈(한글 3, 영문·숫자·띄어쓰기 1)이에요${kind === 'jinro' ? '(특기사항 + 희망분야 합, 희망분야는 따로 150바이트까지)' : ''}. '최대'(${max}바이트, 한글 약 ${Math.floor(max / 3)}자)를 넘으면 그 줄이 빨개져요. 칸 안 줄바꿈(Alt+Enter)은 띄어쓰기로 바뀌어 들어가요(1바이트).`]),
      ...(setuk ? [
        '세특은 나이스 [과목별세부능력및특기사항] 화면에서 과목·반을 먼저 고르고, 이 파일을 패널에 끌어다 놓은 뒤 그 과목 탭을 고르세요.',
        '나이스가 학생마다 한도를 따로 정해 두면(예: 학기 합산) 패널 확인 표에서 그 한도로 다시 검사해요.',
      ] : []),
      '바이트 칸에 #NAME?이 보이면 엑셀이 오래돼 UNICODE 함수가 없는 것이에요. 패널 확인 표에서 바이트를 다시 검사하니 그대로 써도 돼요.',
      '이 파일에는 학생 학번·이름이 들어 있어요. 학교에서 허용한 곳에만 두고, 다 쓰면 지워 주세요.',
    ]);
    const blob = D.writeXlsx([...sheets, how]);
    const fileName = `${(kind === 'reading' ? '독서활동' : textHead).replace(/\s+/g, '')}_${setuk ? '내수업' : '우리반'}_명단양식_${today()}.xlsx`;
    return { blob, fileName, sheets: groups.map((g) => ({ name: g.name, count: g.students.length })) };
  }

  // 수행평가 성적 명단 양식(교사 요청 2026-11-02): 과목마다 탭, 학번·이름·영역 칸. data: runners perf.formData 결과
  // scoreOf: 시험·영상용으로 칸을 채울 때만(평소에는 비어 있음)
  function buildPerf(data, { scoreOf = null } = {}) {
    const sheets = data.subjects.map((s) => {
      const areas = s.areas.length ? s.areas : ['점수'];
      return {
        name: `${s.grade}학년 ${s.name}`,
        rows: [['학번', '이름', ...areas].map((v) => ({ v, s: 'head' })), ...s.students.map((st) => [{ v: st.sid, s: 'center' }, { v: st.name, s: 'center' }, ...areas.map((a) => ({ v: scoreOf ? scoreOf(st, a, s) : '', s: 'center' }))])],
        widths: [8, 10, ...areas.map(() => 24)],
        freeze: 1,
      };
    });
    const how = howSheet([
      '수행평가 성적 명단 양식 — 나이스·에듀파인 도우미',
      '학번·이름·영역은 나이스 [수행평가성적관리]에서 읽어 과목마다 탭으로 넣었어요. 영역 칸에 점수만 적으세요.',
      '결시는 점수 대신 사유를 적어요: 질병결 · 미인정결 · 인정결 · 기타결. 비워 둔 칸은 나이스 값을 건드리지 않아요.',
      '저장한 뒤 패널 [평가 → 수행평가 점수]에 끌어다 놓고 탭을 고르세요. [나이스에서 확인하기]를 누르면 그 탭의 학년·과목으로 나이스 조건을 맞춰요.',
      '이 파일에는 학생 학번·이름이 들어 있어요. 학교에서 허용한 곳에만 두고, 다 쓰면 지워 주세요.',
    ]);
    return { blob: D.writeXlsx([...sheets, how]), fileName: `수행평가성적_내수업_명단양식_${today()}.xlsx`, sheets: data.subjects.map((s) => ({ name: `${s.grade}학년 ${s.name}`, count: s.students.length })) };
  }

  D.recordForms = { build, buildPerf, bytesFormula, homeroomStudents, bySubject, TEXT_HEAD };
})();
