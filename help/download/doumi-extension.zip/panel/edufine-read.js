// 결재함 차례 진행(교사 결정 2026-11-02): [모두 읽기] 문서를 하나씩 열어 읽고 닫는다 / [결재 시작] 문서를 하나씩 열어 두고 교사가 결재하면 다음.
// 문서 창은 WXSClient 프로그램이라 PC 도우미(panel/pc-helper.js)가 본다. 동시에 창 하나만.
// 결재·전자서명은 교사가 문서 창에서 누른다. 이 파일에는 결재를 누르는 길이 없다(PC 도우미에도 없음).
(() => {
  const D = globalThis.Doumi;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let OPEN_WAIT = 60000; // 문서 창이 뜨기를 기다리는 시간. 실제 2026-11-05: 20초로는 창이 뜨기 전에 '열리지 않았어요'가 나옴(누르고 31초 뒤에 뜬 때도 있음)
  const BODY_WAIT = 15000; // 본문 누름틀이 차기를 기다리는 시간
  const CLOSE_WAIT = 20000;

  // keepOpen: 새 문서 창이 '열려있는 기안/결재기를 닫습니다'를 물으면 [취소]만 누른다([확인]은 앞 창을 강제로 끈다, 실제 2026-11-05).
  // 이 도우미가 문서를 차례로 여는 동안에만 쓴다
  async function docWindows(keepOpen = false) {
    const r = await D.pcHelper.windows(keepOpen ? { keepOpen: true } : {});
    if (!r.ok) throw new Error(D.pcHelper.explain(r));
    return (r.windows || []).filter((w) => w.kind === 'approve' || w.kind === 'view');
  }

  async function waitWindow(stop) {
    const end = Date.now() + OPEN_WAIT;
    while (Date.now() < end) {
      if (stop()) return null;
      const ws = await docWindows(true);
      if (ws.length === 1) return ws[0];
      if (ws.length > 1) throw new Error('문서 창이 여러 개 열려 있어요. 하나만 남겨 주세요.');
      await sleep(400);
    }
    return null;
  }

  // 본문이 다 뜰 때까지 다시 읽는다(창이 뜬 직후에는 누름틀이 비어 있다)
  async function waitBody(win, stop) {
    const end = Date.now() + BODY_WAIT;
    let last = null;
    while (Date.now() < end) {
      if (stop()) return last;
      last = await D.pcHelper.readDoc({ pid: win.pid, attach: true, keepOpen: true });
      if (last.ok && String(last.fields?.['본문'] || '').trim()) return last;
      await sleep(500);
    }
    return last;
  }

  async function waitClosed() {
    const end = Date.now() + CLOSE_WAIT;
    while (Date.now() < end) {
      if (!(await docWindows()).length) return true;
      await sleep(300);
    }
    return false;
  }

  D.edufineRead = {
    /**
     * 문서를 하나씩 읽는다. cards: 결재함 카드, on: { step(i, card), doc(card, 결과) }, stop(): 멈춤 눌렀는지
     * → { ok, read, skipped, stopped } 또는 { ok:false, error, firstBlocked }
     * 결과: { summary } 또는 { error }
     */
    setOpenWait: (ms) => { OPEN_WAIT = ms; }, // 시험에서 줄임
    async readAll(cards, { on = {}, stop = () => false } = {}) {
      const st = await D.pcHelper.status(true);
      if (!st.ok) return { ok: false, needHelper: true, error: st.missing ? 'PC 도우미가 있어야 문서 창을 읽을 수 있어요.' : st.text };
      if (st.old) return { ok: false, needHelper: true, error: 'PC 도우미 새 판이 있어요. 설치 파일을 다시 받아 한 번 눌러 주세요.' };
      let open;
      try { open = await docWindows(); } catch (e) { return { ok: false, error: e.message }; }
      if (open.length) return { ok: false, error: '열려 있는 문서 창을 닫은 뒤 다시 눌러 주세요.' };
      let read = 0;
      let skipped = 0;
      for (const [i, c] of cards.entries()) {
        if (stop()) return { ok: true, read, skipped, stopped: true };
        on.step?.(i, c);
        let res;
        try {
          const click = await D.edufineInbox.click(c.docId);
          if (!click.ok) { skipped++; on.doc?.(c, { error: click.error }); continue; }
          const win = await waitWindow(stop);
          if (!win) {
            if (stop()) return { ok: true, read, skipped, stopped: true };
            // 첫 문서부터 안 열리면 브라우저가 프로그램 실행을 막은 것: 교사가 한 번 직접 눌러 허용하면 그 뒤로는 이어진다
            if (!read && !skipped) {
              await D.edufineInbox.mark(c.docId);
              return { ok: false, firstBlocked: true, error: "문서 창이 열리지 않았어요. 에듀파인 목록에 노랗게 표시한 제목을 한 번 직접 눌러 주세요('앱을 열까요?'가 뜨면 '항상 허용' 체크 후 [열기]). 그 창을 닫고 [모두 읽기]를 다시 누르면 이어져요." };
            }
            skipped++;
            on.doc?.(c, { error: '이 문서 창이 열리지 않았어요. 건너뛰고 다음으로 갔어요.' });
            continue;
          }
          const r = await waitBody(win, stop);
          if (r?.ok && r.fields) {
            res = { summary: D.edufineDoc.summarize(r.fields), files: r.files || null, body: String(r.fields['본문'] || '') };
            read++;
            try { await on.opened?.(c, win); } catch { /* 목록을 못 읽어도 읽기는 이어진다 */ }
          } else {
            res = { error: r ? D.pcHelper.explain(r) : '본문을 읽지 못했어요.' };
            skipped++;
          }
          const closed = await D.pcHelper.closeDoc({ pid: win.pid });
          on.doc?.(c, res);
          if (!closed.ok || !(await waitClosed())) return { ok: false, read, skipped, error: `${closed.ok ? '문서 창을 닫지 못했어요.' : D.pcHelper.explain(closed)} 창을 직접 닫은 뒤 [모두 읽기]를 다시 눌러 주세요.` };
        } catch (e) {
          skipped++;
          on.doc?.(c, { error: e?.message || '이 문서를 읽지 못했어요.' });
        }
      }
      return { ok: true, read, skipped, stopped: false };
    },

    /**
     * 결재 시작: 카드 순서대로 문서를 열어 두고 창이 닫히기를 기다린다(그사이 교사가 보고 [결재] 또는 그냥 닫기).
     * 닫히면 목록을 다시 받아 그 문서가 빠졌으면 결재한 것으로 세고 다음 문서를 연다.
     * on: { opened(card, 읽은 결과), result(card, 결재했는지) }
     */
    async approveLoop(cards, { on = {}, stop = () => false, reload } = {}) {
      const st = await D.pcHelper.status(true);
      if (!st.ok) return { ok: false, needHelper: true, error: st.missing ? 'PC 도우미가 있어야 문서를 차례로 열 수 있어요.' : st.text };
      if (st.old) return { ok: false, needHelper: true, error: 'PC 도우미 새 판이 있어요. 설치 파일을 다시 받아 한 번 눌러 주세요.' };
      if ((await docWindows()).length) return { ok: false, error: '열려 있는 문서 창을 닫은 뒤 다시 눌러 주세요.' };
      let approved = 0;
      let passed = 0;
      for (const c of cards) {
        if (stop()) return { ok: true, approved, passed, stopped: true };
        const click = await D.edufineInbox.click(c.docId);
        if (!click.ok) { on.result?.(c, { gone: true }); continue; }
        const win = await waitWindow(stop);
        if (!win) {
          if (stop()) return { ok: true, approved, passed, stopped: true };
          if (!approved && !passed) { await D.edufineInbox.mark(c.docId); return { ok: false, firstBlocked: true, error: "문서 창이 열리지 않았어요. 에듀파인 목록에 노랗게 표시한 제목을 한 번 직접 눌러 주세요('앱을 열까요?'가 뜨면 '항상 허용' 체크 후 [열기])." }; }
          on.result?.(c, { skipped: true });
          continue;
        }
        const r = await waitBody(win, stop);
        const summary = r?.ok && r.fields ? D.edufineDoc.summarize(r.fields) : null;
        await on.opened?.(c, { summary, win, files: r?.files || null });
        // 교사가 창을 닫을 때까지(결재하면 에듀파인이 창을 닫거나 다음 문서로 넘긴다)
        while ((await docWindows().catch(() => [])).length) {
          if (stop()) return { ok: true, approved, passed, stopped: true, leftOpen: true };
          await on.watching?.(c, win);
          await sleep(1200);
        }
        const now = reload ? await reload() : null;
        const gone = now ? !now.some((x) => x.docId === c.docId) : false;
        if (gone) approved++; else passed++;
        await on.result?.(c, { approved: gone });
      }
      return { ok: true, approved, passed, stopped: false };
    },
  };
})();
