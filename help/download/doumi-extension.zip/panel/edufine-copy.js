// 문서번호로 지난 기안 불러오기(교사 요청 2026-11-09): 연도·문서번호 → 문서등록대장 검색 → 그 문서를 조회 창으로 열어 PC 도우미가 읽고 닫는다.
// 읽는 것: 제목·본문(표·글자 모양은 PC 도우미 메모리에만)·결재선·과제카드·공람자. 붙임은 가져오지 않는다(교사 결정). 저장·결재·상신 없음, 외부 전송 없음.
(() => {
  const D = globalThis.Doumi;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let OPEN_WAIT = 60000; // 실제: 누르고 30초 넘게 걸릴 때가 있음(2026-11-05)

  const openWins = async () => { const w = await D.pcHelper.windows({ keepOpen: true }); return w.ok ? (w.windows || []).filter((x) => ['approve', 'view'].includes(x.kind)) : []; };

  D.edufineCopy = {
    setOpenWait(ms) { OPEN_WAIT = ms; },
    async load({ year, no, row = null, rich = true }) {
      const docNo = D.edufineDoc.copyNumber(no);
      const y = String(year || '').trim();
      if (!/^\d{4}$/.test(y)) return { ok: false, error: '연도를 네 자리로 적어 주세요(예: 2026).' };
      if (!docNo) return { ok: false, error: '문서번호를 적어 주세요(예: 1234).' };
      const st = await D.pcHelper.status(true);
      if (!st.ok) return { ok: false, error: st.missing ? 'PC 도우미가 있어야 불러올 수 있어요. 아래 [더 보기]에서 설치해 주세요.' : st.text };
      if (st.old) return { ok: false, error: 'PC 도우미 새 판이 있어요. [더 보기]의 [설치 파일 다시 받기]로 받은 파일을 한 번 눌러 주세요.' };
      const all = await D.pcHelper.windows();
      if (!all.ok) return { ok: false, error: D.pcHelper.explain(all) };
      if ((all.windows || []).length) return { ok: false, error: '열려 있는 문서 창을 닫고 다시 눌러 주세요. 새 문서를 열면 앞 창이 닫힐 수 있어요.' };
      const found = await D.edufineInbox.findByNumber({ year: y, docNo });
      if (!found.ok) return found;
      if (!found.rows.length) return { ok: false, error: `문서등록대장 ${y}년에서 ${docNo}번을 찾지 못했어요. 연도와 번호를 확인해 주세요.` };
      if (found.rows.length > 1 && row == null) return { ok: false, choose: found.rows };
      const pickRow = found.rows.length === 1 ? found.rows[0] : found.rows.find((r) => r.i === row);
      if (!pickRow) return { ok: false, error: '고른 줄을 찾지 못했어요. 다시 눌러 주세요.' };
      const opened = await D.edufineInbox.openRegistRow(found.target, pickRow.i);
      if (!opened.ok) return opened;
      let wins = [];
      const end = Date.now() + OPEN_WAIT;
      while (!wins.length && Date.now() < end) { wins = await openWins(); if (!wins.length) await sleep(500); }
      if (!wins.length) return { ok: false, error: "문서 창이 열리지 않았어요('앱을 열까요?'가 떴는지 봐 주세요)." };
      const win = wins[0];
      try {
        let doc = null;
        const readEnd = Date.now() + 15000;
        do { doc = await D.pcHelper.readDoc({ pid: win.pid }); if (doc.ok && doc.fields?.Sj != null && doc.fields?.['본문'] != null) break; await sleep(500); } while (Date.now() < readEnd);
        if (!doc?.ok || doc.fields?.['본문'] == null) return { ok: false, error: doc?.error ? D.pcHelper.explain(doc) : '문서 내용을 읽지 못했어요. 비공개 문서이거나 서식이 다를 수 있어요.' };
        const r = rich ? await D.pcHelper.readBodyRich({ pid: win.pid }) : null;
        const line = rich ? await D.pcHelper.readLine({ pid: win.pid }) : null;
        const picks = rich ? await D.pcHelper.readPicks({ pid: win.pid }) : null;
        const me = rich ? await D.edufineInbox.myName() : '';
        return { ok: true, ...D.edufineDoc.copyResult({ fields: doc.fields, rich: r, line: line?.ok ? line.line : [], picks: picks?.ok ? picks : null, me }) };
      } finally {
        // 드물게 첫 닫기가 시간 안에 끝나지 않는다(2026-11-09 실제 7건 중 1건) → 한 번 더
        const c = await D.pcHelper.closeDoc({ pid: win.pid });
        if (!c.ok && (await openWins()).length) await D.pcHelper.closeDoc({ pid: win.pid });
      }
    },
  };
})();
