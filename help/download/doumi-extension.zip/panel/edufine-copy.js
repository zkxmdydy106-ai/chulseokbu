// 지난 문서 찾아 기안에 가져오기(교사 요청 2026-11-09 문서번호, 2026-11-12 제목 낱말·기간): 문서등록대장 검색 → 그 문서를 조회 창으로 열어 PC 도우미가 읽고 닫는다.
// 읽는 것: 제목·본문(표·글자 모양은 PC 도우미 메모리에만)·결재선·과제카드·공람자. 붙임은 가져오지 않는다(교사 결정). 저장·결재·상신 없음, 외부 전송 없음.
// 찾은 목록(제목·문서번호·등록일자)은 패널 메모리에만 둔다.
(() => {
  const D = globalThis.Doumi;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let OPEN_WAIT = 60000; // 실제: 누르고 30초 넘게 걸릴 때가 있음(2026-11-05)

  const openWins = async () => { const w = await D.pcHelper.windows({ keepOpen: true }); return w.ok ? (w.windows || []).filter((x) => ['approve', 'view'].includes(x.kind)) : []; };
  const p2 = (n) => String(n).padStart(2, '0');
  const ymdOf = (d) => `${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}`;
  const sameTitle = (a, b) => String(a || '').replace(/\s+/g, '') === String(b || '').replace(/\s+/g, '');

  // 기간: 'YYYY-MM-DD' 두 칸(화면) 또는 연도 하나(예전 호출). 끝 날짜는 오늘을 넘지 않게
  function range({ year, from, to }) {
    const today = ymdOf(new Date());
    if (year != null && from == null) {
      const y = String(year || '').trim();
      if (!/^\d{4}$/.test(y)) return { error: '연도를 네 자리로 적어 주세요(예: 2026).' };
      return { from: `${y}0101`, to: `${y}1231` < today ? `${y}1231` : today };
    }
    const f = String(from || '').replace(/-/g, '');
    let t = String(to || '').replace(/-/g, '');
    if (!/^\d{8}$/.test(f) || !/^\d{8}$/.test(t)) return { error: '기간을 골라 주세요.' };
    if (t > today) t = today;
    if (f > t) return { error: '시작 날짜가 끝 날짜보다 늦어요.' };
    // 에듀파인 문서함은 한 번에 최대 1년(실제 2026-11-12: checkSearchPeriod — 31일을 한 달로 올림해 12달 넘으면 알림 창을 띄우고 검색 안 함).
    // 알림 창이 뜨면 페이지가 멈춰 패널도 기다리게 되므로 미리 막는다
    const day = (x) => Date.UTC(+x.slice(0, 4), +x.slice(4, 6) - 1, +x.slice(6));
    if (Math.ceil((day(t) - day(f)) / (31 * 86400000)) > 12) return { error: '에듀파인은 한 번에 1년까지만 찾을 수 있어요. 기간을 1년 안으로 줄여 주세요.' };
    return { from: f, to: t };
  }

  D.edufineCopy = {
    setOpenWait(ms) { OPEN_WAIT = ms; },
    // 기본 기간: 올해 1월 1일 ~ 오늘(교사 요청 2026-11-12)
    defaultRange() { const d = new Date(); return { from: `${d.getFullYear()}-01-01`, to: `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}` }; },

    // 찾기만: 문서 창을 열지 않는다. 번호 꼴이면 문서번호로, 아니면 제목 낱말로
    async find({ q, from, to }) {
      const sq = D.edufineDoc.searchQuery(q);
      if (!sq) return { ok: false, error: '찾을 낱말이나 문서번호를 적어 주세요.' };
      const rg = range({ from, to });
      if (rg.error) return { ok: false, error: rg.error };
      const r = await D.edufineInbox.search({ ...sq, ...rg });
      if (!r.ok) return r;
      return { ok: true, byNo: !!sq.docNo, docNo: sq.docNo || '', rows: r.rows.map(({ no, title, date }) => ({ no, title, date })), total: r.total == null ? r.rows.length : r.total };
    },

    // 한 문서 가져오기: 문서번호로 다시 찾아(제목이 오면 같은 제목 줄) 조회 창으로 열고 읽은 뒤 닫는다
    async load({ year, from, to, no, title = '', row = null, rich = true }) {
      const docNo = D.edufineDoc.copyNumber(no);
      const rg = range({ year, from, to });
      if (rg.error) return { ok: false, error: rg.error };
      if (!docNo) return { ok: false, error: '문서번호를 적어 주세요(예: 1234).' };
      const st = await D.pcHelper.status(true);
      if (!st.ok) return { ok: false, error: st.missing ? 'PC 도우미가 있어야 가져올 수 있어요. 아래 [더 보기]에서 설치해 주세요.' : st.text };
      if (st.old) return { ok: false, error: 'PC 도우미 새 판이 있어요. [더 보기]의 [설치 파일 다시 받기]로 받은 파일을 한 번 눌러 주세요.' };
      const all = await D.pcHelper.windows();
      if (!all.ok) return { ok: false, error: D.pcHelper.explain(all) };
      if ((all.windows || []).length) return { ok: false, error: '열려 있는 문서 창을 닫고 다시 눌러 주세요. 새 문서를 열면 앞 창이 닫힐 수 있어요.' };
      const found = await D.edufineInbox.search({ docNo, ...rg });
      if (!found.ok) return found;
      if (!found.rows.length) return { ok: false, error: `문서등록대장(${rg.from.slice(0, 4)}.${rg.from.slice(4, 6)}.${rg.from.slice(6)}~${rg.to.slice(0, 4)}.${rg.to.slice(4, 6)}.${rg.to.slice(6)})에서 ${docNo}번을 찾지 못했어요. 번호와 기간을 확인해 주세요.` };
      let rows = found.rows;
      if (title) { const same = rows.filter((r) => sameTitle(r.title, title)); if (same.length) rows = same.slice(0, 1); }
      if (rows.length > 1 && row == null) return { ok: false, choose: rows.map(({ no: n, title: t, date }) => ({ no: n || docNo, title: t, date })) };
      const pickRow = rows.length === 1 ? rows[0] : rows.find((r) => r.i === row);
      if (!pickRow) return { ok: false, error: '고른 줄을 찾지 못했어요. 다시 눌러 주세요.' };
      const opened = await D.edufineInbox.openRegistRow(found.target, pickRow.i);
      if (!opened.ok) return opened;
      let wins = [];
      const end = Date.now() + OPEN_WAIT;
      while (!wins.length && Date.now() < end) { wins = await openWins(); if (!wins.length) await sleep(500); }
      if (!wins.length) return { ok: false, error: "문서 창이 열리지 않았어요('앱을 열까요?'가 떴는지 봐 주세요)." };
      const win = wins[0];
      try {
        let doc = null;
        const readEnd = Date.now() + 15000;
        do { doc = await D.pcHelper.readDoc({ pid: win.pid }); if (doc.ok && doc.fields?.Sj != null && doc.fields?.['본문'] != null) break; await sleep(500); } while (Date.now() < readEnd);
        if (!doc?.ok || doc.fields?.['본문'] == null) return { ok: false, error: doc?.error ? D.pcHelper.explain(doc) : '문서 내용을 읽지 못했어요. 비공개 문서이거나 서식이 다를 수 있어요.' };
        const r = rich ? await D.pcHelper.readBodyRich({ pid: win.pid }) : null;
        const line = rich ? await D.pcHelper.readLine({ pid: win.pid }) : null;
        const picks = rich ? await D.pcHelper.readPicks({ pid: win.pid }) : null;
        const me = rich ? await D.edufineInbox.myName() : '';
        return { ok: true, ...D.edufineDoc.copyResult({ fields: doc.fields, rich: r, line: line?.ok ? line.line : [], picks: picks?.ok ? picks : null, me }) };
      } finally {
        // 드물게 첫 닫기가 시간 안에 끝나지 않는다(2026-11-09 실제 7건 중 1건) → 한 번 더
        const c = await D.pcHelper.closeDoc({ pid: win.pid });
        if (!c.ok && (await openWins()).length) await D.pcHelper.closeDoc({ pid: win.pid });
      }
    },
  };
})();
