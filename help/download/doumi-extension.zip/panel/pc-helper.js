// PC 도우미 연결(native messaging). 확장은 PC에 프로그램을 직접 설치할 수 없으므로(브라우저 보안)
// 이 확장 ID를 넣은 설치 파일(.cmd)을 그 자리에서 만들어 내려받게 하고, 교사가 한 번 더블클릭한다.
// - 설치 위치: %LOCALAPPDATA%\DoumiPcHelper (관리자 권한 없음, 이 사용자만), 엣지·크롬·웨일에 등록(HKCU)
// - PC 도우미는 인터넷 통신을 하지 않고, 파일에 아무것도 남기지 않는다(extension/native/doumi-host.ps1)
// - 할 수 있는 일: ping · windows(창 목록) · readDoc(문서 제목·본문 누름틀 읽기) · fillDraft(기안 창 제목·본문 채우기)
(() => {
  const D = globalThis.Doumi;
  const NAME = 'kr.doumi.pchelper';
  const VERSION = 1;
  const MARK = '###DOUMI-PS###';
  const CRLF = String.fromCharCode(13, 10);

  // .cmd 앞부분은 cmd가, 표시(MARK) 뒤는 PowerShell이 읽는다. cmd 줄은 영어만(한글은 cmd 코드페이지에서 깨짐)
  function wrapCmd(title, ps) {
    return [
      '@echo off',
      'chcp 65001 >nul',
      `title ${title}`,
      `"%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText('%~f0',[Text.Encoding]::UTF8); $i=$t.IndexOf('###DOUMI-PS'+'###'); iex $t.Substring($i)"`,
      'pause',
      'exit /b',
      MARK,
      ps,
    ].join(CRLF);
  }

  const b64 = (text) => btoa(unescape(encodeURIComponent(text)));
  const psq = (s) => String(s).replace(/'/g, "''");

  function buildInstaller(hostText, extId) {
    if (!/^[a-p]{32}$/.test(extId)) throw new Error('확장 ID가 이상해요.');
    const ps = [
      "$ErrorActionPreference = 'Stop'",
      `$name = '${NAME}'`,
      `$extId = '${psq(extId)}'`,
      "$dir = Join-Path $env:LOCALAPPDATA 'DoumiPcHelper'",
      'try {',
      '  New-Item -ItemType Directory -Force -Path $dir | Out-Null',
      `  $hostPs = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64(hostText)}'))`,
      "  [IO.File]::WriteAllText((Join-Path $dir 'doumi-host.ps1'), $hostPs, (New-Object Text.UTF8Encoding $true))",
      `  $launcher = '@"%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0doumi-host.ps1"'`,
      "  [IO.File]::WriteAllText((Join-Path $dir 'host.cmd'), $launcher, (New-Object Text.ASCIIEncoding))",
      '  $manifestPath = Join-Path $dir "$name.json"',
      '  $origins = @()',
      '  if (Test-Path $manifestPath) { try { $origins = @((Get-Content $manifestPath -Raw | ConvertFrom-Json).allowed_origins) } catch { } }',
      '  $o = "chrome-extension://$extId/"',
      '  if ($origins -notcontains $o) { $origins += $o }',
      "  $manifest = [ordered]@{ name = $name; description = 'Doumi PC helper - fills and reads K-Edufine document windows on this PC'; path = (Join-Path $dir 'host.cmd'); type = 'stdio'; allowed_origins = @($origins) }",
      '  [IO.File]::WriteAllText($manifestPath, (ConvertTo-Json -InputObject $manifest -Depth 3), (New-Object Text.UTF8Encoding $false))',
      "  foreach ($b in 'Microsoft\\Edge', 'Google\\Chrome', 'Naver\\Whale') {",
      '    $k = "HKCU:\\Software\\$b\\NativeMessagingHosts\\$name"',
      '    New-Item -Path $k -Force | Out-Null',
      "    Set-ItemProperty -Path $k -Name '(default)' -Value $manifestPath",
      '  }',
      "  Write-Host ''",
      "  Write-Host 'PC 도우미를 설치했어요. 브라우저 패널로 돌아가 [다시 확인]을 눌러 주세요.' -ForegroundColor Green",
      "  Write-Host ('설치 위치: ' + $dir)",
      '} catch {',
      "  Write-Host ('설치하지 못했어요: ' + $_.Exception.Message) -ForegroundColor Red",
      "  Write-Host '학교 PC 보안 정책이 막았을 수 있어요. 패널의 복사 기능을 써 주세요.'",
      '}',
    ].join(CRLF);
    return wrapCmd('Doumi PC helper install', ps);
  }

  function buildUninstaller() {
    const ps = [
      `$name = '${NAME}'`,
      "foreach ($b in 'Microsoft\\Edge', 'Google\\Chrome', 'Naver\\Whale') { Remove-Item -Path \"HKCU:\\Software\\$b\\NativeMessagingHosts\\$name\" -Force -ErrorAction SilentlyContinue }",
      "$dir = Join-Path $env:LOCALAPPDATA 'DoumiPcHelper'",
      'Remove-Item -Path $dir -Recurse -Force -ErrorAction SilentlyContinue',
      "if (Test-Path $dir) { Write-Host '일부 파일을 지우지 못했어요. 브라우저를 닫고 다시 실행해 주세요.' -ForegroundColor Yellow } else { Write-Host 'PC 도우미를 지웠어요.' -ForegroundColor Green }",
    ].join(CRLF);
    return wrapCmd('Doumi PC helper remove', ps);
  }

  function download(name, text) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'application/octet-stream' }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  // ── 연결: 한 번 띄운 PC 도우미를 계속 쓴다(PowerShell 시작이 느려서) ──
  let port = null;
  let seq = 0;
  const pending = new Map();
  function connect() {
    if (port) return port;
    port = chrome.runtime.connectNative(NAME);
    port.onMessage.addListener((m) => {
      const p = pending.get(m?.id);
      if (!p) return;
      pending.delete(m.id);
      clearTimeout(p.timer);
      p.resolve(m);
    });
    port.onDisconnect.addListener(() => {
      const why = chrome.runtime.lastError?.message || '연결이 끊겼어요';
      port = null;
      for (const p of pending.values()) { clearTimeout(p.timer); p.resolve({ ok: false, error: why, disconnected: true }); }
      pending.clear();
    });
    return port;
  }

  function call(op, args = {}, timeout = 25000) {
    return new Promise((resolve) => {
      if (typeof chrome.runtime?.connectNative !== 'function') { resolve({ ok: false, error: 'Specified native messaging host not found.', disconnected: true }); return; }
      let p;
      try { p = connect(); } catch (e) { resolve({ ok: false, error: String(e?.message || e), disconnected: true }); return; }
      const id = ++seq;
      const timer = setTimeout(() => { pending.delete(id); resolve({ ok: false, error: 'PC 도우미가 답하지 않아요.' }); }, timeout);
      pending.set(id, { resolve, timer });
      try { p.postMessage({ id, op, args }); } catch (e) { clearTimeout(timer); pending.delete(id); resolve({ ok: false, error: String(e?.message || e), disconnected: true }); }
    });
  }

  // 패널 문장으로 바꾸기
  function explain(r) {
    const e = String(r?.error || '');
    if (/not found|specified native messaging host/i.test(e)) return 'PC 도우미가 설치되어 있지 않아요.';
    if (/forbidden|access.*denied/i.test(e)) return 'PC 도우미가 이 확장과 연결되지 않았어요. 설치 파일을 다시 받아 실행해 주세요.';
    if (e === 'no-window:draft') return '기안 창을 찾지 못했어요. 에듀파인에서 [기안] → 서식을 골라 기안 창을 연 뒤 다시 눌러 주세요.';
    if (e === 'many-windows:draft') return '기안 창이 2개 이상 열려 있어요. 채울 창 하나만 남겨 주세요.';
    if (e === 'no-window:doc') return '열린 결재·조회 문서 창이 없어요.';
    if (e === 'many-windows:doc') return '문서 창이 여러 개 열려 있어요. 읽을 창 하나만 남겨 주세요.';
    if (/not a draft window/.test(e)) return '기안 창이 아니라서 채우지 않았어요.';
    if (/exited|exit/i.test(e)) return 'PC 도우미가 실행되지 않았어요(학교 PC 보안 정책일 수 있어요).';
    return e || '알 수 없는 문제';
  }

  let last = null;
  D.pcHelper = {
    NAME,
    VERSION,
    buildInstaller,
    buildUninstaller,
    explain,
    get last() { return last; },
    // { ok, version, old } 또는 { ok:false, missing, text }
    async status(force = false) {
      if (last && !force) return last;
      const r = await call('ping', {}, 20000);
      last = r.ok ? { ok: true, version: r.version, old: r.version < VERSION } : { ok: false, missing: /not found|specified native/i.test(r.error || ''), text: explain(r) };
      return last;
    },
    async downloadInstaller() {
      const hostText = await (await fetch(chrome.runtime.getURL('native/doumi-host.ps1'))).text();
      download('PC도우미설치.cmd', buildInstaller(hostText, chrome.runtime.id));
      last = null;
    },
    downloadUninstaller() {
      if (port) { try { port.disconnect(); } catch { /* 이미 끊김 */ } port = null; }
      download('PC도우미지우기.cmd', buildUninstaller());
      last = null;
    },
    windows: () => call('windows'),
    readDoc: (args = {}) => call('readDoc', args),
    // 제목(#Sj + 누름틀 '결재제목')·본문 누름틀·대국민 공개여부(기본 부분공개 6호)·붙임 비공개. 저장·상신은 하지 않는다
    fillDraft: ({ title, body, disclosure = { mode: 'partial', reasons: [6] }, attachPrivate = true }) => call('fillDraft', {
      title, fields: { 결재제목: title, 본문: String(body).split(String.fromCharCode(10)).join(CRLF) }, disclosure, attachPrivate, front: true,
    }),
  };
})();
