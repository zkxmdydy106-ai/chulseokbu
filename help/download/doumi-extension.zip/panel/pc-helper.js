// PC 도우미 연결(native messaging). 확장은 PC에 프로그램을 직접 설치할 수 없으므로(브라우저 보안)
// 이 확장 ID를 넣은 설치 파일(.cmd)을 그 자리에서 만들어 내려받게 하고, 교사가 한 번 더블클릭한다.
// - 설치 위치: %LOCALAPPDATA%\DoumiPcHelper (관리자 권한 없음, 이 사용자만), 엣지·크롬·웨일에 등록(HKCU)
// - PC 도우미는 인터넷 통신을 하지 않는다. 파일은 교사가 버튼을 누를 때만 다운로드\공문 정리 안에 쓴다(교사 결정 2026-11-02, extension/native/doumi-host.ps1)
// - 할 수 있는 일: ping · windows(창 목록) · readDoc(문서 제목·본문 누름틀 읽기) · closeDoc(읽은 창 닫기) · fillDraft(기안 창 채우기) · file*(공문 정리 폴더 안 파일)
(() => {
  const D = globalThis.Doumi;
  const NAME = 'kr.doumi.pchelper';
  const VERSION = 3; // 3: 영어 표시 언어 Windows의 대화상자 제목(Message from webpage)도 알아봄(2026-11-06)
  const MARK = '###DOUMI-PS###';
  const CRLF = String.fromCharCode(13, 10);

  // .cmd 앞부분은 cmd가, 표시(MARK) 뒤는 PowerShell이 읽는다. cmd 줄은 영어만(한글은 cmd 코드페이지에서 깨짐)
  function wrapCmd(title, ps) {
    return [
      '@echo off',
      'chcp 65001 >nul',
      `title ${title}`,
      `"%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText('%~f0',[Text.Encoding]::UTF8); $i=$t.IndexOf('###DOUMI-PS'+'###'); iex $t.Substring($i)"`,
      'pause',
      'exit /b',
      MARK,
      ps,
    ].join(CRLF);
  }

  const b64 = (text) => btoa(unescape(encodeURIComponent(text)));
  const psq = (s) => String(s).replace(/'/g, "''");

  function buildInstaller(hostText, extId) {
    if (!/^[a-p]{32}$/.test(extId)) throw new Error('확장 ID가 이상해요.');
    const ps = [
      "$ErrorActionPreference = 'Stop'",
      `$name = '${NAME}'`,
      `$extId = '${psq(extId)}'`,
      "$dir = Join-Path $env:LOCALAPPDATA 'DoumiPcHelper'",
      'try {',
      '  New-Item -ItemType Directory -Force -Path $dir | Out-Null',
      `  $hostPs = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64(hostText)}'))`,
      "  [IO.File]::WriteAllText((Join-Path $dir 'doumi-host.ps1'), $hostPs, (New-Object Text.UTF8Encoding $true))",
      `  $launcher = '@"%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0doumi-host.ps1"'`,
      "  [IO.File]::WriteAllText((Join-Path $dir 'host.cmd'), $launcher, (New-Object Text.ASCIIEncoding))",
      '  $manifestPath = Join-Path $dir "$name.json"',
      '  $origins = @()',
      '  if (Test-Path $manifestPath) { try { $origins = @((Get-Content $manifestPath -Raw | ConvertFrom-Json).allowed_origins) } catch { } }',
      '  $o = "chrome-extension://$extId/"',
      '  if ($origins -notcontains $o) { $origins += $o }',
      "  $manifest = [ordered]@{ name = $name; description = 'Doumi PC helper - fills and reads K-Edufine document windows on this PC'; path = (Join-Path $dir 'host.cmd'); type = 'stdio'; allowed_origins = @($origins) }",
      '  [IO.File]::WriteAllText($manifestPath, (ConvertTo-Json -InputObject $manifest -Depth 3), (New-Object Text.UTF8Encoding $false))',
      "  foreach ($b in 'Microsoft\\Edge', 'Google\\Chrome', 'Naver\\Whale') {",
      '    $k = "HKCU:\\Software\\$b\\NativeMessagingHosts\\$name"',
      '    New-Item -Path $k -Force | Out-Null',
      "    Set-ItemProperty -Path $k -Name '(default)' -Value $manifestPath",
      '  }',
      "  Write-Host ''",
      "  Write-Host 'PC 도우미를 설치했어요. 브라우저 패널로 돌아가 [다시 확인]을 눌러 주세요.' -ForegroundColor Green",
      "  Write-Host ('설치 위치: ' + $dir)",
      '} catch {',
      "  Write-Host ('설치하지 못했어요: ' + $_.Exception.Message) -ForegroundColor Red",
      "  Write-Host '학교 PC 보안 정책이 막았을 수 있어요. 패널의 복사 기능을 써 주세요.'",
      '}',
    ].join(CRLF);
    return wrapCmd('Doumi PC helper install', ps);
  }

  function buildUninstaller() {
    const ps = [
      `$name = '${NAME}'`,
      "foreach ($b in 'Microsoft\\Edge', 'Google\\Chrome', 'Naver\\Whale') { Remove-Item -Path \"HKCU:\\Software\\$b\\NativeMessagingHosts\\$name\" -Force -ErrorAction SilentlyContinue }",
      "$dir = Join-Path $env:LOCALAPPDATA 'DoumiPcHelper'",
      'Remove-Item -Path $dir -Recurse -Force -ErrorAction SilentlyContinue',
      "if (Test-Path $dir) { Write-Host '일부 파일을 지우지 못했어요. 브라우저를 닫고 다시 실행해 주세요.' -ForegroundColor Yellow } else { Write-Host 'PC 도우미를 지웠어요.' -ForegroundColor Green }",
    ].join(CRLF);
    return wrapCmd('Doumi PC helper remove', ps);
  }

  function download(name, text) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'application/octet-stream' }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  // ── 연결: 한 번 띄운 PC 도우미를 계속 쓴다(PowerShell 시작이 느려서) ──
  let port = null;
  let seq = 0;
  const pending = new Map();
  function connect() {
    if (port) return port;
    port = chrome.runtime.connectNative(NAME);
    port.onMessage.addListener((m) => {
      const p = pending.get(m?.id);
      if (!p) return;
      pending.delete(m.id);
      clearTimeout(p.timer);
      p.resolve(m);
    });
    port.onDisconnect.addListener(() => {
      const why = chrome.runtime.lastError?.message || '연결이 끊겼어요';
      port = null;
      for (const p of pending.values()) { clearTimeout(p.timer); p.resolve({ ok: false, error: why, disconnected: true }); }
      pending.clear();
    });
    return port;
  }

  function call(op, args = {}, timeout = 25000) {
    return new Promise((resolve) => {
      if (typeof chrome.runtime?.connectNative !== 'function') { resolve({ ok: false, error: 'Specified native messaging host not found.', disconnected: true }); return; }
      let p;
      try { p = connect(); } catch (e) { resolve({ ok: false, error: String(e?.message || e), disconnected: true }); return; }
      const id = ++seq;
      const timer = setTimeout(() => { pending.delete(id); resolve({ ok: false, error: 'PC 도우미가 답하지 않아요.' }); }, timeout);
      pending.set(id, { resolve, timer });
      try { p.postMessage({ id, op, args }); } catch (e) { clearTimeout(timer); pending.delete(id); resolve({ ok: false, error: String(e?.message || e), disconnected: true }); }
    });
  }

  // 패널 문장으로 바꾸기
  function explain(r) {
    const e = String(r?.error || '');
    if (/not found|specified native messaging host/i.test(e)) return 'PC 도우미가 설치되어 있지 않아요.';
    if (/forbidden|access.*denied/i.test(e)) return 'PC 도우미가 이 확장과 연결되지 않았어요. 설치 파일을 다시 받아 실행해 주세요.';
    if (/^unknown-op:/.test(e)) return 'PC 도우미가 옛 판이에요. 패널 [기안]의 [PC 도우미 설치]로 받은 파일을 한 번 눌러 새 판으로 바꿔 주세요.';
    if (e === 'window-stays') return '문서 창이 닫히지 않았어요. 창 위에 작은 창이나 안내가 떠 있으면 닫아 주세요.';
    if (e === 'autosave-ask') return "기안 창이 '자동저장문서를 읽어오시겠습니까?'를 묻고 있어요. 쓰다 만 글일 수 있어 도우미가 고르지 않아요. 창에서 [확인](읽어 오기)이나 [취소]를 누른 뒤 다시 눌러 주세요.";
    if (e === 'window-busy') return '문서 창이 아직 바빠요(막 열렸거나 작은 창이 떠 있어요). 작은 창을 닫고 잠시 뒤 다시 눌러 주세요.';
    if (e === 'no-popup') return '에듀파인 창이 열리지 않았어요. PC가 바쁠 수 있어요. 잠시 뒤 다시 눌러 주세요.';
    if (e === 'popup-stays') return '에듀파인 창이 닫히지 않았어요. 문서 창에 떠 있는 안내를 확인해 주세요.';
    if (e === 'no-list') return '결재경로 창의 직원 목록을 읽지 못했어요. 문서 창에서 직접 정해 주세요.';
    if (e === 'not-draft') return '새 기안 창에서만 결재선을 채워요. 문서 창에서 직접 정해 주세요.';
    if (e === 'no-window:draft') return '기안 창을 찾지 못했어요. 에듀파인에서 [기안] → 서식을 골라 기안 창을 연 뒤 다시 눌러 주세요.';
    if (e === 'many-windows:draft') return '기안 창이 2개 이상 열려 있어요. 채울 창 하나만 남겨 주세요.';
    if (e === 'no-window:doc') return '열린 결재·조회 문서 창이 없어요.';
    if (e === 'outside-folder' || e === 'bad-name') return '정해 둔 폴더(다운로드\\공문 정리) 밖의 파일은 다루지 않아요.';
    if (e === 'total-data') return '자료집계 첨부파일은 결재가 끝나기 전에는 에듀파인이 받지 못하게 막아 두었어요.';
    if (e === 'not-saved') return '파일을 받지 못했어요. 문서 창에서 직접 받아 주세요.';
    if (e === 'attach-changed' || e === 'no-attach') return '문서 창의 붙임이 달라졌어요. 다시 읽어 주세요.';
    if (e === 'no-file') return '파일이 없어요(옮기거나 지웠을 수 있어요). 다시 받아 주세요.';
    if (e === 'not-allowed-type') return '실행 파일 등은 도우미가 열지 않아요. 폴더에서 직접 확인해 주세요.';
    if (e === 'many-windows:doc') return '문서 창이 여러 개 열려 있어요. 읽을 창 하나만 남겨 주세요.';
    if (/not a draft window/.test(e)) return '기안 창이 아니라서 채우지 않았어요.';
    if (/exited|exit/i.test(e)) return 'PC 도우미가 실행되지 않았어요(학교 PC 보안 정책일 수 있어요).';
    return e || '알 수 없는 문제';
  }

  let last = null;
  D.pcHelper = {
    NAME,
    VERSION,
    buildInstaller,
    buildUninstaller,
    explain,
    get last() { return last; },
    // { ok, version, old } 또는 { ok:false, missing, text }
    async status(force = false) {
      if (last && !force) return last;
      const r = await call('ping', {}, 20000);
      last = r.ok ? { ok: true, version: r.version, old: r.version < VERSION } : { ok: false, missing: /not found|specified native/i.test(r.error || ''), text: explain(r) };
      return last;
    },
    async downloadInstaller() {
      const hostText = await (await fetch(chrome.runtime.getURL('native/doumi-host.ps1'))).text();
      download('PC도우미설치.cmd', buildInstaller(hostText, chrome.runtime.id));
      last = null;
    },
    downloadUninstaller() {
      if (port) { try { port.disconnect(); } catch { /* 이미 끊김 */ } port = null; }
      download('PC도우미지우기.cmd', buildUninstaller());
      last = null;
    },
    windows: (args = {}) => call('windows', args),
    readDoc: (args = {}) => call('readDoc', args),
    // 읽기만 하고 문서 창을 닫는다(결재 안 함). 결재·조회 창만
    closeDoc: (args = {}) => call('closeDoc', args),
    readPicks: (args = {}) => call('readPicks', args),
    fillPicks: (args) => call('fillPicks', args, 120000),
    // 결재선·수신자·파일(2026-11-03 실제 창). 창 안 메모리만 바뀌고, 서버로는 교사가 [결재올림]을 누를 때 간다
    readLine: (args = {}) => call('readLine', args),
    // 과제카드 목록·공람 후보 이름(메모리에만, 작은 창은 [확인] 없이 닫음)
    readPickLists: (args = {}) => call('readPickLists', args, 240000),
    fillLine: (args) => call('fillLine', args, 120000),
    fillRcver: (args) => call('fillRcver', args, 120000),
    attachAdd: (args) => call('attachAdd', args, 120000),
    // 문서 창 열기: 에듀파인이 준 wxsclient:// 주소를 윈도우로 실행(브라우저는 사용자가 누르지 않으면 프로그램을 연달아 못 열게 막음, 2026-11-02 실제)
    launchDoc: (args) => call('launchDoc', args),
    attachSave: (args) => call('attachSave', args, 60000),
    fileWrite: (args) => call('fileWrite', args),
    fileRead: (args) => call('fileRead', args),
    fileOpen: (args) => call('fileOpen', args),
    folderOpen: (args = {}) => call('folderOpen', args),
    // 제목(#Sj + 누름틀 '결재제목')·본문 누름틀·대국민 공개여부(기본 부분공개 6호)·붙임 비공개. 저장·상신은 하지 않는다
    fillDraft: ({ title, body, disclosure = { mode: 'partial', reasons: [6] }, attachPrivate = true }) => call('fillDraft', {
      title, fields: { 결재제목: title, 본문: String(body).split(String.fromCharCode(10)).join(CRLF) }, disclosure, attachPrivate, front: true,
    }, 120000),
  };
})();
