// 나이스 시간표 가져오기(빈 시간 찾기·오늘 내 수업 공용, 2026-11-06 교사 결정 '컴시간 대신 나이스').
// [전체시간표조회 → 강의실별]을 그 날짜들로 학년마다 조회 → 보고서 자료를 해석 → 날짜·선생님·교시.
// 나이스는 교사가 [가져오기]·[찾기]를 누를 때만 움직인다(메뉴 열기·조회만, 값은 안 바꿈).
// 받은 것(선생님 이름·수업 글)은 작업 중 자료라 chrome.storage.session(브라우저를 닫으면 지워짐)과 메모리에만.
(() => {
  const D = globalThis.Doumi;
  const T = () => D.neisTimetable;
  const KEY = 'timetableDays';
  let mem = null; // { days: { ymd: { 이름: { 교시: 글 } } }, names: [], at: { ymd: 받은 시각 } }

  async function load0() {
    if (mem) return mem;
    try { mem = (await chrome.storage.session.get(KEY))[KEY] || null; } catch { mem = null; }
    if (!mem) mem = { days: {}, names: [], at: {} };
    return mem;
  }
  async function keep() { try { await chrome.storage.session.set({ [KEY]: mem }); } catch { /* 메모리만 */ } }

  // 학년 고르기 칸(화면 설정의 gradeUdc, 목록은 '1'·'2'·'3' 숫자)
  function gradeUdc(options, id) {
    const o = options?.[id];
    return o && o.items.length && o.items.every((x) => /^\d{1,2}$/.test(String(x.cd))) ? { id, ...o, items: o.items.map((x) => ({ cd: x.cd, nm: /학년/.test(x.nm) ? x.nm : `${x.nm}학년` })) } : null;
  }

  D.timetable = {
    KEY,
    // 이미 받아 둔 날(이 브라우저를 켜 둔 동안)
    async has(ymd) { return !!(await load0()).at[ymd]; },
    async day(ymd) { const m = await load0(); return m.at[ymd] ? m.days[ymd] || {} : null; },
    async names() { return (await load0()).names; },
    async clear() { mem = { days: {}, names: [], at: {} }; try { await chrome.storage.session.remove(KEY); } catch { /* 없음 */ } },

    /**
     * 날짜들(ymd 배열)의 시간표를 나이스에서 받는다. force가 아니면 이미 받은 날은 건너뜀.
     * onStep(글): 진행 안내. → { ok, error? }
     */
    async fetch(dates, { force = false, onStep = () => {} } = {}) {
      const m = await load0();
      const need = dates.filter((d) => force || !m.at[d]).sort();
      if (!need.length) return { ok: true };
      const tab = await D.neis.activeTab();
      if (!D.neis.isNeis(tab)) return { ok: false, error: '나이스 탭에서 눌러 주세요. 시간표는 나이스 [전체시간표조회]에서 읽어요.' };
      const screen = D.screens.get('neis.timetable');
      const R = screen.report;
      const det = await D.neis.call('detect', {}, { tabId: tab.id });
      if (!det.ok || !(det.apps || []).includes(screen.appId)) {
        onStep('나이스 [전체시간표조회] 화면을 여는 중…');
        const o = await D.neis.open(screen, tab.id);
        if (!o.ok) return { ok: false, error: `나이스 시간표 화면을 열지 못했어요(${o.error}). 나이스 [교과담임 → 시간표관리 → 전체시간표조회]를 한 번 열어 두고 다시 눌러 주세요.` };
      }
      const opt = await D.neis.call('udcOptions', { appId: screen.appId, udcs: R.udcs }, { tabId: tab.id });
      const g = opt.ok ? gradeUdc(opt.options, R.gradeUdc) : null;
      if (!g) return { ok: false, error: '나이스 시간표 화면에서 학년 칸을 찾지 못했어요. 화면이 바뀌었을 수 있어요.' };
      const from = need[0], to = need[need.length - 1];
      const parsed = [];
      for (const it of g.items) {
        onStep(`나이스 시간표 읽는 중… ${it.nm} (${parsed.length + 1}/${g.items.length})`);
        if (String(g.value) !== String(it.cd)) {
          const p = await D.neis.call('udcPick', { appId: screen.appId, udc: g.id, value: it.cd, udcs: R.udcs, repick: false, settle: 800 }, { tabId: tab.id, timeout: 20000 });
          if (!p.ok) return { ok: false, error: `나이스에서 ${it.nm}을(를) 고르지 못했어요(${p.error}).` };
          g.value = it.cd;
        }
        const r = await D.neis.call('reportGrab', { appId: screen.appId, dataMap: R.dataMap, values: { [R.from]: from, [R.to]: to }, radio: R.radio, button: R.button }, { tabId: tab.id, timeout: 45000 });
        if (!r.ok) return { ok: false, error: r.error };
        try { parsed.push(T().parseDaily(r.text)); } catch (e) { return { ok: false, error: e.message }; }
      }
      const merged = T().merge(parsed);
      const at = Date.now();
      // 받은 기간의 날은 모두 '받음'(수업이 없는 날도), 날짜 칸이 있는 날만 자료
      for (let d = new Date(+from.slice(0, 4), +from.slice(4, 6) - 1, +from.slice(6)); ; d.setDate(d.getDate() + 1)) {
        const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
        if (ymd > to) break;
        m.days[ymd] = merged.byDay[ymd] || {};
        m.at[ymd] = at;
      }
      m.names = [...new Set([...m.names, ...merged.names])].sort((a, b) => a.localeCompare(b, 'ko'));
      await keep();
      return { ok: true };
    },
  };
})();
