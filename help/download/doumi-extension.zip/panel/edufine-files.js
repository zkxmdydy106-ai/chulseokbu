// 공문 붙임·회신 양식 사본 파일(교사 결정 2026-11-02): 다운로드\공문 정리\문서별 폴더에 저장, 누른 파일만. 교사가 지울 때까지 남는다.
// 실제 저장·열기는 PC 도우미(extension/native/doumi-host.ps1)가 그 폴더 안에서만 한다. 인터넷으로 보내지 않는다.
(() => {
  const D = globalThis.Doumi;
  const CHUNK = 540000; // 조각 크기(base64로 약 720KB — native messaging 한 번에 1MB까지)

  const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  // 문서별 폴더 이름: 제목 앞부분(파일 이름에 못 쓰는 글자는 PC 도우미가 바꾼다)
  const folderOf = (it) => String(it?.title || '공문').replace(/\s+/g, ' ').trim().slice(0, 50);

  async function needHelper() {
    const st = await D.pcHelper.status(true);
    if (!st.ok) return { ok: false, error: st.missing ? 'PC 도우미가 있어야 파일을 받을 수 있어요. 기안 준비 화면에서 설치할 수 있어요.' : st.text };
    if (st.old) return { ok: false, error: 'PC 도우미 새 판이 있어요. 설치 파일을 다시 받아 한 번 눌러 주세요.' };
    return null;
  }

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const sq = (t) => String(t || '').replace(/\s+/g, '');
  const docWins = async () => { const r = await D.pcHelper.windows(); return r.ok ? r.windows.filter((w) => w.kind === 'approve' || w.kind === 'view') : []; };

  // 붙임은 문서 창에서 받는다(화면의 저장 함수, 2026-11-02 실제). 창이 없으면 결재대기에서 열고, 받은 뒤 도우미가 연 창만 닫는다
  async function fromDoc({ docId, title }, names, onSaved) {
    const stop = await needHelper();
    if (stop) return stop;
    let wins = await docWins();
    if (wins.length > 1) return { ok: false, error: '문서 창이 여러 개 열려 있어요. 이 공문 창만 남겨 주세요.' };
    let openedHere = false;
    if (!wins.length) {
      const c = docId ? await D.edufineInbox.click(docId) : { ok: false };
      if (!c.ok) return { ok: false, error: '결재대기에 없는 문서예요. [문서 열기]로 찾아 에듀파인에서 문서를 연 뒤 다시 눌러 주세요.' };
      openedHere = true;
      const end = Date.now() + 60000;
      while (!wins.length && Date.now() < end) { await sleep(400); wins = await docWins(); }
      if (!wins.length) return { ok: false, error: "문서 창이 열리지 않았어요('앱을 열까요?'가 떴는지 봐 주세요)." };
    }
    const win = wins[0];
    let doc = null;
    const end = Date.now() + 15000;
    do { doc = await D.pcHelper.readDoc({ pid: win.pid, attach: true }); if (doc.ok && doc.files) break; await sleep(500); } while (Date.now() < end);
    if (!doc?.ok || !doc.files) { if (openedHere) await D.pcHelper.closeDoc({ pid: win.pid }); return { ok: false, error: '붙임 목록을 읽지 못했어요. 문서 창에서 직접 받아 주세요.' }; }
    if (title && doc.fields?.Sj && sq(doc.fields.Sj) !== sq(title) && !sq(doc.fields.Sj).includes(sq(title)) && !sq(title).includes(sq(doc.fields.Sj))) {
      if (openedHere) await D.pcHelper.closeDoc({ pid: win.pid });
      return { ok: false, error: '열린 문서 창이 이 공문이 아니에요. 그 창을 닫고 다시 눌러 주세요.' };
    }
    let saved = 0;
    let firstError = '';
    // names가 없으면 문서 창의 붙임 전부
    const want = names || doc.files.map((f) => f.name);
    for (const name of want) {
      const i = doc.files.findIndex((f) => f.name === name);
      if (i < 0) { firstError = firstError || `문서 창에서 '${name}'을(를) 찾지 못했어요.`; continue; }
      const r = await D.pcHelper.attachSave({ pid: win.pid, i, name, folder: folderOf({ title }) });
      if (r.ok) { saved++; await onSaved(name, r.path); } else firstError = firstError || D.pcHelper.explain(r);
    }
    if (openedHere) await D.pcHelper.closeDoc({ pid: win.pid });
    return saved === want.length ? { ok: true, saved, text: `${saved}개를 받았어요(다운로드\\공문 정리). 다 쓰면 폴더를 지워 주세요.` } : { ok: false, saved, error: firstError || '일부 파일을 받지 못했어요.' };
  }

  D.edufineFiles = {
    folderOf,
    fromDoc,
    // 할 일의 [받기]·[모두 받기]
    save: (it, file) => fromDoc({ docId: it.source?.docId, title: it.title }, [file.name], (name, path) => D.todo.setFile(it.id, name, path)),
    saveAll: (it) => fromDoc({ docId: it.source?.docId, title: it.title }, (it.files || []).filter((f) => !f.path).map((f) => f.name), (name, path) => D.todo.setFile(it.id, name, path)),
    // [열기] 한 번: 아직 안 받은 붙임이면 받아서 바로 연다(교사 요청 2026-11-10 '첨부 파일도 바로 열 수 있게')
    async saveOpen(it, file) {
      if (file.path) return D.edufineFiles.open(file);
      let path = '';
      const r = await fromDoc({ docId: it.source?.docId, title: it.title }, [file.name], async (name, p) => { path = p; await D.todo.setFile(it.id, name, p); });
      return r.ok && path ? D.edufineFiles.open({ name: file.name, path }) : r;
    },
    // 패널에 있는 파일 내용을 공문 정리 폴더에 쓴다(회신 양식 사본 등)
    // 기안에 붙일 파일을 폴더에 둔다. 에듀파인이 [결재올림] 때 이 자리에서 올리므로 교사가 올린 뒤에 지운다(자동으로 안 지움)
    async keep(file, folder = '기안 파일') {
      const stop = await needHelper();
      if (stop) return stop;
      const bytes = new Uint8Array(await file.arrayBuffer());
      let last = null;
      for (let at = 0; at === 0 || at < bytes.length; at += CHUNK) {
        last = await D.pcHelper.fileWrite({ folder, name: file.name, b64: b64(bytes.subarray(at, at + CHUNK)), append: at > 0 });
        if (!last.ok) return { ok: false, error: D.pcHelper.explain(last) };
      }
      return { ok: true, name: file.name, path: last.path, size: last.size };
    },
    async saveBytes(name, bytes, folder = '회신 양식') {
      const stop = await needHelper();
      if (stop) return stop;
      let last = null;
      for (let at = 0; at === 0 || at < bytes.length; at += CHUNK) {
        last = await D.pcHelper.fileWrite({ folder, name, b64: b64(bytes.subarray(at, at + CHUNK)), append: at > 0 });
        if (!last.ok) return { ok: false, error: D.pcHelper.explain(last) };
      }
      const opened = await D.pcHelper.fileOpen({ path: last.path });
      return opened.ok ? { ok: true, path: last.path } : { ok: false, path: last.path, error: D.pcHelper.explain(opened) };
    },
    // 공문 정리 폴더의 파일 내용을 조각으로 읽는다(모아 보기 파일 창). 큰 파일은 읽지 않고 폴더에서 끌어다 놓게 한다
    async read(path, maxBytes = 30 * 1024 * 1024) {
      const stop = await needHelper();
      if (stop) return stop;
      const chunks = [];
      let at = 0;
      let size = 0;
      do {
        const r = await D.pcHelper.fileRead({ path, offset: at, length: CHUNK });
        if (!r.ok) return { ok: false, error: D.pcHelper.explain(r) };
        size = r.size;
        if (size > maxBytes) return { ok: false, tooBig: true, size };
        if (!r.read) break;
        chunks.push(r.b64);
        at += r.read;
      } while (at < size);
      return { ok: true, size, chunks };
    },
    async open(file) {
      if (!file?.path) return { ok: false, error: '아직 받지 않은 파일이에요.' };
      const stop = await needHelper();
      if (stop) return stop;
      const r = await D.pcHelper.fileOpen({ path: file.path });
      return r.ok ? { ok: true, text: `${file.name}을(를) 열었어요.` } : { ok: false, error: D.pcHelper.explain(r) };
    },
    async folder(it) {
      const stop = await needHelper();
      if (stop) return stop;
      const r = await D.pcHelper.folderOpen({ folder: folderOf(it) });
      return r.ok ? { ok: true, text: `폴더를 열었어요: ${r.path}` } : { ok: false, error: D.pcHelper.explain(r) };
    },
  };
})();
