// 폰 출결 자동 연동(교사 결정 2026-10-30): 출석부 웹앱의 '구글 자동 저장' 저장소(gas/sync-store, 선생님 계정)를 패널이 직접 읽는다.
// [PC로 보내기]·[폰 출결 가져오기] 없이, 패널에서 [일일출결]·[과목별출결]을 누르면 폰에서 체크한 출결이 바로 '준비됨'으로.
// - 저장소에는 웹앱이 기기에서 잠근 암호문만 있다(열쇠 = sha256('key|'+t), AES-GCM, 안은 deflate-raw JSON). 이 패널이 같은 열쇠로 풀어 메모리에만 둔다.
// - 열쇠 { u, t }는 [출석부 웹앱 만들기]·[폰 출석부 연결] 때 만들기 다리가 준 것(설정 syncStore, storage.local) — 계정마다 저장소 하나라 폰과 같은 저장소.
// - 표는 웹앱 dailyTable·table과 똑같은 모양(단위 시험이 웹앱 글과 대조) → 지금 쓰는 일일출결·과목별출결 확인 그대로.
(() => {
  const D = globalThis.Doumi;
  const STORE_RE = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]{20,}\/exec$/;
  const MARK = { '': '출석', '/': '결과', 'Ø': '출석인정' };
  const isHome = (c) => !!c && (c.homeroom || c.subject === '담임');
  const labelOf = (cs) => `${cs.kind}${cs.type}`;
  const isoOf = (ymd) => `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6, 8)}`;
  const ymdOf = (d) => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const unb64u = (s) => { s = s.replace(/-/g, '+').replace(/_/g, '/'); s += '='.repeat((4 - (s.length % 4)) % 4); return Uint8Array.from(atob(s), (c) => c.charCodeAt(0)); };
  const squeeze = async (u8, how) => new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(how)).arrayBuffer());
  const tsv = (rows) => (rows && rows.length > 1 ? rows.map((r) => r.map((v) => String(v ?? '').replace(/[\t\r\n]+/g, ' ')).join('\t')).join('\n') : '');

  async function unseal(blob, t) {
    const u8 = unb64u(blob);
    const raw = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`key|${t}`));
    const key = await crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['decrypt']);
    let pt;
    try { pt = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: u8.slice(0, 12) }, key, u8.slice(12))); }
    catch { const e = new Error('출석부 저장소 열쇠가 맞지 않아요. [폰 출석부 연결]을 다시 눌러 주세요.'); e.code = 'auth'; throw e; }
    return JSON.parse(new TextDecoder().decode(await squeeze(pt, new DecompressionStream('deflate-raw'))));
  }

  // unseal의 반대(웹앱 seal과 같은 모양): deflate-raw JSON → AES-GCM → 앞 12바이트 iv + 암호문, base64url
  async function seal(box, t) {
    const raw = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`key|${t}`));
    const key = await crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt']);
    const pt = await squeeze(new TextEncoder().encode(JSON.stringify(box)), new CompressionStream('deflate-raw'));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, pt));
    const all = new Uint8Array(12 + ct.length);
    all.set(iv); all.set(ct, 12);
    let bin = '';
    for (let i = 0; i < all.length; i += 0x8000) bin += String.fromCharCode.apply(null, all.subarray(i, i + 0x8000));
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  // ── 웹앱(webapp/chulseokbu/index.html) dailyRows·exportRows와 같은 규칙 — 고치면 둘 다(단위 시험이 대조) ──
  function dailyRows(S, from, to) {
    const out = [];
    const push = (k, no, cs) => {
      const [ymd, cid] = k.split('|');
      if (ymd < from || ymd > to) return;
      const c = S.classes.find((x) => x.id === cid);
      const s = c?.students.find((x) => x.no === no);
      if (!c || !s || !isHome(c)) return;
      // 나이스 사유 칸(교사 결정 2026-10-30): 기본은 빈칸, 기타는 적은 글, 출석인정 교외체험학습·생리는 그 이름, 적은 글에 '면접'이 있으면 '면접'. 시각은 넣지 않음(교시 칸이 함)
      const reason = !cs ? '' : cs.kind === '기타' ? String(cs.reason || '').trim() : cs.kind === '출석인정' && ['교외체험학습', '생리'].includes(cs.sub) ? cs.sub : /면접/.test(cs.reason || '') ? '면접' : '';
      out.push({ ymd, cls: c.name, no: +no, name: s.name, mark: cs ? labelOf(cs) : '출석', reason, pt: cs && cs.type !== '결석' && cs.t1 ? cs.pt || '' : '' });
    };
    for (const [k, rec] of Object.entries(S.daily || {})) for (const [no, id] of Object.entries(rec)) if ((S.cases || {})[id]) push(k, no, S.cases[id]);
    for (const [k, rec] of Object.entries(S.cleared || {})) for (const no of Object.keys(rec)) if (!((S.daily || {})[k] || {})[no]) push(k, no, null);
    return out.sort((a, b) => a.ymd.localeCompare(b.ymd) || a.cls.localeCompare(b.cls, 'ko', { numeric: true }) || a.no - b.no);
  }
  function exportRows(S, from, to) {
    const out = [];
    for (const [k, rec] of Object.entries(S.marks || {})) {
      const [ymd, pir, cid] = k.split('|');
      if (ymd < from || ymd > to) continue;
      const c = S.classes.find((x) => x.id === cid);
      if (!c) continue;
      for (const [no, e] of Object.entries(rec)) {
        const s = c.students.find((x) => x.no === no);
        if (!s) continue;
        // 과목별출결 사유는 넣지 않음(교사 결정 2026-10-30 — 수업 중 고른 사유는 출석부에만)
        out.push({ ymd, pir: +pir, cls: c.name, no: +no, name: s.name, mark: MARK[e.m] ?? '출석', reason: '' });
      }
    }
    return out.sort((a, b) => a.ymd.localeCompare(b.ymd) || a.pir - b.pir || a.cls.localeCompare(b.cls, 'ko', { numeric: true }) || a.no - b.no);
  }
  const DAILY_HEAD = ['날짜', '번호', '이름', '구분', '교시', '사유'];
  const SUBJECT_HEAD = ['날짜', '교시', '반', '번호', '이름', '구분', '사유'];
  const dailyTable = (S, from, to) => [DAILY_HEAD, ...dailyRows(S, from, to).map((r) => [isoOf(r.ymd), String(r.no), r.name, r.mark, r.pt, r.reason])];
  const subjectTable = (S, from, to) => [SUBJECT_HEAD, ...exportRows(S, from, to).map((r) => [isoOf(r.ymd), String(r.pir), r.cls, String(r.no), r.name, r.mark, r.reason])];

  let cache = null; // { at: 읽은 시각, conf, res } — 같은 열쇠로 1분 안에는 다시 묻지 않음(누를 때만 읽음 — 교사 결정)

  D.phoneSync = {
    dailyRows, exportRows, dailyTable, subjectTable, unseal,
    // 열쇠를 바꾼 뒤: 저장소에 남은 암호문을 옛 열쇠로 풀어 새 열쇠로 다시 잠근다(패널 메모리에서만). 끝나면 옛 QR로는 열리지 않는다
    async reseal(oldT, conf) {
      const post = async (body) => (await fetch(conf.u, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ ...body, t: conf.t }) })).json();
      for (const s of ['h', 'c']) {
        const r = await post({ a: 'get', s });
        if (!r.ok) throw new Error('새 열쇠로 저장소를 열지 못했어요. 잠시 뒤 다시 해 주세요.');
        if (!r.rev || !r.blob) continue;
        const box = await unseal(r.blob, oldT);
        const w = await post({ a: 'put', s, blob: await seal(box, conf.t), force: true, at: r.at || Date.now() });
        if (!w.ok) throw new Error('출석부를 새 열쇠로 다시 저장하지 못했어요. 잠시 뒤 다시 해 주세요.');
      }
      D.phoneSync.forget();
    },
    conf: () => { const c = D.formsMaker?.store; return c && STORE_RE.test(String(c.u)) && /^[0-9a-f]{64}$/.test(String(c.t)) ? c : null; },
    // 저장소 번호: 배포 ID 끝 5자리 — 출석부 웹앱 [설정 → 구글 자동 저장]에 보이는 번호와 같아야 같은 저장소
    tag: (c) => String(c?.u || '').split('/s/')[1]?.split('/')[0].slice(-5) || '',
    forget() { cache = null; },
    // 담임 앱('h')·수업 앱('c') 칸을 모두 읽어 푼다. 결과는 메모리에만
    async read({ fresh = false } = {}) {
      const conf = D.phoneSync.conf();
      if (!conf) return { ok: false, code: 'none', error: '폰 출석부와 아직 연결되지 않았어요.' };
      if (!fresh && cache && cache.conf === conf && Date.now() - cache.at < 60000) return cache.res;
      const slots = {};
      try {
        for (const s of ['h', 'c']) {
          const ctl = new AbortController();
          const timer = setTimeout(() => ctl.abort(), 20000);
          let r;
          try {
            const res = await fetch(conf.u, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ a: 'get', s, t: conf.t }), cache: 'no-store', signal: ctl.signal });
            r = await res.json();
          } finally { clearTimeout(timer); }
          if (!r || r.ok !== true) {
            const auth = r?.err === 'auth';
            return { ok: false, code: auth ? 'auth' : 'store', error: auth ? '출석부 저장소 열쇠가 맞지 않아요. [폰 출석부 연결]을 다시 눌러 주세요.' : `출석부 저장소가 대답하지 않아요(${r?.err || '알 수 없음'}).` };
          }
          if (r.rev && r.blob) { const box = await unseal(r.blob, conf.t); slots[s] = { S: box.data || {}, at: r.at || box.editedAt || 0 }; }
        }
      } catch (e) {
        return { ok: false, code: e.code || 'net', error: e.code ? e.message : e?.name === 'AbortError' ? '출석부 저장소가 20초 넘게 대답하지 않아요. 잠시 뒤 다시 눌러 주세요.' : '출석부 저장소에 연결하지 못했어요. 인터넷 연결을 확인해 주세요.' };
      }
      if (!slots.h && !slots.c) return { ok: false, code: 'empty', error: '출석부 저장소가 비어 있어요. 폰 출석부에서 [설정 → 구글 자동 저장 → 켜기]를 눌러 주세요(같은 교육청 계정).' };
      const res = { ok: true, slots, at: Math.max(slots.h?.at || 0, slots.c?.at || 0), tag: D.phoneSync.tag(conf) };
      cache = { at: Date.now(), conf, res };
      return res;
    },
    // kind 'daily'(담임 앱) · 'subject'(수업 앱 + 담임 앱의 수업 반 — 같은 수업·학생은 수업 앱 것)
    rows(snap, kind, from, to) {
      if (kind === 'daily') return snap.slots.h ? dailyTable(snap.slots.h.S, from, to) : [DAILY_HEAD];
      const seen = new Map();
      for (const s of ['h', 'c']) {
        if (!snap.slots[s]) continue;
        for (const r of subjectTable(snap.slots[s].S, from, to).slice(1)) seen.set(`${r[0]}|${r[1]}|${r[2]}|${r[3]}`, r);
      }
      return [SUBJECT_HEAD, ...[...seen.values()].sort((a, b) => a[0].localeCompare(b[0]) || +a[1] - +b[1] || a[2].localeCompare(b[2], 'ko', { numeric: true }) || +a[3] - +b[3])];
    },
    text: (rows) => tsv(rows),
    // 기본 기간(교사 결정): 도우미가 나이스에 마지막으로 저장한 날 다음 ~ 오늘(기록 없으면 이번 달 1일부터)
    async range(kind, today = ymdOf(new Date())) {
      const last = ((await D.store.settings()).phoneLast || {})[kind] || '';
      let from = `${today.slice(0, 6)}01`;
      if (/^\d{8}$/.test(last)) {
        const d = new Date(+last.slice(0, 4), +last.slice(4, 6) - 1, +last.slice(6, 8) + 1);
        from = ymdOf(d) <= today ? ymdOf(d) : today;
      }
      return { from, to: today, last };
    },
    // 나이스에 저장한 날(가장 늦은 날)을 기억 — 다음 기본 기간의 시작
    async saved(kind, dates) {
      const max = (dates || []).filter((d) => /^\d{8}$/.test(d)).sort().pop();
      if (!max) return;
      const s = await D.store.settings();
      const last = s.phoneLast || {};
      if ((last[kind] || '') >= max) return;
      await D.store.saveSettings({ phoneLast: { ...last, [kind]: max } });
    },
    ymdOf,
  };
})();
