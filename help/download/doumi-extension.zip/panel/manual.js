// 인쇄용 나이스 길잡이: extension/guides/neis-guides.js의 순서·유의사항을 한 쪽에 모아 보여 준다(바깥 통신 없음, 학생 정보 없음)
(() => {
  const D = globalThis.Doumi || {};
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const LOOK = { see: '보기', nopress: '지금은 누르지 않음', press: '누르기' };

  // 일일출결 표 칸 그림(예시 값, 학생 이름 없음)
  function dailyGrid() {
    const cols = ['번호', '성명', '마감', '조회', '1', '2', '3', '4', '5', '6', '7', '종례', '사유'];
    const rows = [
      ['1', '학생 가', '질병지각', '/', '/', '/', '', '', '', '', '', '', '병원 진료', '지각: 조회 ~ 2교시'],
      ['2', '학생 나', '', '', '', '', '', '/', '', '', '', '', '', '교과 선생님이 찍은 \'/\'만 있음 → 담임이 구분을 정해야 저장·마감'],
      ['3', '학생 다', '출석인정결석', 'Ø', 'Ø', 'Ø', 'Ø', 'Ø', 'Ø', 'Ø', '공강', 'Ø', '', '2022 개정 학년 출석인정(2015 개정 학년은 \'/\')'],
      ['4', '학생 라', '미인정조퇴', '', '', '', '', '', '/', '/', '/', '/', '', '조퇴: 5교시 ~ 종례'],
    ];
    return `<figure class="grid-fig">
      <table><thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead>
      <tbody>${rows.map((r) => `<tr class="${r[2] ? '' : 'warn'}">${r.slice(0, 13).map((c, k) => `<td class="${k > 2 && k < 12 ? 'mk' : ''}${c === '공강' ? ' off' : ''}">${esc(c)}</td>`).join('')}</tr><tr class="note"><td colspan="13">↳ ${esc(r[13])}</td></tr>`).join('')}</tbody></table>
      <figcaption>일일출결관리 표 칸(예시). '마감' 칸이 출결구분이에요.</figcaption>
    </figure>`;
  }

  function menuText(g) {
    return g.menu.path.join(' → ');
  }

  function guideHtml(g) {
    return `<section class="guide" id="g-${esc(g.id)}">
      <h2>${esc(g.title)} <small>${esc(g.who)}</small></h2>
      <p class="sum">${esc(g.summary)}</p>
      <p class="menu"><b>메뉴</b> ${esc(menuText(g))}${g.menu.prefer === '002002' ? ' <span>([교과담임] 탭을 먼저 눌러요)</span>' : ''}</p>
      <ol class="steps">
        <li><b>메뉴 열기</b><p>업무 탭 [${esc(g.menu.path[0])}] → ${esc(g.menu.path.slice(1).join(' → '))} 순서로 눌러 화면을 열어요.</p></li>
        ${g.steps.map((s) => `<li class="${esc(s.look || 'press')}">
          <b>${esc(s.title)}</b>${s.look === 'nopress' ? ` <em>${LOOK.nopress}</em>` : ''}
          ${s.body ? `<p>${esc(s.body)}</p>` : ''}
          ${s.caution ? `<p class="ct">${esc(s.caution)}</p>` : ''}
          ${s.figure === 'dailyGrid' ? dailyGrid() : ''}
        </li>`).join('')}
      </ol>
      ${g.tips?.length ? `<div class="tips"><h3>유의사항</h3><ul>${g.tips.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></div>` : ''}
    </section>`;
  }

  const groups = D.guideGroups || [];
  const guides = D.guides || [];
  document.getElementById('toc').innerHTML = groups.map((gr) => `<div><b>${esc(gr.name)}</b>${guides.filter((g) => g.group === gr.name).map((g) => `<a href="#g-${esc(g.id)}">${esc(g.title)}</a>`).join('')}</div>`).join('');
  document.getElementById('doc').innerHTML = groups.map((gr) => `<div class="group">
    <h1 class="gh">${esc(gr.name)}</h1>
    <p class="intro">${esc(gr.intro)}</p>
    ${guides.filter((g) => g.group === gr.name).map(guideHtml).join('')}
  </div>`).join('');
  document.getElementById('print').addEventListener('click', () => window.print());
})();
