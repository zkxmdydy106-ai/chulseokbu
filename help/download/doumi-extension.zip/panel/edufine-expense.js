// 에듀파인 품의 등록 채우기(F3 품의, 2026-10-30). 화면 설정 screens/edufine-expense.js, 품목 값 features/expense.js.
// 순서: 교사가 [품의 등록 화면에 채우기] → 품의등록 화면이 없으면 메뉴를 엶 → 예산 줄이 없으면 "[예산선택]에서 고르세요"로 멈춤
//       → 교사가 예산을 고르고 다시 누름 → 제목·개요(비었을 때만)·품목 줄 → 금액 다시 계산 → 에듀파인 탭을 앞으로. 저장·결재요청은 교사.
(() => {
  const D = globalThis.Doumi;
  const cfg = D.edufineScreens.expense;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ── 페이지(넥사크로 본창 MAIN) 안에서 도는 함수 — 바깥 변수를 쓰지 않는다 ──
  function pageExpense(c, mode, payload) {
    const str = (v) => (v == null ? '' : String(v));
    if (mode === 'open') {
      try {
        const lf = nexacro.getApplication().mainframe.MainVFrameSet.SubHFrameSet.LeftFrame.form;
        if (typeof lf[c.menuFn] !== 'function') return { ok: false };
        lf[c.menuFn](c.menuId);
        return { ok: true };
      } catch { return { ok: false }; }
    }
    const form = window[c.formVar];
    if (!form) return { ok: true, open: false };
    const head = form[c.head], bgt = form[c.budget], items = form[c.items];
    if (!head || !bgt || !items || typeof bgt.getRowCount !== 'function') return { ok: false, code: 'shape' };
    const pos = bgt.rowposition;
    const budget = pos >= 0 && pos < bgt.getRowCount() ? { name: [str(bgt.getColumn(pos, 'detlBsnsNm')), str(bgt.getColumn(pos, 'detlIem'))].filter(Boolean).join(' / '), left: Number(bgt.getColumn(pos, 'bgtBlce')) || 0 } : null;
    const state = { ok: true, open: true, saved: !!str(head.getColumn(0, 'sclCnsulNo')).trim(), budgets: bgt.getRowCount(), budget, items: items.getRowCount() };
    if (mode === 'state') return state;
    // mode 'fill'
    if (state.saved) return { ...state, ok: false, code: 'saved' };
    if (!state.budgets || !budget) return { ...state, ok: false, code: 'no-budget' };
    if (state.items) return { ...state, ok: false, code: 'has-items' };
    if (typeof form[c.addRowFn] !== 'function') return { ...state, ok: false, code: 'shape' };
    const done = [];
    for (const k of ['sj', 'cnsulPurpsCn']) {
      if (payload[k] && !str(head.getColumn(0, k)).trim()) { head.setColumn(0, k, payload[k]); done.push(k); }
    }
    try { if (typeof form[c.lenFn] === 'function') form[c.lenFn](); } catch { /* 바이트 표시만 */ }
    const ud = form[c.units.dataset];
    const btn = form.divAuth2?.form?.btnRowAdit || null;
    const missingUnits = [];
    let n = 0;
    for (const it of payload.rows) {
      const before = items.getRowCount();
      form[c.addRowFn](btn, {});
      if (items.getRowCount() !== before + 1) return { ...state, ok: false, code: 'add-row', done, n };
      const r = items.rowposition;
      items.setColumn(r, 'prdlstCn', it.prdlstCn);
      items.setColumn(r, 'stndrd', it.stndrd);
      if (it.unit) {
        const fixed = { cm: '012', l: '007' }[it.unit.toLowerCase()];
        let code = fixed || '';
        if (!code && ud && typeof ud.findRow === 'function') { const i = ud.findRow(c.units.name, it.unit); if (i >= 0) code = str(ud.getColumn(i, c.units.code)); }
        if (code) items.setColumn(r, 'thngUnitSeCd', code); else if (!missingUnits.includes(it.unit)) missingUnits.push(it.unit);
      }
      items.setColumn(r, 'qty', it.qty);
      items.setColumn(r, 'expectUntpc', it.price);
      items.setColumn(r, 'expectAmt', it.amount);
      n++;
    }
    try { if (typeof form[c.amtFn] === 'function') form[c.amtFn](); } catch { /* 합계는 화면 이벤트가 이미 맞춤 */ }
    let total = 0;
    for (let i = 0; i < items.getRowCount(); i++) total += Number(items.getColumn(i, 'expectAmt')) || 0;
    return { ...state, ok: true, done, n, total, missingUnits };
  }

  // ── 패널 쪽 ──
  const run = async (tabId, args) => (await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, world: 'MAIN', func: pageExpense, args }))[0]?.result;
  async function mainTab() {
    for (const t of await chrome.tabs.query({ url: D.edufine.MATCHES })) {
      let type = 'normal';
      try { type = (await chrome.windows.get(t.windowId)).type; } catch { /* 닫히는 중 */ }
      if (type !== 'popup') return t;
    }
    return null;
  }
  const front = async (t) => { try { await chrome.tabs.update(t.id, { active: true }); await chrome.windows.update(t.windowId, { focused: true }); } catch { /* 이미 앞 */ } };

  D.edufineExpense = {
    // { title, summary, items } → { ok, needBudget?, n, total, budget, missingUnits, done, opened } | { ok:false, error }
    async fill({ title, summary, items }) {
      const t = await mainTab();
      if (!t) return { ok: false, error: '에듀파인 본창을 찾지 못했어요. 에듀파인에 로그인한 첫 화면 탭을 연 뒤 다시 눌러 주세요.' };
      let st;
      try { st = await run(t.id, [cfg, 'state', null]); } catch { st = null; }
      if (!st?.ok) return { ok: false, error: st?.code === 'shape' ? '품의 화면 모양이 예상과 달라요. 에듀파인에서 직접 입력해 주세요.' : '에듀파인 화면을 읽지 못했어요. 에듀파인 탭을 새로고침한 뒤 다시 눌러 주세요.' };
      let opened = false;
      if (!st.open) {
        const o = await run(t.id, [cfg, 'open', null]);
        if (!o?.ok) return { ok: false, error: '품의등록 메뉴를 열지 못했어요. 에듀파인에서 학교회계 → 사업관리 → 품의/정산 → 품의등록을 열어 주세요.' };
        opened = true;
        for (const end = Date.now() + 15000; Date.now() < end; await sleep(500)) {
          st = await run(t.id, [cfg, 'state', null]);
          if (st?.open) break;
        }
        if (!st?.open) return { ok: false, error: '품의등록 화면이 열리지 않았어요. 잠시 뒤 다시 눌러 주세요.' };
      }
      if (st.saved) { await front(t); return { ok: false, error: '이미 저장된 품의가 열려 있어요. 에듀파인 [신규]로 새 품의를 연 뒤 다시 눌러 주세요.' }; }
      if (!st.budgets) { await front(t); return { ok: false, needBudget: true, opened }; }
      if (st.items) { await front(t); return { ok: false, error: `고른 예산 줄에 품목이 이미 ${st.items}개 있어요. 겹치지 않게 넣지 않았어요(새 품의에서 해 주세요).` }; }
      const sj = D.expense.cut(title, cfg.maxBytes.sj);
      const sum = D.expense.cut(summary, cfg.maxBytes.cnsulPurpsCn);
      const r = await run(t.id, [cfg, 'fill', { sj: sj.text, cnsulPurpsCn: sum.text, rows: D.expense.rows(items) }]);
      await front(t);
      if (!r?.ok) return { ok: false, error: r?.code === 'add-row' ? `[행추가]로 품목 줄을 만들지 못했어요(${r.n || 0}개 넣음). 에듀파인 화면을 확인해 주세요.` : '품목을 넣지 못했어요. 에듀파인 화면을 확인해 주세요.' };
      return { ...r, cut: [sj.cut ? '제목' : '', sum.cut ? '개요' : ''].filter(Boolean), opened };
    },
  };
})();
