// 패널 → 지금 보고 있는 나이스 탭의 엔진 호출
(() => {
  const D = globalThis.Doumi;

  // 나이스 탭의 엔진을 패널과 같은 판으로 맞춘다. 패널 파일은 디스크에서 바로 새 판이 뜨지만, 크롬은 확장을 다시 로드할 때까지 옛 내용 스크립트를 넣는다.
  // 판이 다르면 새 기능이 말없이 빠진다(2026-11-02 교사 제보: 결재선을 넣어 드린다고 했는데 안 들어감). 탭을 새로 읽을 때마다 한 번, 같은 판이면 엔진이 그냥 돌아온다
  const matched = new Map(); // 탭 → 맞추는 중인 약속(동시에 온 호출도 다 맞춘 뒤에 보낸다 — 먼저 보내면 옛 엔진이 받음, 2026-11-02 시험에서 발견)
  chrome.tabs?.onUpdated?.addListener?.((id, info) => { if (info.status) matched.delete(id); });
  chrome.tabs?.onRemoved?.addListener?.((id) => matched.delete(id));

  D.neis = {
    async activeTab() {
      const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
      return t || null;
    },
    isNeis(tab) { return globalThis.DoumiSites.isNeis(tab?.url); },

    // tabId를 주면 그 탭으로(미리보기한 탭과 입력할 탭을 같게 하려고)
    async call(op, args = {}, { timeout = 15000, tabId = null } = {}) {
      let id = tabId;
      if (!id) {
        const t = await this.activeTab();
        if (!this.isNeis(t)) return { ok: false, code: 'not-neis', error: '나이스 탭이 아니에요.' };
        id = t.id;
      }
      if (chrome.scripting?.executeScript) {
        if (!matched.has(id)) matched.set(id, this.attach(id).catch(() => { matched.delete(id); })); // 아직 읽는 중이거나 나이스가 아닌 탭이면 다음 호출에 다시
        await matched.get(id);
      }
      // 탭이 대답하지 않아도(페이지 이동 중 등) 패널이 영영 기다리지 않게 한도를 둔다 — 안 그러면 화면 확인이 멈춤(2026-10-28 시험에서 발견)
      const NO_ANSWER = Symbol('no-answer');
      const limited = (p) => Promise.race([p, new Promise((ok) => setTimeout(() => ok(NO_ANSWER), timeout + 5000))]);
      const send = async () => { const r = await limited(chrome.tabs.sendMessage(id, { target: 'neis', op, args, timeout }, { frameId: 0 })); return r === NO_ANSWER ? { ok: false, code: 'no-response', error: '나이스 화면이 응답하지 않아요.' } : r; };
      try {
        return (await send()) || { ok: false, code: 'no-response', error: '나이스 화면이 응답하지 않아요.' };
      } catch {
        // 도우미가 아직 붙지 않은 탭(설치·업데이트 전에 열린 탭) → 지금 붙이고 한 번 더
        try {
          await this.attach(id);
          return (await send()) || { ok: false, code: 'no-response', error: '나이스 화면이 응답하지 않아요.' };
        } catch {
          return { ok: false, code: 'no-script', error: '나이스 탭에 도우미를 붙이지 못했어요. 나이스 탭을 한 번 새로고침해 주세요.' };
        }
      }
    },

    async attach(tabId) {
      await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ['content/bridge.js'] });
      await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ['engine/neis-engine.js'], world: 'MAIN' });
    },

    // 나이스 메뉴를 열어 화면을 띄운다(어느 화면에 있든). screen.menu: { menuId, prefer }
    // screen.otp(생기부): 화면 대신 OTP 창이 뜨면 code 'otp'. waitFirst: OTP 인증 뒤 [이어서] — 화면이 저절로 뜨는지 먼저 기다림
    async open(screen, tabId, { waitFirst = 0 } = {}) {
      return this.call('openMenu', { menuId: screen.menu.menuId, prefer: screen.menu.prefer, appId: screen.appId, step: screen.step || null, tab: screen.tab || null, otp: !!screen.otp, waitFirst },
        // 엔진이 메뉴 목록(막 연 나이스는 10초쯤 비어 있음)·화면 준비(조회 조건 채워짐)까지 기다리므로 넉넉히
        { tabId, timeout: (screen.step ? 50000 : 35000) + waitFirst });
    },
  };
})();
