// 설명 웹앱 열기(교사 요청 2026-11-02): [설명]을 누르면 그 기능의 사용 방법 영상이 있는 곳을 작은 창으로 연다.
// 주소에 실리는 것은 기능 이름(#daily 등)뿐이고 학생·교사 자료는 없다. 영상과 글은 공개판(GitHub Pages)에 있다.
(() => {
  const D = globalThis.Doumi;
  const URL = 'https://zkxmdydy106-ai.github.io/chulseokbu/help/';
  // 패널의 일(runner id·화면 id)마다 설명 웹앱의 어느 곳인지
  const SECTION = {
    daily: 'daily', subject: 'subject',
    'neis.record.jayul': 'record', 'neis.record.jinro': 'record', 'neis.record.haengteuk': 'record', 'neis.record.club': 'record', 'neis.record.personal': 'record', 'neis.record.reading': 'record',
    'neis.record.setuk': 'setuk',
    'neis.assess.standard': 'plan', 'neis.assess.levels': 'plan', 'neis.assess.areas': 'plan', 'neis.assess.ratio': 'plan',
    'neis.assess.items': 'items', 'neis.assess.perf': 'perf',
    duty: 'duty', trip: 'trip', leave: 'leave', free: 'free', guide: 'guide', roster: 'roster', todo: 'todo',
    inbox: 'inbox', draft: 'draft', record: 'inbox',
  };
  const sectionOf = (id) => SECTION[id] || '';
  D.help = {
    URL,
    sectionOf,
    open(id = '') {
      const sec = sectionOf(id) || id;
      const url = `${URL}${sec ? `#${sec}` : ''}`;
      if (chrome.windows?.create) chrome.windows.create({ url, type: 'popup', width: 1120, height: 820 }).catch(() => window.open(url, '_blank'));
      else window.open(url, '_blank');
    },
    // 새 판 알림(zip으로 설치하면 자동 업데이트가 없음, 교사 요청 2026-11-02): 공개판의 판 번호만 받아 비교. 보내는 자료 없음
    newer(a, b) {
      const n = (v) => String(v).split('.').map((x) => +x || 0);
      const [x, y] = [n(a), n(b)];
      for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
      return false;
    },
    async checkUpdate() {
      try {
        const j = await (await fetch(`${URL}version.json`, { cache: 'no-store' })).json();
        const mine = chrome.runtime.getManifest().version;
        return D.help.newer(j.version, mine) ? j.version : null;
      } catch { return null; }
    },
    // 일 이름 옆에 붙는 작은 [설명] 단추
    btn(id) { return sectionOf(id) ? `<button class="help-btn" data-help="${D.esc(id)}" title="사용 방법 영상 보기">설명</button>` : ''; },
  };
})();
