// 복무 신청 즐겨찾기(2026-10-30 교사 결정): 자주 쓰는 초과근무·연가(근무상황)·출장 신청을 즐겨찾기로 저장해 두고,
// 고른 날짜마다 나이스 신청 창 줄을 그대로 채운다. 이 파일은 즐겨찾기 모양·검사·줄 만들기만(나이스·패널 코드 없음, 단위 시험).
// 저장은 이 PC(chrome.storage.local 설정 dutyFavs)에만 — 선생님 본인 복무 정보(학생 자료 없음).
(() => {
  const D = globalThis.Doumi;

  const KINDS = {
    overtime: { label: '초과근무', screenId: 'neis.dutyApply.overtime' },
    leave: { label: '연가·조퇴·외출', screenId: 'neis.dutyApply.leave' },
    trip: { label: '출장', screenId: 'neis.dutyApply.trip' },
  };
  // 나이스 코드표(2026-10-30·11-04 실제 창에서 읽음, 교원 창 목록 그대로 — docs/probe/neis-duty-apply-2026-10-30.md). 이름 보여 주기·고르기용
  const LEAVE_LCLF = { W01: '연가', W02: '병가', W03: '공가', W04: '특별휴가', W05: '대체휴무', W06: '결근', W08: '연수', W99: '기타' };
  const LEAVE_SCLF = {
    W01: { W0101: '연가', W0102: '반일연가', W0103: '지각', W0104: '조퇴', W0105: '외출' },
    W02: { W0201: '병가', W0202: '공무상병가', W0203: '반일병가', W0204: '병지각', W0205: '병조퇴', W0206: '병외출', W0207: '공무상병지각', W0208: '공무상병조퇴', W0209: '공무상병외출', W0210: '공무상반일병가' },
    W03: { W0301: '공가' },
    W04: { W0401: '육아시간', W0402: '모성보호시간', W0403: '경조사휴가', W0404: '출산휴가', W0405: '난임치료시술휴가', W0406: '여성보건휴가', W0407: '교권침해교원지원휴가', W0408: '수업휴가', W0409: '포상휴가', W0410: '유산휴가(사산휴가)', W0411: '가족돌봄휴가(유급)', W0412: '가족돌봄휴가(무급)', W0414: '임신검진휴가', W0426: '임신검진동행휴가', W0417: '장기재직휴가', W0418: '학습휴가', W0419: '조리학습휴가', W0420: '퇴직준비휴가', W0422: '재해구호휴가', W0425: '수유시간', W0498: '기타특별휴가' },
    W05: { W0501: '당직휴무', W0502: '일요대체휴무', W0503: '토요대체휴무', W0504: '공휴대체휴무', W0505: '초과근무대체휴무', W0506: '선거사무휴무' },
    W06: { W0601: '무단결근', W0602: '결근', W0603: '무단지각', W0604: '무단조퇴', W0605: '결근(지각)', W0606: '결근(외출)', W0607: '결근(조퇴)', W0608: '무단외출' },
    W08: { W0801: '교육공무원법제41조연수' },
    W99: { W9941: '근무시간면제', W9999: '기타' },
  };
  const AV_RSN = { '': '없음', '00': '휴업일', '01': '1호 생일(본인·배우자 직계존속)', '02': '2호 기일', '03': '3호 가족 간호·위로', '04': '4호 병가 소진 뒤', '05': '5호 방송대 출석·대학원 시험', '06': '6호 부모 형제자매 장례', '07': '7호 형제자매 배우자 장례', '08': '8호 자녀 입영', '09': '9호 학교장 인정' };
  // 소분류 아래 세부(workSittnDtlCd): 소분류 코드 → { 세부 코드: 이름 }
  const LEAVE_DTL = {
    W0403: { '03101': '결혼(본인)', '03102': '결혼(자녀)', '03103': '출산(배우자)', '03104': '사망(배우자, 본인 및 배우자의 부모)', '03105': '사망(본인 및 배우자의 (외)조부모)', '03106': '사망(자녀와 그 자녀의 배우자)', '03107': '사망(본인 및 배우자의 형제자매)', '03108': '입양(본인)', '03109': '출산(배우자_다태아)' },
    W0405: { '05101': '인공수정', '05102': '체외수정(동결 보존)', '05103': '체외수정(난자 채취)' },
    W0410: { '10101': '배우자 유산(사산)', '10102': '15주(105일)이내', '10103': '16주(106일)이상 21주(147일) 이내', '10104': '22주(148일)이상 27주(189일) 이내', '10105': '28주(190일) 이후' },
  };
  // 기본 근무 시각(교사 요청 2026-11-04). 학교마다 다르면 복무 신청 첫 화면에서 바꿈(settings.dutyDay)
  const DAY = { from: '08:30', to: '16:30' };
  const TRIP_SC = { 10: '국내출장(관내)', 20: '국내출장(관외)', 30: '국외출장', 40: '출장(연수)' };
  const OT_TYP = { 1: '시간외 근무' }; // 창이 처음 넣는 값(실제). 다른 종별은 창에서 가져온 즐겨찾기로

  const pad = (n) => String(n).padStart(2, '0');
  // '16:30' · '1630' · '16시30분' → { h: '16', m: '30' }
  function parseTime(t) {
    const s = String(t ?? '').trim();
    if (!s) return null;
    const m = /^(\d{1,2})\s*(?::|시|\.)?\s*(\d{2})?\s*분?$/.exec(s.replace(/\s+/g, '')) || /^(\d{2})(\d{2})$/.exec(s);
    if (!m) return null;
    const h = +m[1], mi = +(m[2] || 0);
    if (h > 24 || mi > 59 || (h === 24 && mi)) return null;
    return { h: pad(h), m: pad(mi) };
  }
  const hm = (t) => { const p = parseTime(t); return p ? `${p.h}:${p.m}` : ''; };
  // 방과후 차감 시간('1:00'·'0:30'·'' → 분)
  const dedMin = (t) => { const p = parseTime(t); return p ? +p.h * 60 + +p.m : 0; };
  const minutes = (t) => { const p = parseTime(t); return p ? +p.h * 60 + +p.m : NaN; };
  const ymdOf = (d) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
  const weekend = (ymd) => [0, 6].includes(new Date(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6, 8)).getDay());

  // 조퇴·외출은 사유를 비우면 '개인 용무'로(교사 요청 2026-11-02)
  const PERSONAL = '개인 용무';
  const isOutCode = (sclf) => /^W(01|11)0[45]$/.test(String(sclf));
  function blank(kind, day = DAY) {
    const base = { id: `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, kind, name: '' };
    if (kind === 'overtime') return { ...base, typ: '1', from: day.to, to: '21:30', deduct: '', todo: '' };
    if (kind === 'leave') return { ...base, lclf: 'W01', sclf: 'W0104', dtl: '', from: day.from, to: day.to, avRsn: '', reason: PERSONAL, desti: '', emg: '' };
    return { ...base, sc: '10', from: day.from, to: day.to, place: '', purpose: '', move: '', car: 'N', pay: 'N', emg: '' };
  }

  // 결재선(교사 결정 2026-11-02): 출장 관내 교감 / 출장 관외·초과근무 교감+교장 / 근무상황은 직접. 즐겨찾기마다 바꿀 수 있음. 사람은 나이스 직위로 그때 찾음(이름 저장 안 함)
  const LINE_NAMES = { auto: '자동', vp: '교감', 'vp+p': '교감 → 교장', none: '직접 고름' };
  function lineFor(f) {
    const v = f.line || 'auto';
    if (v === 'none') return [];
    if (v === 'vp') return ['교감'];
    if (v === 'vp+p') return ['교감', '교장'];
    if (f.kind === 'overtime') return ['교감', '교장'];
    if (f.kind === 'trip') return String(f.sc) === '10' ? ['교감'] : ['교감', '교장'];
    return [];
  }
  // 종류 이름: 소분류, 세부가 있으면 함께
  const leaveName = (f) => [LEAVE_SCLF[f.lclf]?.[f.sclf] || LEAVE_LCLF[f.lclf] || f.sclf, LEAVE_DTL[f.sclf]?.[f.dtl]].filter(Boolean).join(' ');
  // 즐겨찾기 한 줄 요약(첫 화면 단추·목록)
  function summary(f) {
    const time = f.from && f.to ? `${hm(f.from)}~${hm(f.to)}` : '';
    if (f.kind === 'overtime') return [time, dedMin(f.deduct) ? `방과후 차감 ${hm(f.deduct)}` : '', f.todo].filter(Boolean).join(' · ');
    if (f.kind === 'leave') return [leaveName(f), time, f.reason].filter(Boolean).join(' · ');
    return [TRIP_SC[f.sc] || f.sc, time, f.place, f.purpose].filter(Boolean).join(' · ');
  }
  const nameOf = (f) => f.name || `${KINDS[f.kind]?.label || ''} ${summary(f).split(' · ').slice(0, 2).join(' ')}`.trim();

  // 검사: 빨강(넣지 못함) — 시각 모양, 순서, 근무상황·출장의 5분 단위(나이스 분 목록이 00·05…55), 꼭 있어야 하는 칸
  function check(f, { phone = '' } = {}) {
    const errs = [];
    const a = parseTime(f.from), b = parseTime(f.to);
    if (f.from && !a) errs.push('시작 시각 모양이 달라요(예: 16:30).');
    if (f.to && !b) errs.push('끝 시각 모양이 달라요(예: 21:30).');
    if (a && b && minutes(f.to) <= minutes(f.from)) errs.push('끝 시각이 시작보다 늦어야 해요.');
    if (!!f.from !== !!f.to) errs.push('시작과 끝 시각을 함께 적어 주세요.');
    if (f.kind !== 'overtime' && ((a && +a.m % 5) || (b && +b.m % 5))) errs.push('나이스 분 칸이 5분 단위예요(00·05·10…55).');
    if (f.kind === 'overtime') {
      if (!a || !b) errs.push('초과근무 시각을 적어 주세요.');
      if (f.deduct && !parseTime(f.deduct)) errs.push('방과후 차감 시간 모양이 달라요(예: 1:00).');
      else if (a && b && dedMin(f.deduct) >= minutes(f.to) - minutes(f.from)) errs.push('방과후 차감 시간이 초과근무 시간보다 길어요.');
      if (!String(f.todo || '').trim()) errs.push("'하여야 할 일'은 나이스 필수 칸이에요.");
    }
    if (f.kind === 'leave') {
      if (!LEAVE_LCLF[f.lclf]) errs.push('근무상황 종류를 골라 주세요.');
      if (!f.sclf) errs.push('세부 종류를 골라 주세요.');
      if (LEAVE_DTL[f.sclf] && !LEAVE_DTL[f.sclf][f.dtl]) errs.push(`${LEAVE_SCLF[f.lclf]?.[f.sclf] || '이 종류'}의 세부 항목을 골라 주세요.`);
      // 지각·조퇴·외출은 시각이 있어야 함(연가·반일연가는 창 기본)
      if (/W0(103|104|105|204|205|206)$/.test(f.sclf) && (!a || !b)) errs.push(`${LEAVE_SCLF[f.lclf]?.[f.sclf] || '이 종류'}는 시각을 적어 주세요.`);
    }
    if (f.kind === 'trip') {
      if (!TRIP_SC[f.sc]) errs.push('출장 구분을 골라 주세요.');
      if (!a || !b) errs.push('출장 시각을 적어 주세요.');
      if (!String(f.place || '').trim()) errs.push('출장지를 적어 주세요.');
      if (!String(f.purpose || '').trim()) errs.push('출장 목적을 적어 주세요.');
      if (String(f.emg || phone || '').replace(/\D/g, '').length < 9) errs.push('출장은 연락처가 나이스 필수 칸이에요. 복무 신청 첫 화면에 내 연락처를 저장해 두면 저절로 들어가요.');
    }
    return errs;
  }

  // 날짜 하나의 줄 값(즐겨찾기 칸 이름 → 값). 빈 값은 넣지 않음(창 기본 그대로)
  function valuesFor(f, ymd, { phone = '' } = {}) {
    const a = parseTime(f.from), b = parseTime(f.to);
    const v = { date: ymd };
    if (a) { v.fromH = a.h; v.fromM = a.m; }
    if (b) { v.toH = b.h; v.toM = b.m; }
    if (f.kind === 'overtime') {
      v.typ = f.typ || '1';
      v.hldy = weekend(ymd) ? 'Y' : 'N'; // 토·일은 휴일 표시(법정공휴일은 선생님이 창에서 — 나이스 안내: 휴일은 전날 18시 전 사전신청)
      const d = parseTime(f.deduct);
      if (d) { v.dedH = d.h; v.dedM = d.m; }
      v.todo = String(f.todo || '').trim();
    } else if (f.kind === 'leave') {
      Object.assign(v, { lclf: f.lclf, sclf: f.sclf, dtl: f.dtl && f.dtl !== '00000' ? f.dtl : '', avRsn: f.avRsn || '', reason: String(f.reason || '').trim() || (isOutCode(f.sclf) ? PERSONAL : ''), desti: String(f.desti || '').trim(), emg: String(f.emg || phone || '').replace(/\D/g, '') });
    } else {
      Object.assign(v, { sc: f.sc, car: f.car === 'Y' ? 'Y' : 'N', pay: f.pay === 'Y' ? 'Y' : 'N', place: String(f.place || '').trim(), purpose: String(f.purpose || '').trim(), move: String(f.move || '').trim(), emg: String(f.emg || phone || '').replace(/\D/g, '') });
    }
    return v;
  }

  // 화면 설정(apply.fields) 순서대로 넣을 칸 목록 — 엔진 dutyFill에 그대로 넘김
  function plan(f, dates, screen, opts = {}) {
    const fields = screen.apply.fields;
    return [...new Set(dates)].sort().map((ymd) => {
      const v = valuesFor(f, ymd, opts);
      return {
        date: ymd,
        fields: fields.filter((x) => v[x.key] != null && v[x.key] !== '').map((x) => ({ ctl: x.ctl, type: x.type, value: v[x.key], label: x.label, wait: x.wait || 0, col: x.col })),
      };
    });
  }

  // 미리 보기 안내(노랑): 넣을 수는 있지만 선생님이 볼 것
  function notes(f, dates) {
    const out = [];
    const we = dates.filter(weekend);
    if (f.kind === 'overtime') {
      if (we.length) out.push(`토·일(${we.map((d) => `${+d.slice(4, 6)}/${+d.slice(6)}`).join(', ')})은 [휴일]을 켜서 넣어요 — 휴일 초과근무는 전날 18시 전에 올려야 사전신청이에요.`);
      const span = minutes(f.to) - minutes(f.from);
      if (dates.some((d) => !weekend(d)) && span > 5 * 60) out.push('평일은 저녁 1시간을 빼고 하루 4시간까지 잡혀요(나이스가 계산).');
    } else if (we.length) out.push(`토·일(${we.map((d) => `${+d.slice(4, 6)}/${+d.slice(6)}`).join(', ')})이 들어 있어요.`);
    return out;
  }

  // [이 창 내용을 즐겨찾기로]: 나이스 창에서 고른 줄(칼럼 값) → 즐겨찾기
  function fromDialog(kind, values, screen) {
    const f = blank(kind);
    const map = screen.apply.capture;
    const t = (s) => (/^\d{4}$/.test(String(s || '')) ? `${String(s).slice(0, 2)}:${String(s).slice(2)}` : '');
    const parts = {};
    for (const [key, col] of Object.entries(map)) {
      const v = String(values[col] ?? '').trim();
      if (/^(from|to|ded)[HM]$/.test(key)) parts[key] = v;
      else f[key] = key === 'from' || key === 'to' ? t(v) : v;
    }
    // 근무상황·출장은 시·분이 따로(2026-10-30 실제: bgngHm은 승인요청 때 만듦)
    if (parts.fromH && parts.fromM) f.from = `${parts.fromH.padStart(2, '0')}:${parts.fromM.padStart(2, '0')}`;
    if (parts.toH && parts.toM) f.to = `${parts.toH.padStart(2, '0')}:${parts.toM.padStart(2, '0')}`;
    if (+parts.dedH || +parts.dedM) f.deduct = `${String(parts.dedH || '0').padStart(2, '0')}:${String(parts.dedM || '0').padStart(2, '0')}`;
    if (kind === 'trip') { f.car = f.car === 'Y' ? 'Y' : 'N'; f.pay = f.pay === 'Y' ? 'Y' : 'N'; }
    f.name = nameOf({ ...f, name: '' });
    return f;
  }

  // 넣은 뒤 다시 읽은 줄 → 맞는지(날짜·시각) + 나이스 시간합 글
  function verify(f, row, screen) {
    const v = row.values || {};
    const want = valuesFor(f, row.date || v.mtWorkYmd || v.bgngYmd);
    const bad = [];
    const dateCol = f.kind === 'overtime' ? 'mtWorkYmd' : 'bgngYmd';
    if (v[dateCol] && v[dateCol] !== want.date) bad.push('날짜');
    const hm2 = (h, m) => (h && m ? `${h}${m}` : '');
    const from = f.kind === 'overtime' ? v.aplyBgngHm : v.bgngHm || hm2(v.bgngH, v.bgngM) || hm2(v.bgngHh, v.bgngMm);
    const to = f.kind === 'overtime' ? v.aplyEndHm : v.endHm || hm2(v.endH, v.endM) || hm2(v.endHh, v.endMm);
    if (want.fromH && from && from !== `${want.fromH}${want.fromM}`) bad.push('시작 시각');
    if (want.toH && to && to !== `${want.toH}${want.toM}`) bad.push('끝 시각');
    if (want.dtl && v.workSittnDtlCd && v.workSittnDtlCd !== want.dtl) bad.push('세부 항목');
    const T = screen.apply.total || {};
    const num = (c) => (c && v[c] != null && v[c] !== '' ? +v[c] : null);
    const d = num(T.d), h = num(T.h), m = num(T.m);
    const total = [d ? `${d}일` : '', h != null ? `${h}시간` : '', m ? `${m}분` : ''].filter(Boolean).join(' ') || '';
    return { ok: !bad.length, bad, total };
  }

  D.duty = { DAY, LEAVE_DTL, leaveName, PERSONAL, isOutCode, lineFor, LINE_NAMES, dedMin, KINDS, LEAVE_LCLF, LEAVE_SCLF, AV_RSN, TRIP_SC, OT_TYP, parseTime, hm, weekend, ymdOf, blank, summary, nameOf, check, valuesFor, plan, notes, fromDialog, verify };
})();
