// F5 회신 양식 기본 칸 채우기(교사 결정 2026-11-02): 학교명·담당자·직위·연락처·작성일처럼 이름이 정해진 칸 옆 빈칸만 채운 사본을 만든다.
// 조사 내용 칸은 건드리지 않는다. .xlsx·.hwpx만(.hwp는 브라우저에서 고칠 수 없다). 파일은 이 브라우저 안에서만 다룬다. AI 없음.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const norm = (s) => String(s || '').replace(/[\s*:：·※]/g, '');
  // '학교명' 같은 이름표 → 채울 값 열쇠. '성명'처럼 학생일 수 있는 말은 넣지 않는다
  const LABELS = [
    ['school', /^(학교명|학교|기관명|기관|학교\(기관\)명|학교기관명|학교\/기관명)$/],
    ['name', /^(담당자|담당자명|담당자성명|담당교사|담당교사명|작성자|작성자명|작성자성명|담당)$/],
    ['position', /^(직위|직책|담당자직위|직위\(직급\)|직급)$/],
    ['phone', /^(연락처|전화|전화번호|담당자연락처|담당자전화번호|담당자전화|교무실전화|학교전화)$/],
    ['date', /^(작성일|작성일자|제출일|제출일자|작성날짜|작성연월일)$/],
  ];
  const keyOf = (label) => { const n = norm(label); const hit = LABELS.find(([, re]) => re.test(n)); return hit ? hit[0] : ''; };
  const xmlEsc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const NAMES = { school: '학교', name: '담당자', position: '직위', phone: '연락처', date: '작성일' };

  // ── zip 다시 묶기: 고치지 않은 파일은 그대로 풀어서 저장(압축 없음). 순서는 원본대로(hwpx는 mimetype이 먼저여야 함) ──
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = (u8) => { let c = 0xffffffff; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  function packZip(files) {
    const enc = new TextEncoder();
    const parts = [];
    const central = [];
    let offset = 0;
    const u16 = (v) => [v & 0xff, (v >>> 8) & 0xff];
    const u32 = (v) => [v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff];
    for (const [name, data] of files) {
      const nm = enc.encode(name);
      const crc = crc32(data);
      const head = [...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nm.length), ...u16(0)];
      const local = new Uint8Array([...u32(0x04034b50), ...head]);
      parts.push(local, nm, data);
      central.push(new Uint8Array([...u32(0x02014b50), ...u16(20), ...head, ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)]), nm);
      offset += local.length + nm.length + data.length;
    }
    const cdSize = central.reduce((n, p) => n + p.length, 0);
    const end = new Uint8Array([...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(cdSize), ...u32(offset), ...u16(0)]);
    const all = [...parts, ...central, end];
    const out = new Uint8Array(all.reduce((n, p) => n + p.length, 0));
    let at = 0;
    for (const p of all) { out.set(p, at); at += p.length; }
    return out;
  }
  async function unzipAll(buf) {
    const files = D.zip.entries(new Uint8Array(buf));
    const out = [];
    for (const [name, e] of files) {
      if (e.method !== 0 && e.method !== 8) throw new Error('지원하지 않는 압축 방식이에요.');
      out.push([name, e.method === 0 ? e.data : await inflateEntry(e)]);
    }
    return out;
  }
  async function inflateEntry(e) {
    const stream = new Blob([e.data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }
  const dec = (u8) => new TextDecoder().decode(u8);
  const encd = (s) => new TextEncoder().encode(s);

  // ── 한글 .hwpx: 표 줄(hp:tr)에서 이름표 칸 다음 칸이 비어 있으면 그 칸에 글을 넣는다 ──
  const cellText = (tc) => [...tc.matchAll(/<hp:t(?:\s[^>]*)?>([\s\S]*?)<\/hp:t>/g)].map((m) => m[1].replace(/<[^>]+>/g, '')).join('');
  function fillHwpCell(tc, value, charPr) {
    const pm = /<hp:p(?:\s[^>]*)?>[\s\S]*?<\/hp:p>|<hp:p(?:\s[^>]*)?\/>/.exec(tc);
    if (!pm) return null;
    let p = pm[0];
    if (/\/>$/.test(p) && !/<\/hp:p>$/.test(p)) p = `${p.slice(0, -2)}></hp:p>`;
    p = p.replace(/<hp:linesegarray>[\s\S]*?<\/hp:linesegarray>/, ''); // 줄 위치 기록은 지운다(한글이 다시 계산)
    const text = `<hp:t>${xmlEsc(value)}</hp:t>`;
    if (/<hp:t\s*\/>/.test(p)) p = p.replace(/<hp:t\s*\/>/, text);
    else if (/<hp:t(?:\s[^>]*)?><\/hp:t>/.test(p)) p = p.replace(/<hp:t(?:\s[^>]*)?><\/hp:t>/, text);
    else if (/<hp:run\b[^>]*\/>/.test(p)) p = p.replace(/<hp:run\b([^>]*)\/>/, `<hp:run$1>${text}</hp:run>`);
    else if (/<hp:run\b[^>]*><\/hp:run>/.test(p)) p = p.replace(/(<hp:run\b[^>]*>)<\/hp:run>/, `$1${text}</hp:run>`);
    else p = p.replace(/<\/hp:p>$/, `<hp:run charPrIDRef="${charPr || 0}">${text}</hp:run></hp:p>`);
    return tc.slice(0, pm.index) + p + tc.slice(pm.index + pm[0].length);
  }
  function fillHwpSection(xml, values, filled) {
    return xml.replace(/<hp:tr(?:\s[^>]*)?>[\s\S]*?<\/hp:tr>/g, (tr) => {
      const cells = [...tr.matchAll(/<hp:tc(?:\s[^>]*)?>[\s\S]*?<\/hp:tc>/g)];
      if (cells.length < 2 || /<hp:tbl\b/.test(tr)) return tr; // 표 안의 표는 건드리지 않음
      let out = tr;
      for (let i = 0; i < cells.length - 1; i++) {
        const key = keyOf(cellText(cells[i][0]));
        if (!key || !values[key] || filled.includes(key)) continue;
        if (cellText(cells[i + 1][0]).trim()) continue; // 이미 적혀 있으면 그대로
        const charPr = (/<hp:run\b[^>]*charPrIDRef="(\d+)"/.exec(cells[i][0]) || [])[1];
        const next = fillHwpCell(cells[i + 1][0], values[key], charPr);
        if (next) { out = out.replace(cells[i + 1][0], next); filled.push(key); }
      }
      return out;
    });
  }

  // ── 엑셀 .xlsx: 이름표 칸 오른쪽(합친 칸이면 그 다음) 칸이 비어 있으면 글을 넣는다 ──
  const colToNum = (c) => [...c].reduce((n, ch) => n * 26 + ch.charCodeAt(0) - 64, 0);
  const numToCol = (n) => { let s = ''; for (; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s; return s; };
  function sharedList(xml) {
    if (!xml) return [];
    return [...xml.matchAll(/<si(?:\s[^>]*)?>([\s\S]*?)<\/si>/g)].map((m) => [...m[1].matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map((t) => D.zip.unescape(t[1])).join(''));
  }
  function cellValue(c, shared) {
    if (/\bt="s"/.test(c.attrs)) { const m = /<v>(\d+)<\/v>/.exec(c.body); return m ? shared[+m[1]] || '' : ''; }
    if (/\bt="inlineStr"/.test(c.attrs)) return [...c.body.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map((t) => D.zip.unescape(t[1])).join('');
    const m = /<v>([\s\S]*?)<\/v>/.exec(c.body);
    return m ? D.zip.unescape(m[1]) : '';
  }
  function fillSheet(xml, shared, values, filled) {
    const merges = {};
    for (const m of xml.matchAll(/<mergeCell\s+ref="([A-Z]+)(\d+):([A-Z]+)(\d+)"/g)) merges[`${m[1]}${m[2]}`] = colToNum(m[3]);
    return xml.replace(/<row\b([^>]*)>([\s\S]*?)<\/row>/g, (row, rowAttrs, inner) => {
      const cells = [...inner.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)].map((m) => {
        const ref = /\br="([A-Z]+)(\d+)"/.exec(m[1]);
        return { raw: m[0], attrs: m[1], body: m[2] || '', col: ref ? colToNum(ref[1]) : 0, rowNo: ref ? ref[2] : '', ref: ref ? `${ref[1]}${ref[2]}` : '' };
      });
      let out = inner;
      for (const c of cells) {
        const key = keyOf(cellValue(c, shared));
        if (!key || !values[key] || filled.includes(key)) continue;
        const toCol = (merges[c.ref] || c.col) + 1;
        const target = cells.find((x) => x.col === toCol);
        if (target && cellValue(target, shared).trim()) continue;
        const style = target ? (/\bs="(\d+)"/.exec(target.attrs) || [])[1] : (/\bs="(\d+)"/.exec(c.attrs) || [])[1];
        const ref = `${numToCol(toCol)}${c.rowNo}`;
        const newCell = `<c r="${ref}"${style ? ` s="${style}"` : ''} t="inlineStr"><is><t>${xmlEsc(values[key])}</t></is></c>`;
        if (target) out = out.replace(target.raw, newCell);
        else {
          const after = cells.filter((x) => x.col < toCol).pop();
          out = after ? out.replace(after.raw, after.raw + newCell) : newCell + out;
        }
        filled.push(key);
      }
      return `<row${rowAttrs}>${out}</row>`;
    });
  }

  /**
   * values: { school, name, position, phone, date } (빈 값은 안 채움)
   * → { bytes(Uint8Array), name('원래 이름(채움).xlsx'), filled: ['school', …], names: ['학교', …] }
   */
  async function fill(fileName, buf, values) {
    const isXlsx = /\.xlsx$/i.test(fileName);
    const isHwpx = /\.hwpx$/i.test(fileName);
    if (/\.hwp$/i.test(fileName)) return { ok: false, error: '한글 .hwp는 도우미가 고칠 수 없어요. 열어서 직접 적어 주세요(한글에서 .hwpx로 저장하면 채워 드려요).' };
    if (!isXlsx && !isHwpx) return { ok: false, error: '양식은 엑셀(.xlsx)·한글(.hwpx)만 채울 수 있어요.' };
    let files;
    try { files = await unzipAll(buf); } catch { return { ok: false, error: '이 파일을 열지 못했어요(암호·문서 보안이 걸렸을 수 있어요). 열어서 직접 적어 주세요.' }; }
    const filled = [];
    if (isHwpx) {
      if (!files.some(([n]) => /^Contents\/section\d+\.xml$/i.test(n))) return { ok: false, error: '한글(.hwpx) 문서가 아니거나 손상됐어요.' };
      files = files.map(([n, d]) => (/^Contents\/section\d+\.xml$/i.test(n) ? [n, encd(fillHwpSection(dec(d), values, filled))] : [n, d]));
    } else {
      const sharedEntry = files.find(([n]) => n === 'xl/sharedStrings.xml');
      const shared = sharedList(sharedEntry ? dec(sharedEntry[1]) : '');
      if (!files.some(([n]) => /^xl\/worksheets\/sheet\d+\.xml$/i.test(n))) return { ok: false, error: '엑셀(.xlsx) 파일이 아니거나 손상됐어요.' };
      files = files.map(([n, d]) => (/^xl\/worksheets\/sheet\d+\.xml$/i.test(n) ? [n, encd(fillSheet(dec(d), shared, values, filled))] : [n, d]));
    }
    const dot = fileName.lastIndexOf('.');
    return { ok: true, bytes: packZip(files), name: `${fileName.slice(0, dot)}(채움)${fileName.slice(dot)}`, filled, names: filled.map((k) => NAMES[k]) };
  }

  D.formFill = { fill, keyOf, packZip, NAMES };
})();
