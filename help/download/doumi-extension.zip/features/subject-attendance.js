// N7 과목별출결 — 자료(날짜·교시·반·번호·이름·구분·사유) 해석 → 수업(날짜·교시·반)별로 나누기 → 나이스 학생 목록과 비교 → 입력 계획
// 과목별출결 칸(chulScCd)은 '/' 결과, 'Ø' 출석인정결과, '' 출석 세 가지뿐이다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;

  // 구분 낱말 → 표시. 결석·지각·조퇴도 과목 시간에는 모두 '결과'(/)로 찍힌다.
  const MARK_WORDS = {
    '/': ['결과', '결', '결석', '지각', '조퇴', '미인정', '무단', '질병', '병결', '기타', '미인정결과', '질병결과', '기타결과', '/', 'x', 'X', '×'],
    'Ø': ['출석인정', '인정', '출석인정결과', '인정결과', '공결', 'Ø', 'ø', '∅'],
    '': ['출석', '출', '정상', 'o', 'O', '○', '-'],
  };
  const MARK = new Map(Object.entries(MARK_WORDS).flatMap(([m, ws]) => ws.map((w) => [D.squash(w), m])));
  const markOf = (t) => (MARK.has(D.squash(t)) ? MARK.get(D.squash(t)) : undefined);

  const HEAD = {
    date: ['날짜', '일자', '출결일'], period: ['교시'], cls: ['반', '학반', '반명', '학급'], studentId: ['학번'],
    no: ['번호', '번'], name: ['이름', '성명', '학생'], mark: ['구분', '출결', '상태', '결과', '출결상태'], reason: ['사유', '비고', '메모'],
    subject: ['과목', '과목명'],
  };
  const headField = (c) => { const s = D.squash(c); return Object.keys(HEAD).find((f) => HEAD[f].includes(s)) || null; };

  // '1-3', '1학년3반', '1학년 3반', '3반' → { grade, cls }
  function parseClass(t) {
    const s = D.squash(t);
    let m = /^(\d)[-./](\d{1,2})$/.exec(s) || /^(\d)학년(\d{1,2})반$/.exec(s);
    if (m) return { grade: String(+m[1]), cls: String(+m[2]) };
    m = /^(\d{1,2})반$/.exec(s);
    return m ? { grade: '', cls: String(+m[1]) } : null;
  }
  const classLabel = (c) => (c ? `${c.grade ? `${c.grade}학년 ` : ''}${c.cls}반` : '');
  // 선택과목 수업 반(여러 반 학생이 섞임)은 나이스 이름이 '3학년 302(경제 수학)', '2학년 201(F)(미적분Ⅰ)', '3학년 건강예술실(F)(과학사)' 꼴(2026-10-28 실제 확인).
  // 과목 괄호를 떼고 학년을 뗀 글로 비교: '302', '201(F)', '건강예술실(F)'
  const normGroup = (s) => D.squash(s).replace(/^\d학년/, '');
  const groupLabel = (row, P) => { const sb = String(row[P.subject] ?? '').trim(); let t = String(row[P.cls] ?? '').trim(); if (sb && t.endsWith(`(${sb})`)) t = t.slice(0, -sb.length - 2); return t.trim(); };
  // 학번 10305 → 1학년 3반 5번
  function fromStudentId(s) {
    const d = String(s).replace(/\D/g, '');
    if (d.length === 5) return { cls: { grade: String(+d[0]), cls: String(+d.slice(1, 3)) }, no: String(+d.slice(3)) };
    if (d.length === 4) return { cls: { grade: String(+d[0]), cls: String(+d[1]) }, no: String(+d.slice(2)) };
    return { cls: null, no: D.normNo(d) };
  }
  const parsePeriod = (t) => { const m = /^(\d{1,2})교시$/.exec(D.squash(t)); return m ? String(+m[1]) : ''; };

  const blank = (line) => ({ line, dates: [], pir: '', cls: null, group: '', no: '', name: '', mark: null, markText: '', reason: null, issues: [] });

  function addDate(item, t, year) {
    const s = String(t).replace(/\s*~\s*/g, '~').trim();
    if (D.isDateRangeToken(s)) {
      const r = D.expandDateRange(s, year);
      if (r.error) item.issues.push(r.error);
      item.dates.push(...r.dates);
      return;
    }
    const d = D.normDate(s, year);
    if (d) item.dates.push(d); else item.issues.push(`날짜를 알 수 없어요: "${t}"`);
  }

  function finish(item) {
    if (!item.pir) item.issues.push('교시가 없어요 (예: 3교시).');
    if (!item.no && !item.name) item.issues.push('번호나 이름이 없어요.');
    if (item.mark === null) item.issues.push(item.markText ? `구분을 알 수 없어요: "${item.markText}" (결과·출석인정·출석)` : '구분이 없어요 (결과·출석인정·출석).');
    return item;
  }

  function parseHeader(lines, sep, fields, opts) {
    return lines.map((l) => {
      const cells = sep ? D.splitCells(l.raw, sep) : l.raw.trim().split(/\s+/);
      const get = (f) => { const i = fields.indexOf(f); return i >= 0 ? String(cells[i] ?? '').trim() : ''; };
      const it = blank(l.no);
      if (get('date')) addDate(it, get('date'), opts.year);
      it.pir = parsePeriod(get('period')) || D.normNo(get('period'));
      if (get('studentId')) Object.assign(it, fromStudentId(get('studentId')));
      if (get('cls')) { const pc = parseClass(get('cls')); if (pc) it.cls = pc; else it.group = normGroup(get('cls')); }
      // 번호 칸에 학번(4~5자리)이 오면 학번으로(수업 출석부는 여러 반 학생이 섞여 학번을 씀)
      if (get('no')) { const n = get('no').replace(/\D/g, ''); if (n.length >= 4) Object.assign(it, fromStudentId(n)); else it.no = D.normNo(n); }
      it.name = D.squash(get('name'));
      it.markText = get('mark');
      const m = markOf(it.markText);
      it.mark = it.markText === '' ? null : m === undefined ? null : m;
      it.reason = get('reason') || null;
      return finish(it);
    });
  }

  // 머리줄 없는 한 줄: "10/27 3교시 1-3 5 박서연 결과 병원", "3교시 10305 인정 대회"
  function parseFree(line, opts) {
    const raw = line.raw.replace(/\s*~\s*/g, '~');
    const it = blank(line.no);
    const re = /[^\s,\t]+/g;
    let m, rest = null;
    while ((m = re.exec(raw))) {
      const t = m[0].replace(/^"|"$/g, '');
      if (D.isDateToken(t) || D.isDateRangeToken(t)) { addDate(it, t, opts.year); continue; }
      if (parsePeriod(t)) { it.pir = parsePeriod(t); continue; }
      if (parseClass(t)) { it.cls = parseClass(t); continue; }
      if (/^\d+$/.test(t)) {
        if (t.length >= 4) Object.assign(it, fromStudentId(t));
        else if (!it.no) it.no = D.normNo(t);
        else it.issues.push(`무엇인지 모르는 숫자: "${t}"`);
        continue;
      }
      const mk = markOf(t);
      if (mk !== undefined) { it.mark = mk; it.markText = t; rest = raw.slice(re.lastIndex); break; }
      if (!it.name && /^[가-힣A-Za-z]{2,10}$/.test(t)) { it.name = t; continue; }
      it.issues.push(`무엇인지 모르는 말: "${t}"`);
    }
    if (rest !== null) it.reason = rest.replace(/^[\s,\t"]+|[\s,\t"]+$/g, '') || null;
    return finish(it);
  }

  function parse(text, opts = {}) {
    const lines = D.lines(text);
    if (!lines.length) return { items: [], issues: [] };
    const first = lines[0].raw;
    const sep = first.includes('\t') ? '\t' : first.includes(',') ? ',' : null;
    const fields = (sep ? D.splitCells(first, sep) : first.trim().split(/\s+/)).map(headField);
    if (fields.filter(Boolean).length >= 2) {
      const issues = [];
      if (!fields.includes('period')) issues.push('자료에 교시 칸이 없어요.');
      if (!fields.includes('mark')) issues.push('자료에 구분 칸(결과·출석인정·출석)이 없어요.');
      return { items: parseHeader(lines.slice(1), sep, fields, opts), issues };
    }
    return { items: lines.map((l) => parseFree(l, opts)), issues: [] };
  }

  // 수업(날짜·교시·반)별로 나누기. 날짜 없는 줄은 기본 날짜(오늘).
  function split(parsed, defaultDate) {
    const groups = new Map();
    for (const it of parsed.items) {
      for (const date of it.dates.length ? [...new Set(it.dates)] : [defaultDate]) {
        const key = `${date}|${it.pir}|${it.group ? `g:${it.group}` : it.cls ? `${it.cls.grade}-${it.cls.cls}` : ''}`;
        // 수업 반 이름(group)이 있으면 그것으로 수업을 찾고, 학생의 반(cls, 학번에서)은 학생을 고를 때만 씀
        if (!groups.has(key)) groups.set(key, { key, date, pir: it.pir, cls: it.group ? null : it.cls, group: it.group, items: [] });
        groups.get(key).items.push({ ...it, date, issues: [...it.issues] });
      }
    }
    return [...groups.values()].sort((a, b) => a.key.localeCompare(b.key, 'ko', { numeric: true }));
  }

  // 나이스 수업 목록 줄이 이 반인지: 반 이름에서 숫자를 뽑아 비교(학년은 줄의 grd 또는 반 이름)
  function classOfRow(row, P) {
    const nums = String(row[P.cls] ?? '').match(/\d+/g) || [];
    const grade = nums.length >= 2 ? String(+nums[0]) : String(+(row.grd || 0) || '');
    const cls = nums.length ? String(+nums[nums.length - 1]) : String(+String(row[P.clsCd] ?? '').slice(-2) || '');
    return { grade, cls };
  }
  const sameClass = (a, b) => !!a && !!b && a.cls === b.cls && (!a.grade || !b.grade || a.grade === b.grade);

  // 그 날 수업 목록에서 이 묶음(교시·반)의 줄 찾기
  function findPeriod(group, periodRows, screen) {
    const P = screen.periods;
    let hits = periodRows.filter((r) => D.normNo(r[P.pir]) === group.pir);
    // 수업 반 이름은 과목까지 붙은 나이스 목록 글 그대로('3학년 302(경제 수학)')로 적어도 맞춘다(2026-10-29 실제 모양)
    if (group.group) hits = hits.filter((r) => normGroup(groupLabel(r, P)) === group.group || normGroup(r[P.cls]) === group.group);
    else if (group.cls) hits = hits.filter((r) => sameClass(classOfRow(r, P), group.cls));
    if (!hits.length) return { error: `${D.showDay(group.date)} ${group.pir}교시${group.group ? ` ${group.group}` : group.cls ? ` ${classLabel(group.cls)}` : ''} 수업이 나이스 목록에 없어요.` };
    if (hits.length > 1) return { error: `${D.showDay(group.date)} ${group.pir}교시 수업이 여러 반이에요. 자료에 반(나이스 수업 반 이름 그대로, 예: 302)을 적어 주세요.` };
    return { row: hits[0] };
  }

  function pickArgs(screen, periodRow) {
    const P = screen.periods;
    return {
      appId: screen.appId, grid: P.grid, dataset: P.dataset, target: screen.dataset, dataMap: screen.search.dataMap,
      match: { [P.pir]: periodRow[P.pir], [P.clsCd]: periodRow[P.clsCd], etbSbjtCd: periodRow.etbSbjtCd },
      copy: P.copy, verify: P.verify, submission: P.submission,
    };
  }

  function readStudentsArgs(screen) {
    const K = screen.key, C = screen.columns;
    return { appId: screen.appId, dataset: screen.dataset, columns: [K.no, K.name, K.cls, K.sameName, C.mark, C.reason, ...C.closed, 'grd', 'clsCd'] };
  }
  function readPeriodsArgs(screen) {
    const P = screen.periods;
    return {
      appId: screen.appId, dataset: P.dataset,
      columns: [...new Set([P.pir, P.subject, P.cls, P.clsCd, P.closed, 'grd', 'etbSbjtCd', ...Object.values(P.copy).map((c) => (typeof c === 'string' ? c : c.col))])],
      dataMaps: { [screen.search.dataMap]: [screen.search.date] },
    };
  }

  // 학생 목록과 비교
  // choices[번호] === 'neis': 나이스에 이미 있는 표시('/'·'Ø')와 자료 표시가 다른 줄을 '나이스 그대로'(교사 결정 2026-10-30 — 일일출결과 같음)
  function compare({ group, rows, screen, verified = false, budget = Infinity, choices = {} }) {
    const K = screen.key, C = screen.columns;
    const issues = [];
    if (!rows.length) issues.push('이 수업의 학생 목록이 비어 있어요.');
    const multiClass = new Set(rows.map((r) => String(r[K.cls] ?? ''))).size > 1;
    const taken = new Map();
    const out = group.items.map((it) => {
      const res = { line: it.line, no: it.no, name: it.name, kindText: it.markText, neisName: '', issues: [...it.issues], warnings: [], cur: null, next: null, set: null, row: null, status: 'error' };
      let cand = rows;
      if (multiClass && it.cls) cand = rows.filter((r) => sameClass(classOfRow({ ...r, [screen.periods.cls]: r[K.cls] }, { cls: screen.periods.cls, clsCd: '' }), it.cls));
      else if (multiClass && it.no) res.issues.push('이 수업에는 여러 반 학생이 있어요. 반(예: 1-3)이나 학번을 적어 주세요.');
      let row = null;
      if (!res.issues.length && it.no) {
        const hits = cand.filter((r) => D.normNo(r[K.no]) === it.no);
        if (hits.length !== 1) res.issues.push(hits.length ? `${it.no}번이 여러 명이에요.` : `${it.no}번 학생이 이 수업에 없어요.`);
        else {
          row = hits[0];
          if (it.name && D.squash(row[K.name]) !== D.squash(it.name)) res.issues.push(`이름이 달라요 (나이스: ${row[K.name]})`);
          if (!it.name) res.warnings.push('번호로만 맞췄어요. 이름을 확인해 주세요.');
        }
      } else if (!res.issues.length && it.name) {
        const hits = cand.filter((r) => D.squash(r[K.name]) === D.squash(it.name));
        if (hits.length !== 1) res.issues.push(hits.length ? '같은 이름이 있어요. 번호를 함께 적어 주세요.' : '이 이름이 이 수업에 없어요.');
        else row = hits[0];
      }
      if (row) {
        res.neisName = row[K.name];
        res.neisNo = D.normNo(row[K.no]);
        if (taken.has(row._row)) res.issues.push(`${taken.get(row._row)}번째 줄과 같은 학생이에요.`); else taken.set(row._row, it.line);
        if (C.closed.some((c) => String(row[c] ?? '').trim() === 'Y')) res.issues.push('마감된 출결이에요. 마감 취소는 나이스에서 직접 해 주세요.');
        res.cur = { kind: String(row[C.mark] ?? ''), reason: String(row[C.reason] ?? '') };
      }
      if (res.cur && it.mark !== null) {
        const reason = it.mark === '' ? '' : it.reason !== null ? it.reason : res.cur.reason;
        res.next = { kind: it.mark, reason };
        if (screen.reasonMaxBytes && D.bytes(reason) > screen.reasonMaxBytes) res.issues.push(`사유가 너무 길어요 (${D.bytes(reason)}/${screen.reasonMaxBytes}바이트).`);
        const set = {};
        if (res.next.kind !== res.cur.kind) set[C.mark] = res.next.kind;
        if (res.next.reason !== res.cur.reason) set[C.reason] = res.next.reason;
        res.set = set;
        res.row = row;
      }
      res.status = res.issues.length ? 'error' : res.set && Object.keys(res.set).length ? 'change' : 'same';
      if (res.status === 'change' && res.cur.kind !== '' && res.next.kind !== res.cur.kind) {
        res.conflict = true;
        if (choices[res.neisNo || res.no] === 'neis') { res.status = 'keep'; res.would = res.set; res.set = null; }
      }
      return res;
    });
    const changes = out.filter((r) => r.status === 'change');
    if (!verified && changes.length > budget) issues.push('처음에는 1건만 넣을 수 있어요. 나이스에서 결과를 확인하면 전체 입력이 열려요.');
    const errors = out.filter((r) => r.status === 'error').length;
    const canApply = !issues.length && !errors && changes.length > 0;
    return {
      rows: out, issues, notes: [],
      summary: { change: changes.length, same: out.filter((r) => r.status === 'same').length, error: errors, untouched: Math.max(0, rows.length - taken.size) },
      canApply,
      plan: canApply ? {
        appId: screen.appId, dataset: screen.dataset, grid: screen.grid, keyColumns: [K.no, K.name],
        rows: changes.map((r) => ({
          key: { [K.no]: r.row[K.no], [K.name]: r.row[K.name] },
          expect: { [C.mark]: r.row[C.mark] ?? '', [C.reason]: r.row[C.reason] ?? '' },
          set: r.set,
        })),
      } : null,
    };
  }

  const groupTitle = (g) => `${D.showDay(g.date)} ${g.pir}교시${g.group ? ` · ${g.group}` : g.cls ? ` · ${classLabel(g.cls)}` : ''}`;

  const classOf = (row, screen) => classOfRow(row, screen.periods);

  // 출석부 명단용 학생: 여러 반 학생이 섞인 수업(선택과목)은 번호가 겹치므로 학번으로 — 학년+반+번호 2자리(예 2103, 교사 요청 2026-10-28), 10반 이상이면 반도 2자리(21003)
  function rosterStudents(rows) {
    const mixed = new Set(rows.map((x) => `${x.grd}|${x.clsCd}`)).size > 1;
    const p2 = (v) => String(+String(v ?? '').replace(/\D/g, '').slice(-2) || 0).padStart(2, '0');
    const cls = (v) => { const n = +String(v ?? '').replace(/\D/g, '').slice(-2) || 0; return String(n); };
    const sid = (x) => (x.grd ? `${+x.grd}${cls(x.clsCd)}${p2(x.clsNo)}` : D.normNo(x.clsNo));
    return rows.map((x) => ({ no: mixed && x.grd ? sid(x) : D.normNo(x.clsNo), sid: sid(x), name: D.squash(x.stuFlnm) }));
  }

  // 출석부 명단용: 여러 주 수업 목록에서 정규 수업만. 2주 이상 나온 반|과목 = 정규, 한 주만 = 교체·보강(교사 요청 2026-10-28).
  // classes: [{ key, weeks: Set }], weeksWithData: 자료가 있던 주 수, include: 교사가 다시 넣은 key
  function splitRegular(classes, weeksWithData, include = []) {
    const isRegular = (c) => weeksWithData < 2 || c.weeks.size >= 2 || include.includes(c.key);
    return { regular: classes.filter(isRegular), skipped: classes.filter((c) => !isRegular(c)) };
  }

  D.subject = { parse, split, findPeriod, pickArgs, readStudentsArgs, readPeriodsArgs, compare, groupTitle, classLabel, markOf, classOf, splitRegular, groupLabel, normGroup, rosterStudents };
})();
