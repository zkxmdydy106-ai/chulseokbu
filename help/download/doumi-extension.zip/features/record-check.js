// V1 생기부 점검 — 입력 전에 글을 살펴 '확인 필요'를 알린다. 막지는 않는다(바이트 초과만 입력 확인 단계에서 막음).
// - 기재요령 확인 낱말: extension/rules/record-check-<연도>.js
// - 문장 모양: 마침표·'~함.'꼴 끝맺음·띄어쓰기 두 번·문장부호 앞 빈칸·괄호 짝
// - 학생 사이 같은 문장·비슷한 문장(글자 두 개씩 묶어 비교)
// 맞춤법 전체 검사는 외부 서비스가 필요해 하지 않는다(학생 글을 밖으로 보내지 않음).
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const flat = (s) => String(s ?? '').replace(/\s+/g, '').toLowerCase();

  // 걸린 낱말 → [{ cat, word, note }]
  function words(text, rules = D.recordRules) {
    if (!rules) return [];
    const t = flat(text);
    const out = [];
    for (const cat of rules.categories) {
      const ex = (cat.except || []).map(flat);
      for (const w of cat.words) {
        const f = flat(w);
        let i = t.indexOf(f);
        let hit = false;
        while (i >= 0 && !hit) {
          // 예외 말(예: '교외체험학습') 안에 들어 있는 경우는 건너뛴다
          const inside = ex.some((e) => { const k = e.indexOf(f); return k >= 0 && t.slice(i - k, i - k + e.length) === e; });
          if (!inside) hit = true;
          i = t.indexOf(f, i + 1);
        }
        if (hit) { out.push({ cat: cat.name, word: w, note: cat.note }); break; }
      }
    }
    return out;
  }

  // 한글 글자의 받침이 ㅁ인지 (~함, ~임, ~음, ~됨, ~남 …)
  const endsWithM = (ch) => { const c = ch.charCodeAt(0) - 0xac00; return c >= 0 && c < 11172 && c % 28 === 16; };
  const sentences = (text) => String(text ?? '').split(/(?<=[.!?])\s+|\n+/).map((s) => s.trim()).filter(Boolean);

  function form(text) {
    const t = String(text ?? '').trim();
    const out = [];
    if (!t) return out;
    if (!/[.!?]["'”’)]*$/.test(t)) out.push('마지막 문장에 마침표가 없어요.');
    const odd = sentences(t).filter((s) => {
      const body = s.replace(/[.!?]+["'”’)\]]*$/, '').replace(/["'”’)\]]+$/, '');
      const last = body.slice(-1);
      return /[가-힣]/.test(last) && !endsWithM(last);
    });
    if (odd.length) out.push(`'~함.'·'~임.'꼴이 아닌 문장 끝 ${odd.length}곳 (예: "…${odd[0].slice(-8)}")`);
    if (/[^\s] {2,}[^\s]/.test(t)) out.push('띄어쓰기가 두 번 된 곳이 있어요.');
    if (/\s[.,)\]]/.test(t)) out.push('문장부호 앞에 빈칸이 있어요.');
    if (/[가-힣a-z)][.,][가-힣]/i.test(t)) out.push('마침표·쉼표 뒤에 띄어쓰기가 없는 곳이 있어요.');
    if (/\.\.|,,/.test(t.replace(/\.{3}|…/g, ''))) out.push('문장부호가 겹친 곳이 있어요.');
    const open = (t.match(/[(（]/g) || []).length, close = (t.match(/[)）]/g) || []).length;
    if (open !== close) out.push('괄호 짝이 맞지 않아요.');
    return out;
  }

  // 한 학생 글 점검 → 알림 문장들
  // 맞춤법·띄어쓰기(내장 규칙 rules/spelling-*.js, 외부 검사기 없음)
  function spelling(t, rules = D.spellRules) {
    if (!rules) return [];
    const out = [];
    const s = String(t || '');
    for (const [kind, list] of [['맞춤법', rules.words || []], ['띄어쓰기', rules.spacing || []]]) {
      for (const [bad, good, note] of list) {
        if (bad === good || !s.includes(bad)) continue;
        out.push(`${kind} 확인 — '${bad}' → '${good}'${note ? ` (${note})` : ''}`);
      }
    }
    return out.slice(0, 5);
  }
  function text(t, rules = D.recordRules) {
    return [...words(t, rules).map((w) => `기재요령 확인 — '${w.word}' (${w.cat}): ${w.note}`), ...form(t), ...spelling(t)];
  }

  // 글자 두 개씩 묶음(멀티셋)
  function bigrams(s) {
    const m = new Map();
    for (let i = 0; i < s.length - 1; i++) { const b = s.slice(i, i + 2); m.set(b, (m.get(b) || 0) + 1); }
    return m;
  }
  function dice(a, b) {
    let common = 0;
    const [x, y] = a.m.size < b.m.size ? [a.m, b.m] : [b.m, a.m];
    for (const [k, n] of x) { const o = y.get(k); if (o) common += Math.min(n, o); }
    return (2 * common) / (a.n + b.n);
  }

  // 학생 사이 같은·비슷한 문장. items: [{ id, label, text }] → Map(id → [알림])
  function across(items, rules = D.recordRules) {
    const limit = rules?.similarity ?? 0.8;
    const min = rules?.minSentence ?? 15;
    const all = [];
    for (const it of items) {
      for (const s of sentences(it.text)) {
        const f = flat(s).replace(/[^0-9a-z가-힣]/g, '');
        if (f.length < min) continue;
        all.push({ it, s, f, m: bigrams(f), n: f.length - 1 });
      }
    }
    const found = new Map(); // id → Map(상대 id → { same, best, sample })
    const note = (a, b, sim) => {
      if (!found.has(a.it.id)) found.set(a.it.id, new Map());
      const per = found.get(a.it.id);
      const cur = per.get(b.it.id);
      if (!cur || sim > cur.sim) per.set(b.it.id, { other: b.it.label, sim, sample: a.s });
    };
    for (let i = 0; i < all.length; i++) {
      for (let j = i + 1; j < all.length; j++) {
        const a = all[i], b = all[j];
        if (a.it.id === b.it.id) continue;
        if ((2 * Math.min(a.n, b.n)) / (a.n + b.n) < limit) continue;
        const sim = a.f === b.f ? 1 : dice(a, b);
        if (sim < limit) continue;
        note(a, b, sim); note(b, a, sim);
      }
    }
    const out = new Map();
    for (const [id, per] of found) {
      const list = [...per.values()].sort((x, y) => y.sim - x.sim);
      const msgs = list.slice(0, 3).map((x) => `${x.other}와(과) ${x.sim === 1 ? '같은' : `비슷한(${Math.round(x.sim * 100)}%)`} 문장: "${x.sample.slice(0, 18)}…"`);
      if (list.length > 3) msgs.push(`그 밖에 ${list.length - 3}명과 겹치는 문장이 있어요.`);
      out.set(id, msgs);
    }
    return out;
  }

  D.recordCheck = { words, form, spelling, text, across, sentences };
})();
