// 공문 형식·오타 검사와 고치기 제안(화면과 무관한 순수 로직. 패널과 node 시험 양쪽에서 돈다). AI·외부 검사기 없음.
// 입력: { title, body } → issues: [{ level: 'err'|'warn', kind, where: 'title'|'body', line, at, len, word, fix, text }]
//   at·len: 그 칸 글자 안의 위치, fix: 바꿀 글(없으면 눈으로 고칠 것). applyOne/applyAll로 고친다.
// 표기 기준: 행정업무운영 편람 — 날짜 2026. 11. 2.(월), 시각 14:30, 금액 금113,560원(금일십일만삼천오백육십원), 항목 1. 가. 1) 가) (1) (가) ① ㉮, 붙임 뒤 두 칸, 끝에 두 칸 '끝.'
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const GA = '가나다라마바사아자차카타파하';
  const CIRCLE = '①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮';
  const CIRCLE_GA = '㉮㉯㉰㉱㉲㉳㉴㉵㉶㉷㉸㉹㉺㉻';

  // 줄 머리 항목 기호 → { level, index, mark, indent, rest }
  const MARKS = [
    { level: 0, re: /^(\d{1,2})\.(?=\s|\S)/, idx: (m) => +m[1] - 1 },
    { level: 1, re: /^([가-하])\.(?=\s|\S)/, idx: (m) => GA.indexOf(m[1]) },
    { level: 2, re: /^(\d{1,2})\)/, idx: (m) => +m[1] - 1 },
    { level: 3, re: /^([가-하])\)/, idx: (m) => GA.indexOf(m[1]) },
    { level: 4, re: /^\((\d{1,2})\)/, idx: (m) => +m[1] - 1 },
    { level: 5, re: /^\(([가-하])\)/, idx: (m) => GA.indexOf(m[1]) },
    { level: 6, re: /^([①-⑮])/, idx: (m) => CIRCLE.indexOf(m[1]) },
    { level: 7, re: /^([㉮-㉻])/, idx: (m) => CIRCLE_GA.indexOf(m[1]) },
  ];
  function parseMark(line) {
    const indent = /^ */.exec(line)[0].length;
    const body = line.slice(indent);
    for (const k of MARKS) {
      const m = k.re.exec(body);
      if (!m) continue;
      // '2026. 11. 2.' 처럼 날짜로 시작하는 줄은 항목이 아니다(숫자 기호는 두 자리까지만)
      return { level: k.level, index: k.idx(m), mark: m[0], indent, rest: body.slice(m[0].length) };
    }
    return null;
  }
  const markOf = (level, i) => (D.draft ? D.draft.mark(level, i) : '');

  // ── 한 줄 글자 규칙 ──
  // make(…, m) → 바꿀 글. 같은 자리를 두 규칙이 잡으면 먼저 찾은 것만 남긴다
  function dateFix(y, mo, d, tail = '') { return `${+y}. ${+mo}. ${+d}.${tail}`; }
  const RULES = [
    // 날짜
    { kind: '날짜', re: /(?<![\d-])(\d{4})-(\d{1,2})-(\d{1,2})(?![\d-])/g, fix: (m) => dateFix(m[1], m[2], m[3]) },
    { kind: '날짜', re: /(?<!\d)(\d{4})\/(\d{1,2})\/(\d{1,2})(?!\d)/g, fix: (m) => dateFix(m[1], m[2], m[3]) },
    { kind: '날짜', re: /(?<!\d)(\d{4})\.(\d{1,2})\.(\d{1,2})\.?(?!\d)/g, fix: (m) => dateFix(m[1], m[2], m[3]) },
    { kind: '날짜', re: /(?<!\d)(\d{4})년\s*(\d{1,2})월\s*(\d{1,2})일(?!\d)/g, fix: (m) => dateFix(m[1], m[2], m[3]) },
    { kind: '날짜', re: /(?<!\d)(\d{4})\. (0\d|\d{1,2})\. (0\d|\d{1,2})\.?(?=[\s(~,)]|$)/g, fix: (m) => dateFix(m[1], m[2], m[3]), only: (m) => !/^(\d{4})\. [1-9]\d?\. [1-9]\d?\.$/.test(m[0]) },
    // 시각
    { kind: '시각', re: /(오전|오후)\s*(\d{1,2})시(?:\s*(\d{1,2})분)?/g, fix: (m) => { let h = +m[2]; if (m[1] === '오후' && h < 12) h += 12; if (m[1] === '오전' && h === 12) h = 0; return `${String(h).padStart(2, '0')}:${String(+m[3] || 0).padStart(2, '0')}`; } },
    { kind: '시각', re: /(?<!\d)(\d{1,2})시\s*(\d{1,2})분/g, fix: (m) => `${String(+m[1]).padStart(2, '0')}:${String(+m[2]).padStart(2, '0')}` },
    { kind: '시각', re: /(?<![\d:.])(\d{1,2})시(?=[\s,.)~]|$)/g, fix: (m) => `${String(+m[1]).padStart(2, '0')}:00` },
    // 쌍점: 왼쪽은 붙이고 오른쪽은 한 칸
    { kind: '쌍점', re: /([가-힣)]+) +:\s*(?=\S)/g, fix: (m) => `${m[1]}: ` },
    { kind: '쌍점', re: /([가-힣)]+):(?=[^\s])/g, fix: (m) => `${m[1]}: ` },
    // 쉼표 뒤 한 칸, 기간 물결표는 붙임
    { kind: '띄어쓰기', re: /([가-힣]+),(?=[가-힣])/g, fix: (m) => `${m[1]}, ` },
    { kind: '띄어쓰기', re: /(\.|\)|\d) +~ *(?=[\d(])|(\.|\)|\d) *~ +(?=[\d(])/g, fix: (m) => `${m[1] || m[2]}~` },
  ];

  function wordRules() {
    const out = [];
    const add = (list, kind) => { for (const [from, to, note] of list || []) out.push({ kind, re: new RegExp(from, 'g'), to, note }); };
    const G = D.gongmunRules || {};
    add(G.typos, '오타');
    add(G.plain, '쉬운 말');
    add(G.spacing, '띄어쓰기');
    const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    for (const [from, to, note] of [...(D.spellRules?.words || []), ...(D.spellRules?.spacing || [])]) out.push({ kind: '오타', re: new RegExp(esc(from), 'g'), to, note });
    return out;
  }

  function scanLine(line, wordList) {
    const found = [];
    const push = (at, len, fix, kind, note) => {
      if (fix === line.slice(at, at + len)) return;
      if (found.some((f) => at < f.at + f.len && f.at < at + len)) return;
      found.push({ at, len, fix, kind, note: note || '', word: line.slice(at, at + len) });
    };
    for (const r of RULES) {
      r.re.lastIndex = 0;
      for (const m of line.matchAll(r.re)) { if (!r.only || r.only(m)) push(m.index, m[0].length, r.fix(m), r.kind); }
    }
    for (const w of wordList) {
      w.re.lastIndex = 0;
      for (const m of line.matchAll(w.re)) push(m.index, m[0].length, w.to.replace(/\$(\d)/g, (_, n) => m[+n] ?? ''), w.kind, w.note);
    }
    return found.sort((a, b) => a.at - b.at);
  }

  // 금액: 금113,560원(금일십일만삼천오백육십원). 숫자·한글이 어긋나면 오류, 예산·금액 줄의 숫자만 있는 금액은 제안
  function moneyIssues(line) {
    const out = [];
    const kor = D.draft?.koreanAmount;
    if (!kor) return out;
    const money = (n) => `금${Number(n).toLocaleString('en-US')}원(금${kor(n)}원)`;
    for (const m of line.matchAll(/금\s*([\d,]+)\s*원\s*\(\s*금?\s*([가-힣]+?)\s*원?\s*\)/g)) {
      const n = Number(m[1].replace(/,/g, ''));
      if (!n) continue;
      const right = money(n);
      if (kor(n) !== m[2]) out.push({ level: 'err', at: m.index, len: m[0].length, word: m[0], fix: right, kind: '금액', note: `숫자 ${n.toLocaleString('en-US')}원과 한글이 달라요` });
      else if (m[0] !== right) out.push({ level: 'warn', at: m.index, len: m[0].length, word: m[0], fix: right, kind: '금액' });
    }
    if (/(예산|금액|합계|총액|소요|집행|품의|지출)/.test(line) && !/\(\s*금/.test(line)) {
      for (const m of line.matchAll(/(?<![\d,])(금\s*)?(\d{1,3}(?:,\d{3})+|\d{4,})\s*원(?!\s*\()/g)) {
        const n = Number(m[2].replace(/,/g, ''));
        out.push({ level: 'warn', at: m.index, len: m[0].length, word: m[0], fix: money(n), kind: '금액', note: '금액은 한글을 함께 써요' });
      }
    }
    return out;
  }

  // 항목 기호 순서·들여쓰기
  function itemIssues(lines) {
    const out = [];
    const stack = []; // 단계별 마지막 순번
    let lastLevel = -1;
    const tail = lines.findIndex((l) => /^\s*붙\s*임(\s|:|$|\d)/.test(l)); // 붙임 줄부터는 항목이 아니다
    lines.forEach((line, i) => {
      if (tail >= 0 && i >= tail) return;
      const p = parseMark(line);
      if (!p) return;
      // 항목 기호 건너뜀(1. 다음에 바로 1)) — 고칠 글은 알 수 없으니 알리기만
      if (p.level > lastLevel + 1) out.push({ level: 'warn', line: i, at: p.indent, len: p.mark.length, word: p.mark, fix: null, kind: '항목', note: `'${markOf(lastLevel + 1, 0)}' 단계를 건너뛰었어요(1. → 가. → 1) → 가) → (1) → (가))` });
      else {
        for (let k = p.level + 1; k < stack.length; k++) stack[k] = -1;
        const want = (stack[p.level] ?? -1) + 1;
        if (p.index !== want) {
          const fix = markOf(p.level, want);
          out.push({ level: 'warn', line: i, at: p.indent, len: p.mark.length, word: p.mark, fix, kind: '항목', note: `순서로는 '${fix}'예요` });
          stack[p.level] = want;
        } else stack[p.level] = p.index;
        const wantIndent = p.level * 2;
        if (p.indent !== wantIndent) out.push({ level: 'warn', line: i, at: 0, len: p.indent, word: ' '.repeat(p.indent), fix: ' '.repeat(wantIndent), kind: '들여쓰기', note: `${p.level + 1}단계는 ${wantIndent}칸 들여 써요` });
      }
      // 기호 뒤 한 칸
      if (p.rest && !/^\s/.test(p.rest)) out.push({ level: 'warn', line: i, at: p.indent + p.mark.length, len: 0, word: '', fix: ' ', kind: '띄어쓰기', note: '항목 기호 뒤는 한 칸 띄워요' });
      lastLevel = p.level;
    });
    return out;
  }

  // 붙임·끝 표시
  function tailIssues(lines) {
    const out = [];
    const nonEmpty = lines.map((l, i) => [l, i]).filter(([l]) => l.trim());
    if (!nonEmpty.length) return out;
    const at = lines.findIndex((l) => /^\s*붙\s*임(\s|:|$|\d)/.test(l));
    if (at >= 0) {
      const m = /^(\s*)붙\s*임\s*:?\s*/.exec(lines[at]);
      if (m[0] !== `${m[1]}붙임  `) out.push({ level: 'warn', line: at, at: 0, len: m[0].length, word: m[0], fix: '붙임  ', kind: '붙임', note: "'붙임' 뒤는 두 칸 띄워요" });
    }
    const [last, li] = nonEmpty[nonEmpty.length - 1];
    if (!/끝\.\s*$/.test(last)) {
      const m = /\s*끝\s*\.?\s*$/.exec(last);
      if (m) out.push({ level: 'warn', line: li, at: m.index, len: m[0].length, word: m[0], fix: '  끝.', kind: '끝', note: "끝 표시는 두 칸 띄우고 '끝.'" });
      else out.push({ level: 'warn', line: li, at: last.trimEnd().length, len: last.length - last.trimEnd().length, word: '', fix: '  끝.', kind: '끝', note: "본문 끝에 두 칸 띄우고 '끝.'" });
    } else {
      const m = /(\S)( *)끝\.\s*$/.exec(last);
      if (m && m[2] !== '  ') out.push({ level: 'warn', line: li, at: m.index + 1, len: m[2].length, word: m[2], fix: '  ', kind: '끝', note: "'끝.' 앞은 두 칸 띄워요" });
    }
    return out;
  }

  function titleIssues(title, wordList) {
    const out = scanLine(title, wordList).map((f) => ({ ...f, where: 'title', level: 'warn', line: 0 }));
    const t = /[.。]\s*$/.exec(title);
    if (t) out.push({ where: 'title', level: 'warn', line: 0, at: t.index, len: t[0].length, word: t[0], fix: '', kind: '제목', note: '제목 끝에는 마침표를 찍지 않아요' });
    const sp = /^\s*제\s*목\s*[:：]\s*/.exec(title);
    if (sp) out.push({ where: 'title', level: 'warn', line: 0, at: 0, len: sp[0].length, word: sp[0], fix: '', kind: '제목', note: "'제목:'은 쓰지 않아요" });
    return out;
  }

  const lineStarts = (lines) => { const s = []; let n = 0; for (const l of lines) { s.push(n); n += l.length + 1; } return s; };

  function describe(i) {
    const place = i.where === 'title' ? '제목' : `${i.line + 1}줄`;
    if (i.fix == null) return `${place}: ${i.note}`;
    const from = i.word.trim() ? `'${i.word}'` : '';
    const to = i.fix.trim() ? `'${i.fix}'` : '';
    return `${place}: ${from}${from && to ? ' → ' : ''}${to}${i.note ? ` — ${i.note}` : ''}${!from && !to ? i.kind : ''}`;
  }

  /** { title, body } → { issues, errs, canFix } */
  function scan({ title = '', body = '' } = {}) {
    const words = wordRules();
    const lines = String(body).replace(/\r\n?/g, '\n').split('\n');
    const starts = lineStarts(lines);
    const issues = [];
    const add = (o, line) => issues.push({ where: 'body', level: 'warn', line, ...o, abs: starts[o.line ?? line] + o.at });
    lines.forEach((l, i) => {
      for (const f of moneyIssues(l)) add({ ...f, line: i }, i);
      const taken = issues.filter((x) => x.line === i && x.where === 'body');
      for (const f of scanLine(l, words)) if (!taken.some((t) => f.at < t.at + t.len && t.at < f.at + f.len)) add({ ...f, line: i }, i);
    });
    for (const f of itemIssues(lines)) add(f, f.line);
    for (const f of tailIssues(lines)) add(f, f.line);
    for (const f of titleIssues(String(title), words)) issues.push(f);
    // 개인정보: 공문은 공개될 수 있다 → 고치지 않고 알린다(찾는 규칙은 features/mask.js)
    if (D.mask) {
      const mk = D.mask(String(body));
      if (mk.total) issues.push({ where: 'body', level: 'warn', kind: '개인정보', line: 0, at: 0, len: 0, word: '', fix: null, note: `본문에 ${D.mask.summary(mk.kinds)}가 있어요. 공개 문서라면 지워 주세요` });
    }
    issues.sort((a, b) => (a.where === b.where ? (a.abs ?? a.at) - (b.abs ?? b.at) : a.where === 'title' ? -1 : 1));
    issues.forEach((x, i) => { x.id = i; x.text = describe(x); });
    return { issues, errs: issues.filter((x) => x.level === 'err').length, canFix: issues.filter((x) => x.fix != null).length };
  }

  function applyOne({ title = '', body = '' }, issue) {
    if (issue.fix == null) return { title, body };
    const put = (s, at, len) => s.slice(0, at) + issue.fix + s.slice(at + len);
    if (issue.where === 'title') return { title: put(String(title), issue.at, issue.len), body };
    const norm = String(body).replace(/\r\n?/g, '\n');
    return { title, body: put(norm, issue.abs, issue.len) };
  }

  // 한 번 고치면 다른 자리가 밀리므로 다시 훑어 고칠 것이 없을 때까지(순서 번호처럼 앞을 고치면 뒤가 맞아지는 것도 처리)
  function applyAll(input) {
    let cur = { title: input.title || '', body: input.body || '' };
    let changed = 0;
    for (let round = 0; round < 200; round++) {
      const one = scan(cur).issues.find((x) => x.fix != null);
      if (!one) break;
      const next = applyOne(cur, one);
      if (next.title === cur.title && next.body === cur.body) break;
      cur = next;
      changed++;
    }
    return { ...cur, changed };
  }

  D.draftCheck = { scan, applyOne, applyAll, parseMark };
})();
