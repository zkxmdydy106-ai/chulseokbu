// 공문 → 선생님께 보낼 쉬운 공지 멘트(교사 결정 2026-11-09: 내장 규칙만, AI 없음, 짧은 항목형).
// 공문 원문은 바꾸지 않는다. 초안을 만들 뿐이고 교사가 고쳐 복사해 메신저에서 직접 보낸다. 화면과 무관한 순수 로직(모아 보기 창·node 시험).
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const NL = String.fromCharCode(10);
  const MAX_LINES = 10;

  // 받침 있는 글자인지('입니다' → '이에요'/'예요')
  const hasJong = (ch) => { const c = (ch || '').charCodeAt(0) - 0xac00; return c >= 0 && c <= 11171 && c % 28 > 0; };

  // 위에서부터 차례로. 긴 표현을 먼저 바꾼다
  const RULES = [
    [/위\s*호(?:와|에)\s*관련하여\s*/g, ''],
    [/하여\s*주시기\s*바랍니다/g, '해 주세요'],
    [/해\s*주시기\s*바랍니다/g, '해 주세요'],
    [/주시기\s*바랍니다/g, '주세요'],
    [/하시기\s*바랍니다/g, '해 주세요'],
    [/하여\s*주/g, '해 주'],
    [/바랍니다/g, '부탁드려요'],
    [/바람(\.?)\s*$/, '부탁드려요$1'],
    [/요망(\.?)\s*$/, '부탁드려요$1'],
    [/하고자\s*합니다/g, '하려고 해요'],
    [/하고자\s*하오니/g, '하려고 하니'],
    [/하고자\s*/g, '하려고 '],
    [/하오니/g, '하니'],
    [/함에\s*따라/g, '해서'],
    [/에\s*(?:의거하여|의거|의하여)/g, '에 따라'],
    [/관련하여/g, '관련해서'],
    [/위하여/g, '위해'],
    [/대하여/g, '대해'],
    [/관하여/g, '관해'],
    [/통하여/g, '통해'],
    [/인하여/g, '인해'],
    [/다음과\s*같이/g, '아래와 같이'],
    [/붙임과\s*같이/g, '붙임 파일과 같이'],
    [/붙임\s*참조/g, '붙임 파일 참고'],
    [/참조/g, '참고'],
    [/하여(?=\s)/g, '해서'],
    [/드립니다/g, '드려요'],
    [/(?<!감사)합니다/g, '해요'],
    [/됩니다/g, '돼요'],
    [/있습니다/g, '있어요'],
    [/없습니다/g, '없어요'],
    [/아울러/g, '또한'],
    [/금번/g, '이번'],
    [/익일/g, '다음 날'],
    [/(^|\s)상기(?=\s)/g, '$1위'],
    [/(귀교|본교)/g, '우리 학교'],
    [/제반/g, '여러'],
    [/\s*끝\.?\s*$/, ''],
  ];

  function plain(line) {
    let t = String(line || '');
    for (const [re, to] of RULES) t = t.replace(re, to);
    // '입니다'는 앞 글자 받침에 따라 다르다
    t = t.replace(/(.)입니다/g, (_, ch) => `${ch}${hasJong(ch) ? '이에요' : '예요'}`);
    return t.replace(/[ \t]+/g, ' ').trim();
  }

  const SUB = /^\s*(?:[가-하]\.|\(?[가-하]\)|\(?\d+\)|[-·•○●ㅇ※▶□■◦]|[①-⑳])\s*/;
  const TOP = /^\s*\d+[.)]\s*/;
  const RELATED = /^\s*(?:\d+\.\s*)?관\s*련\s*[:：]?/;
  const HEAD = /^\s*(?:수신자?|경유|제목)\s*[:：(\s]/;

  // 본문 → 쉬운 말 줄들. 관련 줄·붙임 목록·수신 줄은 뺀다
  function bodyLines(body) {
    const out = [];
    const ls = String(body || '').replace(/\r\n?/g, NL).split(NL);
    let inRelated = false;
    for (const raw of ls) {
      if (!raw.trim()) continue;
      if (/^\s*붙\s*임(\s|$)/.test(raw)) break;
      if (HEAD.test(raw)) continue;
      if (RELATED.test(raw)) { inRelated = true; continue; }
      if (inRelated && SUB.test(raw) && /-\s*\d/.test(raw)) continue;
      inRelated = false;
      if (/^\s*끝\.?\s*$/.test(raw)) continue;
      const sub = SUB.test(raw);
      const text = plain(raw.replace(sub ? SUB : TOP, ''));
      if (!text) continue;
      const label = /^[^:：]{1,12}[:：]/.test(text);
      out.push(sub || label ? `- ${text}` : text);
    }
    return out;
  }

  const titleOf = (t) => { const s = String(t || '').replace(/\s+/g, ' ').trim(); return s.replace(/^\d{4}\s*학년도\s*/, '').replace(/\s*(?:안내|알림)$/, '') || s; };

  // doc: { title, body, targets[], deadline, submits[], files[] } → 멘트 글
  function make(doc = {}) {
    const lines = bodyLines(doc.body);
    // 본문 항목 이름에 이미 있으면('제출 기한: …') 겹쳐 쓰지 않는다
    const has = (word) => lines.some((l) => { const m = /^(?:- )?([^:：]{1,12})[:：]/.exec(l); return !!m && m[1].includes(word) && (word !== '제출' || !/기한|기간|방법/.test(m[1])); });
    const keys = [];
    if (doc.targets?.length && !has('대상')) keys.push(`- 대상: ${doc.targets.join(', ')}`);
    if (doc.deadline && !has('기한')) keys.push(`- 기한: ${doc.deadline}까지`);
    if (doc.submits?.length && !has('제출')) keys.push(`- 제출: ${doc.submits.join(', ')}`);
    const more = lines.length > MAX_LINES;
    const hasFiles = !!doc.files?.length;
    const tail = more ? (hasFiles ? '자세한 내용은 공문과 붙임 파일을 봐 주세요.' : '자세한 내용은 공문을 봐 주세요.') : (hasFiles ? '자세한 내용은 붙임 파일을 봐 주세요.' : '자세한 내용은 공문을 봐 주세요.');
    const out = ['선생님들, 안녕하세요.', `'${titleOf(doc.title)}' 공문 안내드려요.`];
    if (keys.length) out.push('', ...keys);
    if (lines.length) out.push('', ...lines.slice(0, MAX_LINES));
    out.push('', tail, '감사합니다.');
    return out.join(NL);
  }

  D.edufineNotice = { plain, bodyLines, titleOf, make };
})();
