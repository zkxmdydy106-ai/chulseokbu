// F3 품의 등록 채우기 — 견적서 품목(features/draft.js parseItems) → 품의 화면 품목 줄 값. 화면과 무관한 부분(패널·node 시험 둘 다).
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  // 단위 이름 → 화면 단위 코드: 화면의 엑셀 올리기와 같은 규칙(cm → 012, l → 007, 나머지는 코드표 이름 그대로 — 2026-10-29 화면 스크립트)
  const UNIT_FIXED = { cm: '012', l: '007' };
  function unitCode(name, table) {
    const n = String(name ?? '').trim();
    if (!n) return '';
    if (UNIT_FIXED[n.toLowerCase()]) return UNIT_FIXED[n.toLowerCase()];
    const hit = (table || []).find((u) => String(u.name).trim() === n);
    return hit ? String(hit.code) : '';
  }
  // 바이트 한도로 자르기(한글 3바이트 셈 — 에듀파인 maxlengthbyte 셈은 확인 필요, 넉넉하게)
  function cut(text, max) {
    const s = String(text ?? '');
    if (D.neisBytes(s) <= max) return { text: s, cut: false };
    let out = '';
    for (const ch of s) { if (D.neisBytes(out + ch) > max - 3) break; out += ch; }
    return { text: `${out}…`, cut: true };
  }
  // 품목 → 화면 칸 값(숫자는 Number — 화면은 쉼표·공백이 든 글자를 넣으면 수량을 지운다). 금액은 수량 × 단가(내림)로 맞춤 — 다르면 저장 확인 창이 바뀜
  function rows(items) {
    return (items || []).map((it) => {
      const qty = Number(it.qty) || 0;
      const price = Number(it.price) || 0;
      return { prdlstCn: String(it.name || '').trim(), stndrd: String(it.spec || '').trim(), unit: String(it.unit || '').trim(), qty, price, amount: Math.floor(qty * price) };
    });
  }
  D.expense = { unitCode, cut, rows };
})();
