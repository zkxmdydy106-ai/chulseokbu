// 평가 입력: N2 성취기준(성취기준관리), N3 문항정보표(문항정보표관리)
// 파일(엑셀·한글 hwpx·CSV) 해석 → 나이스 줄과 비교 → 검증(배점 합계·빈 값·마감) → 입력 계획. 화면 설정은 screens/neis-assessment.js
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const cut = (s, n = 30) => { s = String(s ?? ''); return s.length > n ? `${s.slice(0, n)}…` : s; };
  const sepOf = (raw) => (raw.includes('\t') ? '\t' : raw.includes(',') ? ',' : null);
  const cellsOf = (l) => { const sep = sepOf(l.raw); return sep ? D.splitCells(l.raw, sep).map((c) => String(c ?? '').trim()) : [l.raw.trim()]; };
  const fieldsOf = (cells, HEAD) => cells.map((c) => { const s = D.squash(c).replace(/[()（）]/g, ''); return Object.keys(HEAD).find((f) => HEAD[f].includes(s)) || null; });

  // ── N2 성취기준 ─────────────────────────────────────────
  // 코드: [12기하-01-01], [12기하01-01], [10공수1-01-01], [9수01-01]
  const CODE = /\[?\s*(\d{1,2}[가-힣A-Za-z]+\d?\s*-?\s*\d{2}\s*-\s*\d{2})\s*\]?/;
  const canon = (c) => String(c ?? '').replace(/[\s[\]-]/g, '');
  const cleanCode = (c) => String(c ?? '').replace(/[\s[\]]/g, '');
  const SHEAD = {
    code: ['성취기준코드', '코드', '기준코드', '성취기준번호'],
    text: ['성취기준', '성취기준내용', '내용', '성취기준명'],
    area: ['영역', '영역명', '내용영역', '영역번호', '단원'],
  };

  // 표 어디에 있든 코드가 든 줄을 성취기준으로 본다(평가기준안처럼 표가 여러 개여도)
  function parseStandards(text) {
    const items = [];
    const issues = [];
    const seen = new Map();
    let fields = null;
    let lastArea = '';
    let dup = 0;
    for (const l of D.lines(text)) {
      const cells = cellsOf(l);
      const f = fieldsOf(cells, SHEAD);
      if (!cells.some((c) => CODE.test(c)) && f.filter(Boolean).length >= 2) { fields = f; lastArea = ''; continue; }
      const ci = fields && fields.indexOf('code') >= 0 && CODE.test(cells[fields.indexOf('code')] || '') ? fields.indexOf('code') : cells.findIndex((c) => CODE.test(c));
      if (ci < 0) continue;
      const m = CODE.exec(cells[ci]);
      const code = cleanCode(m[1]);
      let body = cells[ci].slice(m.index + m[0].length).replace(/^[\s.:·)\]-]+/, '').trim();
      if (body.length < 5) {
        const ti = fields ? fields.indexOf('text') : -1;
        const cand = ti >= 0 && ti !== ci && cells[ti] && !CODE.test(cells[ti]) ? cells[ti] : cells.slice(ci + 1).find((c) => c.length >= 5 && !CODE.test(c)) || '';
        body = cand.trim();
      }
      // 영역: 칸 이름이 '영역'인 칸(병합된 칸이라 비면 위 줄 영역)
      const ai = fields ? fields.indexOf('area') : -1;
      let area = ai >= 0 && ai !== ci && fields.length === cells.length ? cells[ai] : '';
      if (area) lastArea = area; else if (ai >= 0) area = lastArea;
      const k = canon(code);
      if (seen.has(k)) { dup++; continue; }
      seen.set(k, true);
      const it = { line: l.no, code, canon: k, text: body, area: area.trim(), issues: [] };
      if (!body) it.issues.push('성취기준 내용이 비어 있어요.');
      items.push(it);
    }
    if (!items.length) issues.push('파일에서 성취기준 코드(예: [12기하-01-01])를 찾지 못했어요.');
    return { items, issues, notes: dup ? [`같은 코드가 여러 번 나와 첫 줄만 썼어요(${dup}줄 건너뜀).`] : [] };
  }

  // 나이스 줄의 코드 모양(가운데 '-' 유무)에 맞춘다
  function codeStyle(code, rows, col) {
    const withDash = rows.filter((r) => (String(r[col]).match(/-/g) || []).length >= 2).length;
    const without = rows.filter((r) => (String(r[col]).match(/-/g) || []).length === 1).length;
    if (withDash > without) return code.replace(/^(\d{1,2}[가-힣A-Za-z]+\d?)(\d{2}-\d{2})$/, '$1-$2');
    if (without > withDash) return code.replace(/^(\d{1,2}[가-힣A-Za-z]+\d?)-(\d{2}-\d{2})$/, '$1$2');
    return code;
  }

  function compareStandards({ parsed, rows, areas = [], screen }) {
    const C = screen.columns, A = screen.areas;
    const issues = [...parsed.issues];
    const notes = [...(parsed.notes || [])];
    const byCanon = new Map();
    for (const r of rows) { const k = canon(r[C.code]); if (!byCanon.has(k)) byCanon.set(k, []); byCanon.get(k).push(r); }
    const areaList = areas.map((a) => ({ no: String(a[A.no] ?? '').trim(), name: String(a[A.name] ?? '').trim() })).filter((a) => a.no);
    const areaText = areaList.map((a) => `${a.no} ${a.name}`).join(', ');
    const findArea = (v) => {
      const s = D.squash(v);
      if (!s) return null;
      const byNo = /^\d+$/.test(s) ? areaList.find((a) => D.normNo(a.no) === D.normNo(s)) : null;
      return byNo || areaList.find((a) => D.squash(a.name) === s) || areaList.find((a) => D.squash(a.name).includes(s) || s.includes(D.squash(a.name))) || null;
    };
    const out = parsed.items.map((it) => {
      const res = { line: it.line, no: it.code, name: '', issues: [...it.issues], warnings: [], checks: [], cur: null, next: { kind: it.text, reason: '' }, set: null, row: null, status: 'error' };
      const hits = byCanon.get(it.canon) || [];
      const area = it.area ? findArea(it.area) : null;
      if (it.area && !area) res.issues.push(areaList.length ? `영역 '${it.area}'이(가) 나이스에 없어요 (나이스 영역: ${areaText}).` : '나이스에 영역이 없어요. [영역명관리]에서 먼저 만들어 주세요.');
      if (hits.length > 1) res.issues.push('나이스에 같은 코드가 여러 줄 있어요. 나이스에서 직접 고쳐 주세요.');
      else if (hits.length === 1) {
        const row = hits[0];
        res.row = row;
        res.mode = 'update';
        res.name = row[C.areaName] || row[C.area] || '';
        res.cur = { kind: String(row[C.text] ?? ''), reason: '' };
        if (String(row[C.closed] ?? '').trim() === 'Y') res.issues.push('마감된 성취기준이에요.');
        const set = {};
        if (it.text && it.text.trim() !== res.cur.kind.trim()) set[C.text] = it.text;
        if (area && String(row[C.area]).trim() !== area.no) { set[C.area] = area.no; if (C.areaName) set[C.areaName] = area.name; res.warnings.push(`영역을 ${area.name}(으)로 바꿔요.`); }
        res.set = set;
        if (set[C.text] && res.cur.kind) res.warnings.push('나이스에 있는 내용을 바꿔요.');
      } else if (!res.issues.length) {
        res.mode = 'insert';
        res.cur = { kind: '', reason: '' };
        const a = area || (areaList.length === 1 ? areaList[0] : null);
        if (!a) res.issues.push(areaList.length ? `새 성취기준이에요. 영역 칸을 적어 주세요 (나이스 영역: ${areaText}).` : '나이스에 영역이 없어요. [영역명관리]에서 먼저 만들어 주세요.');
        else {
          res.name = a.name;
          res.set = { [C.code]: codeStyle(it.code, rows, C.code), [C.text]: it.text, [C.area]: a.no, ...(C.areaName ? { [C.areaName]: a.name } : {}), ...(screen.newRow || {}) };
          res.warnings.push('나이스에 없는 코드라 새 줄로 넣어요.');
        }
      }
      res.status = res.issues.length ? 'error' : res.set && Object.keys(res.set).length ? 'change' : 'same';
      return res;
    });
    const upd = out.filter((r) => r.status === 'change' && r.mode === 'update');
    const ins = out.filter((r) => r.status === 'change' && r.mode === 'insert');
    const errors = out.filter((r) => r.status === 'error').length;
    const untouched = rows.filter((r) => !parsed.items.some((i) => i.canon === canon(r[C.code]))).length;
    if (untouched) notes.push(`나이스에만 있는 성취기준 ${untouched}개는 그대로 둬요(지우지 않음).`);
    const canApply = !issues.length && !errors && upd.length + ins.length > 0;
    return {
      rows: out, issues, notes,
      summary: { change: upd.length + ins.length, same: out.filter((r) => r.status === 'same').length, error: errors, untouched, added: ins.length },
      canApply,
      plan: canApply ? {
        appId: screen.appId,
        parts: [{
          dataset: screen.dataset, grid: screen.grid, keyColumns: [C.code],
          rows: upd.map((r) => ({ key: { [C.code]: r.row[C.code] }, expect: Object.fromEntries(Object.keys(r.set).map((c) => [c, r.row[c] ?? ''])), set: r.set })),
          insert: ins.length ? { button: screen.insert.button, rows: ins.map((r) => ({ set: r.set })) } : null,
        }],
      } : null,
    };
  }

  const standard = {
    parse: parseStandards,
    compare: compareStandards,
    readArgs: (screen) => ({
      appId: screen.appId, dataset: screen.dataset, columns: Object.values(screen.columns),
      extraDatasets: { [screen.areas.dataset]: [screen.areas.no, screen.areas.name] },
    }),
  };

  // ── N3 문항정보표 ───────────────────────────────────────
  const IHEAD = {
    no: ['문항', '문항번호', '번호', '번', '문번'],
    type: ['유형', '문항유형', '형식', '문항형식', '구분', '출제형식', '문항형태'],
    allot: ['배점', '점수', '배점점'],
    level: ['난이도', '난도', '예상난이도'],
    answer: ['정답', '답', '정답번호', '모범답안', '채점기준', '정답및채점기준', '예시답안', '정답채점기준'],
    text: ['평가요소', '평가내용', '출제의도', '문항내용', '평가요소문항내용'],
    area: ['영역', '영역번호', '내용영역'],
    plsc: ['복수정답', '복수정답처리', '처리방법'],
    std: ['성취기준', '성취기준코드'],
    L1: ['상', '어려움'], L2: ['중', '보통'], L3: ['하', '쉬움'],
  };
  const LEVEL_NAME = { 1: '어려움', 2: '보통', 3: '쉬움' };
  const SBJCT_ANSWER = '서답형 채점기준표 참조';
  const levelOf = (v) => {
    const s = D.squash(v);
    if (!s) return '';
    if (/^(상|어려움|어렵|상위|1|high)/i.test(s)) return '1';
    if (/^(중|보통|중간|2|mid)/i.test(s)) return '2';
    if (/^(하|쉬움|쉽|하위|3|low)/i.test(s)) return '3';
    return '?';
  };
  const CIRCLED = { '①': '1', '②': '2', '③': '3', '④': '4', '⑤': '5' };
  const answersOf = (v) => [...new Set((String(v ?? '').replace(/[①-⑤]/g, (c) => CIRCLED[c]).match(/[1-5]/g) || []))].sort();
  const plscOf = (v) => {
    const s = D.squash(v).toUpperCase();
    if (!s) return '';
    if (/AND|그리고/.test(s)) return '1';
    if (/2개?이상/.test(s)) return '3';
    if (/ALL|전부|모두/.test(s)) return '4';
    if (/OR|또는|하나/.test(s)) return '2';
    if (/없|단일|^0$/.test(s)) return '0';
    return '?';
  };
  // 유형 칸이 없거나 비면 정답으로 가늠: 번호(①~⑤·1~5)만 있으면 객관식, 글이면 서답형(양식은 배점·정답·평가요소만 — 2026-10-28)
  const typeOf = (typeCell, noCell, answer = '') => {
    const s = D.squash(typeCell) || D.squash(noCell);
    if (/서|논|단답|주관|J/i.test(s)) return 'J';
    if (D.squash(typeCell)) return 'G';
    const a = String(answer).replace(/\s+/g, '');
    if (a && !/^[①②③④⑤1-5,，/·와및]+$/.test(a)) return 'J';
    return 'G';
  };
  const num = (v) => { const m = /\d+(\.\d+)?/.exec(String(v ?? '')); return m ? String(Number(m[0])) : ''; };
  const marked = (v) => /[○OoVv✓✔●◯√1]/.test(String(v ?? '').trim());

  // rule: { hard, normal } — 배점이 hard 이상이면 어려움, normal 이상이면 보통, 그 아래 쉬움(교사가 설정에서 정함)
  function parseItems(text, { rule = null } = {}) {
    const lines = D.lines(text);
    const items = [];
    const issues = [];
    let hi = -1, fields = null;
    for (let i = 0; i < Math.min(lines.length, 6); i++) {
      const f = fieldsOf(cellsOf(lines[i]), IHEAD);
      if (f.includes('no') && f.filter(Boolean).length >= 2) { hi = i; fields = f; break; }
    }
    if (!fields) return { items, issues: ['첫 줄에 칸 이름(문항 · 배점 · 정답 · 난이도…)을 적어 주세요.'], has: {} };
    const reverse = () => {
      // 난이도 1 어려움 · 2 보통 · 3 쉬움. 같은 유형 안에서 어려운 쪽 배점이 쉬운 쪽보다 작으면 역배점
      const lv = items.filter((x) => /^[123]$/.test(x.level || '') && x.allot);
      for (const a of lv) {
        const worse = lv.find((b) => b.type === a.type && b.level > a.level && Number(b.allot) > Number(a.allot)); // 객관식끼리·서답형끼리
        if (worse) a.issues.push(`역배점: ${LEVEL_NAME[a.level]} ${a.allot}점인데 ${LEVEL_NAME[worse.level]} 문항(${worse.type === 'J' ? '서답형 ' : ''}${worse.no}번)이 ${worse.allot}점이에요. 패널에 난이도 기준 점수를 정하면 배점으로 자동으로 맞춰요.`);
      }
    };
    const has = Object.fromEntries(Object.keys(IHEAD).map((k) => [k, fields.includes(k)]));
    has.levelCols = has.L1 || has.L2 || has.L3;
    for (const l of lines.slice(hi + 1)) {
      const cells = cellsOf(l);
      const get = (f) => { const i = fields.indexOf(f); return i >= 0 ? String(cells[i] ?? '').trim() : ''; };
      if (!D.normNo(get('no'))) continue; // 합계 줄·빈 줄
      if (!get('allot') && !get('answer') && !get('text') && !get('level')) continue; // 양식에 번호만 미리 적힌 빈 줄
      const type = typeOf(get('type'), get('no'), get('answer'));
      const it = { line: l.no, type, no: D.normNo(get('no')), allot: num(get('allot')), text: get('text'), area: D.normNo(get('area')), issues: [], warnings: [] };
      if (has.level) it.level = levelOf(get('level'));
      else if (has.levelCols) it.level = ['L1', 'L2', 'L3'].map((k, i) => (marked(get(k)) ? String(i + 1) : '')).find(Boolean) || '';
      // 난이도 기준 점수(교사 결정 2026-10-28: 역배점이 생기지 않게 배점으로 정함)가 있으면 파일 난이도보다 기준이 먼저
      if (rule && rule.hard > 0 && it.allot) {
        const a = Number(it.allot);
        const byRule = a >= rule.hard ? '1' : rule.normal > 0 && a >= rule.normal ? '2' : '3';
        if (it.level && it.level !== '?' && it.level !== byRule) it.warnings.push(`파일 난이도(${LEVEL_NAME[it.level]})와 배점 기준(${LEVEL_NAME[byRule]})이 달라 기준대로 넣어요.`);
        it.level = byRule;
        it.levelAuto = true;
      }
      if (has.answer) { if (type === 'G') it.answers = answersOf(get('answer')); else it.answerText = get('answer'); }
      // 서답형 정답은 양식에 쓰지 않음 → 나이스에는 '서답형 채점기준표 참조'(교사 결정 2026-10-28, 채점기준표 파일은 첨부로)
      if (type === 'J' && !it.answerText) it.answerText = SBJCT_ANSWER;
      if (has.plsc) it.plsc = plscOf(get('plsc'));
      if (has.std) it.std = codesIn(get('std')); // 출제표에 성취기준 코드 칸이 있으면(양식은 4칸 그대로 — 교사 결정 2026-10-29)
      if (it.level === '?') it.issues.push('난이도를 알아보지 못했어요 (상·중·하 또는 어려움·보통·쉬움).');
      if ((has.allot) && !it.allot) it.issues.push('배점이 비어 있어요.');
      if (it.plsc === '?') it.issues.push('복수정답 처리를 알아보지 못했어요 (AND · OR · 2개 이상 · ALL).');
      if (type === 'G' && has.answer && !it.answers.length) it.issues.push('정답(1~5)이 비어 있어요.');
      items.push(it);
    }
    // 기준 점수도 파일 난이도도 없으면 배점으로 정한다(교사 요청 2026-11-02: 난이도가 비어 넘어감). 유형마다 높은 배점부터 상·보통·쉬움 — 역배점이 생기지 않음
    if (!(rule && rule.hard > 0) && !has.level && !has.levelCols) {
      for (const type of ['G', 'J']) {
        const list = items.filter((x) => x.type === type && Number(x.allot) > 0);
        const vals = [...new Set(list.map((x) => Number(x.allot)))].sort((a, b) => b - a);
        const n = vals.length;
        for (const it of list) {
          const i = vals.indexOf(Number(it.allot));
          it.level = n === 1 ? '2' : n === 2 ? (i === 0 ? '1' : '3') : i < n / 3 ? '1' : i < (2 * n) / 3 ? '2' : '3';
          it.levelAuto = true;
        }
      }
    }
    if (!items.length) issues.push('파일에서 문항 줄을 찾지 못했어요.');
    reverse();
    return { items, issues, has };
  }

  // ── 성취기준 연결(N3, 교사 결정 2026-10-29) ─────────────────
  // 목록: 나이스 '성취기준자료 가져오기' 창의 줄(성취기준 × 성취수준 A~E) → 성취기준마다 하나로 묶음(코드·내용은 나이스 값 그대로)
  function stdIndex(rows, S) {
    const out = [];
    for (const r of rows || []) {
      const raw = String(r.sccesCtrCd ?? '');
      if (!raw.trim()) continue;
      const key = `${canon(raw)}|${String(r.evlCriaSccesCtrCd ?? '').trim()}`;
      let e = out.find((x) => x.key === key);
      if (!e) { e = { key, raw, code: raw.trim(), cria: String(r.evlCriaSccesCtrCd ?? ''), cn: String(r.sccesCtrCn ?? ''), area: String(r.relmNo ?? '').trim(), levels: [] }; out.push(e); }
      const lv = String(r.evlCtrCn ?? '').trim();
      if (lv) e.levels.push(lv);
    }
    return out;
  }
  // 평가요소 글 ↔ 성취기준 내용 비교: 낱말(조사 뗌)·두 글자 묶음, 여러 성취기준에 흔한 말은 가볍게(idf), 뒤쪽 낱말(중심어)은 무겁게.
  // 실제 나이스 2026 기하 1회고사 평가요소 23개로 맞춤 — 23개 모두 교사가 고른 성취기준과 같음(tests: '포물선의 접선의 방정식' → 이차곡선의 접선)
  const JOSA = /(에서|으로|에게|하여|하고|하기|하는|대한|이다|한|할|된|되는|의|을|를|이|가|은|는|과|와|에|로|도|만)$/;
  const STD_STOP = new Set(['수', '있다', '알고', '뜻', '이용', '활용', '성질', '이해', '표현', '문제', '해결', '관계', '크기', '구하']);
  const wordsOf = (s) => String(s ?? '').replace(/[^가-힣A-Za-z0-9 ]/g, ' ').split(/\s+/).filter(Boolean).map((w) => (w.length > 1 ? w.replace(JOSA, '') : w)).filter(Boolean);
  function gramsOf(s) {
    const out = [];
    for (const w of wordsOf(s)) {
      if (!STD_STOP.has(w)) out.push(`w:${w}`);
      for (let i = 0; i + 1 < w.length; i++) out.push(`b:${w.slice(i, i + 2)}`);
    }
    return out;
  }
  function stdMatcher(index) {
    const docs = index.map((e) => ({ e, g: new Set(gramsOf(e.cn)), lv: new Set(e.levels.flatMap(gramsOf)) }));
    const df = new Map();
    for (const d of docs) for (const g of d.g) df.set(g, (df.get(g) || 0) + 1);
    const idf = (g) => Math.log((docs.length + 1) / ((df.get(g) || 0) + 0.5));
    return (text) => {
      const q = gramsOf(text);
      const score = (set) => q.reduce((n, g, i) => n + (set.has(g) ? Math.max(0.1, idf(g)) * (g.startsWith('w:') ? 2 : 1) * (1 + 1.5 * (i / Math.max(1, q.length - 1))) : 0), 0);
      let ranked = docs.map((d) => ({ e: d.e, sc: score(d.g) })).sort((a, b) => b.sc - a.sc);
      // 내용 글에 겹치는 말이 하나도 없을 때만 성취수준(A~E) 글로 한 번 더
      if (!ranked.length || ranked[0].sc <= 0) ranked = docs.map((d) => ({ e: d.e, sc: score(d.lv) * 0.5 })).sort((a, b) => b.sc - a.sc);
      return ranked.filter((x) => x.sc > 0);
    };
  }
  // 고른 성취기준 → 문항 줄 7칸(나이스 창이 돌려주는 모양 그대로)
  function stdValues(picks) {
    const areas = picks.map((e) => e.area);
    return {
      area: [...areas].sort()[0] || '', areas: areas.join('^'), codes: picks.map((e) => e.raw).join('^'),
      crias: picks.map((e) => e.cria).join('^'), texts: picks.map((e) => e.cn).join('^'), text: picks.map((e) => e.cn).join(' '), count: String(picks.length),
    };
  }
  const codesIn = (v) => [...String(v ?? '').matchAll(new RegExp(CODE.source, 'g'))].map((m) => canon(m[1]));

  // 정답 체크 칸 값 모양: 나이스에 이미 든 값에서 알아낸다
  function answerFormat(rows, screen) {
    const vals = new Set();
    for (const r of rows) for (const c of screen.columns.answers) { const v = String(r[c] ?? '').trim(); if (v) vals.add(v); }
    if (vals.has('Y') || vals.has('N')) return { on: 'Y', off: vals.has('N') ? 'N' : '', known: true };
    if (vals.has('true') || vals.has('false')) return { on: 'true', off: 'false', known: true };
    if (vals.has('1') || vals.has('0')) return { on: '1', off: vals.has('0') ? '0' : '', known: true };
    return { on: screen.answerOn, off: screen.answerOff, known: false };
  }

  const filled = (v) => String(v ?? '').trim() !== '';
  const same = (a, b, numeric) => (numeric ? filled(a) === filled(b) && Number(a || 0) === Number(b || 0) : String(a ?? '').trim() === String(b ?? '').trim());

  // std: { rows: 나이스 성취기준 목록 줄 } 또는 { error } — 없으면 성취기준은 건드리지 않음
  function compareItems({ parsed, obt = [], sbjct = [], totals = [], dm = {}, screen, attach = null, atch = {}, std = null }) {
    const C = screen.columns;
    const issues = [...parsed.issues];
    const notes = [];
    const SC = screen.std?.columns;
    let SI = null;
    if (SC && std) {
      const index = std.rows ? stdIndex(std.rows) : [];
      if (std.error) notes.push(`${std.error} 성취기준은 나이스에서 직접 골라 주세요.`);
      else if (!index.length) notes.push('나이스 [성취기준관리]에 이 과목 성취기준이 없어요. 성취기준을 먼저 넣으면 문항마다 골라 드려요.');
      else SI = { index, match: stdMatcher(index) };
    }
    const has = parsed.has || {};
    const fmt = answerFormat(obt, screen);
    const neis = { G: obt, J: sbjct };
    const tot = totals[0] || {};
    if (String(tot[screen.totals.closed] ?? '').trim() === 'Y') issues.push('문항정보표가 마감되어 있어요. 나이스에서 마감을 풀어야 입력할 수 있어요.');
    if (dm.exmNo) notes.push(`나이스 화면에 고른 고사: ${screen.exams[dm.exmNo] || `고사 ${dm.exmNo}`}. 다른 고사라면 나이스 화면 위쪽 조건을 바꾸고 다시 확인해 주세요.`);
    if (!obt.length && !sbjct.length) issues.push('나이스 문항정보표가 비어 있어요. 나이스에서 고사·과목을 고르고 문항 수를 먼저 정해 주세요.');
    const ansText = (r) => C.answers.map((c, i) => (String(r[c] ?? '').trim() === fmt.on ? i + 1 : 0)).filter(Boolean).join(',');
    const summaryOf = (type, allot, level, answers) => [allot ? `${allot}점` : '', LEVEL_NAME[level] || '', type === 'G' ? (answers ? `정답 ${answers}` : '') : (answers ? `답 ${cut(answers, 12)}` : '')].filter(Boolean).join(' · ');
    const taken = new Set();
    const finalAllot = { G: new Map(), J: new Map() };
    for (const t of ['G', 'J']) for (const r of neis[t]) finalAllot[t].set(r._row, r[C.allot]);

    const out = parsed.items.map((it) => {
      const T = screen.types[it.type];
      const list = neis[it.type];
      const res = { line: it.line, type: it.type, no: `${T.name} ${it.no}`, name: cut(it.text, 24), issues: [...it.issues], warnings: [], checks: [], cur: null, next: null, set: null, row: null, status: 'error' };
      let row = list.find((r) => D.normNo(r[C.no]) === it.no);
      if (!row && it.type === 'J' && !list.some((r) => D.normNo(r[C.no]) === it.no) && +it.no >= 1 && +it.no <= list.length) {
        row = list[+it.no - 1];
        res.warnings.push(`나이스 서답형 ${D.normNo(row[C.no])}번 칸에 넣어요(서답형 ${it.no}번째).`);
      }
      if (!row) { res.issues.push(`나이스에 ${T.name} ${it.no}번 문항이 없어요 (나이스 ${T.name} ${list.length}문항).`); res.status = 'error'; return res; }
      const k = `${it.type}${row._row}`;
      if (taken.has(k)) res.issues.push('같은 문항이 파일에 두 번 있어요.'); else taken.add(k);
      res.row = row;
      res.cur = { kind: summaryOf(it.type, row[C.allot], row[C.level], it.type === 'G' ? ansText(row) : row[C.answers[0]]), reason: '' };
      const set = {};
      const put = (c, v, numeric = false) => { if (v != null && !same(row[c], v, numeric)) set[c] = v; };
      if (has.allot && it.allot) { put(C.allot, it.allot, true); finalAllot[it.type].set(row._row, it.allot); }
      if (it.level && it.level !== '?') put(C.level, it.level);
      if (has.text && it.text) put(C.text, it.text);
      if (has.area && it.area) put(C.area, it.area);
      let nextAns = it.type === 'G' ? ansText(row) : row[C.answers[0]];
      if (it.type === 'G' && has.answer && it.answers.length) {
        C.answers.forEach((c, i) => put(c, it.answers.includes(String(i + 1)) ? fmt.on : fmt.off));
        let p = it.plsc && it.plsc !== '?' ? it.plsc : '';
        if (!p) { p = it.answers.length > 1 ? '2' : '0'; if (it.answers.length > 1) res.warnings.push('복수정답이라 \'OR(하나만 맞아도 정답)\'으로 넣어요.'); }
        put(C.plsc, p);
        nextAns = it.answers.join(',');
      }
      // 기본 문구('채점기준표 참조')는 나이스 칸이 비었을 때만 — 교사가 이미 쓴 모범답안은 덮지 않음
      if (it.type === 'J' && has.answer && it.answerText && !(it.answerText === SBJCT_ANSWER && D.squash(row[C.answers[0]]))) { put(C.answers[0], it.answerText); nextAns = it.answerText; }
      if (it.levelAuto) res.warnings.push(`난이도는 배점 기준으로 골랐어요 (${LEVEL_NAME[it.level]}).`);
      // 성취기준(교사 결정 2026-10-29): 파일 코드 → 그대로 / 나이스에 이미 연결 → 그대로 / 평가요소 글로 골라 확인 없이 넣음(확인 표에서 바꿀 수 있음)
      if (SI) {
        const now = String(row[SC.codes] ?? '').split('^').map((c) => c.trim()).filter(Boolean);
        const label = (e) => `${e.code} ${cut(e.cn.trim(), 26)}`;
        let picks = null, how = '';
        if (it.std?.length) {
          const found = it.std.map((c) => SI.index.find((e) => canon(e.code) === c) || c);
          const bad = found.filter((x) => typeof x === 'string');
          if (bad.length) res.issues.push(`나이스 [성취기준관리]에 없는 성취기준이에요: ${bad.join(', ')}`);
          else { picks = found; how = '파일 코드'; }
        } else if (now.length) {
          res.std = { how: 'neis', codes: now };
          res.warnings.push(`성취기준 ${now.join(', ')} — 나이스에 이미 연결돼 그대로 둬요.`);
        } else if (it.text) {
          const ranked = SI.match(it.text);
          if (ranked.length) { picks = [ranked[0].e]; how = '평가요소로 고름'; }
          else res.checks.push('평가요소와 비슷한 성취기준을 찾지 못했어요. [고치기]에서 고르거나 나이스에서 직접 골라 주세요.');
        }
        if (picks) {
          const v = stdValues(picks);
          if (picks.length > screen.std.max) res.issues.push(`성취기준은 문항마다 ${screen.std.max}개까지예요.`);
          else if (D.neisBytes(v.texts) > screen.std.maxBytes) res.issues.push(`고른 성취기준 글이 ${screen.std.maxBytes}바이트를 넘어요.`);
          else for (const [k, c] of Object.entries(SC)) put(c, v[k]);
          res.std = { how, codes: picks.map((e) => e.code) };
          res.warnings.push(`성취기준 ${picks.map(label).join(' · ')} (${how})`);
        }
        if (res.std || it.text) res.stdPick = true; // 확인 표 [고치기]에서 성취기준을 고를 수 있는 줄
      }
      res.set = set;
      res.next = { kind: summaryOf(it.type, set[C.allot] ?? row[C.allot], set[C.level] ?? row[C.level], nextAns), reason: '' };
      res.status = res.issues.length ? 'error' : Object.keys(set).length ? 'change' : 'same';
      return res;
    });

    // 배점 합계 = 나이스 만점(반영비율/만점관리에서 정한 객관식·서답형 만점)
    for (const t of ['G', 'J']) {
      const T = screen.types[t];
      const pes = Number(tot[T.pes] || 0);
      const sum = Math.round([...finalAllot[t].values()].reduce((n, v) => n + Number(v || 0), 0) * 100) / 100;
      if (!neis[t].length) continue;
      if (pes > 0 && sum !== pes) issues.push(`${T.name} 배점 합계가 ${sum}점이에요. 나이스 만점은 ${pes}점이에요.`);
      const missing = neis[t].filter((r) => !out.some((x) => x.row === r)).map((r) => D.normNo(r[C.no]));
      if (missing.length && parsed.items.length) notes.push(`나이스 ${T.name} ${missing.length}문항(${cut(missing.join(','), 20)}번)은 파일에 없어 그대로 둬요.`);
    }
    if (has.answer && !fmt.known && out.some((r) => r.type === 'G' && r.set && C.answers.some((c) => c in r.set))) {
      notes.push('정답 칸 값 모양을 나이스에서 알아내지 못해 기본값으로 넣어요. 처음 1건을 넣은 뒤 나이스 정답 칸이 맞게 체크됐는지 꼭 확인해 주세요.');
    }
    // 서답형 채점기준표 파일 → 나이스 '서답형 첨부파일'(하나만, 새 파일이 옛 파일을 바꿈). 교사 결정 2026-10-28
    if (attach) {
      const AT = screen.attach;
      const curName = String(atch[AT.nameColumn] ?? '').trim();
      const r = { line: 0, type: 'F', no: '서답형 첨부', name: cut(attach.name, 30), issues: [], warnings: [], checks: [], cur: { kind: curName || '없음', reason: '' }, next: { kind: attach.name, reason: '' }, set: null, row: null, status: 'change', attach: true };
      const ext = (/\.([a-z0-9]+)$/i.exec(attach.name) || [])[1] || '';
      if (!AT.accept.includes(ext.toLowerCase())) r.issues.push('채점기준표는 한글(.hwp·.hwpx)이나 PDF 파일로 붙여요.');
      if (String(tot[screen.totals.closed] ?? '').trim() === 'Y') r.issues.push('마감되어 첨부를 바꿀 수 없어요.');
      else if (String(tot[screen.totals.done] ?? '').trim() === 'Y') r.issues.push('정답·배점 입력완료 상태라 나이스가 첨부를 막아 둬요. 나이스에서 입력완료를 푼 뒤 다시 해 주세요.');
      if (curName) r.warnings.push(curName === attach.name ? '같은 이름의 첨부를 이 파일로 바꿔 올려요.' : `지금 붙은 '${cut(curName, 30)}'을(를) 이 파일로 바꿔요(나이스는 하나만 받아요).`);
      if (attach.size > 20 * 1024 * 1024) r.issues.push('파일이 너무 커요(20MB 넘음).');
      if (r.issues.length) r.status = 'error';
      out.push(r);
    }
    const changes = out.filter((r) => r.status === 'change');
    const errors = out.filter((r) => r.status === 'error').length;
    const canApply = !issues.length && !errors && changes.length > 0;
    const part = (t) => {
      const ch = changes.filter((r) => r.type === t);
      return ch.length ? {
        dataset: screen.types[t].dataset, grid: screen.types[t].grid, keyColumns: [C.no],
        rows: ch.map((r) => ({ key: { [C.no]: r.row[C.no] }, expect: Object.fromEntries(Object.keys(r.set).map((c) => [c, r.row[c] ?? ''])), set: r.set })),
      } : null;
    };
    return {
      rows: out, issues, notes,
      summary: { change: changes.length, same: out.filter((r) => r.status === 'same').length, error: errors },
      canApply,
      plan: canApply ? { appId: screen.appId, parts: ['G', 'J'].map(part).filter(Boolean), attach: !!attach } : null,
      // 확인 표 [고치기]에서 고를 성취기준(나이스 목록 그대로)
      stdList: SI ? SI.index.map((e) => ({ code: e.code, cn: e.cn.trim(), area: e.area })) : null,
    };
  }

  const items = {
    parse: (text, o) => (String(text || '').trim() ? parseItems(text, o) : { items: [], issues: [], has: {} }),
    compare: compareItems,
    readArgs: (screen) => {
      const C = screen.columns;
      const cols = [...new Set([C.no, C.text, C.area, C.level, C.allot, C.plsc, ...C.answers, ...Object.values(screen.std?.columns || {})])];
      return {
        appId: screen.appId, dataset: screen.types.G.dataset, columns: cols,
        dataMaps: { dmSearch: ['exmNo'], ...(screen.attach ? { [screen.attach.dataMap]: [screen.attach.nameColumn] } : {}) },
        extraDatasets: { [screen.types.J.dataset]: cols, [screen.totals.dataset]: [screen.types.G.pes, screen.types.J.pes, screen.totals.closed, screen.totals.done].filter(Boolean) },
      };
    },
    levelName: LEVEL_NAME,
    // 성취기준 목록 읽기(엔진 stdList): 나이스 '성취기준자료 가져오기' 창을 열어 목록만 읽고 닫음
    stdArgs: (screen) => ({ appId: screen.appId, popup: screen.std.popup, list: screen.std.list, rowDataset: screen.types.G.dataset, columns: screen.std.listColumns, menuName: screen.std.menuName, title: screen.std.title }),
    stdIndex, stdMatcher, stdValues,
  };

  // ── N2 수행평가 영역(이름·만점·반영비율) ───────────────
  // 평가기준안의 '평가 영역 | 만점 | 반영비율' 표. 지필(1회고사 등) 줄은 넣지 않고 반영비율 합계에만 쓴다.
  const AHEAD = {
    name: ['평가영역', '영역', '영역명', '수행평가영역', '평가항목', '수행평가', '평가종류', '구분'],
    max: ['만점', '배점', '영역만점', '점수'],
    ratio: ['반영비율', '비율', '반영비율%', '반영율', '반영'],
  };
  const isExam = (name) => /고사|지필|정기시험|중간|기말/.test(D.squash(name));
  const ratioOf = (v) => { const m = /\d+(\.\d+)?/.exec(String(v ?? '')); return m ? String(Number(m[0])) : ''; };

  function parseAreas(text) {
    const items = [];
    const exams = [];
    const issues = [];
    let fields = null;
    let nameAt = -1;
    for (const l of D.lines(text)) {
      const cells = cellsOf(l);
      const f = fieldsOf(cells, AHEAD);
      if (f.includes('name') && (f.includes('max') || f.includes('ratio'))) {
        // 이름 칸이 여럿이면('평가 종류', '평가 영역') '영역'이 든 칸
        const names = f.map((x, i) => (x === 'name' ? i : -1)).filter((i) => i >= 0);
        nameAt = names.find((i) => /영역/.test(cells[i])) ?? names[0];
        fields = f;
        continue;
      }
      if (!fields) continue;
      const get = (k) => { const i = k === 'name' ? nameAt : fields.indexOf(k); return i >= 0 ? String(cells[i] ?? '').trim() : ''; };
      const name = get('name');
      if (!name || /^(합계|계|총계)$/.test(D.squash(name))) continue;
      const it = { line: l.no, name, max: num(get('max')), ratio: ratioOf(get('ratio')), issues: [] };
      if (isExam(name)) { exams.push(it); continue; }
      if (!it.max && !it.ratio) continue; // 설명 줄
      if (fields.includes('max') && !it.max) it.issues.push('만점이 비어 있어요.');
      if (fields.includes('ratio') && !it.ratio) it.issues.push('반영비율이 비어 있어요.');
      if (items.some((x) => D.squash(x.name) === D.squash(name))) continue;
      items.push(it);
    }
    if (!items.length) issues.push("파일에서 수행평가 영역 표('평가 영역 · 만점 · 반영비율' 칸)를 찾지 못했어요.");
    return { items, exams, issues, hasRatio: !!fields?.includes('ratio'), hasMax: !!fields?.includes('max') };
  }

  function compareAreas({ parsed, rows, screen }) {
    const C = screen.columns;
    const issues = [...parsed.issues];
    const notes = [];
    const out = parsed.items.map((it) => {
      const res = { line: it.line, no: '', name: it.name, issues: [...it.issues], warnings: [], checks: [], cur: null, next: null, set: null, row: null, status: 'error' };
      const desc = (max, ratio) => [max ? `만점 ${max}` : '', ratio ? `반영 ${ratio}%` : ''].filter(Boolean).join(' · ');
      const hits = rows.filter((r) => D.squash(r[C.name]) === D.squash(it.name));
      res.next = { kind: desc(it.max, it.ratio), reason: '' };
      if (hits.length > 1) res.issues.push('나이스에 같은 이름의 영역이 여러 줄 있어요.');
      else if (hits.length === 1) {
        const row = hits[0];
        res.row = row; res.mode = 'update'; res.no = D.normNo(row[C.no]);
        res.cur = { kind: desc(row[C.max], row[C.ratio]), reason: '' };
        if (String(row[C.closed] ?? '').trim() === 'Y') res.issues.push('마감된 영역이에요.');
        const set = {};
        if (it.max && !same(row[C.max], it.max, true)) set[C.max] = it.max;
        if (it.ratio && !same(row[C.ratio], it.ratio, true)) set[C.ratio] = it.ratio;
        if (Object.keys(set).length && (row[C.max] || row[C.ratio])) res.warnings.push('나이스에 있는 값을 바꿔요.');
        res.set = set;
      } else if (!res.issues.length) {
        res.mode = 'insert'; res.no = '새';
        res.cur = { kind: '', reason: '' };
        res.set = { [C.name]: it.name, ...(it.max ? { [C.max]: it.max } : {}), ...(it.ratio ? { [C.ratio]: it.ratio } : {}), ...(screen.newRow || {}) };
        res.warnings.push('나이스에 없는 영역이라 새 줄로 넣어요.');
      }
      res.status = res.issues.length ? 'error' : res.set && Object.keys(res.set).length ? 'change' : 'same';
      return res;
    });
    // 반영비율 합계: 파일에 지필(고사) 비율이 있으면 지필 + 수행 = 100이어야 한다
    const inFile = new Set(parsed.items.map((i) => D.squash(i.name)));
    const others = rows.filter((r) => !inFile.has(D.squash(r[C.name])));
    const perfSum = Math.round((parsed.items.reduce((n, i) => n + Number(i.ratio || 0), 0) + others.reduce((n, r) => n + Number(r[C.ratio] || 0), 0)) * 100) / 100;
    const examSum = Math.round(parsed.exams.reduce((n, e) => n + Number(e.ratio || 0), 0) * 100) / 100;
    if (parsed.hasRatio && parsed.exams.length && examSum + perfSum !== 100) {
      issues.push(`반영비율 합계가 ${examSum + perfSum}%예요 (지필 ${examSum}% + 수행 ${perfSum}%). 100%가 되어야 해요.`);
    } else if (parsed.hasRatio) notes.push(`수행평가 반영비율 합계 ${perfSum}%${parsed.exams.length ? ` + 지필 ${examSum}% = 100%` : ''}.`);
    if (others.length) notes.push(`나이스에만 있는 영역 ${others.length}개(${cut(others.map((r) => r[C.name]).join(', '), 30)})는 그대로 둬요(지우지 않음).`);
    const upd = out.filter((r) => r.status === 'change' && r.mode === 'update');
    const ins = out.filter((r) => r.status === 'change' && r.mode === 'insert');
    const errors = out.filter((r) => r.status === 'error').length;
    const canApply = !issues.length && !errors && upd.length + ins.length > 0;
    return {
      rows: out, issues, notes,
      summary: { change: upd.length + ins.length, same: out.filter((r) => r.status === 'same').length, error: errors, added: ins.length },
      canApply,
      plan: canApply ? {
        appId: screen.appId,
        parts: [{
          dataset: screen.dataset, grid: screen.grid, keyColumns: [C.name],
          rows: upd.map((r) => ({ key: { [C.name]: r.row[C.name] }, expect: Object.fromEntries(Object.keys(r.set).map((c) => [c, r.row[c] ?? ''])), set: r.set })),
          insert: ins.length ? { button: screen.insert.button, rows: ins.map((r) => ({ set: r.set })) } : null,
        }],
      } : null,
    };
  }

  const areas = {
    parse: parseAreas,
    compare: compareAreas,
    readArgs: (screen) => ({ appId: screen.appId, dataset: screen.dataset, columns: Object.values(screen.columns) }),
  };

  // ── N2 성취수준(평가기준) 상·중·하 / A~E ─────────────────
  // 평가기준안의 '교육과정 성취기준 | 평가기준' 표. 실제 학교 양식(2025 기하·경제수학, 2026 기하)은 세로 모양:
  //   [12기하01-01] 내용 | 상 | 글      (경제수학은 [12경수01-01-00] 평가준거 칸, 뒤에 평가요소·평가방법 칸이 더 있음)
  //   중 | 글
  //   하 | 글
  // 가로 모양(머리줄 '성취기준 | 상 | 중 | 하')도 읽는다. 한 칸에 코드가 여럿 든 칸(요약 칸, '[..] ~ [..]')은 건너뛴다.
  const SCALES = { 3: ['상', '중', '하'], 5: ['A', 'B', 'C', 'D', 'E'] };
  const LABEL = (c) => { const s = D.squash(c).replace(/[()（）]/g, '').replace(/수준$/, ''); return /^(상|중|하|[A-E])$/.test(s) ? s : ''; };
  const CODE_G = new RegExp(CODE.source, 'g');
  const CRIA = /\[?\s*(\d{1,2}[가-힣A-Za-z]+\d?\s*-?\s*\d{2}\s*-\s*\d{2})\s*-\s*(\d{2})\s*\]/;
  const CRIA_JOINED = /\[\s*\(([^)]*)\)\s*-\s*(\d{2})\s*\]/; // 묶은 평가준거: [(12경수02-04/12경수02-05)-01]
  const nextText = (cells, i) => (cells.slice(i + 1).find((c) => c.trim()) || '').trim();
  const scaleOf = (labels) => (labels.every((l) => SCALES[3].includes(l)) ? SCALES[3] : labels.every((l) => SCALES[5].includes(l)) ? SCALES[5] : null);

  function parseLevels(text) {
    const items = [];
    const issues = [];
    const seen = new Set();
    let dup = 0;
    let cur = null; // 지금 채우는 성취기준(바로 위 줄이 그 코드 줄이나 수준 줄일 때만 이어 받음)
    let head = null; // 가로 표: { at: [[칸 번호, 수준]], width }
    const close = () => {
      if (cur?.levels.length) {
        for (const it of [cur, ...cur.joinedWith]) {
          const k = `${it.canon}|${it.cria}`;
          if (seen.has(k)) dup++;
          else { seen.add(k); items.push(it); }
        }
      }
      cur = null;
    };
    for (const l of D.lines(text)) {
      const cells = cellsOf(l);
      const labels = cells.map(LABEL);
      // 코드가 여럿 든 칸(요약 칸)은 건너뛴다. 단 수준 칸이 있는 줄(묶은 평가준거)은 읽는다.
      if (!labels.some(Boolean) && cells.some((c) => (c.match(CODE_G) || []).length > 1)) { close(); head = null; continue; }
      const ci = cells.findIndex((c) => (c.match(CODE_G) || []).length === 1);
      // 묶은 평가준거: 위 줄 코드에 수준이 아직 하나만 붙었을 때, 수준 칸 없는 코드 줄은 같은 평가기준을 함께 쓴다
      if (ci >= 0 && !head && !labels.some(Boolean) && cur?.levels.length === 1 && cur.joinedCria) {
        const code = cleanCode(CODE.exec(cells[ci])[1]);
        cur.joinedWith.push({ line: l.no, code, canon: canon(code), cria: cur.cria, text: cells[ci].replace(CODE, '').trim(), levels: cur.levels, joined: cur.code });
        continue;
      }
      if (ci < 0 && labels.filter(Boolean).length >= 3 && scaleOf(labels.filter(Boolean))) {
        close();
        head = { at: labels.map((x, i) => [i, x]).filter(([, x]) => x), width: cells.length };
        continue;
      }
      if (ci >= 0) {
        close();
        const code = cleanCode(CODE.exec(cells[ci])[1]);
        const cm = cells.map((c) => CRIA.exec(c)).find((m) => m && canon(m[1]) === canon(code));
        const jm = cells.map((c) => CRIA_JOINED.exec(c)).find((m) => m && canon(m[1]).includes(canon(code)));
        cur = { line: l.no, code, canon: canon(code), cria: cm ? cm[2] : jm ? jm[2] : '', joinedCria: !!jm, text: cells[ci].replace(CODE, '').trim(), levels: [], joinedWith: [] };
        const li = labels.findIndex((x, i) => x && i > ci);
        if (li >= 0) cur.levels.push({ label: labels[li], text: nextText(cells, li), line: l.no });
        else if (head) {
          const off = cells.length - head.width;
          for (const [i, label] of head.at) cur.levels.push({ label, text: String(cells[i + (off > 0 ? off : 0)] ?? '').trim(), line: l.no });
          close();
        }
        continue;
      }
      const fi = cells.findIndex((c) => c.trim());
      if (cur && fi >= 0 && labels[fi]) { cur.levels.push({ label: labels[fi], text: nextText(cells, fi), line: l.no }); continue; }
      close();
      if (fi >= 0 && !labels[fi]) head = null;
    }
    close();
    for (const it of items) {
      it.issues = [];
      const ls = it.levels.map((x) => x.label);
      if (!scaleOf(ls)) it.issues.push(`수준 이름이 섞여 있어요(${ls.join('·')}). 상·중·하 또는 A~E 중 하나로 적어 주세요.`);
      if (new Set(ls).size !== ls.length) it.issues.push('같은 수준이 두 번 있어요.');
      for (const x of it.levels) if (!x.text) it.issues.push(`${x.label} 평가기준 글이 비어 있어요.`);
    }
    if (!items.length) issues.push("파일에서 평가기준 표('성취기준 | 상 | 글' 또는 A~E)를 찾지 못했어요.");
    return { items, issues, notes: dup ? [`같은 성취기준의 평가기준이 여러 번 나와 첫 표만 썼어요(${dup}개 건너뜀).`] : [] };
  }

  // 1건 시험에 넣을 줄: 성취기준 줄 + 바로 아래 수준 줄들. 한 줄만 떼면 A칸만 들어가고, 평가기준이 빈 과목은 상·중·하 필수에 걸려 막힌다(2026-11-02 실제)
  function levelBlock(lines, i) {
    const out = [lines[i]];
    for (let j = i + 1; j < lines.length; j++) {
      const l = D.lines(String(lines[j]))[0];
      if (!l) break;
      const cells = cellsOf(l);
      const fi = cells.findIndex((c) => c.trim());
      if (fi < 0 || !LABEL(cells[fi]) || cells.some((c) => CODE.test(c))) break;
      out.push(lines[j]);
    }
    return out;
  }

  // rows: 나이스 dsRelm(성취기준 × 수준 한 줄씩, 수준이 아직 없으면 성취기준마다 빈 줄 하나)
  function compareLevels({ parsed, rows, screen }) {
    const C = screen.columns;
    const issues = [...parsed.issues];
    const notes = [...(parsed.notes || [])];
    const max = screen.maxBytes || 4000;
    const need = screen.required || 3;
    // 나이스 줄을 성취기준(코드+평가준거)별로 묶는다
    const groups = [];
    for (const r of rows) {
      const k = `${canon(r[C.code])}|${String(r[C.cria] ?? '').trim()}`;
      let g = groups.find((x) => x.key === k);
      if (!g) { g = { key: k, canon: canon(r[C.code]), code: String(r[C.code] ?? '').trim(), cria: String(r[C.cria] ?? '').trim(), text: String(r[C.text] ?? '').trim(), rows: [] }; groups.push(g); }
      g.rows.push(r);
    }
    for (const g of groups) {
      const names = g.rows.map((r) => String(r[C.levelName] ?? '').trim()).filter(Boolean);
      const n = Number(g.rows[0][C.count]) || names.length || 3;
      g.list = (names.some((x) => SCALES[5].includes(x)) || n > 3 ? SCALES[5] : SCALES[3]).slice(0, n);
      g.cur = Object.fromEntries(g.rows.filter((r) => String(r[C.levelName] ?? '').trim()).map((r) => [String(r[C.levelName]).trim(), String(r[C.levelText] ?? '')]));
      g.empty = !names.length;
    }
    const used = new Set();
    const show = (obj, list) => list.filter((x) => String(obj[x] ?? '').trim()).map((x) => `${x}: ${cut(obj[x], 16)}`).join(' / ');
    const out = parsed.items.map((it) => {
      const res = { line: it.line, no: it.code, name: cut(it.text, 24), issues: [...it.issues], warnings: [], checks: [], cur: null, next: null, set: null, row: null, status: 'error' };
      let hits = groups.filter((g) => g.canon === it.canon);
      if (hits.length > 1 && it.cria) hits = hits.filter((g) => g.cria === it.cria);
      // 묶은 평가준거의 두 번째 성취기준은 나이스에 따로 없을 수 있다(첫 성취기준 줄에 들어감)
      if (!hits.length && it.joined) { notes.push(`${it.code}는 ${it.joined}와 한 평가준거로 묶여 있어 나이스에 따로 없으면 건너뛰어요.`); return null; }
      if (!hits.length) { res.issues.push('나이스 [성취기준관리]에 없는 성취기준이에요. 성취기준을 먼저 넣어 주세요.'); return res; }
      if (hits.length > 1) { res.issues.push('나이스에 이 성취기준이 평가준거별로 여러 줄 있어요. 파일에 평가준거 코드(예: [12경수01-01-01])를 적어 주세요.'); return res; }
      const g = hits[0];
      used.add(g.key);
      res.name = cut(g.text || it.text, 24);
      res.group = g;
      res.cur = { kind: show(g.cur, g.list) || '(비어 있음)', reason: '' };
      const fileScale = scaleOf(it.levels.map((x) => x.label));
      if (fileScale && fileScale !== (g.list[0] === 'A' ? SCALES[5] : SCALES[3])) {
        res.issues.push(`파일은 ${fileScale.slice(0, 3).join('·')}… 수준인데 나이스는 ${g.list.join('·')} ${g.list.length}단계예요.`);
      }
      const set = {};
      for (const x of it.levels) {
        if (!g.list.includes(x.label)) { if (!res.issues.some((s) => s.includes('단계예요'))) res.issues.push(`나이스는 ${g.list.join('·')} ${g.list.length}단계라 '${x.label}'을(를) 넣을 곳이 없어요.`); continue; }
        if (x.text && x.text.trim() !== String(g.cur[x.label] ?? '').trim()) set[x.label] = x.text.trim();
      }
      const final = Object.fromEntries(g.list.map((x) => [x, set[x] ?? g.cur[x] ?? '']));
      g.list.forEach((x, i) => {
        const b = D.bytes(final[x]);
        if (i < need && !String(final[x]).trim()) res.issues.push(`${x} 평가기준이 비어 있어요(${g.list.slice(0, need).join('·')}은 꼭 채워야 해요).`);
        if (i >= need && String(final[x]).trim() && !String(final[g.list[i - 1]]).trim()) res.issues.push('평가기준은 순서대로 채워야 해요(앞 수준이 비어 있음).');
        if (b > max) res.issues.push(`${x} 평가기준이 ${b}바이트예요(나이스 한도 ${max}바이트).`);
      });
      if (Object.keys(set).some((x) => String(g.cur[x] ?? '').trim())) res.warnings.push('나이스에 있는 평가기준을 바꿔요.');
      res.set = set;
      res.row = g.rows[0];
      res.next = { kind: Object.keys(set).length ? show(set, g.list) : res.cur.kind, reason: '' };
      res.status = res.issues.length ? 'error' : Object.keys(set).length ? 'change' : 'same';
      return res;
    }).filter(Boolean);
    const untouched = groups.filter((g) => !used.has(g.key)).length;
    if (untouched) notes.push(`파일에 없는 나이스 성취기준 ${untouched}개는 그대로 둬요.`);
    if (!rows.length) issues.push('나이스 성취수준 목록이 비어 있어요. 나이스 화면에 학년도·학기·과목을 고르고 [조회]를 눌러 주세요.');
    const changes = out.filter((r) => r.status === 'change');
    const errors = out.filter((r) => r.status === 'error').length;
    const canApply = !issues.length && !errors && changes.length > 0;
    const DT = screen.detail;
    return {
      rows: out, issues, notes,
      summary: { change: changes.length, same: out.filter((r) => r.status === 'same').length, error: errors, untouched },
      canApply,
      // 성취기준마다: 왼쪽 줄 고르기(→ 오른쪽 dsEvl) → 수준 글 넣기 → 저장. 순서대로 runner가 한다.
      plan: canApply ? {
        appId: screen.appId,
        steps: changes.map((r) => ({
          code: r.group.code, cria: r.group.cria,
          set: r.set,
          expect: Object.fromEntries(Object.keys(r.set).map((x) => [x, r.group.cur[x] ?? ''])),
          emptyRows: r.group.empty ? r.group.list.map((x, i) => ({ [DT.code]: r.group.code, [C.cria]: r.group.cria, [DT.no]: String(i + 1), [DT.name]: x })) : null,
        })),
      } : null,
    };
  }

  // 왼쪽 줄을 골라 불러온 dsEvl에 넣을 계획(엔진 apply의 parts 한 개)
  function levelPart(step, evlRows, screen) {
    const DT = screen.detail;
    const rows = [];
    for (const [label, text] of Object.entries(step.set)) {
      const hit = evlRows.filter((r) => String(r[DT.name] ?? '').trim() === label);
      if (hit.length !== 1) return { error: `나이스 오른쪽 표에서 '${label}' 줄을 찾지 못했어요. 나이스에서 그 성취기준을 눌러 확인해 주세요.` };
      if (String(hit[0][DT.text] ?? '').trim() !== String(step.expect[label] ?? '').trim()) return { error: '확인한 뒤에 나이스 값이 바뀌었어요. 다시 확인해 주세요.' };
      rows.push({ key: { [DT.name]: label }, expect: { [DT.text]: hit[0][DT.text] ?? '' }, set: { [DT.text]: text } });
    }
    return { part: { dataset: DT.dataset, grid: DT.grid, keyColumns: [DT.name], rows } };
  }

  const levels = {
    parse: parseLevels,
    block: levelBlock,
    compare: compareLevels,
    part: levelPart,
    readArgs: (screen) => ({ appId: screen.appId, dataset: screen.dataset, columns: Object.values(screen.columns) }),
    detailArgs: (screen) => ({ appId: screen.appId, dataset: screen.detail.dataset, columns: [screen.detail.no, screen.detail.name, screen.detail.text, screen.detail.code] }),
    pickArgs: (screen, step) => ({
      appId: screen.appId, grid: screen.grid, dataset: screen.dataset, target: screen.detail.dataset, submission: screen.detail.submission,
      match: { [screen.columns.code]: step.code, [screen.columns.cria]: step.cria }, first: true, rowText: step.code, rowState: true,
      emptyRows: step.emptyRows, verifyTarget: { [screen.detail.code]: step.code },
    }),
    SCALES,
  };

  // ── V2 반영비율 점검(읽기만) ─────────────────────────────
  // 나이스 반영비율/만점관리(지필·수행 줄) ↔ 수행평가영역관리(영역 만점·반영비율) ↔ 평가기준안 파일(있으면). 나이스 값은 바꾸지 않음
  function compareRatio({ parsed = null, rows = [], areas = null, screen, areaScreen }) {
    const C = screen.columns;
    const AC = areaScreen?.columns || {};
    const issues = [];
    const notes = [];
    const pct = (n) => Math.round(n * 100) / 100;
    const isPerf = (r) => String(r[C.kindNo] ?? '').trim() === screen.kinds.perf || /수행/.test(String(r[C.kind] ?? ''));
    const used = (r) => String(r[C.used] ?? '').trim() !== 'N';
    const desc = (ratio, max) => [ratio !== '' && ratio != null ? `${Number(ratio)}%` : '', max ? `만점 ${Number(max)}` : ''].filter(Boolean).join(' · ');
    const fileExams = parsed?.exams || [], fileAreas = parsed?.items || [];
    const sq = (s) => D.squash(s);
    const takenArea = new Set(), takenFile = new Set();
    const out = rows.map((r, i) => {
      const perf = isPerf(r);
      const name = String(r[C.name] ?? '').trim();
      const res = { line: 0, type: perf ? 'P' : 'E', no: perf ? '수행' : '지필', name, issues: [], warnings: [], checks: [], cur: { kind: desc(r[C.ratio], r[C.max]), reason: '' }, next: null, set: null, row: r, status: 'same' };
      if (!used(r)) res.warnings.push('반영하지 않는 평가예요(합계에서 뺌).');
      if (String(r[C.closed] ?? '').trim() === 'Y') res.warnings.push('마감됨');
      if (perf && areas) {
        const no = String(r[C.area] ?? '').trim();
        const a = areas.find((x) => no && String(x[AC.no] ?? '').trim() === no) || areas.find((x) => sq(x[AC.name]) === sq(name));
        if (!a) res.issues.push('수행평가영역관리에 없는 영역이에요.');
        else {
          takenArea.add(a);
          if (!same(a[AC.max], r[C.max], true)) res.issues.push(`만점이 달라요 — 수행평가영역관리 ${Number(a[AC.max] || 0)}점.`);
          if (!same(a[AC.ratio], r[C.ratio], true)) res.issues.push(`반영비율이 달라요 — 수행평가영역관리 ${Number(a[AC.ratio] || 0)}%.`);
        }
      }
      if (parsed) {
        const f = perf ? fileAreas.find((x) => sq(x.name) === sq(name)) : fileExams.find((x) => sq(x.name) === sq(name));
        if (!f) res.warnings.push('평가기준안 파일에 없는 평가예요.');
        else {
          takenFile.add(f);
          res.next = { kind: desc(f.ratio, f.max), reason: '평가기준안' };
          if (f.ratio && !same(f.ratio, r[C.ratio], true)) res.issues.push(`평가기준안은 반영비율 ${Number(f.ratio)}%예요.`);
          if (f.max && !same(f.max, r[C.max], true)) res.issues.push(`평가기준안은 만점 ${Number(f.max)}점이에요.`);
        }
      }
      res.status = res.issues.length ? 'error' : 'same';
      return res;
    });
    // 수행평가영역관리에만 있는 영역, 평가기준안에만 있는 평가
    for (const a of areas || []) {
      if (takenArea.has(a) || String(a[AC.used] ?? 'Y').trim() === 'N') continue;
      out.push({ line: 0, type: 'P', no: '수행', name: String(a[AC.name] ?? '').trim(), issues: ['반영비율/만점관리에 없는 수행평가 영역이에요.'], warnings: [], checks: [], cur: { kind: desc(a[AC.ratio], a[AC.max]), reason: '수행평가영역관리' }, next: null, set: null, row: null, status: 'error' });
    }
    for (const f of [...fileExams.map((x) => ({ ...x, perf: false })), ...fileAreas.map((x) => ({ ...x, perf: true }))]) {
      if ([...takenFile].some((t) => sq(t.name) === sq(f.name))) continue;
      out.push({ line: f.line || 0, type: f.perf ? 'P' : 'E', no: f.perf ? '수행' : '지필', name: f.name, issues: ['나이스 반영비율/만점관리에 없는 평가예요(평가기준안에는 있음).'], warnings: [], checks: [], cur: null, next: { kind: desc(f.ratio, f.max), reason: '평가기준안' }, set: null, row: null, status: 'error' });
    }
    const sum = (perf) => pct(rows.filter((r) => used(r) && isPerf(r) === perf).reduce((n, r) => n + Number(r[C.ratio] || 0), 0));
    const exam = sum(false), perfSum = sum(true);
    if (!rows.length) issues.push('나이스 반영비율/만점관리가 비어 있어요. 나이스에서 과목을 고르고 반영비율을 먼저 넣어 주세요.');
    else if (pct(exam + perfSum) !== 100) issues.push(`반영비율 합계가 ${pct(exam + perfSum)}%예요 (지필 ${exam}% + 수행 ${perfSum}%). 100%가 되어야 해요.`);
    else notes.push(`반영비율 합계 100% (지필 ${exam}% + 수행 ${perfSum}%).`);
    if (areas == null) notes.push('수행평가영역관리를 읽지 못해 영역 만점·반영비율은 맞대어 보지 못했어요.');
    notes.push('점검만 해요 — 나이스 값은 바꾸지 않아요. 다른 곳은 나이스에서 고쳐 주세요.');
    const errors = out.filter((r) => r.status === 'error').length;
    return { rows: out, issues, notes, summary: { change: 0, same: out.length - errors, error: errors }, canApply: false, plan: null, subject: String(rows[0]?.[C.subject] ?? '').trim() };
  }
  const ratio = {
    compare: compareRatio,
    readArgs: (screen) => ({ appId: screen.appId, dataset: screen.dataset, columns: Object.values(screen.columns) }),
  };

  D.assess = { standard, items, areas, levels, ratio, canon, CODE };
})();
