// N1 담임 출결 — 입력 자료 해석 → 나이스 값과 비교 → 검증 → 입력 계획.
// 화면 설정(screens/neis-daily-attendance.js)과 엔진이 읽어 온 행만 다룬다. 나이스 화면을 직접 건드리지 않는다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;

  // 코드 규칙: 십의 자리 = 종류, 일의 자리 = 사유 (docs/selectors.md 출결 구분 코드표)
  const TYPE = { 0: '결석', 1: '지각', 2: '조퇴', 3: '결과' };
  const REASON_ALIAS = { 1: ['질병', '병'], 2: ['미인정', '무단'], 3: ['기타'], 4: ['출석인정', '인정'] };
  const HEAD = {
    no: ['번호', '번', '출석번호', '학생번호'],
    studentId: ['학번'],
    name: ['이름', '성명', '학생', '학생명', '학생이름'],
    kind: ['구분', '출결', '출결구분', '종류', '출결종류', '상태'],
    reason: ['사유', '비고', '메모', '내용', '출결사유'],
    date: ['날짜', '일자', '출결일', '출결일자'],
    period: ['교시'],
  };
  const headField = (cell) => {
    const s = D.squash(cell);
    return Object.keys(HEAD).find((f) => HEAD[f].includes(s)) || null;
  };

  // '질병결석', '병결', '무단지각', '01', '출석' … → 코드
  function kindLookup(codes) {
    const m = new Map();
    const add = (k, code) => { k = D.squash(k); if (k && !m.has(k)) m.set(k, code); };
    for (const [code, label] of Object.entries(codes)) {
      add(label, code);
      if (code) add(code, code);
    }
    // 줄임말이 겹치면('병결' = 질병결석/질병결과) 결석 쪽이 이긴다. '11' 같은 키는 객체에서 앞으로 오므로 직접 정렬한다.
    for (const code of Object.keys(codes).sort()) {
      const mm = /^([0-3])([1-4])$/.exec(code);
      if (!mm) continue;
      const t = TYPE[mm[1]];
      for (const r of REASON_ALIAS[mm[2]]) { add(r + t, code); add(r + t[0], code); }
    }
    for (const k of ['출석', '출', '정상']) add(k, '');
    return m;
  }

  // 화면의 코드표(dsAtteGb)를 먼저 쓰고, 못 읽으면 설정 파일의 표
  function codeTable(screen, extra) {
    const t = screen.codeTable;
    const rows = extra && extra[t.dataset];
    if (rows && rows.length) {
      const codes = { '': '출석' };
      for (const r of rows) {
        const c = String(r[t.code] ?? '').trim();
        const l = String(r[t.label] ?? '').trim();
        if (c && l) codes[c] = l;
      }
      if (Object.keys(codes).length > 1) return { codes, source: 'neis' };
    }
    return { codes: { ...screen.codes }, source: 'builtin' };
  }

  // 교시 표시 칸: 조회(jo), 1~N교시(gyo1…), 종례(jong) / 수업 있음(g1…)·행사 아님(e1…) / 최대 교시(totMax)
  function markColumns(screen) {
    const M = screen.marks;
    if (!M) return [];
    const n = Array.from({ length: M.max }, (_, i) => i + 1);
    return [M.totMax, M.first, M.last, ...n.map((i) => M.period + i), ...n.map((i) => M.hasClass + i), ...n.map((i) => M.noEvent + i)];
  }

  function readArgs(screen) {
    const K = screen.key, C = screen.columns, S = screen.search;
    return {
      appId: screen.appId,
      dataset: screen.dataset,
      columns: [K.no, K.name, K.sameName, C.kind, C.reason, ...(C.closed || []), ...markColumns(screen)],
      dataMaps: { [S.dataMap]: [S.year, S.grade, S.cls, S.date, ...(S.chasu ? [S.chasu] : [])] },
      extraDatasets: { [screen.codeTable.dataset]: [screen.codeTable.code, screen.codeTable.label] },
    };
  }

  function contextOf(screen, dm) {
    const S = screen.search;
    const m = (dm && dm[S.dataMap]) || {};
    return { year: m[S.year] || '', grade: m[S.grade] || '', cls: m[S.cls] || '', date: D.normDate(m[S.date] || ''), rawDate: m[S.date] || '', chasu: m[S.chasu] || '' };
  }
  const sameClass = (a, b) => !!a && !!b && a.year === b.year && a.grade === b.grade && a.cls === b.cls;
  const classLabel = (c) => {
    if (!c || !c.grade) return '';
    const n = (v) => (/^\d+$/.test(v) ? String(parseInt(v, 10)) : v);
    return `${n(c.grade)}학년 ${n(c.cls)}반`;
  };

  // ── 입력 자료 해석 ────────────────────────────────────────
  const blank = (line) => ({ line, no: '', name: '', kind: null, kindText: '', reason: null, dates: [], periods: [], issues: [] });

  // 날짜 칸·낱말 하나 → 날짜 목록 (기간이면 평일로 펼침)
  function addDates(item, text, year) {
    text = String(text ?? '').replace(/\s*~\s*/g, '~').trim();
    if (D.isDateRangeToken(text)) {
      const r = D.expandDateRange(text, year);
      if (r.error) item.issues.push(r.error);
      item.dates.push(...r.dates);
      return;
    }
    const d = D.normDate(text, year);
    if (d) item.dates.push(d);
    else item.issues.push(`날짜를 알 수 없어요: "${text}"`);
  }

  function noFromStudentId(s) {
    const d = String(s ?? '').replace(/\D/g, '');
    return d.length >= 3 ? String(parseInt(d.slice(-2), 10)) : D.normNo(d);
  }

  // 교시 칸: '2,3' · '1-3' · '조회~2' · '3~종례' → 숫자 목록. 조회는 0, 종례는 99
  const PERIOD_WORD = { 조회: 0, 종례: 99 };
  function parsePeriods(s) {
    const out = new Set();
    const num = (t) => (t in PERIOD_WORD ? PERIOD_WORD[t] : /^\d+$/.test(t) ? +t : null);
    for (const part of String(s ?? '').replace(/교시/g, '').replace(/·/g, ',').split(/[,\s]+/)) {
      const r = /^(조회|종례|\d+)\s*[~-]\s*(조회|종례|\d+)$/.exec(part);
      if (r) { const a = num(r[1]), b = num(r[2]); for (let i = a; i <= Math.min(b, 12); i++) out.add(i); if (b === 99) out.add(99); continue; }
      const n = num(part);
      if (n !== null) out.add(n);
    }
    return [...out].filter((n) => (n >= 0 && n <= 12) || n === 99).sort((a, b) => a - b);
  }

  function setKind(item, text, lookup) {
    item.kindText = String(text ?? '').trim();
    if (!item.kindText) { item.issues.push('출결 구분이 비었어요.'); return; }
    const code = lookup.get(D.squash(item.kindText));
    if (code === undefined) {
      const bare = /^(결석|지각|조퇴|결과)$/.test(String(item.kindText || '').replace(/\s+/g, ''));
      item.issues.push(bare ? `'${item.kindText}'만으로는 나이스 칸을 고를 수 없어요. 질병${item.kindText}·미인정${item.kindText}·기타${item.kindText}·인정${item.kindText}처럼 적거나 [고치기]에서 골라 주세요.` : `출결 구분을 알 수 없어요: "${item.kindText}"`);
    }
    else item.kind = code;
  }

  function parseWithHeader(lines, sep, fields, lookup, opts) {
    const issues = [];
    if (!fields.includes('kind')) issues.push('자료에 출결 구분 칸(구분·출결)이 없어요.');
    if (!fields.some((f) => f === 'no' || f === 'name' || f === 'studentId')) issues.push('자료에 번호나 이름 칸이 없어요.');
    const items = lines.map((l) => {
      let cells = sep ? D.splitCells(l.raw, sep) : l.raw.trim().split(/\s+/);
      if (!sep && cells.length > fields.length) cells = [...cells.slice(0, fields.length - 1), cells.slice(fields.length - 1).join(' ')];
      const get = (f) => { const i = fields.indexOf(f); return i >= 0 ? String(cells[i] ?? '').trim() : null; };
      const item = blank(l.no);
      const sid = get('studentId');
      item.no = D.normNo(get('no')) || (sid ? noFromStudentId(sid) : '');
      item.name = D.squash(get('name') ?? '');
      setKind(item, get('kind'), lookup);
      const reason = get('reason');
      item.reason = reason ? reason : null;
      const date = get('date');
      if (date) addDates(item, date, opts.year);
      const period = get('period');
      if (period) item.periods = parsePeriods(period);
      if (!item.no && !item.name) item.issues.push('번호나 이름이 없어요.');
      return item;
    });
    return { mode: 'header', items, issues };
  }

  // 머리줄 없는 자유 입력: "3 홍길동 질병결석 병원 진료", "10305,병결,감기", "홍길동 무단지각"
  function parseFree(line, lookup, opts) {
    const raw = line.raw
      .replace(/(질병|미인정|기타|출석인정|무단|인정)\s+(결석|지각|조퇴|결과)/g, '$1$2')
      .replace(/\s*~\s*/g, '~');
    const item = blank(line.no);
    const re = /[^\s,\t]+/g;
    let m, rest = null;
    while ((m = re.exec(raw))) {
      const t = m[0].replace(/^"|"$/g, '');
      if (D.isDateToken(t) || D.isDateRangeToken(t)) { addDates(item, t, opts.year); continue; }
      if (/^\d+$/.test(t)) {
        if (!item.no) { item.no = t.length >= 3 ? noFromStudentId(t) : D.normNo(t); continue; }
        if (lookup.has(t)) { item.kind = lookup.get(t); item.kindText = t; rest = raw.slice(re.lastIndex); break; }
        item.issues.push(`무엇인지 모르는 숫자: "${t}"`);
        continue;
      }
      const code = lookup.get(D.squash(t));
      if (code !== undefined) { item.kind = code; item.kindText = t; rest = raw.slice(re.lastIndex); break; }
      if (!item.name && /^[가-힣A-Za-z]{2,10}$/.test(t)) { item.name = t; continue; }
      item.issues.push(`무엇인지 모르는 말: "${t}"`);
    }
    if (rest !== null) {
      const pm = /(\d+(?:\s*[,~-]\s*\d+)*)\s*교시/.exec(rest);
      if (pm) { item.periods = parsePeriods(pm[1]); rest = rest.replace(pm[0], ''); }
      const reason = rest.replace(/^[\s,\t"]+|[\s,\t"]+$/g, '');
      item.reason = reason || null;
    } else {
      item.issues.push('출결 구분을 찾지 못했어요 (예: 질병결석, 병결, 미인정지각, 출석).');
    }
    if (!item.no && !item.name) item.issues.push('번호나 이름이 없어요.');
    return item;
  }

  function parseInput(text, codes, opts = {}) {
    const lookup = kindLookup(codes);
    const lines = D.lines(text);
    if (!lines.length) return { mode: null, items: [], issues: [] };
    const first = lines[0].raw;
    const sep = first.includes('\t') ? '\t' : first.includes(',') ? ',' : null;
    const headCells = sep ? D.splitCells(first, sep) : first.trim().split(/\s+/);
    const fields = headCells.map(headField);
    if (fields.filter(Boolean).length >= 2) return parseWithHeader(lines.slice(1), sep, fields, lookup, opts);
    return { mode: 'free', items: lines.map((l) => parseFree(l, lookup, opts)), issues: [] };
  }

  // ── 날짜별로 나누기 ───────────────────────────────────────
  // 날짜가 없는 줄은 지금 나이스 화면의 날짜. 같은 줄이 기간이면 날짜마다 한 줄씩.
  function splitByDate(parsed, screenDate) {
    const groups = new Map();
    for (const item of parsed.items) {
      const dates = item.dates.length ? [...new Set(item.dates)] : [screenDate];
      for (const d of dates) {
        if (!groups.has(d)) groups.set(d, []);
        groups.get(d).push({ ...item, date: d, issues: [...item.issues] });
      }
    }
    return [...groups.keys()].sort().map((date) => ({ date, parsed: { mode: parsed.mode, items: groups.get(date), issues: [] } }));
  }

  function searchArgs(screen, ctx, ymd) {
    const S = screen.search;
    return { appId: screen.appId, dataMap: S.dataMap, values: { [S.date]: D.formatDateLike(ctx.rawDate, ymd) }, button: S.button, dataset: screen.dataset };
  }

  // ── 나이스 값과 비교·검증 ────────────────────────────────
  function group(rows, keyFn) {
    const m = new Map();
    for (const r of rows) {
      const k = keyFn(r);
      if (!m.has(k)) m.set(k, []);
      m.get(k).push(r);
    }
    return m;
  }

  // 교시 표시('/' 결석·결과, 'Ø' 출석인정) — 나이스 화면 규칙을 따른다(docs/probe '일일출결관리 저장 규칙').
  // 결석(0x): 마감 칸에서 결석을 고를 때처럼 조회·수업 있는 교시(g=Y·e=Y)·종례 전부
  // 지각·조퇴·결과: 자료에 교시(출석부 웹앱이 시각으로 계산한 것)가 있으면 그 교시에, 없으면 교과 선생님이 이미 찍은 표시로
  //   (지각: 조회~찍힌 마지막 교시, 조퇴: 찍힌 첫 교시~종례, 결과: 찍힌 그대로).
  //   출석인정이면 '/'→'Ø'. 자료 교시 밖에 이미 찍힌 표시는 건드리지 않는다
  // 출석(''): 표시를 모두 지운다
  function planMarks(screen, row, kind, context, wanted = []) {
    const M = screen.marks;
    const out = { set: {}, count: 0, issue: '', note: '' };
    if (!M || !row) return out;
    const tot = Math.min(M.max, parseInt(row[M.totMax], 10) || M.max);
    const periods = Array.from({ length: tot }, (_, i) => i + 1);
    const cells = [M.first, ...periods.map((n) => M.period + n), M.last];
    const val = (c) => String(row[c] ?? '');
    const isMark = (v) => v === M.absent || v === M.recognized;
    const recognized = (screen.recognizedKinds || []).includes(kind) && (parseInt(context.year, 10) || 0) >= M.recognizedFromYear
      && (parseInt(context.chasu, 10) || 0) >= (M.recognizedFromChasu || 0);
    const mark = recognized ? M.recognized : M.absent;
    const put = (c, v) => { if (val(c) !== v) out.set[c] = v; };

    if (kind === '') {
      cells.forEach((c) => { if (isMark(val(c))) put(c, ''); });
      out.count = Object.keys(out.set).length;
      if (out.count) out.note = `교시 표시 ${out.count}칸을 지워요`;
      return out;
    }
    if (/^0/.test(kind)) {
      const target = [M.first, ...periods.filter((n) => val(M.hasClass + n) === 'Y' && val(M.noEvent + n) === 'Y').map((n) => M.period + n), M.last];
      target.forEach((c) => put(c, mark));
      out.count = target.length;
      out.note = `조회·수업 교시·종례 ${target.length}칸에 ${mark}`;
      return out;
    }
    if (wanted.length) {
      const target = [
        ...(wanted.includes(0) ? [M.first] : []),
        ...periods.filter((n) => wanted.includes(n) && val(M.hasClass + n) === 'Y' && val(M.noEvent + n) === 'Y').map((n) => M.period + n),
        ...(wanted.includes(99) ? [M.last] : []),
      ];
      if (!target.length) { out.issue = '자료의 교시가 이 날 수업 교시와 겹치지 않아요. 시각과 날짜를 확인해 주세요.'; return out; }
      target.forEach((c) => put(c, mark));
      out.count = target.length;
      const other = cells.filter((c) => !target.includes(c) && isMark(val(c))).length;
      const name = (c) => (c === M.first ? '조회' : c === M.last ? '종례' : `${c.slice(M.period.length)}교시`);
      out.note = `${target.map(name).join('·')} ${target.length}칸에 ${mark}${other ? ` · 나이스에 찍힌 다른 교시 ${other}칸은 그대로` : ''}`;
      return out;
    }
    const existing = cells.filter((c) => isMark(val(c)));
    if (!existing.length) {
      out.issue = '나이스에 찍힌 교시 표시(/)가 없어요. 과목 선생님이 교시 출결을 넣은 뒤에 하거나, 나이스에서 교시를 직접 눌러 주세요.';
      return out;
    }
    // 시각이 없을 때: 지각은 조회부터 찍힌 마지막 교시까지, 조퇴는 찍힌 첫 교시부터 종례까지, 결과는 찍힌 그대로
    const lesson = (c) => c === M.first || c === M.last || isMark(val(c)) || (val(M.hasClass + c.slice(M.period.length)) === 'Y' && val(M.noEvent + c.slice(M.period.length)) === 'Y');
    let target = existing;
    if (/^1/.test(kind)) target = cells.slice(0, cells.indexOf(existing[existing.length - 1]) + 1).filter(lesson);
    else if (/^2/.test(kind)) target = cells.slice(cells.indexOf(existing[0])).filter(lesson);
    target.forEach((c) => put(c, mark));
    out.count = target.length;
    out.note = target.length === existing.length ? `나이스에 찍힌 교시 ${existing.length}칸 사용` : `나이스에 찍힌 교시로 ${/^1/.test(kind) ? '조회부터 마지막 찍힌 교시까지' : '첫 찍힌 교시부터 종례까지'} ${target.length}칸`;
    return out;
  }

  // 동명이인 표시: 실제 나이스는 '0'(아님)으로 온다(2026-10-27 확인). 그 밖의 값('1', 'Y' 등)은 동명이인으로 본다.
  const isSameName = (v) => !['', '0', 'N'].includes(String(v ?? '').trim());

  // 나이스에 이미 넣은 출결 구분과 자료(폰) 구분이 다른 줄(교사 결정 2026-10-30: 구분이 다를 때만, 기본은 자료 값으로)
  // choices[번호] === 'neis'이면 그 줄은 '나이스 그대로'(status 'keep') — 저장 계획·저장 검사에서 빠지고 나이스 값 그대로
  function markConflict(res, choices) {
    if (res.status !== 'change' || !res.cur || res.cur.kind === '' || !res.next || res.next.kind === res.cur.kind) return;
    res.conflict = true;
    if ((choices || {})[res.neisNo || res.no] !== 'neis') return;
    res.status = 'keep';
    res.would = res.set;
    res.set = null;
  }

  function compare({ parsed, rows, screen, context = {}, codes, verified = false, choices = {} }) {
    const K = screen.key, C = screen.columns;
    const lookup = kindLookup(codes);
    const toCode = (v) => {
      v = String(v ?? '').trim();
      if (v === '' || v in codes) return v;
      const c = lookup.get(D.squash(v));
      return c === undefined ? v : c;
    };
    // 나이스 칸에 코드가 아니라 이름('질병결석')이 들어 있으면 같은 형식으로 넣는다(일일출결은 이름 — 설정 kindFormat)
    const labelFormat = screen.kindFormat === 'label' || rows.some((r) => /[가-힣]/.test(r[C.kind] || ''));
    const toStored = (code) => (labelFormat && code !== '' ? codes[code] : code);

    const issues = [...parsed.issues];
    if (!rows.length) issues.push('이 날은 나이스 표가 비어 있어요. 휴업일인지, 학년·반이 맞는지 확인해 주세요.');
    const byNo = group(rows, (r) => D.normNo(r[K.no]));
    const byName = group(rows, (r) => D.squash(r[K.name]));
    const taken = new Map();

    const out = parsed.items.map((item) => {
      const res = {
        line: item.line, no: item.no, name: item.name, kindText: item.kindText, neisName: '',
        issues: [...item.issues], warnings: [], cur: null, next: null, set: null, row: null, status: 'error',
      };
      let row = null;
      if (rows.length && item.no) {
        const hits = byNo.get(item.no) || [];
        if (!hits.length) res.issues.push(`${item.no}번 학생이 나이스 표에 없어요.`);
        else if (hits.length > 1) res.issues.push(`${item.no}번이 나이스 표에 여러 줄 있어요.`);
        else {
          row = hits[0];
          if (item.name && D.squash(row[K.name]) !== D.squash(item.name)) res.issues.push(`이름이 달라요 (나이스: ${row[K.name]})`);
          if (!item.name) res.warnings.push('번호로만 맞췄어요. 이름을 확인해 주세요.');
        }
      } else if (rows.length && item.name) {
        const hits = byName.get(D.squash(item.name)) || [];
        if (!hits.length) res.issues.push('이 이름이 나이스 표에 없어요.');
        else if (hits.length > 1 || isSameName(hits[0][K.sameName])) res.issues.push('같은 이름이 있어요. 번호를 함께 적어 주세요.');
        else row = hits[0];
      }

      if (row) {
        res.neisName = row[K.name];
        res.neisNo = D.normNo(row[K.no]);
        if (taken.has(row._row)) res.issues.push(`${taken.get(row._row)}번째 줄과 같은 학생이에요.`);
        else taken.set(row._row, item.line);
        if ((C.closed || []).some((c) => String(row[c] ?? '').trim() === 'Y')) res.issues.push('마감된 출결이에요. 마감 취소는 나이스에서 직접 해 주세요.');
        res.cur = { kind: toCode(row[C.kind]), reason: String(row[C.reason] ?? '') };
      }

      if (item.date && context.date && item.date !== context.date) {
        res.issues.push(`날짜가 달라요: 자료 ${D.showDate(item.date)}, 나이스 ${D.showDate(context.date)}`);
      }
      if (item.kind !== null && item.periods.length && /^0/.test(item.kind)) res.warnings.push('결석은 자료의 교시와 상관없이 수업 있는 교시 전부에 넣어요.');

      if (res.cur && item.kind !== null) {
        const reason = item.kind === '' ? '' : (item.reason !== null ? item.reason : res.cur.reason);
        res.next = { kind: item.kind, reason };
        const b = D.bytes(reason);
        if (screen.reasonMaxBytes && b > screen.reasonMaxBytes) res.issues.push(`사유가 너무 길어요 (${b}/${screen.reasonMaxBytes}바이트).`);
        if ((screen.reasonRequired || []).includes(item.kind) && !reason.trim()) res.issues.push(`${codes[item.kind]}은 사유를 꼭 적어야 해요.`);
        // 기타가 아니면 사유는 비어도 됨(교사 2026-10-30) — 안내도 띄우지 않음
        const set = {};
        if (res.next.kind !== res.cur.kind) set[C.kind] = toStored(res.next.kind);
        if (res.next.reason !== res.cur.reason) set[C.reason] = res.next.reason;
        const m = planMarks(screen, row, item.kind, context, item.periods);
        if (m.issue) res.issues.push(m.issue);
        Object.assign(set, m.set);
        res.marks = m.count;
        res.markNote = m.note;
        res.set = set;
        res.row = row;
      }
      res.status = res.issues.length ? 'error' : res.set && Object.keys(res.set).length ? 'change' : 'same';
      markConflict(res, choices);
      return res;
    });

    const notes = [];
    // 저장 검사: 자료에 없는 학생 중 교시 표시만 있고 구분이 없는 학생이 있으면 나이스가 저장 전체를 막는다(SW-SRG-4023, 차수 795 미만)
    const M = screen.marks;
    if (M && rows.length) {
      const isMark = (v) => v === M.absent || v === M.recognized;
      const cells = [M.first, M.last, ...Array.from({ length: M.max }, (_, i) => M.period + (i + 1))];
      const pending = rows.filter((r) => !taken.has(r._row) && !String(r[C.kind] ?? '').trim() && cells.some((c) => isMark(String(r[c] ?? ''))));
      if (pending.length) {
        const nos = pending.map((r) => D.normNo(r[K.no])).join(', ');
        const strict = (parseInt(context.chasu, 10) || 0) < (screen.markCheckBelowChasu || 0);
        const msg = `교시 표시(/)는 있는데 출결구분이 없는 학생이 ${pending.length}명 있어요(${nos}번).`;
        if (strict) issues.push(`${msg} 이 학년은 이대로 저장하면 나이스가 막아요. 그 학생들도 자료에 넣어 주세요.`);
        else notes.push(`${msg} 저장은 되지만 마감 전에 처리해야 해요.`);
      }
    }
    // 자료에 없는데 나이스에 출결 구분이나 교시 표시가 있는 학생(교사 요청 2026-10-29: 확인 표에서 바로 추가해 고치기)
    const marked = (r) => {
      if (!M) return false;
      const cells = [M.first, M.last, ...Array.from({ length: M.max }, (_, i) => M.period + (i + 1))];
      return cells.some((c) => [M.absent, M.recognized].includes(String(r[c] ?? '')));
    };
    // 그 학생의 나이스 교시 표시(조회 0 · 1~12교시 · 종례 99) — 패널 [고치기]가 지각·조퇴 범위를 미리 고르는 데 씀(교사 요청 2026-10-30)
    const markList = (r) => {
      if (!M) return [];
      const on = (c) => [M.absent, M.recognized].includes(String(r[c] ?? ''));
      return [...(on(M.first) ? [0] : []), ...Array.from({ length: M.max }, (_, i) => i + 1).filter((n) => on(M.period + n)), ...(on(M.last) ? [99] : [])];
    };
    const neisOnly = rows.filter((r) => !taken.has(r._row) && (String(r[C.kind] ?? '').trim() || marked(r)))
      .map((r) => ({ no: D.normNo(r[K.no]), name: String(r[K.name] ?? ''), kind: toCode(r[C.kind]), reason: String(r[C.reason] ?? ''), marksOnly: !String(r[C.kind] ?? '').trim(),
        marks: markList(r), tot: parseInt(r[M?.totMax], 10) || 0 }));
    const changes = out.filter((r) => r.status === 'change');
    if (!verified && changes.length > 1) {
      issues.push(`처음에는 학생 1명만 넣을 수 있어요(지금 ${changes.length}명). 나이스에서 결과를 확인하면 전체 입력이 열려요.`);
    }
    const errors = out.filter((r) => r.status === 'error').length;
    // 나이스 저장 검사 흉내(2026-10-30 화면 스크립트 his_srgaa02_m02 — 교사 제보: 확인 표는 괜찮았는데 저장에서 SW-SRG-4023으로 멈춤)
    // 차수 795 미만이면 그날 반 학생 누구라도 ① '/'가 있는데 출결구분이 비었거나 ② 출결구분이 있는데 '/'가 하나도 없으면 그날 저장 전체를 막는다.
    // 2026학년도부터는 ③ 'Ø'가 있는데 출결구분이 빈 것도. 넣을 값을 겹친 뒤의 모양으로 미리 본다(①의 '자료에 없는 학생'은 위 안내가 이미 다룸)
    if (M && rows.length && (parseInt(context.chasu, 10) || 0) < (screen.markCheckBelowChasu || 0)) {
      const cells = [M.first, ...Array.from({ length: M.max }, (_, i) => M.period + (i + 1)), M.last];
      const setOf = new Map(out.filter((r) => r.row && r.set).map((r) => [r.row._row, r.set]));
      const bad = [];
      for (const r of rows) {
        const s = setOf.get(r._row) || {};
        const v = (c) => String((c in s ? s[c] : r[c]) ?? '').trim();
        const slash = cells.filter((c) => v(c) === M.absent).length;
        const rec = cells.filter((c) => v(c) === M.recognized).length;
        const gb = v(C.kind);
        const mine = setOf.has(r._row);
        if (gb && !slash) bad.push(`${D.normNo(r[K.no])}번(출결구분은 있는데 교시 '/'가 없음)`);
        else if (!gb && slash && mine) bad.push(`${D.normNo(r[K.no])}번('/'는 있는데 출결구분이 빔)`);
        else if (!gb && rec && (parseInt(context.year, 10) || 0) >= (M.recognizedFromYear || 0)) bad.push(`${D.normNo(r[K.no])}번('Ø'는 있는데 출결구분이 빔)`);
      }
      if (bad.length) issues.push(`이대로 저장하면 나이스가 이 날을 막아요 — ${bad.join(', ')}. 그 학생 줄을 [고치기]·[추가해서 고치기]로 맞춰 주세요(지각·조퇴·결과는 교시를 골라 주세요).`);
    }
    const canApply = !issues.length && !errors && changes.length > 0;
    const plan = canApply ? {
      appId: screen.appId,
      dataset: screen.dataset,
      grid: screen.grid,
      keyColumns: [K.no, K.name],
      rows: changes.map((r) => ({
        key: { [K.no]: r.row[K.no], [K.name]: r.row[K.name] },
        // 바꿀 칸은 모두 미리보기 때 값과 같아야 넣는다
        expect: Object.fromEntries([C.kind, C.reason, ...Object.keys(r.set)].map((c) => [c, r.row[c] ?? ''])),
        set: r.set,
      })),
    } : null;

    return {
      rows: out,
      issues,
      notes,
      summary: {
        change: changes.length,
        same: out.filter((r) => r.status === 'same').length,
        error: errors,
        untouched: Math.max(0, rows.length - taken.size),
      },
      canApply,
      plan,
      labelFormat,
      neisOnly,
    };
  }

  // 저장 뒤 나이스를 다시 읽어 계획한 값이 들어갔는지 센다.
  function verifySaved(plan, rows) {
    const norm = (v) => String(v ?? '').trim();
    let ok = 0;
    const missed = [];
    plan.rows.forEach((p, i) => {
      const row = rows.find((r) => plan.keyColumns.every((c) => norm(r[c]) === norm(p.key[c])));
      if (row && Object.entries(p.set).every(([c, v]) => String(row[c] ?? '') === String(v))) ok++;
      else missed.push(i);
    });
    return { ok, missed };
  }

  D.attendance = { kindLookup, codeTable, readArgs, contextOf, sameClass, classLabel, parseInput, parsePeriods, splitByDate, searchArgs, compare, verifySaved };
})();
