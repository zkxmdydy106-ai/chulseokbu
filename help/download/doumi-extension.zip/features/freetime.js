// S1 빈 시간 찾기 — 컴시간 시간표(교사별) + 나이스 일일근무상황(성명·기간) → 교시마다 수업/부재/비어 있음.
// 결정(2026-10-28): 그룹 저장, 부재는 '부재'만(근무상황 종류·목적지는 읽지 않음), 교시 단위(조회~7교시), 하루·한 주.
// 컴시간은 학생용 웹이 쓰는 자료를 그대로 읽는다(공식 연동 없음). 교사 이름은 컴시간에서 '김요*'처럼 가려져 온다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const DAY = ['일', '월', '화', '수', '목', '금', '토'];
  const LAST = 7; // 조회~7교시

  // 컴시간 응답(JSON) → 필요한 것만. 교사별 일일 시간표(자료542)에는 변경이 '>새값' 글자로 붙어 온다('>0' = 변경되어 수업 없음)
  function parseComci(d) {
    // 칸 이름의 숫자는 컴시간이 바꾼다(자료446·542·492 → 2026-11-04 실제 자료122·174·194) → 모양으로 찾는다.
    // 교사 이름 = 별표로 가린 글 목록, 교사별 표 = 이름 목록과 길이가 같은 표, 과목 = 나머지 글 목록
    const lists = Object.keys(d || {}).filter((k) => /^자료\d+$/.test(k) && Array.isArray(d[k])).map((k) => d[k]);
    const texts = lists.filter((a) => a.slice(1).some((x) => typeof x === 'string' && x));
    const who = texts.find((a) => a.slice(1).some((x) => typeof x === 'string' && x.includes('*')));
    const table = who && lists.find((a) => a.length === who.length && a.slice(1).some((x) => Array.isArray(x)));
    if (!who || !table) throw new Error('컴시간 자료 모양이 달라요. 컴시간이 바뀌었을 수 있어요.');
    const subjects = texts.filter((a) => a !== who).sort((x, y) => y.length - x.length)[0];
    return {
      school: String(d.학교명 || ''),
      names: who.map((n, i) => (i ? String(n || '') : '')),
      weeks: (d.일자자료 || []).map((w) => ({ no: +w[0], label: String(w[1] || '') })),
      times: (d.일과시간 || []).map((t) => String(t)),
      table,
      subjects: subjects ? subjects.map((x, i) => (i ? String(x || '') : '')) : [],
      sep: Number(d.분리) || 1000,
    };
  }
  // 교사별 칸 숫자 → 과목·학년·반(2026-10-29 실제 강경고 컴시간 확인: 4014302 = 과목 14 '경수' · 302 = 3학년 2반, 학급별 칸과 맞대어 봄)
  function lesson(cm, v) {
    const s = String(v ?? '').trim();
    const changed = s.startsWith('>');
    const n = Number(changed ? s.slice(1) : s);
    if (!n) return null;
    const sep = cm.sep || 1000, cls = n % sep;
    return { subject: cm.subjects?.[Math.floor(n / sep) % sep] || '', grade: Math.floor(cls / 100), ban: cls % 100, changed };
  }
  // '오늘 내 수업'(H1): 교사 t의 그 요일 수업 — [{ p, start: '08:50', subject, grade, ban, changed }]
  function myDay(cm, t, weekday) {
    const row = cm.table?.[t]?.[weekday];
    if (!Array.isArray(row)) return [];
    const bells = Object.fromEntries((cm.times || []).map((x) => /^(\d+)\((\d{1,2}:\d{2})\)/.exec(String(x))).filter(Boolean).map((m) => [+m[1], m[2]]));
    const out = [];
    for (let p = 1; p < row.length && p <= 9; p++) { const l = lesson(cm, row[p]); if (l) out.push({ p, start: bells[p] || '', ...l }); }
    return out;
  }
  const cellBusy = (v) => {
    if (typeof v === 'number') return v !== 0;
    const s = String(v ?? '').trim();
    if (s.startsWith('>')) return Number(s.slice(1)) !== 0 && s.slice(1) !== '';
    return s !== '' && s !== '0';
  };
  // 교사 t의 요일(1=월…5=금) 수업 교시 목록
  function busyPeriods(cm, t, weekday) {
    const row = cm.table?.[t]?.[weekday];
    if (!Array.isArray(row)) return [];
    const out = [];
    for (let p = 1; p < row.length && p <= LAST; p++) if (cellBusy(row[p])) out.push(p);
    return out;
  }

  const mins = (hm) => { const m = /(\d{1,2}):(\d{2})/.exec(String(hm || '')); return m ? +m[1] * 60 + +m[2] : null; };
  // 컴시간 일과시간 ['1(08:50)', …] → 교시 시각(50분), 조회는 1교시 앞 10분
  function bellsFrom(times, len = 50) {
    const out = [];
    for (const t of times || []) {
      const m = /^(\d+)\((\d{1,2}:\d{2})\)/.exec(String(t));
      if (m && +m[1] <= LAST) out.push({ p: +m[1], s: mins(m[2]), e: mins(m[2]) + len });
    }
    out.sort((a, b) => a.p - b.p);
    if (out.length) out.unshift({ p: 0, s: out[0].s - 10, e: out[0].s });
    return out;
  }

  // 근무상황 기간 'YYYY-MM-DD HH:MM ~ YYYY-MM-DD HH:MM'을 그날(ymd)의 분 범위로. 비었으면 하루 종일
  function dutyRange(prd, ymd) {
    const day = `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6)}`;
    const m = /(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})\s*~\s*(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})/.exec(String(prd || ''));
    if (!m) return [0, 24 * 60];
    if (m[3] < day || m[1] > day) return null;
    return [m[1] < day ? 0 : mins(m[2]), m[3] > day ? 24 * 60 : mins(m[4])];
  }

  // 컴시간 가린 이름('김요*')과 나이스 성명('김요한') 맞추기: 그룹에 적어 둔 나이스 이름이 있으면 그것, 없으면 앞 글자가 같은 사람이 한 명일 때만
  function matchDuty(member, dutyNames) {
    if (member.full) return dutyNames.includes(member.full) ? member.full : null;
    const mask = String(member.comci || '').replace(/\s+/g, '');
    if (!mask.replace(/\*/g, '')) return null;
    // '김요*' → 김요로 시작, '김*한' → 김으로 시작해 한으로 끝남
    const re = new RegExp(`^${mask.split(/\*+/).map((x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('.*')}${/\*$/.test(mask) ? '' : '$'}`);
    const hits = [...new Set(dutyNames.filter((n) => re.test(n)))];
    return hits.length === 1 ? hits[0] : hits.length > 1 ? { ambiguous: hits.length } : null;
  }

  const ymdDate = (ymd) => new Date(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6));
  const ymdOf = (d) => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  // 그 날짜가 든 컴시간 주(일자자료 '26-10-26 ~ 26-10-31')
  function weekFor(cm, ymd) {
    for (const w of cm.weeks) {
      const m = /(\d{2})-(\d{2})-(\d{2})\s*~\s*(\d{2})-(\d{2})-(\d{2})/.exec(w.label);
      if (m && `20${m[1]}${m[2]}${m[3]}` <= ymd && ymd <= `20${m[4]}${m[5]}${m[6]}`) return w.no;
    }
    return null;
  }
  // 하루 또는 그 주(월~금)
  function datesFor(ymd, range) {
    if (range !== 'week') return [ymd];
    const d = ymdDate(ymd);
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    return Array.from({ length: 5 }, (_, i) => { const x = new Date(d); x.setDate(d.getDate() + i); return ymdOf(x); });
  }

  /**
   * 표 만들기.
   * members: [{ comci: '김요*', idx: 3, full?: '김요한' }]
   * weekData: { [ymd]: parseComci 결과 } — 그 날짜 주의 컴시간 자료
   * duties: { [ymd]: [{ name, prd }] } | null(복무 못 읽음)
   * fixes: { 'ymd|idx|p': 'free'|'class' } 교사가 칸을 눌러 고친 것
   */
  function build({ members, dates, weekData, duties, fixes = {} }) {
    const out = { days: [], notes: [] };
    const unmatched = new Set();
    for (const ymd of dates) {
      const cm = weekData[ymd];
      const wd = ymdDate(ymd).getDay();
      const bells = cm ? bellsFrom(cm.times) : [];
      const dutyList = duties ? duties[ymd] || [] : null;
      const names = dutyList ? dutyList.map((x) => x.name) : [];
      const rows = members.map((m) => {
        const cls = cm && wd >= 1 && wd <= 5 ? busyPeriods(cm, m.idx, wd) : [];
        let away = [];
        if (dutyList) {
          const who = matchDuty(m, names);
          if (who && typeof who === 'object') unmatched.add(`${m.comci}(나이스에 비슷한 이름 ${who.ambiguous}명)`);
          else if (who) {
            for (const x of dutyList.filter((y) => y.name === who)) {
              const r = dutyRange(x.prd, ymd);
              if (r) for (const b of bells) if (b.s < r[1] && b.e > r[0] && !away.includes(b.p)) away.push(b.p);
            }
          }
        }
        const cells = [];
        for (let p = 0; p <= LAST; p++) {
          let st = away.includes(p) ? 'away' : cls.includes(p) ? 'class' : 'free';
          const f = fixes[`${ymd}|${m.idx}|${p}`];
          if (f && st !== 'away') st = f;
          cells.push(st);
        }
        return { name: m.comci, idx: m.idx, cells };
      });
      const allFree = Array.from({ length: LAST + 1 }, (_, p) => rows.length > 0 && rows.every((r) => r.cells[p] === 'free'));
      out.days.push({ ymd, label: `${+ymd.slice(4, 6)}/${+ymd.slice(6)}(${DAY[wd]})`, rows, allFree, noTable: !cm });
    }
    if (unmatched.size) out.notes.push(`이름을 정확히 못 맞춘 선생님: ${[...unmatched].join(', ')} — 그룹에서 나이스 이름을 적어 주세요.`);
    return out;
  }

  const pName = (p) => (p === 0 ? '조회' : `${p}교시`);
  // 모두 비는 시간: 날짜마다 [{ label: '10/28(수)', ps: ['조회', '6교시'] }] (비는 교시가 없는 날은 뺌)
  const freeDays = (result) => result.days.map((d) => ({ label: d.label, ps: d.allFree.map((v, p) => (v ? p : -1)).filter((p) => p >= 0).map(pName) })).filter((x) => x.ps.length);
  // 복사용(교사 요청 2026-10-29: 한 줄로 붙어 있으면 보기 어려움) — 날짜마다 한 줄
  //   모두 비는 시간
  //   10/28(수)  조회, 6교시
  function summary(result) {
    const days = freeDays(result);
    return days.length ? ['모두 비는 시간', ...days.map((x) => `${x.label}  ${x.ps.join(', ')}`)].join('\n') : '모두 비는 시간이 없어요.';
  }

  D.freetime = { parseComci, cellBusy, busyPeriods, lesson, myDay, bellsFrom, dutyRange, matchDuty, weekFor, datesFor, build, summary, freeDays, pName, LAST };
})();
