// S1 빈 시간 찾기 — 나이스 시간표(그날 실제 수업, 바뀐 수업 포함) + 나이스 일일근무상황(성명·기간) → 교시마다 수업/부재/비어 있음.
// 결정(2026-10-28): 그룹 저장, 부재는 '부재'만(근무상황 종류·목적지는 읽지 않음), 교시 단위(조회~7교시), 하루·한 주.
// 2026-11-06 교사 결정: 컴시간 대신 나이스 [전체시간표조회 → 강의실별](features/neis-timetable.js, panel/timetable.js).
// 그룹에는 가린 이름('김요*')과 이름 확인값만 저장하고, 실제 이름은 그때 받은 나이스 시간표에서 확인값으로 찾는다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const DAY = ['일', '월', '화', '수', '목', '금', '토'];
  const LAST = 7; // 조회~7교시

  const mins = (hm) => { const m = /(\d{1,2}):(\d{2})/.exec(String(hm || '')); return m ? +m[1] * 60 + +m[2] : null; };
  // 우리 학교 교시 시각(출석부 웹앱과 같은 꼴, 줄마다 '1교시 08:50-09:40', '조회 08:40-08:50') → [{ p, s, e }]
  const BELLS_TEXT = ['조회 08:40-08:50', '1교시 08:50-09:40', '2교시 09:50-10:40', '3교시 10:50-11:40', '4교시 11:50-12:40', '5교시 13:30-14:20', '6교시 14:30-15:20', '7교시 15:40-16:30'].join('\n');
  function bellsFrom(text = BELLS_TEXT) {
    const out = [];
    for (const line of String(text || '').split(/\r?\n/)) {
      const m = /^\s*(조회|(\d{1,2})\s*교시)\s+(\d{1,2}:\d{2})\s*[-~]\s*(\d{1,2}:\d{2})/.exec(line);
      if (!m) continue;
      const p = m[1] === '조회' ? 0 : +m[2];
      if (p <= LAST) out.push({ p, s: mins(m[3]), e: mins(m[4]) });
    }
    return out.sort((a, b) => a.p - b.p);
  }

  // 근무상황 기간 'YYYY-MM-DD HH:MM ~ YYYY-MM-DD HH:MM'을 그날(ymd)의 분 범위로. 비었으면 하루 종일
  function dutyRange(prd, ymd) {
    const day = `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6)}`;
    const m = /(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})\s*~\s*(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})/.exec(String(prd || ''));
    if (!m) return [0, 24 * 60];
    if (m[3] < day || m[1] > day) return null;
    return [m[1] < day ? 0 : mins(m[2]), m[3] > day ? 24 * 60 : mins(m[4])];
  }

  const ymdDate = (ymd) => new Date(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6));
  const ymdOf = (d) => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  // 하루 또는 그 주(월~금)
  function datesFor(ymd, range) {
    if (range !== 'week') return [ymd];
    const d = ymdDate(ymd);
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    return Array.from({ length: 5 }, (_, i) => { const x = new Date(d); x.setDate(d.getDate() + i); return ymdOf(x); });
  }

  // 그룹 선생님(가린 이름·확인값) → 그때 받은 나이스 이름. 못 찾으면 null
  function nameOf(member, names) {
    const T = D.neisTimetable;
    return names.find((n) => T.nameKey(n) === member.key) || null;
  }
  // '오늘 내 수업'(H1): 그날 시간표에서 그 선생님 수업 — [{ p, start, text }]
  function myDay(day, name, bells = bellsFrom()) {
    const ps = (day && day[name]) || {};
    const at = Object.fromEntries(bells.map((b) => [b.p, b.s]));
    const hm = (v) => (v == null ? '' : `${String(Math.floor(v / 60)).padStart(2, '0')}:${String(v % 60).padStart(2, '0')}`);
    return Object.keys(ps).map(Number).sort((a, b) => a - b).map((p) => ({ p, start: hm(at[p]), text: ps[p] }));
  }

  /**
   * 표 만들기.
   * members: [{ mask: '김요*', key }]
   * days: { [ymd]: { 이름: { 교시: 수업 글 } } | null(못 받음) }
   * names: 받은 시간표의 선생님 이름 전부(확인값으로 찾기)
   * duties: { [ymd]: [{ name, prd }] } | null(복무 못 읽음)
   * fixes: { 'ymd|key|p': 'free'|'class' } 교사가 칸을 눌러 고친 것
   */
  function build({ members, dates, days, names = [], duties, fixes = {}, bells = bellsFrom() }) {
    const out = { days: [], notes: [] };
    const missing = new Set();
    for (const ymd of dates) {
      const day = days[ymd];
      const wd = ymdDate(ymd).getDay();
      const dutyList = duties ? duties[ymd] || [] : null;
      const rows = members.map((m) => {
        const full = nameOf(m, names);
        if (!full && day) missing.add(m.mask);
        const cls = full && day && day[full] ? Object.keys(day[full]).map(Number) : [];
        const away = [];
        if (dutyList && full) {
          for (const x of dutyList.filter((y) => y.name === full)) {
            const r = dutyRange(x.prd, ymd);
            if (r) for (const b of bells) if (b.s < r[1] && b.e > r[0] && !away.includes(b.p)) away.push(b.p);
          }
        }
        const cells = [];
        for (let p = 0; p <= LAST; p++) {
          let st = away.includes(p) ? 'away' : cls.includes(p) ? 'class' : 'free';
          const f = fixes[`${ymd}|${m.key}|${p}`];
          if (f && st !== 'away') st = f;
          cells.push(st);
        }
        return { name: full || m.mask, key: m.key, cells, what: full && day ? day[full] || {} : {} };
      });
      const allFree = Array.from({ length: LAST + 1 }, (_, p) => rows.length > 0 && rows.every((r) => r.cells[p] === 'free'));
      out.days.push({ ymd, label: `${+ymd.slice(4, 6)}/${+ymd.slice(6)}(${DAY[wd]})`, rows, allFree, noTable: !day });
    }
    if (missing.size) out.notes.push(`이번 시간표에 수업이 없거나 이름이 바뀐 선생님: ${[...missing].join(', ')} — 그날 수업이 없으면 그대로 두셔도 돼요.`);
    return out;
  }

  const pName = (p) => (p === 0 ? '조회' : `${p}교시`);
  // 모두 비는 시간: 날짜마다 [{ label: '10/28(수)', ps: ['조회', '6교시'] }] (비는 교시가 없는 날은 뺌)
  const freeDays = (result) => result.days.map((d) => ({ label: d.label, ps: d.allFree.map((v, p) => (v ? p : -1)).filter((p) => p >= 0).map(pName) })).filter((x) => x.ps.length);
  // 복사용(교사 요청 2026-10-29: 한 줄로 붙어 있으면 보기 어려움) — 날짜마다 한 줄
  function summary(result) {
    const days = freeDays(result);
    return days.length ? ['모두 비는 시간', ...days.map((x) => `${x.label}  ${x.ps.join(', ')}`)].join('\n') : '모두 비는 시간이 없어요.';
  }

  D.freetime = { BELLS_TEXT, bellsFrom, dutyRange, datesFor, nameOf, myDay, build, summary, freeDays, pName, LAST };
})();
