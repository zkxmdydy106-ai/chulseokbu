// S1 빈 시간 찾기 — 나이스 시간표(그날 실제 수업, 바뀐 수업 포함) + 나이스 일일근무상황(성명·기간) → 교시마다 수업/부재/비어 있음.
// 결정(2026-10-28): 그룹 저장, 부재는 '부재'만(근무상황 종류·목적지는 읽지 않음), 교시 단위(조회~7교시), 하루·한 주.
// 2026-11-06 교사 결정: 컴시간 대신 나이스 [전체시간표조회 → 강의실별](features/neis-timetable.js, panel/timetable.js).
// 그룹에는 가린 이름('김요*')과 이름 확인값만 저장하고, 실제 이름은 그때 받은 나이스 시간표에서 확인값으로 찾는다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const DAY = ['일', '월', '화', '수', '목', '금', '토'];
  const LAST = 7; // 조회~7교시

  const mins = (hm) => { const m = /(\d{1,2}):(\d{2})/.exec(String(hm || '')); return m ? +m[1] * 60 + +m[2] : null; };
  // 우리 학교 교시 시각(출석부 웹앱과 같은 꼴, 줄마다 '1교시 08:50-09:40', '조회 08:40-08:50') → [{ p, s, e }]
  const BELLS_TEXT = ['조회 08:40-08:50', '1교시 08:50-09:40', '2교시 09:50-10:40', '3교시 10:50-11:40', '4교시 11:50-12:40', '5교시 13:30-14:20', '6교시 14:30-15:20', '7교시 15:40-16:30'].join('\n');
  function bellsFrom(text = BELLS_TEXT) {
    const out = [];
    for (const line of String(text || '').split(/\r?\n/)) {
      const m = /^\s*(조회|(\d{1,2})\s*교시)\s+(\d{1,2}:\d{2})\s*[-~]\s*(\d{1,2}:\d{2})/.exec(line);
      if (!m) continue;
      const p = m[1] === '조회' ? 0 : +m[2];
      if (p <= LAST) out.push({ p, s: mins(m[3]), e: mins(m[4]) });
    }
    return out.sort((a, b) => a.p - b.p);
  }

  // 근무상황 기간 'YYYY-MM-DD HH:MM ~ YYYY-MM-DD HH:MM'을 그날(ymd)의 분 범위로. 비었으면 하루 종일
  function dutyRange(prd, ymd) {
    const day = `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6)}`;
    const m = /(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})\s*~\s*(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})/.exec(String(prd || ''));
    if (!m) return [0, 24 * 60];
    if (m[3] < day || m[1] > day) return null;
    return [m[1] < day ? 0 : mins(m[2]), m[3] > day ? 24 * 60 : mins(m[4])];
  }

  const ymdDate = (ymd) => new Date(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6));
  const ymdOf = (d) => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  // 하루 또는 그 주(월~금)
  function datesFor(ymd, range) {
    if (range !== 'week') return [ymd];
    const d = ymdDate(ymd);
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    return Array.from({ length: 5 }, (_, i) => { const x = new Date(d); x.setDate(d.getDate() + i); return ymdOf(x); });
  }

  // 그룹 선생님(가린 이름·확인값) → 그때 받은 나이스 이름. 못 찾으면 null
  function nameOf(member, names) {
    const T = D.neisTimetable;
    return names.find((n) => T.nameKey(n) === member.key) || null;
  }
  // '오늘 내 수업'(H1): 그날 시간표에서 그 선생님 수업 — [{ p, start, text }]
  function myDay(day, name, bells = bellsFrom()) {
    const ps = (day && day[name]) || {};
    const at = Object.fromEntries(bells.map((b) => [b.p, b.s]));
    const hm = (v) => (v == null ? '' : `${String(Math.floor(v / 60)).padStart(2, '0')}:${String(v % 60).padStart(2, '0')}`);
    return Object.keys(ps).map(Number).sort((a, b) => a - b).map((p) => ({ p, start: hm(at[p]), text: ps[p] }));
  }

  // 그 선생님이 그날 부재인 교시들(복무 기간과 교시 시각이 겹치는 교시)
  function awayPs(name, ymd, duties, bells) {
    const out = [];
    for (const x of ((duties && duties[ymd]) || []).filter((y) => y.name === name)) {
      const r = dutyRange(x.prd, ymd);
      if (r) for (const b of bells) if (b.s < r[1] && b.e > r[0] && !out.includes(b.p)) out.push(b.p);
    }
    return out;
  }

  /**
   * 표 만들기.
   * members: [{ mask: '김요*', key }]
   * days: { [ymd]: { 이름: { 교시: 수업 글 } } | null(못 받음) }
   * names: 받은 시간표의 선생님 이름 전부(확인값으로 찾기)
   * duties: { [ymd]: [{ name, prd }] } | null(복무 못 읽음)
   * fixes: { 'ymd|key|p': 'free'|'class' } 교사가 칸을 눌러 고친 것
   */
  function build({ members, dates, days, names = [], duties, fixes = {}, bells = bellsFrom() }) {
    const out = { days: [], notes: [] };
    const missing = new Set();
    for (const ymd of dates) {
      const day = days[ymd];
      const wd = ymdDate(ymd).getDay();
      const dutyList = duties ? duties[ymd] || [] : null;
      const rows = members.map((m) => {
        const full = nameOf(m, names);
        if (!full && day) missing.add(m.mask);
        const cls = full && day && day[full] ? Object.keys(day[full]).map(Number) : [];
        const away = dutyList && full ? awayPs(full, ymd, duties, bells) : [];
        const cells = [];
        for (let p = 0; p <= LAST; p++) {
          let st = away.includes(p) ? 'away' : cls.includes(p) ? 'class' : 'free';
          const f = fixes[`${ymd}|${m.key}|${p}`];
          if (f && st !== 'away') st = f;
          cells.push(st);
        }
        return { name: full || m.mask, key: m.key, cells, what: full && day ? day[full] || {} : {} };
      });
      const allFree = Array.from({ length: LAST + 1 }, (_, p) => rows.length > 0 && rows.every((r) => r.cells[p] === 'free'));
      out.days.push({ ymd, label: `${+ymd.slice(4, 6)}/${+ymd.slice(6)}(${DAY[wd]})`, rows, allFree, noTable: !day });
    }
    if (missing.size) out.notes.push(`이번 시간표에 수업이 없거나 이름이 바뀐 선생님: ${[...missing].join(', ')} — 그날 수업이 없으면 그대로 두셔도 돼요.`);
    return out;
  }

  const pName = (p) => (p === 0 ? '조회' : `${p}교시`);
  // 모두 비는 시간: 날짜마다 [{ label: '10/28(수)', ps: ['조회', '6교시'] }] (비는 교시가 없는 날은 뺌)
  const freeDays = (result) => result.days.map((d) => ({ label: d.label, ps: d.allFree.map((v, p) => (v ? p : -1)).filter((p) => p >= 0).map(pName) })).filter((x) => x.ps.length);
  // 복사용(교사 요청 2026-10-29: 한 줄로 붙어 있으면 보기 어려움) — 날짜마다 한 줄
  function summary(result) {
    const days = freeDays(result);
    return days.length ? ['모두 비는 시간', ...days.map((x) => `${x.label}  ${x.ps.join(', ')}`)].join('\n') : '모두 비는 시간이 없어요.';
  }

  // ── 선택과목 세트 교체(2026-11-11 교사 결정, docs/specs/빈시간-찾기.md 12절) ──
  const dayLabel = (ymd) => `${+ymd.slice(4, 6)}/${+ymd.slice(6)}(${DAY[ymdDate(ymd).getDay()]})`;
  const slotLabel = (ymd, p) => `${dayLabel(ymd)} ${pName(p)}`;
  const lessonsAt = (grid, ymd, grade, p) => grid[ymd]?.[grade]?.[p] || [];
  const teachersOf = (ls) => [...new Set(ls.flatMap((l) => l.names))];
  // 교실 이름(끝 괄호를 뗌): '과학실(2)'·'과학실(3)'·'201(A)'·'201(2학년 1반)' → 같은 교실끼리 맞댐
  const roomOf = (place) => String(place || '').replace(/\s*\([^()]*\)\s*$/, '').trim();
  const othersAt = (grid, ymd, grade, p) => Object.keys(grid[ymd] || {}).filter((g) => g !== grade).flatMap((g) => lessonsAt(grid, ymd, g, p).map((l) => ({ ...l, grade: g })));

  // 지난 시간인지: 오늘 이전이거나, 오늘이고 그 교시가 이미 시작함
  function pastFn(now, bells = bellsFrom()) {
    const today = ymdOf(now), nowMin = now.getHours() * 60 + now.getMinutes();
    const at = Object.fromEntries(bells.map((b) => [b.p, b.s]));
    return (ymd, p) => ymd < today || (ymd === today && at[p] != null && at[p] <= nowMin);
  }

  // 그 주의 세트 후보: 세트 글자가 있는 시간을 학년·글자로 묶음 → [{ grade, letter, label, times: [{ ymd, p, day, past }] }]
  function setList(grid, dates, isPast = () => false) {
    const map = new Map();
    for (const ymd of dates) {
      for (const grade of Object.keys(grid[ymd] || {})) {
        for (const p of Object.keys(grid[ymd][grade]).map(Number)) {
          const letters = [...new Set(lessonsAt(grid, ymd, grade, p).map((l) => l.set).filter(Boolean))].sort();
          if (!letters.length) continue;
          const key = `${grade}|${letters.join('·')}`;
          if (!map.has(key)) map.set(key, { grade, letter: letters.join('·'), label: `${grade}학년 ${letters.join('·')}세트`, times: [] });
          map.get(key).times.push({ ymd, p, day: DAY[ymdDate(ymd).getDay()], past: isPast(ymd, p) });
        }
      }
    }
    const list = [...map.values()].sort((a, b) => a.grade.localeCompare(b.grade) || a.letter.localeCompare(b.letter));
    for (const s of list) s.times.sort((a, b) => a.ymd.localeCompare(b.ymd) || a.p - b.p);
    return list;
  }

  /**
   * 세트 한 시간을 그 주의 다른 시간과 맞바꿀 수 있는지.
   * grid: { ymd: { 학년: { 교시: [{ place, set, text, names }] } } }, from: { ymd, p, grade }, skip: 세트에서 뺀 수업 글
   * → { from, label, moved, stay, ok: [칸], empty: [칸], no: [칸], unread }, 칸 = { ymd, p, label, lessons, blocks: [{ name, side, kind, grade }], rooms }
   */
  function swapCheck({ grid, dates, duties = null, bells = bellsFrom(), from, skip = [], isPast = () => false }) {
    const { grade } = from;
    const all = lessonsAt(grid, from.ymd, grade, from.p);
    const moved = all.filter((l) => !skip.includes(l.text));
    const stay = all.filter((l) => skip.includes(l.text));
    const movedT = teachersOf(moved);
    const sig = (ls) => ls.map((l) => l.text).sort().join('\n');
    const atFrom = othersAt(grid, from.ymd, grade, from.p);
    const out = { from, label: slotLabel(from.ymd, from.p), moved, stay, ok: [], empty: [], no: [], unread: moved.filter((l) => !l.names.length).length };
    for (const ymd of dates) {
      if (!grid[ymd] || !Object.keys(grid[ymd]).length) continue; // 시간표 없는 날
      for (let p = 1; p <= LAST; p++) {
        if ((ymd === from.ymd && p === from.p) || isPast(ymd, p)) continue;
        const there = lessonsAt(grid, ymd, grade, p);
        if (there.length && sig(there) === sig(moved)) continue; // 같은 세트의 다른 시간: 바꿔도 달라지지 않음
        const atThere = othersAt(grid, ymd, grade, p);
        const blocks = [];
        const add = (b) => { if (!blocks.some((x) => x.name === b.name && x.side === b.side)) blocks.push(b); };
        for (const t of movedT) {
          const o = atThere.find((l) => l.names.includes(t));
          if (o) add({ name: t, side: 'there', kind: 'class', grade: o.grade });
          else if (duties && awayPs(t, ymd, duties, bells).includes(p)) add({ name: t, side: 'there', kind: 'away' });
        }
        for (const t of teachersOf(there)) {
          const o = atFrom.find((l) => l.names.includes(t));
          if (o) add({ name: t, side: 'here', kind: 'class', grade: o.grade });
          else if (stay.some((l) => l.names.includes(t))) add({ name: t, side: 'here', kind: 'class', grade });
          else if (duties && awayPs(t, from.ymd, duties, bells).includes(from.p)) add({ name: t, side: 'here', kind: 'away' });
        }
        // 교실은 막지 않고 알림
        const clash = (ls, others) => ls.map((l) => roomOf(l.place)).filter((r) => r && others.some((o) => roomOf(o.place) === r));
        const rooms = [...new Set([...clash(moved, atThere), ...clash(there, [...atFrom, ...stay.map((l) => ({ ...l, grade }))])])];
        const slot = { ymd, p, label: slotLabel(ymd, p), lessons: there, blocks, rooms, unread: there.filter((l) => !l.names.length).length };
        (blocks.length ? out.no : there.length ? out.ok : out.empty).push(slot);
      }
    }
    return out;
  }

  // 복사용: 시간만(동료 이름 없음), 날짜마다 한 줄
  function swapSummary(setLabel, r) {
    if (!r.ok.length) return `${setLabel} ${r.label} — 맞바꿀 수 있는 시간이 없어요.`;
    const by = new Map();
    for (const s of r.ok) { const d = dayLabel(s.ymd); if (!by.has(d)) by.set(d, []); by.get(d).push(pName(s.p)); }
    return [`${setLabel} ${r.label} — 맞바꿀 수 있는 시간`, ...[...by].map(([d, ps]) => `${d}  ${ps.join(', ')}`)].join('\n');
  }

  D.freetime = { BELLS_TEXT, bellsFrom, dutyRange, datesFor, nameOf, myDay, build, summary, freeDays, pName, LAST, awayPs, pastFn, setList, swapCheck, swapSummary, roomOf };
})();
