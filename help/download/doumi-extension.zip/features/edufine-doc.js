// F1 2단계: 결재함에서 연 문서의 본문(PC 도우미 readDoc이 읽은 누름틀 글) → 할 일 정리(규칙만, AI 없음).
// 정리하는 것: 기한(…까지), 제출물, 대상, 관련 문서 줄(기관-번호(날짜)), 붙임 목록, 문서번호·시행일자.
// 본문은 패널 메모리에서만 쓴다. 할 일로 넣는 것은 정리한 몇 줄(memo)뿐 — 저장·내보내기 규칙은 features/todo.js(F2).
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const NL = String.fromCharCode(10);
  const lines = (s) => String(s || '').replace(/\r\n?/g, NL).split(NL);
  const one = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const WEEK = /\s*\([월화수목금토일]\)/g;

  // '충청남도교육청 교육과정과-12345(2026. 10. 1.) 「제목」' 꼴을 모두 찾는다(관련 줄 안에서)
  const REF = /((?:[가-힣A-Za-z0-9·()]+\s){0,2}[가-힣A-Za-z0-9·]+?)\s*-\s*(\d{1,7})\s*(?:\(\s*(\d{4}\s*\.\s*\d{1,2}\s*\.\s*\d{1,2}\s*\.?)\s*\))?(?:\s*[「『"]([^」』"]{1,80})[」』"])?/g;
  function parseRefs(text) {
    const out = [];
    for (const m of String(text || '').matchAll(REF)) {
      const words = one(m[1]).split(' ');
      const dept = words.pop();
      if (!dept || /^\d+$/.test(dept)) continue;
      const org = words.filter((w) => !/^(관련|및|[가-하]\.|\d+\.)$/.test(w) && !/[:：]$/.test(w)).join(' ');
      const ymd = m[3] ? D.normDate(m[3]) : '';
      out.push({ org, dept, docNo: m[2], ymd, title: one(m[4]), text: one(m[0]) });
    }
    return out;
  }

  // 본문의 '관련' 항목: '1. 관련: …' 한 줄, 또는 '관련:' 다음 '가. …' 줄들
  function relatedOf(body) {
    const ls = lines(body);
    const out = [];
    const i = ls.findIndex((l) => /^\s*(?:\d+\.\s*)?관\s*련\s*[:：]?/.test(l));
    if (i < 0) return out;
    const head = ls[i].replace(/^\s*(?:\d+\.\s*)?관\s*련\s*[:：]?/, '');
    let block = head;
    for (let k = i + 1; k < ls.length && k < i + 8; k++) {
      if (/^\s*[가-하]\.\s|^\s*\(?\d+\)\s/.test(ls[k])) block += NL + ls[k];
      else break;
    }
    for (const r of parseRefs(block)) if (!out.some((x) => x.dept === r.dept && x.docNo === r.docNo)) out.push(r);
    return out;
  }

  // 붙임 목록: '붙임  1. 계획서 1부.' / '      2. 명단 1부.  끝.' / '붙임  계획서 1부.  끝.'
  function attachmentsOf(body) {
    const ls = lines(body);
    const i = ls.findIndex((l) => /^\s*붙\s*임(\s|$)/.test(l));
    if (i < 0) return [];
    const take = (s) => one(one(s).replace(/^붙\s*임\s*/, '').replace(/^\d+\.\s*/, '').replace(/\s*끝\.?\s*$/, '').replace(/\s*\d+\s*부\.?\s*$/, ''));
    const out = [];
    const first = take(ls[i]);
    if (first) out.push(first);
    for (let k = i + 1; k < ls.length; k++) {
      if (!/^\s+\d+\.\s/.test(ls[k])) break;
      const t = take(ls[k]);
      if (t) out.push(t);
    }
    return out;
  }

  // 기한 글('2026. 11. 5.(목) 18:00') → { text, due: 'YYYYMMDD', time } (연도가 없으면 시행일자·올해 기준)
  function deadlineOf(text, baseYmd) {
    if (!text) return { text: '', due: '', time: '' };
    const t = one(text).replace(WEEK, '');
    const tm = /(\d{1,2}):(\d{2})/.exec(t);
    const year = (baseYmd || '').slice(0, 4) || String(new Date().getFullYear());
    const due = D.normDate(tm ? t.slice(0, tm.index) : t, year);
    return { text: one(text), due, time: tm ? `${tm[1].padStart(2, '0')}:${tm[2]}` : '' };
  }

  /**
   * fields: PC 도우미 readDoc의 fields — { Sj, 결재제목, 본문, 수신, 경유, 시행일자, 문서번호 }
   * → { title, docNo, enforce, receiver, related[], deadline{}, submits[], targets[], attachments[], memo, empty }
   */
  function summarize(fields = {}) {
    const body = String(fields['본문'] || '');
    const title = one(fields.Sj || fields['결재제목']);
    const enforce = D.normDate(fields['시행일자'] || '');
    const req = D.draft ? D.draft.extractRequirements(body) : { deadline: '', submits: [], targets: [] };
    const deadline = deadlineOf(req.deadline, enforce);
    const related = relatedOf(body);
    const attachments = attachmentsOf(body);
    const s = {
      title, docNo: one(fields['문서번호']), enforce, receiver: one(fields['수신']), sender: one(fields['발신기관명']),
      related, deadline, submits: req.submits, targets: req.targets, attachments,
      empty: !body.trim(),
    };
    s.memo = memoOf(s);
    return s;
  }

  // 할 일 메모(몇 줄). 본문 전체는 넣지 않는다
  function memoOf(s) {
    const out = [];
    if (s.deadline.text) out.push(`기한: ${s.deadline.text}`);
    if (s.submits.length) out.push(`제출: ${s.submits.join(', ')}`);
    if (s.targets.length) out.push(`대상: ${s.targets.join(', ')}`);
    if (s.related.length) out.push(`관련: ${s.related.map((r) => `${r.org ? `${r.org} ` : ''}${r.dept}-${r.docNo}`).join(', ')}`);
    return out.join(NL);
  }

  // 문서등록대장에서 찾을 칸: 다른 기관 공문은 발신기관문서번호(orignlDocNo '교육과정과-12345'),
  // '○○학교-1234'처럼 학교 이름이면 우리 학교 등록번호(docNo '1234')로도 본다(목록 문서번호 칸은 숫자만, 2026-10-29 실제)
  function searchPlan(ref) {
    const school = /(학교|초|중|고)$/.test(ref.dept) || /학교/.test(ref.org || '');
    return school ? { docNo: ref.docNo, orignlDocNo: '' } : { docNo: '', orignlDocNo: `${ref.dept}-${ref.docNo}` };
  }

  // 할 일 넣기 입력(Doumi.todo.add)
  function todoInput(s, docId) {
    return { title: s.title || '(제목 없는 공문)', due: s.deadline.due, time: s.deadline.time, memo: s.memo, files: s.attachments, source: { kind: 'edufine', label: '에듀파인 결재함', ...(docId ? { docId } : {}), ...(s.docNo ? { docNo: s.docNo } : {}) } };
  }

  // F5 자료집계·조사 회신: 받은 공문 정리 → 회신 기안 틀(제목·관련 줄·제출 기한·제출 자료·붙임·받는 기관). 규칙만, AI 없음.
  // '… 제출 안내', '… 조사 요청'에서 뒤 말을 떼어 주제로 쓴다
  function replyInput(s) {
    const subject = one(String(s.title || '').replace(/\s*(?:제출|회신|보고|조사|자료\s*집계|실태\s*조사|현황\s*조사)?\s*(?:안내|요청|협조|알림|통보|의뢰)?(?:\s*\(.*?\))?\s*$/, '')) || one(s.title);
    const ref = s.docNo && D.draft ? D.draft.parseDocNo(s.docNo) : null;
    const related = ref ? { org: s.sender && s.sender !== ref.dept ? s.sender : '', ...ref, date: s.enforce, title: s.title } : { title: s.title, date: s.enforce };
    return {
      kind: 'reply', subject, deadline: s.deadline.text, submit: s.submits[0] || '',
      relatedText: [[related.org, related.dept && related.docNo ? `${related.dept}-${related.docNo}` : ''].filter(Boolean).join(' '), related.date ? D.draft.formatDate(related.date) : '', related.title || ''].join(' | '),
      attachText: s.attachments.join('\n'), receiver: s.sender || '',
    };
  }

  D.edufineDoc = { parseRefs, relatedOf, attachmentsOf, deadlineOf, summarize, memoOf, searchPlan, todoInput, replyInput };
})();
