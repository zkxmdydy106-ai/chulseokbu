// 나이스 [전체시간표조회 → 강의실별] 보고서 → 날짜·교시마다 누가 수업하는지(그날 바뀐 수업 포함).
// 2026-11-06 실제 조사(docs/probe/neis-timetable-2026-11-06.md):
// - 결과는 크라운릭스 보고서라 화면 자료(데이터셋)에는 없고, 보고서 뷰어가 받는 자료(/report/service, MML XML)에 글자 칸이 있다.
// - 칸(PR)마다 머리칸 번호 hd="학년칸,반·강의실칸,날짜칸,교시칸"이 붙어 있어 좌표를 짐작하지 않고 머리칸으로 맞춘다.
// - 수업 칸 글은 '과목(선생님 이름)'. 변경수업조회와 맞대어 그날 바뀐 수업이 들어 있음을 확인(바뀐 6칸 모두 같음).
// 선생님 이름은 패널 메모리에서만 쓴다(그룹에는 가린 이름 + 확인값만 저장).
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const ent = (s) => String(s).replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16))).replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
  const attrs = (s) => Object.fromEntries([...String(s).matchAll(/([\w-]+)="([^"]*)"/g)].map((m) => [m[1], m[2]]));
  // 칸 글: 칸 폭에서 잘린 여러 TL을 그대로 이어 붙임
  const textOf = (body) => [...String(body).matchAll(/<TL\b[^>]*>([\s\S]*?)<\/TL>/g)].map((m) => ent(m[1]).replace(/[\r\n]+/g, '')).join('').replace(/\s+/g, ' ').trim();
  // '2026.11.06.(금요일)' → '20261106'
  const ymdOf = (t) => { const m = /(\d{4})\.\s*(\d{1,2})\.\s*(\d{1,2})/.exec(String(t)); return m ? `${m[1]}${m[2].padStart(2, '0')}${m[3].padStart(2, '0')}` : ''; };
  // '1', '1교시' → 1
  const pirOf = (t) => { const m = /^(\d{1,2})(교시)?$/.exec(String(t).replace(/\s+/g, '')); return m ? +m[1] : 0; };
  // '과목명2(김철수)' → ['김철수'], 여러 명이면 쉼표로 나뉨. 이름은 한글 2~5자만
  function teachersIn(text) {
    const m = /\(([^()]*)\)\s*$/.exec(String(text || ''));
    if (!m) return [];
    return m[1].split(/[,，/]/).map((x) => x.trim()).filter((x) => /^[가-힣]{2,5}$/.test(x));
  }

  // 선택과목 세트 글자: 강의실 칸 이름 끝의 영문 대문자 한 글자 '201(A)' → 'A'(2026-11-11 실제, docs/probe/neis-timetable-sets-2026-11-11.md)
  const setOf = (place) => (/\(([A-Z])\)\s*$/.exec(String(place || '')) || [])[1] || '';

  /**
   * MML 글 → { meta: { ayr, sem, grade, from, to }, lessons: [{ ymd, p, grade, place, set, text, names }] }
   * 모양이 다르면 throw(나이스 화면이 바뀜)
   */
  function parseDaily(xml) {
    const text = String(xml || '');
    if (!/<MML\b/.test(text)) throw new Error('나이스 시간표 보고서 자료가 아니에요.');
    const va = Object.fromEntries([...text.matchAll(/<VA key="([^"]*)">([\s\S]*?)<\/VA>/g)].map((m) => [m[1], ent(m[2])]));
    const lessons = [];
    let sawGrid = false;
    for (const pg of text.matchAll(/<PG\b[^>]*>([\s\S]*?)<\/PG>/g)) {
      const head = new Map();
      const cells = [];
      // 가장 안쪽 PR(안에 PR이 없는 것)만
      for (const m of pg[1].matchAll(/<PR\b([^>]*)>((?:(?!<PR\b)[\s\S])*?)<\/PR>/g)) {
        const a = attrs(m[1]);
        const t = textOf(m[2]);
        if (a.id && !a.hd) head.set(a.id, t);
        else if (a.hd) cells.push({ hd: a.hd.split(',').map((x) => x.trim()), t });
      }
      for (const c of cells) {
        const hs = c.hd.map((h) => head.get(h) ?? '');
        const ymd = hs.map(ymdOf).find(Boolean);
        const pi = hs.length - 1;
        const p = pirOf(hs[pi]);
        if (!ymd || !p) continue;
        sawGrid = true;
        if (!c.t) continue;
        // 반·강의실 칸: 날짜·교시·학년이 아닌 머리칸
        const place = hs.filter((h, i) => i !== pi && !ymdOf(h) && !/^\d학년$/.test(h.replace(/\s+/g, ''))).join(' ');
        const gradeHead = hs.map((h) => /^(\d)학년$/.exec(h.replace(/\s+/g, ''))).find(Boolean);
        lessons.push({ ymd, p, grade: gradeHead ? gradeHead[1] : String(va.$4 || ''), place, set: setOf(place), text: c.t, names: teachersIn(c.t) });
      }
    }
    if (!sawGrid) throw new Error('나이스 시간표 보고서 모양이 달라요(날짜·교시 칸을 못 찾음). 도우미를 고쳐야 해요.');
    return { meta: { ayr: va.$2 || '', sem: va.$3 || '', grade: va.$4 || '', from: va.$6 || '', to: va.$7 || '' }, lessons };
  }

  // 여러 학년 보고서를 합쳐 날짜 → 선생님 → 교시 → 수업 글, grid: 날짜 → 학년 → 교시 → 수업들(세트 교체용)
  function merge(parsed) {
    const byDay = {};
    const grid = {};
    const names = new Set();
    for (const r of parsed) {
      for (const l of r.lessons) {
        const g = (grid[l.ymd] = grid[l.ymd] || {});
        const row = ((g[l.grade] = g[l.grade] || {})[l.p] = g[l.grade][l.p] || []);
        // 반 칸과 강의실 칸에 같은 수업이 겹쳐 나오면 하나로(세트 글자는 있는 쪽을)
        const same = row.find((x) => x.text === l.text);
        if (!same) row.push({ place: l.place, set: l.set, text: l.text, names: l.names });
        else if (!same.set && l.set) { same.set = l.set; same.place = l.place; }
        for (const n of l.names) {
          names.add(n);
          const d = (byDay[l.ymd] = byDay[l.ymd] || {});
          const t = (d[n] = d[n] || {});
          // 같은 교시에 두 칸(반·강의실에 같은 수업이 겹쳐 나옴)이면 글을 한 번만
          if (!t[l.p]) t[l.p] = l.text;
          else if (!t[l.p].split(' / ').includes(l.text)) t[l.p] += ` / ${l.text}`;
        }
      }
    }
    return { byDay, grid, names: [...names].sort((a, b) => a.localeCompare(b, 'ko')) };
  }

  // 가린 이름(그룹 저장용): 김요한 → 김요*, 두 글자 → 김*
  const maskName = (n) => { const s = String(n || ''); return s.length <= 2 ? `${s.slice(0, 1)}*` : `${s.slice(0, -1)}*`; };
  // 이름 확인값(그룹 저장용, 이름 자체는 저장하지 않음): FNV-1a 32비트 → 16진수 8자리
  const nameKey = (n) => { let h = 0x811c9dc5; for (const ch of `doumi|${n}`) { h ^= ch.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, '0'); };

  D.neisTimetable = { parseDaily, merge, teachersIn, setOf, maskName, nameKey, ymdOf, pirOf };
})();
