// 생기부 글 입력(자율·진로·행동특성·교과 세특·동아리·개인별 세특·독서) — 파일(번호·이름·내용) 해석 → 나이스 학생 줄과 비교 → 바이트 검사 → 생기부 점검 → 입력 계획
// 2026-10-30 더함: 진로 희망분야(hope), 동아리(학년+반+번호·건너뛸 부서·이수시간), 개인별 세특(개정별 탭·길이 칸·세 칸 합 한도), 독서(도서명·저자 줄 → 한 칸, 길이 칸)
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;

  const HEAD = {
    no: ['번호', '번', '출석번호'], studentId: ['학번'], name: ['이름', '성명', '학생', '학생명'], cls: ['반', '학반', '학급'], grade: ['학년'],
    text: ['내용', '특기사항', '기록', '세특', '세부능력및특기사항', '과목별세부능력및특기사항', '자율', '자율활동', '진로', '진로활동', '행특', '행동특성', '종합의견', '행동특성및종합의견', '누가기록', '입력내용',
      '동아리', '동아리활동', '동아리활동특기사항', '개인별세특', '개인별세부능력및특기사항', '독서', '독서활동', '독서활동상황'],
    hope: ['희망분야', '진로희망', '진로희망분야', '희망'],
    book: ['도서명', '책', '책이름', '도서', '책제목'], author: ['저자', '지은이', '글쓴이'],
  };
  const fieldOf = (c) => { const s = D.squash(c); return Object.keys(HEAD).find((f) => HEAD[f].includes(s)) || null; };
  // '2-3', '3반', '2학년 3반', '03' → '3'
  const clsOf = (v) => { const m = /(\d+)\s*반?\s*$/.exec(String(v ?? '').trim()); return m ? String(+m[1]) : ''; };
  const gradeOf = (v) => { const m = /(\d+)/.exec(String(v ?? '')); return m ? String(+m[1]) : ''; };
  const clean = (s) => String(s ?? '').replace(/ /g, ' ').trim();

  // 머리줄이 있으면 칸 이름으로, 없으면 '번호 이름 내용…'(탭·쉼표 칸이면 마지막 긴 칸이 내용)
  function parse(text) {
    const lines = D.lines(text);
    if (!lines.length) return { items: [], issues: [], headers: [] };
    const first = lines[0].raw;
    const sep = first.includes('\t') ? '\t' : first.includes(',') ? ',' : null;
    const heads = sep ? D.splitCells(first, sep) : first.trim().split(/\s+/);
    const fields = heads.map(fieldOf);
    const items = [];
    const issues = [];
    if (fields.filter(Boolean).length >= 2 && sep) {
      const rows = lines.slice(1).map((l) => D.splitCells(l.raw, sep));
      // 독서: 한 줄에 책 한 권(도서명·저자) → 학생마다 '도서명(저자), 도서명(저자)' 한 칸으로 모음
      const bi = fields.indexOf('book');
      // 내용 칸: 이름이 맞는 칸, 없으면 가장 긴 글이 든 칸(희망분야·도서 칸은 빼고)
      let ti = fields.indexOf('text');
      if (ti < 0 && bi < 0) {
        const len = heads.map((_, i) => (['hope', 'author'].includes(fields[i]) ? -1 : rows.reduce((n, r) => n + String(r[i] ?? '').length, 0)));
        ti = len.indexOf(Math.max(...len));
      }
      if (!fields.includes('no') && !fields.includes('name') && !fields.includes('studentId')) issues.push('자료에 번호나 이름 칸이 없어요.');
      const hi = fields.indexOf('hope');
      let empty = 0;
      const byStudent = new Map();
      rows.forEach((r, k) => {
        const get = (f) => { const i = fields.indexOf(f); return i >= 0 ? String(r[i] ?? '').trim() : ''; };
        const sid = get('studentId').replace(/\D/g, '');
        let body = ti >= 0 ? clean(r[ti]) : '';
        if (bi >= 0) {
          const book = clean(r[bi]);
          const author = clean(get('author'));
          body = book ? (author ? `${book}(${author})` : book) : '';
        }
        const hope = hi >= 0 ? clean(r[hi]) : null;
        // 명단 양식(학번·이름이 미리 든 것)에서 내용을 안 쓴 학생은 넣지 않음(2026-10-29). 희망분야만 쓴 줄은 넣음
        if (!body && !hope && (fields[ti] === 'text' || bi >= 0)) { empty++; return; }
        const it = {
          line: k + 2,
          no: D.normNo(get('no')) || (sid.length >= 3 ? String(+sid.slice(-2)) : ''),
          // 학번: 학년 한 자리 + 반 + 번호 두 자리 → 20301·2103 모두 반 3·1, 학년 2
          cls: clsOf(get('cls')) || (sid.length >= 4 ? String(+sid.slice(1, -2)) : ''),
          grade: gradeOf(get('grade')) || (sid.length >= 4 ? sid[0] : ''),
          name: D.squash(get('name')),
          text: body,
          ...(hope != null ? { hope } : {}),
        };
        if (bi < 0) { items.push(finish(it)); return; }
        const key = `${it.grade}|${it.cls}|${it.no}|${it.name}`;
        const got = byStudent.get(key);
        if (got) { if (body) got.text = got.text ? `${got.text}, ${body}` : body; } else { byStudent.set(key, it); items.push(it); }
      });
      if (bi >= 0) items.forEach(finish);
      return { items, issues, headers: heads, textHeader: bi >= 0 ? heads[bi] : heads[ti], empty };
    }
    for (const l of lines) {
      const cells = sep ? D.splitCells(l.raw, sep) : null;
      let no = '', name = '', body = '', cls = '';
      if (cells && cells.length >= 2) {
        no = D.normNo(cells[0]);
        name = cells.length >= 3 && /^[가-힣A-Za-z]{2,10}$/.test(cells[1].trim()) ? D.squash(cells[1]) : '';
        body = cells.slice(name ? 2 : 1).join(sep === ',' ? ', ' : ' ').trim();
      } else {
        const m = /^\s*(\d{1,5})\s+(?:([가-힣A-Za-z]{2,10})\s+)?([\s\S]*)$/.exec(l.raw);
        if (m) {
          no = m[1].length >= 3 ? String(+m[1].slice(-2)) : D.normNo(m[1]);
          if (m[1].length >= 5) cls = String(+m[1].slice(-4, -2));
          name = m[2] || ''; body = m[3].trim();
        }
      }
      items.push(finish({ line: l.no, no, cls, name, text: clean(body) }));
    }
    return { items, issues, headers: [] };
  }
  function finish(it) {
    it.issues = [];
    if (!it.no && !it.name) it.issues.push('번호나 이름이 없어요.');
    if (!it.text && !it.hope) it.issues.push('내용이 비어 있어요.');
    return it;
  }

  // 파일이 이 화면(자율·진로·행특…) 것으로 보이는 정도: 머리줄 낱말이 화면 낱말과 맞으면 높게
  function score(parsed, screen) {
    const head = D.squash((parsed.headers || []).join(' ') + ' ' + (parsed.textHeader || ''));
    return (screen.words || []).reduce((n, w) => n + (head.includes(D.squash(w)) ? 1 : 0), 0);
  }

  const isSameName = (v) => !['', '0', 'N'].includes(String(v ?? '').trim());
  const num = (v) => Number(String(v ?? '').replace(/,/g, '')) || 0;

  // 개정마다 다른 탭·칸(개인별 세특): 나이스 dmSearch 값으로 고른 화면 설정
  function resolve(screen, value) {
    const v = screen.variant;
    if (!v) return screen;
    const o = v.options[String(value)] || v.options.false;
    return { ...screen, variantLabel: o.label, tab: o.tab, grid: o.grid, text: o.text, lenColumn: o.lenColumn, sumLenColumns: o.sumLenColumns, save: { ...screen.save, button: o.saveButton } };
  }
  const variantArgs = (screen) => ({ appId: screen.appId, dataset: screen.dataset, columns: [], dataMaps: { [screen.variant.dataMap]: [screen.variant.column] } });

  function readArgs(screen) {
    const K = screen.key;
    const cols = [K.no, K.name, K.sameName, K.cls, K.grade, screen.text, screen.maxBytesColumn, screen.enable?.column, ...(screen.closed || []),
      screen.hope?.column, screen.extraBytesColumn, screen.lenColumn, screen.lenBaseColumn, ...(screen.sumLenColumns || []), screen.skip?.column, screen.requiredAll?.column];
    const dataMaps = screen.closedMap ? { [screen.closedMap.dataMap]: [screen.closedMap.column] } : {};
    return { appId: screen.appId, dataset: screen.dataset, columns: [...new Set(cols.filter(Boolean))], dataMaps };
  }
  const searchArgs = (screen) => ({ appId: screen.appId, dataMap: 'dmSearch', values: {}, button: screen.search.button, dataset: screen.dataset });
  const keyColumns = (screen) => [screen.key.grade, screen.key.cls, screen.key.no, screen.key.name].filter(Boolean);

  // 파일 한 줄 → 나이스 학생 줄
  function match(it, rows, K, res) {
    const inCls = (r) => (!K.cls || !it.cls || clsOf(r[K.cls]) === it.cls) && (!K.grade || !it.grade || gradeOf(r[K.grade]) === it.grade);
    const where = `${it.grade && K.grade ? `${it.grade}학년 ` : ''}${it.cls ? `${it.cls}반 ` : ''}`;
    if (it.no) {
      let hits = rows.filter((r) => D.normNo(r[K.no]) === it.no && inCls(r));
      if (hits.length > 1 && it.name) hits = hits.filter((r) => D.squash(r[K.name]) === D.squash(it.name));
      if (hits.length !== 1) {
        res.issues.push(!hits.length ? `${where}${it.no}번 학생이 나이스 목록에 없어요.`
          : (K.cls || K.grade) && !it.cls ? `${it.no}번이 여러 반에 있어요. 반이나 학번 칸을 함께 적어 주세요.` : `${it.no}번이 여러 명이에요.`);
        return null;
      }
      const row = hits[0];
      if (it.name && D.squash(row[K.name]) !== D.squash(it.name)) { res.issues.push(`이름이 달라요 (나이스: ${row[K.name]})`); return null; }
      if (!it.name) res.warnings.push('번호로만 맞췄어요. 이름을 확인해 주세요.');
      return row;
    }
    if (it.name) {
      const hits = rows.filter((r) => D.squash(r[K.name]) === D.squash(it.name) && inCls(r));
      if (hits.length !== 1 || (K.sameName && isSameName(hits[0][K.sameName]))) {
        res.issues.push(hits.length ? '같은 이름이 있어요. 번호를 함께 적어 주세요.' : '이 이름이 나이스 목록에 없어요.');
        return null;
      }
      return hits[0];
    }
    return null;
  }

  // dm: 읽은 데이터맵(closedMap 마감 표시)
  function compare({ parsed, rows, screen, rules, dm = {} }) {
    const K = screen.key, T = screen.text, H = screen.hope?.column;
    const issues = [...parsed.issues];
    if (!rows.length) issues.push('나이스 학생 목록이 비어 있어요. 나이스 화면의 학년·반(과목·부서)을 확인해 주세요.');
    if (screen.closedMap && String(dm?.[screen.closedMap.dataMap]?.[screen.closedMap.column] ?? '').trim() === 'Y') issues.push('학생부가 마감되어 있어요. 나이스에서 마감을 확인해 주세요.');
    // 이 칸이 빈 학생이 하나라도 있으면 나이스가 저장 전체를 막음(동아리 이수시간)
    if (screen.requiredAll && rows.some((r) => String(r[screen.requiredAll.column] ?? '').trim() === '' && !(screen.skip && screen.skip.values[String(r[screen.skip.column] ?? '').trim()]))) issues.push(screen.requiredAll.message);
    const taken = new Map();
    const out = parsed.items.map((it) => {
      const res = { line: it.line, no: it.no, name: it.name, kindText: '', neisName: '', issues: [...it.issues], warnings: [], checks: [], cur: null, next: null, set: null, row: null, status: 'error' };
      const row = match(it, rows, K, res);
      if (row) {
        res.neisName = row[K.name];
        res.neisNo = (K.grade ? `${gradeOf(row[K.grade])}-` : '') + (K.cls ? `${clsOf(row[K.cls])}-` : '') + D.normNo(row[K.no]);
        if (taken.has(row._row)) res.issues.push(`${taken.get(row._row)}번째 줄과 같은 학생이에요.`); else taken.set(row._row, it.line);
        if ((screen.closed || []).some((c) => String(row[c] ?? '').trim() === 'Y')) res.issues.push('마감된 학생부예요. 나이스에서 확인해 주세요.');
        const why = screen.skip?.values[String(row[screen.skip.column] ?? '').trim()];
        if (why) res.issues.push(`${why}.`);
        if (screen.enable && String(row[screen.enable.column] ?? '').trim() === screen.enable.off) res.warnings.push('나이스에서 입력이 막힌 학생일 수 있어요.');
        res.cur = { kind: String(row[T] ?? ''), reason: H ? String(row[H] ?? '') : '' };
      }
      const text = it.text || (H && res.cur ? res.cur.kind : '');
      if (res.cur && (text || it.hope)) {
        if (!text && screen.noEmpty) res.issues.push('빈 글로는 저장할 수 없어요(나이스 규칙). 지우려면 나이스에서 직접 지워 주세요.');
        if (screen.clean === 'reading' && /□/.test(text)) res.issues.push("'□' 글자가 있으면 나이스가 저장을 막아요. 글을 고쳐 주세요.");
        const b = D.neisBytes(text);
        const hope = H && it.hope != null ? it.hope : res.cur.reason;
        const hb = H ? D.neisBytes(hope) : 0;
        const own = screen.maxBytesColumn ? num(row[screen.maxBytesColumn]) : 0;
        const max = own > 0 ? own : screen.maxBytes;
        const extra = screen.extraBytesColumn ? num(row[screen.extraBytesColumn]) : 0;
        // 개인별 세특: 같은 줄의 다른 탭 칸 길이도 한도에 함께 셈
        const others = (screen.sumLenColumns || []).filter((c) => c !== screen.lenColumn).reduce((n, c) => n + num(row[c]), 0);
        const used = b + extra + others + (H ? hb : 0);
        if (max && used > max) {
          const parts = [extra ? `부서 머리 ${extra}` : '', others ? `다른 칸 ${others}` : '', H && hb ? `희망분야 ${hb}` : ''].filter(Boolean);
          res.issues.push(`글이 너무 길어요 (${used}/${max}바이트${parts.length ? ` — 글 ${b} + ${parts.join(' + ')}` : ''}, 한글 ${Math.floor(max / 3)}자).`);
        }
        if (H && hb > screen.hope.maxBytes) res.issues.push(`희망분야가 너무 길어요 (${hb}/${screen.hope.maxBytes}바이트, 한글 ${Math.floor(screen.hope.maxBytes / 3)}자).`);
        res.next = { kind: text, reason: H ? hope : '' };
        res.bytes = b;
        res.maxBytes = max;
        res.set = {};
        if (text !== res.cur.kind) res.set[T] = text;
        if (H && hope !== res.cur.reason) res.set[H] = hope;
        // 길이 칸: 나이스 저장 검사가 보는 칸(입력창이 갱신) — 글을 바꾸면 함께 맞춤
        if (res.set[T] != null && screen.lenColumn) res.set[screen.lenColumn] = b + (screen.lenBaseColumn ? num(row[screen.lenBaseColumn]) : 0);
        if (res.cur.kind && res.set[T] != null) res.warnings.push('나이스에 이미 있는 글을 바꿔요.');
        if (H && res.cur.reason && res.set[H] != null) res.warnings.push('나이스에 이미 있는 희망분야를 바꿔요.');
        res.row = row;
        // 독서는 책 목록(도서명(저자))이라 문장 점검을 하지 않음
        if (D.recordCheck && text && screen.clean !== 'reading') res.checks = D.recordCheck.text(text, rules);
      }
      res.status = res.issues.length ? 'error' : res.set && Object.keys(res.set).length ? 'change' : 'same';
      return res;
    });
    // 학생 사이 같은·비슷한 문장(독서는 책 목록이라 빼고)
    if (D.recordCheck && screen.clean !== 'reading') {
      const items = out.filter((r) => r.next?.kind).map((r, i) => ({ id: i, r, label: `${r.neisNo || r.no}번 ${r.neisName || r.name}`, text: r.next.kind }));
      const dup = D.recordCheck.across(items, rules);
      for (const x of items) if (dup.has(x.id)) x.r.checks.push(...dup.get(x.id));
    }
    const flagged = out.filter((r) => r.checks.length).length;
    const changes = out.filter((r) => r.status === 'change');
    const errors = out.filter((r) => r.status === 'error').length;
    const canApply = !issues.length && !errors && changes.length > 0;
    const keys = keyColumns(screen);
    return {
      rows: out, issues,
      notes: [
        ...(screen.variantLabel ? [`나이스 화면: ${screen.variantLabel} 탭에 넣어요.`] : []),
        ...(flagged ? [`생기부 점검: ${flagged}명의 글에 확인할 곳이 있어요(입력은 막지 않아요). 상세 내역의 노란 글을 봐 주세요.`] : []),
      ],
      summary: { change: changes.length, same: out.filter((r) => r.status === 'same').length, error: errors, untouched: Math.max(0, rows.length - taken.size), flagged },
      canApply,
      plan: canApply ? {
        appId: screen.appId, dataset: screen.dataset, grid: screen.grid, keyColumns: keys,
        rows: changes.map((r) => ({ key: Object.fromEntries(keys.map((c) => [c, r.row[c]])), expect: { [T]: r.row[T] ?? '', ...(H ? { [H]: r.row[H] ?? '' } : {}) }, set: r.set })),
      } : null,
    };
  }

  D.record = { parse, score, readArgs, searchArgs, compare, clsOf, match, resolve, variantArgs };
})();
