// 공람자·과제카드 기억(교사 결정 2026-11-02): 선생님이 전에 고른 것을 기억해 비슷한 문서에 채운다. 처음에는 비어 있고 쓸수록 맞아 간다.
// 비슷한 문서: 발신 기관이 같거나 제목 낱말이 겹치면. 화면과 무관한 순수 로직(패널·node 시험). 기억은 storage.local 'eduPicks'(교직원 이름·과제카드 이름, 이 PC만).
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const MAX = 300;
  const MAX_NAMES = 200; // 문서 하나의 공람자(전체 선택해도 잘리지 않게)
  const MAX_FAVS = 30;
  // 어느 공문에나 나오는 말은 비교에서 뺀다
  const STOP = new Set(['안내', '제출', '요청', '협조', '계획', '결과', '보고', '알림', '통보', '시행', '운영', '관련', '실시', '학교', '학년도', '안내문', '공문', '회신', '조사', '자료', '학기', '학년', '교육', '활동', '사업', '관리', '현황', '확인', '참여', '지원', '개최', '선정', '대상', '비용']);

  // 제목 → 낱말(숫자·기호 빼고 두 글자 이상). '2026학년도 진로체험 운영 계획' → ['진로체험']
  function wordsOf(title) {
    return [...new Set(String(title || '')
      .replace(/\d{4}\s*(학년도|년도|년)?/g, ' ')
      .replace(/[^가-힣A-Za-z]+/g, ' ')
      .split(' ')
      .map((w) => w.replace(/(에|의|을|를|은|는|이|가|와|과|및)$/, ''))
      .filter((w) => w.length >= 2 && !STOP.has(w)))];
  }

  // 점수: 발신 기관 같음 2점, 겹치는 제목 낱말 하나에 3점. 3점 미만이면 비슷하지 않다고 본다(기관만 같으면 채우지 않음)
  function scoreOf(mem, doc) {
    const ws = new Set(wordsOf(doc.title));
    const hits = (mem.words || []).filter((w) => ws.has(w)).length;
    return (mem.sender && doc.sender && mem.sender === doc.sender ? 2 : 0) + hits * 3;
  }
  // 기억 목록에서 가장 비슷한 것(같은 점수면 최근). 없으면 null
  function suggest(list, doc) {
    let best = null;
    let bestScore = 0;
    for (const m of list || []) {
      const s = scoreOf(m, doc);
      if (s > bestScore || (s === bestScore && best && (m.at || 0) > (best.at || 0))) { best = m; bestScore = s; }
    }
    return bestScore >= 3 ? { ...best, score: bestScore } : null;
  }
  // 기억하기: 같은 기관·같은 낱말 조합이면 고쳐 쓴다. 고른 것이 하나도 없으면 기억하지 않는다
  function remember(list, doc, picks, now = Date.now()) {
    const cnrs = [...new Set((picks.cnrs || []).filter(Boolean))].slice(0, MAX_NAMES);
    const tkcrd = String(picks.tkcrd || '').trim();
    if (!cnrs.length && !tkcrd) return list || [];
    const words = wordsOf(doc.title);
    const sender = String(doc.sender || '');
    const key = (m) => `${m.sender}|${(m.words || []).join(',')}`;
    const entry = { sender, words, cnrs, tkcrd, at: now };
    const rest = (list || []).filter((m) => key(m) !== key(entry));
    return [entry, ...rest].slice(0, MAX);
  }

  // ── 공람 즐겨찾기(교사 요청 2026-11-09): 이름 붙인 사람 묶음. storage.local 'cnrsFavs', 이 PC만 ──
  const uniq = (names) => [...new Set((names || []).map((n) => String(n || '').trim()).filter(Boolean))];
  // 같은 이름이면 바꿔 저장한다 → { list, replaced } 또는 { error }
  function favSave(list, name, names, id) {
    const label = String(name || '').trim().slice(0, 20);
    const people = uniq(names).slice(0, MAX_NAMES);
    if (!label) return { error: '이름을 적어 주세요.' };
    if (!people.length) return { error: '먼저 공람자를 골라 주세요.' };
    const old = (list || []).find((f) => f.name === label);
    if (!old && (list || []).length >= MAX_FAVS) return { error: `즐겨찾기는 ${MAX_FAVS}개까지예요. 안 쓰는 것을 지워 주세요.` };
    const entry = { id: old?.id || id, name: label, names: people };
    return { list: old ? list.map((f) => (f === old ? entry : f)) : [...(list || []), entry], replaced: !!old };
  }
  // 지금 후보에 있는 사람만(전근 등으로 빠진 사람은 넣지 않는다). 후보 목록을 못 읽었으면 그대로
  const favNames = (fav, people) => { const all = uniq(fav?.names); return people?.length ? all.filter((n) => people.includes(n)) : all; };
  const favOn = (cnrs, fav, people) => { const names = favNames(fav, people); return !!names.length && names.every((n) => cnrs.includes(n)); };
  // 누르면 더하고, 이미 다 들어 있으면 뺀다 → { cnrs, removed, skipped(후보에 없어 뺀 수) }
  function favToggle(cnrs, fav, people) {
    const names = favNames(fav, people);
    const skipped = uniq(fav?.names).length - names.length;
    if (favOn(cnrs, fav, people)) return { cnrs: cnrs.filter((n) => !names.includes(n)), removed: true, skipped };
    return { cnrs: uniq([...cnrs, ...names]), removed: false, skipped };
  }
  // 전체 선택: 후보 전부 + 후보 밖에 직접 적은 이름은 그대로
  const selectAll = (cnrs, people) => uniq([...cnrs.filter((n) => !people.includes(n)), ...people]);

  D.edufinePickLogic = { wordsOf, scoreOf, suggest, remember, uniq, favSave, favNames, favOn, favToggle, selectAll, MAX_FAVS };
})();
