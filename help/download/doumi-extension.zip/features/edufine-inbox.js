// 에듀파인 결재대기 목록 → 카드. 브라우저 없이 도는 부분(머리줄 짝짓기·대기 일수·순서·누를 수 있는지 검사).
// 목록 내용(제목·기안자 등)은 패널 메모리에서만 쓰고 저장하지 않는다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const norm = (s) => String(s || '').replace(/\s+/g, '');

  // 머리줄 글자 → { 칸 이름: 순번 }. 똑같은 이름 먼저, 그다음 포함하는 이름
  function mapHeaders(heads, cfg) {
    const hs = heads.map(norm);
    const map = {};
    const used = new Set();
    for (const pass of ['exact', 'part']) {
      for (const [field, aliases] of Object.entries(cfg.headers)) {
        if (field in map) continue;
        const i = hs.findIndex((h, k) => !used.has(k) && h && aliases.some((a) => (pass === 'exact' ? h === norm(a) : h.includes(norm(a)))));
        if (i >= 0) { map[field] = i; used.add(i); }
      }
    }
    return map;
  }

  function parseDate(s) {
    const m = /(\d{4})\s*[-./년]\s*(\d{1,2})\s*[-./월]\s*(\d{1,2})/.exec(String(s || ''));
    if (!m) return null;
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  // 기안일부터 오늘까지 며칠(달력 날짜 기준)
  function waitDays(dateText, now = new Date()) {
    const d = parseDate(dateText);
    if (!d) return null;
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    return Math.max(0, Math.round((today - d) / 86400000));
  }
  const waitLabel = (n) => (n == null ? '' : n === 0 ? '오늘' : n === 1 ? '어제' : `${n}일째`);

  // 페이지에서 읽은 날것 → 카드 목록. 긴급은 맨 위, 나머지는 에듀파인 순서 그대로
  function toCards(raw, cfg, now = new Date()) {
    const map = mapHeaders(raw.heads || [], cfg);
    if (!('title' in map)) return { ok: false, error: 'shape', heads: raw.heads || [] };
    const cell = (r, f) => (f in map ? String(r.cells[map[f]] || '').trim() : '');
    const cards = (raw.rows || [])
      .filter((r) => r.docId || r.link)
      .map((r, i) => {
        const n = waitDays(cell(r, 'date'), now);
        return {
          docId: r.docId || '', order: i, title: cell(r, 'title') || '(제목 없음)', dept: cell(r, 'dept'), drafter: cell(r, 'drafter'),
          date: cell(r, 'date'), status: cell(r, 'status'), kind: cell(r, 'kind'), type: cell(r, 'type'), docNo: cell(r, 'docNo'),
          urgent: !!r.urgent, waitDays: n, wait: waitLabel(n), canOpen: !!(r.docId && r.link),
        };
      });
    cards.sort((a, b) => (b.urgent - a.urgent) || (a.order - b.order));
    const shown = cards.length;
    return { ok: true, cards, total: raw.total && raw.total > shown ? raw.total : shown, more: !!(raw.total && raw.total > shown), missing: Object.keys(cfg.headers).filter((f) => !(f in map)) };
  }

  const fnOf = (s) => (/^\s*(?:javascript:)?\s*([\w$.]+)\s*\(/.exec(s || '') || [])[1] || '';
  const hasAny = (s, words) => words.some((w) => String(s || '').includes(w));
  // 도우미가 누를 수 있는지: 메뉴는 정해 둔 글자와 똑같을 때, [조회]는 글자가 '조회'이고 함수 이름이 안전할 때, 제목 링크는 문서 여는 함수일 때만
  const safe = {
    menu: (text, cfg) => cfg.menuPath.includes(norm(text).replace(/\(\d+\)$|\d+$/, '')),
    search: (label, fn, cfg) => norm(label) === cfg.searchLabel && !hasAny(label, cfg.forbidden) && !hasAny(fn, cfg.forbiddenFn),
    open: (fn, cfg) => fnOf(fn) === cfg.openFn || fn === cfg.openFn,
  };

  D.edufineInboxLogic = { mapHeaders, parseDate, waitDays, waitLabel, toCards, fnOf, safe };
})();
