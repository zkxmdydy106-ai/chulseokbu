// F2 할 일 목록: 교사가 적거나, 다른 기능(에듀파인 결재함 카드 등)이 Doumi.todo.add로 넣는다.
// 보관: chrome.storage.local 'todo' — 교사가 지울 때까지 남김(2026-10-28 교사 결정). 원문 그대로 두고, 가리기는 내보낼 때 한다.
// 학생 자료를 넣는 곳이 아니다(업무 할 일: 공문 제목·기한·요약).
(() => {
  const D = globalThis.Doumi;
  const KEY = 'todo';
  const MAX = 200;
  const MEMO_MAX = 4000;
  const listeners = new Set();

  const clean = (s, n) => String(s ?? '').replace(/\r\n?/g, '\n').replace(/[ \t]+/g, ' ').trim().slice(0, n);
  const newId = () => `t${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

  // 출처: 문자열('에듀파인 결재함') 또는 { kind, label, docId }. docId는 겹침 확인에만 쓰고 내보내지 않는다.
  function sourceOf(s) {
    if (!s) return { kind: 'manual', label: '' };
    if (typeof s === 'string') return { kind: 'other', label: clean(s, 40) };
    return { kind: clean(s.kind, 20) || 'other', label: clean(s.label, 40), ...(s.docId ? { docId: clean(s.docId, 80) } : {}) };
  }

  // 기한: '2026-10-30', '10/30', '2026.10.30. 18:00', '20261030' → { due: 'YYYYMMDD', time: 'HH:MM' }
  function dueOf(raw, timeRaw, now = new Date()) {
    const s = String(raw ?? '').trim();
    let time = String(timeRaw ?? '').trim();
    const tm = /(\d{1,2}):(\d{2})/.exec(s);
    const dateText = tm ? s.slice(0, tm.index) : s;
    if (!time && tm) time = `${tm[1]}:${tm[2]}`;
    let error = '';
    let due = '';
    if (dateText.trim()) {
      due = D.normDate(dateText, String(now.getFullYear()));
      if (!due) error = `기한 날짜를 알 수 없어요: "${dateText.trim()}"`;
    }
    if (time) {
      const m = /^(\d{1,2}):(\d{2})$/.exec(time);
      if (!m || +m[1] > 23 || +m[2] > 59) { error = error || `기한 시각을 알 수 없어요: "${time}"`; time = ''; }
      else time = `${m[1].padStart(2, '0')}:${m[2]}`;
      if (!due && time) { error = error || '시각만 있고 날짜가 없어요.'; time = ''; }
    }
    return { due, time, error };
  }

  // 넣을 수 있는 모양으로 → { ok, item, error }
  function normalize(input, now = new Date()) {
    const title = clean(input?.title, 120).replace(/\n/g, ' ');
    if (!title) return { ok: false, error: '제목을 적어 주세요.' };
    const d = dueOf(input.due, input.time, now);
    if (d.error) return { ok: false, error: d.error };
    return { ok: true, item: { title, due: d.due, time: d.time, memo: clean(input.memo, MEMO_MAX), source: sourceOf(input.source) } };
  }

  const todayYmd = (now = new Date()) => `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
  // 목록 순서: 기한 빠른 것 → 기한 없는 것, 같으면 먼저 넣은 것
  const sort = (list) => [...list].sort((a, b) => ((a.due || '99999999') + (a.time || '99:99')).localeCompare((b.due || '99999999') + (b.time || '99:99')) || a.createdAt - b.createdAt);
  const sameItem = (a, b) => a.title === b.title && (a.source.docId && b.source.docId ? a.source.docId === b.source.docId : a.source.label === b.source.label && a.due === b.due);

  // 읽고-고쳐-쓰기는 한 줄로 세워 차례로(교사가 더하는 중에 다른 기능이 Doumi.todo.add를 불러도 하나가 사라지지 않게)
  let queue = Promise.resolve();
  const serial = (fn) => { const run = queue.then(fn, fn); queue = run.catch(() => {}); return run; };

  async function read() {
    const v = (await chrome.storage.local.get(KEY))[KEY];
    return Array.isArray(v) ? v : [];
  }
  async function write(list) {
    if (list.length) await chrome.storage.local.set({ [KEY]: sort(list).slice(0, MAX) });
    else await chrome.storage.local.remove(KEY);
    for (const fn of listeners) fn();
  }

  D.todo = {
    KEY,
    normalize,
    dueOf,
    sort,
    todayYmd,
    list: async () => sort(await read()),
    onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); },

    // 다른 기능이 부르는 입구: Doumi.todo.add({ title, due, time?, memo, source }) → { ok, item | error, duplicate? }
    add(input) {
      const n = normalize(input);
      if (!n.ok) return Promise.resolve(n);
      return serial(() => addNow(n));
    },
    update: (id, input) => serial(() => updateNow(id, input)),
    remove: (ids) => serial(() => removeNow(ids)),
    markSent: (ids, destLabels) => serial(() => markSentNow(ids, destLabels)),
    clear: () => serial(() => write([])),
  };

  async function addNow(n) {
    const list = await read();
    if (list.some((x) => sameItem(x, n.item))) return { ok: false, duplicate: true, error: '이미 목록에 있어요.' };
    if (list.length >= MAX) return { ok: false, error: `할 일은 ${MAX}개까지 모아 둘 수 있어요. 보낸 것을 지워 주세요.` };
    const item = { id: newId(), ...n.item, createdAt: Date.now() };
    await write([...list, item]);
    return { ok: true, item };
  }
  async function updateNow(id, input) {
    const list = await read();
    const i = list.findIndex((x) => x.id === id);
    if (i < 0) return { ok: false, error: '목록에 없는 할 일이에요.' };
    const n = normalize({ ...input, source: input.source ?? list[i].source });
    if (!n.ok) return n;
    list[i] = { ...list[i], ...n.item };
    await write(list);
    return { ok: true, item: list[i] };
  }
  async function removeNow(ids) {
    const drop = new Set([].concat(ids));
    await write((await read()).filter((x) => !drop.has(x.id)));
  }
  // 보낸 표시: 어느 보낼 곳으로 언제(내용은 그대로)
  async function markSentNow(ids, destLabels) {
    const set = new Set(ids);
    const at = Date.now();
    await write((await read()).map((x) => (set.has(x.id) ? { ...x, sentAt: at, sentTo: [...new Set([...(x.sentTo || []), ...destLabels])] } : x)));
  }
})();
