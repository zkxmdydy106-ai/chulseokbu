// V2 수행평가 점수 — 파일(학번·번호·이름 + 영역별 점수 칸) 해석 → 영역마다 나이스 학생 줄과 비교 → 검증(만점 초과·빈 점수·사유 코드) → 입력 계획
// 점수 칸 이름이 나이스 영역 이름(예: 논술, 실험보고서)이면 그 영역에, '점수' 한 칸이면 나이스 화면에 고른 영역(또는 영역이 하나뿐이면 그 영역)에 넣는다.
// 점수 대신 '결시'처럼 사유를 적으면 나이스 사유 코드표(dsAfeCd)에서 찾아 넣는다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  const HEAD = { no: ['번호', '번', '출석번호'], studentId: ['학번'], name: ['이름', '성명', '학생', '학생명'], cls: ['반', '학반', '학급'] };
  const ANY = ['점수', '총점', '수행평가', '수행평가점수', '합계', '득점', '영역점수'];
  const sq = (s) => D.squash(s).replace(/[()（）]/g, '');
  const sepOf = (raw) => (raw.includes('\t') ? '\t' : raw.includes(',') ? ',' : null);
  const cellsOf = (raw) => { const sep = sepOf(raw); return sep ? D.splitCells(raw, sep).map((c) => String(c ?? '').trim()) : raw.trim().split(/\s+/); };

  // areas: [{ no, name }] — 나이스 영역 목록
  function parse(text, areas = []) {
    const lines = D.lines(text);
    const items = [];
    const issues = [];
    const areaOfHead = (h) => {
      if (ANY.includes(sq(h))) return '*';
      const s = sq(h).replace(/점수$|\d+점$/, '');
      if (!s) return null;
      const a = areas.find((x) => sq(x.name) === s) || areas.find((x) => s.length >= 2 && (sq(x.name).includes(s) || s.includes(sq(x.name))));
      return a ? a.no : null;
    };
    let hi = -1, fields = null, scoreCols = [];
    for (let i = 0; i < Math.min(lines.length, 6); i++) {
      const cells = cellsOf(lines[i].raw);
      const f = cells.map((c) => Object.keys(HEAD).find((k) => HEAD[k].includes(sq(c))) || null);
      if (!f.some(Boolean)) continue;
      const sc = cells.map((c, j) => (f[j] ? null : areaOfHead(c))).map((a, j) => (a ? { col: j, area: a, head: cells[j] } : null)).filter(Boolean);
      hi = i; fields = f; scoreCols = sc;
      break;
    }
    if (fields) {
      if (!scoreCols.length) return { items, issues: [`점수 칸을 찾지 못했어요. 칸 이름을 영역 이름${areas.length ? `(${areas.map((a) => a.name).join(', ')})` : ''} 또는 '점수'로 적어 주세요.`], areasUsed: [] };
      for (const l of lines.slice(hi + 1)) {
        const cells = cellsOf(l.raw);
        const get = (k) => { const i = fields.indexOf(k); return i >= 0 ? String(cells[i] ?? '').trim() : ''; };
        const sid = get('studentId').replace(/\D/g, '');
        const it = {
          line: l.no,
          no: D.normNo(get('no')) || (sid.length >= 3 ? String(+sid.slice(-2)) : ''),
          cls: D.record.clsOf(get('cls')) || (sid.length >= 5 ? String(+sid.slice(-4, -2)) : ''),
          name: D.squash(get('name')),
          scores: Object.fromEntries(scoreCols.map((s) => [s.area, String(cells[s.col] ?? '').trim()])),
          issues: [],
        };
        if (!it.no && !it.name) continue; // 합계·빈 줄
        items.push(it);
      }
      return { items, issues, areasUsed: [...new Set(scoreCols.map((s) => s.area))], heads: scoreCols.map((s) => s.head) };
    }
    // 머리줄 없음: '번호 (이름) 점수'
    for (const l of lines) {
      const m = /^\s*(\d{1,5})[\s,\t]+(?:([가-힣A-Za-z]{2,10})[\s,\t]+)?(\S+)\s*$/.exec(l.raw);
      if (!m) { issues.push(`${l.no}번째 줄을 알아보지 못했어요: ${l.raw.slice(0, 30)}`); continue; }
      items.push({ line: l.no, no: m[1].length >= 3 ? String(+m[1].slice(-2)) : D.normNo(m[1]), cls: m[1].length >= 5 ? String(+m[1].slice(-4, -2)) : '', name: m[2] || '', scores: { '*': m[3] }, issues: [] });
    }
    return { items, issues, areasUsed: items.length ? ['*'] : [] };
  }

  // 결시 칸: '질병결시' · '질병결시 16'(인정점) · '질병결시 16 기준 18'(인정점·기준점) — 2026-10-28 교사 결정: 인정점은 파일에 적고 도우미는 계산하지 않는다
  const ABSENT = /^(.*?[^\d\s.(（])\s*[(（]?\s*(\d+(?:\.\d+)?)\s*점?\s*(?:[,/]?\s*기준\s*점?\s*(\d+(?:\.\d+)?)\s*점?)?\s*[)）]?$/;
  function splitAbsence(raw) {
    const s = String(raw ?? '').trim();
    if (!s || s === '-' || /^\d+(\.\d+)?$/.test(s)) return null;
    const m = ABSENT.exec(s);
    return m ? { name: m[1].trim(), acsc: String(Number(m[2])), base: m[3] ? String(Number(m[3])) : '' } : { name: s, acsc: '', base: '' };
  }
  // '미인정'과 '인정'은 글자가 겹치지만 정반대다(미인정결시 ≠ 인정결)
  const sameReason = (a, b) => { const x = sq(a).replace(/[[\]]/g, ''), y = sq(b).replace(/[[\]]/g, ''); return !!x && !!y && x.includes('미인정') === y.includes('미인정') && (x === y || x.includes(y) || y.includes(x)); };
  // 나이스는 사유가 없는 학생을 코드 '0'(이름 빈칸)으로 둔다(2026-11-02 실제). 사유 이름은 인정결·질병결·미인정결·기타결
  const noAfe = (v) => { const s = String(v ?? '').trim(); return !s || s === '0'; };

  // 칸 값 → { score } | { afe: { code, name }, acsc?, base? } | { bad } | null(비어 있음 — 건드리지 않음)
  function valueOf(raw, reasons) {
    const s = String(raw ?? '').trim();
    if (!s || s === '-') return null;
    if (/^\d+(\.\d+)?$/.test(s)) return { score: String(Number(s)) };
    const a = splitAbsence(s);
    const k = sq(a.name);
    // '질병결시'처럼 '시'까지 적어도, '미인정결시'가 '인정결'로 잘못 잡히지 않게 같은 이름 → 긴 이름부터 찾는다(2026-11-02 실제 코드표)
    const bare = k.replace(/시$/, '');
    const r = reasons.find((x) => sq(x.name) === k) || reasons.find((x) => sq(x.name) === bare)
      || [...reasons].sort((x, y) => sq(y.name).length - sq(x.name).length).find((x) => sameReason(x.name, k));
    if (!r) return { bad: s };
    return a.acsc ? { afe: r, acsc: a.acsc, base: a.base } : { afe: r };
  }

  // area: { no, name, max, closed }, rows: 나이스 학생 줄, reasons: [{ code, name }]
  function compare({ parsed, areaKey, area, rows, reasons = [], screen }) {
    const K = screen.key, C = screen.columns;
    const issues = [];
    const notes = [];
    if (!rows.length) issues.push('나이스 학생 목록이 비어 있어요. 나이스 화면의 과목·반을 확인해 주세요.');
    if (area.closed === 'Y') issues.push(`${area.name} 영역은 마감되어 있어요. 마감 취소는 나이스에서 직접 해 주세요.`);
    const max = Number(area.max || 0);
    const taken = new Map();
    const out = [];
    let withAcsc = 0;
    for (const it of parsed.items) {
      const v = valueOf(it.scores[areaKey], reasons);
      if (!v) continue;
      const res = { line: it.line, no: it.no, name: it.name, issues: [...it.issues], warnings: [], checks: [], cur: null, next: null, set: null, row: null, status: 'error' };
      const row = D.record.match(it, rows, K, res);
      if (row) {
        res.neisName = row[K.name];
        res.neisNo = `${D.record.clsOf(row[K.cls]) ? `${D.record.clsOf(row[K.cls])}-` : ''}${D.normNo(row[K.no])}`;
        if (taken.has(row._row)) res.issues.push(`${taken.get(row._row)}번째 줄과 같은 학생이에요.`); else taken.set(row._row, it.line);
        res.cur = { kind: String(row[C.afeName] || '').trim() || (String(row[C.score] ?? '').trim() ? `${row[C.score]}점` : ''), reason: '' };
        const set = {};
        if (v.bad) res.issues.push(`'${v.bad}'을(를) 점수나 사유로 알아보지 못했어요${reasons.length ? ` (사유: ${reasons.map((x) => x.name).join(', ')})` : ''}.`);
        if (v.score != null) {
          const n = Number(v.score);
          if (max > 0 && n > max) res.issues.push(`만점(${max}점)보다 커요.`);
          if (String(row[C.score] ?? '').trim() === '' || Number(row[C.score]) !== n) set[C.score] = v.score;
          if (!noAfe(row[C.afe])) { set[C.afe] = rows.some((x) => String(x[C.afe] ?? '').trim() === '0') ? '0' : ''; set[C.afeName] = ''; res.warnings.push(`나이스의 사유(${row[C.afeName] || row[C.afe]})를 지우고 점수를 넣어요.`); }
          res.next = { kind: `${v.score}점`, reason: '' };
        }
        if (v.afe) {
          if (String(row[C.afe] ?? '').trim() !== v.afe.code) { set[C.afe] = v.afe.code; set[C.afeName] = v.afe.name; }
          if (String(row[C.score] ?? '').trim()) res.warnings.push('점수가 있는 학생에 사유를 넣어요. 인정점은 나이스 계산을 확인해 주세요.');
          res.next = { kind: v.afe.name, reason: v.acsc ? `인정점 ${v.acsc}점은 [결시생 인정점]에서` : '' };
          if (v.acsc) withAcsc++;
        }
        if (res.cur.kind && Object.keys(set).length && !res.warnings.length) res.warnings.push('나이스에 있는 점수를 바꿔요.');
        res.set = set;
        res.row = row;
      }
      res.status = res.issues.length ? 'error' : res.set && Object.keys(res.set).length ? 'change' : 'same';
      out.push(res);
    }
    if (!out.length && parsed.items.length) notes.push(`파일에 ${area.name} 점수가 하나도 없어요.`);
    if (withAcsc) notes.push(`${area.name}: 인정점이 적힌 결시 ${withAcsc}명은 여기서 사유만 넣어요. 저장한 뒤 같은 파일을 [결시생 인정점]에 넣으면 인정점이 들어가요.`);
    const blank = rows.filter((r) => !taken.has(r._row) && !String(r[C.score] ?? '').trim() && noAfe(r[C.afe])).length;
    if (blank && rows.length) notes.push(`${area.name}: 점수도 사유도 없는 학생 ${blank}명이에요. 결시·인정점 처리를 확인해 주세요.`);
    const changes = out.filter((r) => r.status === 'change');
    const errors = out.filter((r) => r.status === 'error').length;
    const canApply = !issues.length && !errors && changes.length > 0;
    const keys = [K.cls, K.no, K.name];
    return {
      rows: out, issues, notes,
      summary: { change: changes.length, same: out.filter((r) => r.status === 'same').length, error: errors, untouched: Math.max(0, rows.length - taken.size) },
      canApply,
      plan: canApply ? {
        appId: screen.appId, dataset: screen.dataset, grid: screen.grid, keyColumns: keys,
        rows: changes.map((r) => ({ key: Object.fromEntries(keys.map((c) => [c, r.row[c]])), expect: Object.fromEntries(Object.keys(r.set).map((c) => [c, r.row[c] ?? ''])), set: r.set })),
      } : null,
    };
  }

  const areasOf = (extra, screen) => (extra?.[screen.areas.dataset] || []).map((a) => ({
    no: String(a[screen.areas.no] ?? '').trim(), name: String(a[screen.areas.name] ?? '').trim(),
    max: String(a[screen.areas.max] ?? '').trim(), ratio: String(a[screen.areas.ratio] ?? '').trim(), closed: String(a[screen.areas.closed] ?? '').trim(),
  })).filter((a) => a.no);
  const reasonsOf = (extra, screen) => (extra?.[screen.reasons.dataset] || []).map((r) => ({ code: String(r[screen.reasons.code] ?? '').trim(), name: String(r[screen.reasons.name] ?? '').trim() })).filter((r) => r.code && r.name);

  function readArgs(screen) {
    const K = screen.key, C = screen.columns, A = screen.areas, R = screen.reasons;
    return {
      appId: screen.appId, dataset: screen.dataset, columns: [K.cls, K.no, K.name, C.score, C.afe, C.afeName],
      dataMaps: { [screen.search.dataMap]: [screen.search.area] },
      extraDatasets: { [A.dataset]: [A.no, A.name, A.max, A.ratio, A.closed], [R.dataset]: [R.code, R.name] },
    };
  }

  // ── V2 결시생 인정점(결시생인정점관리) ─────────────────────
  // 같은 수행평가 파일(또는 지필 고사 칸)을 넣으면 '사유 + 점수'가 적힌 칸만 골라 나이스 인정점(_scr)에 넣는다. 계산은 하지 않는다.
  // 나이스 표는 학생 한 줄에 고사·영역마다 칸 묶음: 'A' + 구분 + '_' + 과목 + '_' + 번호 + (_afe 사유 · _afeCd · _acscBasScr 기준점 · _scr 인정점)
  const examsOf = (extra, screen) => {
    const E = screen.exams;
    return (extra?.[E.dataset] || []).map((e) => ({
      prefix: `A${String(e[E.kind] ?? '').trim()}_${String(e[E.sbjt] ?? '').trim()}_${String(e[E.no] ?? '').trim()}`,
      name: String(e[E.name] ?? '').trim(), max: String(e[E.max] ?? '').trim(), perf: String(e[E.kind] ?? '').trim() === E.perf,
    })).filter((e) => e.name);
  };
  const absenceArgs = (screen) => {
    const E = screen.exams, S = screen.status;
    return { appId: screen.appId, dataset: E.dataset, columns: [E.kind, E.sbjt, E.no, E.name, E.max], dataMaps: { [S.dataMap]: [S.closed, S.reg, 'trgtStuCnt'] } };
  };
  const absenceGridArgs = (screen, exams) => {
    const K = screen.key, X = screen.cell;
    return { appId: screen.appId, dataset: screen.dataset, columns: [K.cls, K.no, K.name, ...exams.flatMap((e) => Object.values(X).map((s) => e.prefix + s))] };
  };
  const filledV = (v) => String(v ?? '').trim() !== '' && String(v).trim() !== '[미입력]';

  function compareAbsence({ parsed, rows, exams, status = {}, screen }) {
    const K = screen.key, X = screen.cell;
    const issues = [...parsed.issues];
    const notes = [];
    if (status.closed === 'Y') issues.push('결시생 인정점이 마감되어 있어요. 마감 취소는 나이스에서 직접 해 주세요.');
    if (status.reg === 'N') issues.push('인정점 기준이 등록되어 있지 않아요. 나이스 [결시생인정점관리]에서 인정점 기준을 먼저 등록해 주세요.');
    if (!rows.length || status.trgtStuCnt === '0') issues.push('나이스 결시생 목록이 비어 있어요. 나이스 화면에 학년도·학기·과목을 고르고, [수행평가성적관리]에 결시 사유가 들어 있는지 확인해 주세요.');
    const examOf = (k) => (k === '*' ? (exams.length === 1 ? exams[0] : null) : exams.find((e) => e.prefix === k));
    if (parsed.areasUsed.includes('*') && exams.length !== 1) issues.push(`점수 칸이 어느 고사·영역인지 모르겠어요. 칸 이름을 ${exams.map((e) => e.name).join(', ')} 중 하나로 적어 주세요.`);
    const out = [];
    const done = new Set();
    let noScore = 0;
    for (const it of parsed.items) {
      for (const key of parsed.areasUsed) {
        const ex = examOf(key);
        const a = ex && splitAbsence(it.scores[key]);
        if (!a) continue; // 빈칸·점수(숫자)는 이 화면과 관계없음
        if (!a.acsc) { noScore++; continue; }
        const res = { line: it.line, no: it.no, name: `${it.name} · ${ex.name}`, issues: [], warnings: [], checks: [], cur: null, next: null, set: null, row: null, status: 'error' };
        const row = D.record.match(it, rows, K, res);
        if (row) {
          res.neisName = `${row[K.name]} · ${ex.name}`;
          res.name = res.neisName;
          res.neisNo = `${D.record.clsOf(row[K.cls]) ? `${D.record.clsOf(row[K.cls])}-` : ''}${D.normNo(row[K.no])}`;
          const k = `${row._row}|${ex.prefix}`;
          if (done.has(k)) res.issues.push('같은 학생·같은 고사가 파일에 두 번 있어요.'); else done.add(k);
          const afe = String(row[ex.prefix + X.afe] ?? '').trim();
          const afeCd = String(row[ex.prefix + X.afeCd] ?? '').trim();
          const base = String(row[ex.prefix + X.base] ?? '').trim();
          const score = String(row[ex.prefix + X.score] ?? '').trim();
          res.cur = afeCd
            ? { kind: `${afe.replace(/[[\]]/g, '') || '결시'} · ${filledV(score) ? `인정점 ${score}` : '인정점 없음'}`, reason: base ? `기준점 ${base}` : '' }
            : { kind: '결시 아님', reason: '' };
          const set = {};
          if (!afeCd) res.issues.push('나이스에 이 학생 결시 처리가 없어요. [수행평가성적관리](지필은 성적 입력 화면)에 결시 사유를 먼저 넣어 주세요.');
          else if (afe && !sameReason(afe, a.name)) res.issues.push(`나이스 사유는 ${afe}인데 파일은 ${a.name}이에요.`);
          const max = Number(ex.max || 0);
          if (max > 0 && Number(a.acsc) > max) res.issues.push(`인정점이 만점(${max}점)보다 커요.`);
          if (!filledV(base) && !a.base) res.issues.push("기준점이 없어요. 파일에 '질병결시 16 기준 18'처럼 기준점도 적어 주세요.");
          if (a.base && Number(a.base) !== Number(base || NaN)) { set[ex.prefix + X.base] = Number(a.base); if (filledV(base)) res.warnings.push(`나이스 기준점(${base})을 바꿔요.`); }
          if (!filledV(score) || Number(score) !== Number(a.acsc)) set[ex.prefix + X.score] = Number(a.acsc);
          if (filledV(score) && set[ex.prefix + X.score] != null) res.warnings.push('나이스에 있는 인정점을 바꿔요.');
          res.next = { kind: `인정점 ${a.acsc}`, reason: a.base || base ? `기준점 ${a.base || base}` : '' };
          res.set = set;
          res.row = row;
        }
        res.status = res.issues.length ? 'error' : Object.keys(res.set || {}).length ? 'change' : 'same';
        out.push(res);
      }
    }
    // 나이스는 인정점이 빈 결시생이 하나라도 있으면 저장을 막는다(SW-SCR-0487·0300)
    const left = [];
    for (const r of rows) {
      for (const ex of exams) {
        if (!String(r[ex.prefix + X.afeCd] ?? '').trim() || done.has(`${r._row}|${ex.prefix}`)) continue;
        if (!filledV(r[ex.prefix + X.score])) left.push(`${D.normNo(r[K.no])}번 ${ex.name}`);
      }
    }
    if (left.length) issues.push(`인정점이 빈 결시생이 ${left.length}칸 더 있어요(${cut(left.join(', '), 40)}). 나이스가 저장을 막으니 파일에 함께 적어 주세요.`);
    if (noScore) notes.push(`사유만 있고 인정점이 없는 칸 ${noScore}개는 건너뛰어요('질병결시 16'처럼 점수를 함께 적어 주세요).`);
    if (!out.length && !issues.length) issues.push("파일에서 인정점이 적힌 결시 칸을 찾지 못했어요. '질병결시 16'처럼 사유와 인정점을 함께 적어 주세요.");
    const changes = out.filter((r) => r.status === 'change');
    const errors = out.filter((r) => r.status === 'error').length;
    const canApply = !issues.length && !errors && changes.length > 0;
    const keys = [K.cls, K.no, K.name];
    return {
      rows: out, issues, notes,
      summary: { change: changes.length, same: out.filter((r) => r.status === 'same').length, error: errors },
      canApply,
      plan: canApply ? {
        appId: screen.appId, dataset: screen.dataset, grid: screen.grid, keyColumns: keys,
        rows: changes.map((r) => ({ key: Object.fromEntries(keys.map((c) => [c, r.row[c]])), expect: Object.fromEntries(Object.keys(r.set).map((c) => [c, r.row[c] ?? ''])), set: r.set })),
      } : null,
    };
  }
  const cut = (s, n) => { s = String(s ?? ''); return s.length > n ? `${s.slice(0, n)}…` : s; };

  const absence = {
    parse: (text, exams) => parse(text, exams.map((e) => ({ no: e.prefix, name: e.name }))),
    compare: compareAbsence, examsOf, readArgs: absenceArgs, gridArgs: absenceGridArgs, split: splitAbsence,
  };

  D.perf = { parse, valueOf, compare, readArgs, areasOf, reasonsOf, absence };
})();
