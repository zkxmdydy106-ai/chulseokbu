// 할 일 내보내기 전 자동 가리기: 찾을 수 있는 개인식별정보만 '(전화번호 가림)'처럼 바꾼다.
// 찾는 것: 주민·외국인등록번호, 카드번호, 휴대전화·일반 전화, 이메일, 계좌번호, 학번, 'n학년 n반 n번 이름'·'1-3 15번 이름'.
// 이름만 따로 적힌 것 등 자유 서술 속 개인정보는 다 찾지 못한다(방침에 적음) → 미리보기에서 교사가 본다.
(() => {
  const D = globalThis.Doumi;

  const digits = (s) => s.replace(/\D/g, '').length;
  const BANK = '(?:계좌|은행|농협|국민|신한|우리|하나|기업|새마을|우체국|수협|신협|카카오뱅크|케이뱅크|토스뱅크|SC제일|씨티|부산|경남|대구|광주|전북|제주)';

  // 순서가 중요하다: 긴 것(주민·카드)을 먼저 가려야 짧은 규칙(전화)이 그 안을 잘못 잡지 않는다.
  const RULES = [
    { kind: '주민등록번호', re: /(?<!\d)\d{6}\s?[-–]\s?[1-8](?:\d{6}|\*{6})(?!\d)/g },
    { kind: '주민등록번호', re: /(?<!\d)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])[1-8]\d{6}(?!\d)/g },
    { kind: '카드번호', re: /(?<!\d)\d{4}[- ]\d{4}[- ]\d{4}[- ]\d{3,4}(?!\d)/g },
    { kind: '전화번호', re: /(?<!\d)01[016789][-. ]?\d{3,4}[-. ]?\d{4}(?!\d)/g },
    { kind: '전화번호', re: /(?<![\d-])\(?0(?:2|[3-6][1-5]|70)\)?[-. )]\s?\d{3,4}[-. ]\d{4}(?!\d)/g },
    { kind: '이메일', re: /[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g },
    // 은행·계좌 낱말 뒤 20자 안의 숫자 묶음(10~16자리)
    { kind: '계좌번호', re: new RegExp(`(${BANK}[^\\d\\n]{0,20})(\\d[\\d -]{8,22}\\d)`, 'g'), group: 2, test: (m) => digits(m) >= 10 && digits(m) <= 16 },
    // 낱말이 없어도 '123-456789-01-234'처럼 하이픈 3묶음 이상, 10~16자리
    { kind: '계좌번호', re: /(?<![\d-])\d{2,6}-\d{2,6}-\d{2,8}(?:-\d{1,3})?(?![\d-])/g, test: (m) => digits(m) >= 10 && digits(m) <= 16 },
    { kind: '학번', re: /(학번\s*[:：]?\s*)(\d{4,6})(?!\d)/g, group: 2 },
    { kind: '학생 번호·이름', re: /(\d\s*학년\s*\d{1,2}\s*반\s*)(\d{1,2}\s*번(?:\s*[가-힣]{2,4}(?![가-힣]))?)/g, group: 2 },
    { kind: '학생 번호·이름', re: /((?<![\d-])\d-\d{1,2}\s*반?\s*)(\d{1,2}\s*번(?:\s*[가-힣]{2,4}(?![가-힣]))?)/g, group: 2 },
  ];

  const label = (kind) => `(${kind} 가림)`;

  // → { text, total, kinds: { 전화번호: 1, … } }
  D.mask = (input) => {
    let text = String(input ?? '');
    const kinds = {};
    for (const r of RULES) {
      text = text.replace(r.re, (...m) => {
        const whole = m[0];
        const part = r.group ? m[r.group] : whole;
        if (!part || (r.test && !r.test(part))) return whole;
        kinds[r.kind] = (kinds[r.kind] || 0) + 1;
        return r.group ? m.slice(1, r.group).join('') + label(r.kind) : label(r.kind);
      });
    }
    return { text, total: Object.values(kinds).reduce((a, b) => a + b, 0), kinds };
  };
  D.mask.label = label;
  D.mask.summary = (kinds) => Object.entries(kinds).map(([k, n]) => `${k} ${n}`).join(', ');
})();
