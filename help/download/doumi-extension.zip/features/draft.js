// F3 에듀파인 기안·품의 — 본문 만들기와 검사(화면과 무관한 순수 로직). 패널과 node 테스트 양쪽에서 돈다.
// 공문 표기는 「행정업무의 운영 및 혁신에 관한 규정」 시행규칙·행정업무운영편람을 따른다:
//   항목 기호 1. → 가. → 1) → 가) → (1) → (가) → ① → ㉮, 아래 단계는 두 칸씩 들여 씀
//   날짜 2026. 10. 28.  금액 금113,560원(금일십일만삼천오백육십원)
//   붙임은 '붙임' 뒤 두 칸, 여러 개면 1. 2. … 끝에 두 칸 띄우고 '끝.'
// AI는 쓰지 않는다(CLAUDE.md F3: AI 다듬기는 승인·방침 개정 뒤 별도).
(() => {
  const D = globalThis.Doumi;
  const NL = String.fromCharCode(10);
  const GA = '가나다라마바사아자차카타파하';
  const CIRCLE = '①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮';
  const CIRCLE_GA = '㉮㉯㉰㉱㉲㉳㉴㉵㉶㉷㉸㉹㉺㉻';

  // 단계(0부터)와 순번(0부터) → 항목 기호
  function mark(level, i) {
    const ga = GA[i % GA.length];
    switch (level) {
      case 0: return `${i + 1}.`;
      case 1: return `${ga}.`;
      case 2: return `${i + 1})`;
      case 3: return `${ga})`;
      case 4: return `(${i + 1})`;
      case 5: return `(${ga})`;
      case 6: return CIRCLE[i] || `(${i + 1})`;
      default: return CIRCLE_GA[i] || `(${ga})`;
    }
  }

  // 받침 있으면 앞, 없으면 뒤: josa('계획', '을', '를') → '계획을'
  function josa(word, withFinal, withoutFinal) {
    const w = String(word || '').trim();
    const last = w.replace(/[\s)」』"'.]+$/, '').slice(-1);
    const code = last.charCodeAt(0);
    let has;
    if (code >= 0xac00 && code <= 0xd7a3) has = (code - 0xac00) % 28 !== 0;
    else if (/[0-9]/.test(last)) has = '0136781'.includes(last); // 영·일·삼·육·칠·팔·십(0)
    else if (/[a-z]/i.test(last)) has = /[lmnr]/i.test(last);
    else has = false;
    return w + (has ? withFinal : withoutFinal);
  }

  // '20261028' / '2026-10-28' / Date → '2026. 10. 28.'
  function formatDate(v) {
    let ymd = v instanceof Date ? `${v.getFullYear()}${String(v.getMonth() + 1).padStart(2, '0')}${String(v.getDate()).padStart(2, '0')}` : D.normDate(v);
    if (!ymd) return String(v ?? '');
    return `${+ymd.slice(0, 4)}. ${+ymd.slice(4, 6)}. ${+ymd.slice(6)}.`;
  }

  // 113560 → '일십일만삼천오백육십' (공문 금액 한글: 단위 앞 '일'도 쓴다)
  function koreanAmount(n) {
    n = Math.floor(Math.abs(Number(n) || 0));
    if (!n) return '영';
    const DIG = '영일이삼사오육칠팔구';
    const SMALL = ['', '십', '백', '천'];
    const BIG = ['', '만', '억', '조', '경'];
    let out = '';
    for (let g = 0; n > 0; g++, n = Math.floor(n / 10000)) {
      const part = n % 10000;
      if (!part) continue;
      let s = '';
      String(part).padStart(4, '0').split('').forEach((c, i) => { if (c !== '0') s += DIG[+c] + SMALL[3 - i]; });
      out = s + BIG[g] + out;
    }
    return out;
  }
  const comma = (n) => Math.round(Number(n) || 0).toLocaleString('en-US');
  const formatMoney = (n) => `금${comma(n)}원(금${koreanAmount(n)}원)`;
  const toNumber = (v) => {
    if (typeof v === 'number') return v;
    const s = String(v ?? '').replace(/[,\s원₩]/g, '');
    return /^-?\d+(\.\d+)?$/.test(s) ? Number(s) : NaN;
  };

  // 관련 문서 한 건 → '충청남도교육청 교육과정과-12345(2026. 10. 1.) 「제목」'
  function relatedText(r) {
    const head = [r.org, r.dept].filter(Boolean).join(' ');
    const no = r.docNo ? (head ? `${head}-${r.docNo}` : r.docNo) : head;
    const date = r.date ? `(${formatDate(r.date)})` : '';
    const title = r.title ? ` 「${String(r.title).trim()}」` : '';
    return `${no}${date}${title}`.trim();
  }
  // 에듀파인 문서번호 모양 '교육과정과-12345' / '○○고등학교-1234' 를 기관·번호로
  function parseDocNo(s) {
    const m = /^\s*(.+?)-(\d{1,7})\s*$/.exec(String(s || ''));
    return m ? { dept: m[1].trim(), docNo: m[2] } : null;
  }

  // 본문 나무 → 글 줄. node = { text, children: [] } (첫 단계는 1. 2. …)
  function renderItems(nodes, level = 0, start = 0) {
    const lines = [];
    nodes.forEach((n, i) => {
      if (!n) return;
      const text = typeof n === 'string' ? n : n.text;
      const pad = '  '.repeat(level);
      lines.push(`${pad}${mark(level, i + (level === 0 ? start : 0))} ${String(text ?? '').trim()}`);
      if (n.children?.length) lines.push(...renderItems(n.children, level + 1));
    });
    return lines;
  }

  // 붙임 줄 + '끝.' (붙임 없으면 마지막 본문 줄 뒤에 '  끝.')
  function renderTail(lines, attachments) {
    const out = lines.slice();
    const att = (attachments || []).map((a) => (typeof a === 'string' ? { name: a } : a)).filter((a) => a.name);
    const one = (a) => `${String(a.name).replace(/\.[a-z0-9]{2,5}$/i, '').trim()} ${a.copies || 1}부.`;
    if (!att.length) {
      if (out.length) out[out.length - 1] = `${out[out.length - 1].replace(/\s+$/, '')}  끝.`;
      return out;
    }
    out.push('');
    if (att.length === 1) out.push(`붙임  ${one(att[0])}  끝.`);
    else att.forEach((a, i) => out.push(`${i === 0 ? '붙임  ' : '      '}${i + 1}. ${one(a)}${i === att.length - 1 ? '  끝.' : ''}`));
    return out;
  }

  // 기안 종류별 틀. 입력: { subject, when, where, who, what, result, budget, items, budgetCode, method, deadline, submit }
  const KINDS = {
    free: {
      label: '직접 쓰기',
      title: (d) => d.subject,
      body: () => [],
    },
    plan: {
      label: '계획(내부결재)',
      title: (d) => `${d.year || new Date().getFullYear()}학년도 ${d.subject} 계획`,
      body: (d) => [
        { text: `${josa(d.subject, '을', '를')} 다음과 같이 실시하고자 합니다.`, children: [
          `일시: ${d.when || '　'}`, `장소: ${d.where || '　'}`, `대상: ${d.who || '　'}`, `내용: ${d.what || '　'}`,
          ...(d.budget ? [`소요 예산: ${formatMoney(d.budget)}`] : []),
        ] },
      ],
    },
    result: {
      label: '결과 보고(내부결재)',
      title: (d) => `${d.year || new Date().getFullYear()}학년도 ${d.subject} 결과 보고`,
      body: (d) => [
        { text: `${josa(d.subject, '을', '를')} 다음과 같이 실시하였기에 그 결과를 보고합니다.`, children: [
          `일시: ${d.when || '　'}`, `장소: ${d.where || '　'}`, `대상: ${d.who || '　'}`, `내용: ${d.what || '　'}`,
          ...(d.result ? [`결과: ${d.result}`] : []),
          ...(d.budget ? [`집행 금액: ${formatMoney(d.budget)}`] : []),
        ] },
      ],
    },
    expense: {
      label: '지출품의',
      title: (d) => `${d.subject} 물품 구입`,
      body: (d) => {
        const items = d.items || [];
        const total = items.reduce((s, it) => s + (toNumber(it.amount) || 0), 0);
        const name = items.length ? `${items[0].name}${items.length > 1 ? ` 외 ${items.length - 1}종` : ''}` : (d.subject || '');
        return [
          { text: `${d.subject} 운영에 필요한 물품을 다음과 같이 구입하고자 합니다.`, children: [
            `품명: ${name}`,
            `소요 예산: ${formatMoney(total || d.budget || 0)}`,
            `예산 과목: ${d.budgetCode || '　'}`,
            `구입 방법: ${d.method || '　'}`,
          ] },
        ];
      },
    },
    reply: {
      label: '대외 회신(보고)',
      title: (d) => `${d.subject} 제출`,
      body: (d) => [
        { text: `위 호와 관련하여 ${d.subject} 자료를 붙임과 같이 제출합니다.`, children: [
          ...(d.deadline ? [`제출 기한: ${formatDate(d.deadline) || d.deadline}`] : []),
          ...(d.submit ? [`제출 자료: ${d.submit}`] : []),
        ].filter(Boolean) },
      ],
    },
  };

  // 기안 초안 → { title, lines, text }
  function compose(draft) {
    const kind = KINDS[draft.kind] || KINDS.plan;
    const d = { ...draft, subject: String(draft.subject || '').trim() };
    const title = String(draft.title || '').trim() || (d.subject ? kind.title(d) : '');
    const related = (draft.related || []).filter((r) => r && (r.docNo || r.dept || r.title));
    const top = [];
    if (related.length === 1) top.push(`관련: ${relatedText(related[0])}`);
    else if (related.length > 1) top.push({ text: '관련:', children: related.map(relatedText) });
    const body = draft.bodyItems?.length ? draft.bodyItems : (d.subject ? kind.body(d) : []);
    const lines = renderTail(renderItems([...top, ...body]), draft.attachments);
    return { title, lines, text: lines.join(NL) };
  }

  // 견적서 표(2차원 배열) → 품목. 머리줄을 찾아 품명·규격·단위·수량·단가·금액 칸을 고른다
  const HEAD = {
    name: /^(품\s*명|품\s*목|물\s*품\s*명|상\s*품\s*명|내\s*역|항\s*목)$/,
    spec: /^(규\s*격|사\s*양|모\s*델)/,
    unit: /^단\s*위$/,
    qty: /^(수\s*량|수량\(.*\))$/,
    price: /^(단\s*가|단가\(.*\))$/,
    amount: /^(금\s*액|공급가액|합\s*계\s*금\s*액|금액\(.*\))$/,
  };
  function parseItems(rows) {
    const cells = (r) => (r || []).map((c) => String(c ?? '').trim());
    let headAt = -1, cols = null;
    for (let i = 0; i < Math.min(rows.length, 40); i++) {
      const r = cells(rows[i]);
      const found = {};
      r.forEach((c, j) => { for (const [k, re] of Object.entries(HEAD)) if (found[k] === undefined && re.test(c)) found[k] = j; });
      if (found.name !== undefined && (found.qty !== undefined || found.amount !== undefined)) { headAt = i; cols = found; break; }
    }
    if (!cols) return { items: [], error: '견적서에서 품명·수량(또는 금액) 머리줄을 찾지 못했어요.' };
    const items = [];
    for (let i = headAt + 1; i < rows.length; i++) {
      const r = cells(rows[i]);
      const name = r[cols.name] || '';
      if (!name) continue;
      if (/^(합\s*계|소\s*계|총\s*계|계|부가세|부가가치세|VAT)/i.test(name.replace(/\s/g, ''))) break;
      const it = { row: i + 1, name, spec: cols.spec !== undefined ? r[cols.spec] : '', unit: cols.unit !== undefined ? r[cols.unit] : '',
        qty: cols.qty !== undefined ? toNumber(r[cols.qty]) : NaN, price: cols.price !== undefined ? toNumber(r[cols.price]) : NaN,
        amount: cols.amount !== undefined ? toNumber(r[cols.amount]) : NaN };
      if (Number.isNaN(it.amount) && !Number.isNaN(it.qty) && !Number.isNaN(it.price)) it.amount = it.qty * it.price;
      items.push(it);
    }
    return { items, error: items.length ? '' : '견적서 머리줄 아래에 품목이 없어요.' };
  }

  // 품목 검사: 단가×수량=금액, 빈 칸, 합계, 예산 잔액
  function checkItems(items, { budgetLeft } = {}) {
    const issues = [];
    let total = 0;
    (items || []).forEach((it, i) => {
      const no = `${i + 1}번 품목(${it.name || '이름 없음'})`;
      if (!it.name) issues.push({ level: 'err', text: `${i + 1}번 품목: 품명이 비어 있어요.` });
      if (!(it.qty > 0)) issues.push({ level: 'err', text: `${no}: 수량이 비었거나 0이에요.` });
      if (!(it.price >= 0) || Number.isNaN(it.price)) issues.push({ level: 'err', text: `${no}: 단가가 비어 있어요.` });
      if (it.qty > 0 && it.price >= 0 && !Number.isNaN(it.amount) && Math.round(it.qty * it.price) !== Math.round(it.amount)) {
        issues.push({ level: 'err', text: `${no}: 단가×수량 ${comma(it.qty * it.price)}원 ≠ 금액 ${comma(it.amount)}원` });
      }
      total += Number.isNaN(it.amount) ? 0 : it.amount;
    });
    if (budgetLeft !== undefined && budgetLeft !== null && budgetLeft !== '' && total > toNumber(budgetLeft)) {
      issues.push({ level: 'err', text: `예산 잔액 ${comma(toNumber(budgetLeft))}원보다 품의 합계 ${comma(total)}원이 많아요.` });
    }
    return { total, issues };
  }

  // 본문의 '붙임' 개수(붙임  1. … 2. … 또는 붙임 한 줄)
  function countAttachMarks(text) {
    const lines = String(text || '').split(/\r?\n/);
    const at = lines.findIndex((l) => /^\s*붙\s*임(\s|$)/.test(l));
    if (at < 0) return 0;
    if (!/^\s*붙\s*임\s+\d+\./.test(lines[at])) return 1;
    let n = 0;
    for (let i = at; i < lines.length; i++) { if (/(^\s*붙\s*임\s+|^\s+)\d+\.\s/.test(lines[i])) n++; else if (lines[i].trim()) break; }
    return n;
  }

  // 기안 전체 검사 → [{ level: 'err'|'warn', text }]  err가 하나라도 있으면 [기안 창에 채우기]를 끈다
  function check(draft, composed) {
    const c = composed || compose(draft);
    const issues = [];
    if (!c.title) issues.push({ level: 'err', text: '제목을 적어 주세요.' });
    if (c.title.length > 100) issues.push({ level: 'warn', text: `제목이 ${c.title.length}자예요. 짧게 줄여 주세요.` });
    if (!c.lines.length) issues.push({ level: 'err', text: '본문이 비어 있어요. 요청 문장이나 본문을 넣어 주세요.' });
    const marks = countAttachMarks(c.text);
    const files = (draft.attachments || []).length;
    if (marks !== files) issues.push({ level: 'err', text: `본문 붙임 표기 ${marks}개와 붙일 파일 ${files}개가 달라요.` });
    if (/　/.test(c.text)) issues.push({ level: 'warn', text: '본문에 아직 빈 항목(일시·장소 등)이 있어요.' });
    (draft.related || []).forEach((r, i) => { if (r && !r.docNo && !r.title) issues.push({ level: 'warn', text: `관련 문서 ${i + 1}: 문서번호나 제목이 없어요.` }); });
    if (draft.kind === 'expense') {
      if (!draft.items?.length) issues.push({ level: 'err', text: '품목이 없어요. 견적서를 끌어다 놓거나 품목을 적어 주세요.' });
      issues.push(...checkItems(draft.items, { budgetLeft: draft.budgetLeft }).issues);
    }
    if (draft.kind === 'reply' && !(draft.related || []).length) issues.push({ level: 'err', text: '회신할 공문(관련 문서)을 골라 주세요.' });
    const p = draft.props || {};
    if (draft.external && !(p.receivers || []).length) issues.push({ level: 'err', text: '대외시행 문서예요. 수신처를 정해 주세요.' });
    if (p.disclosure && p.disclosure !== '공개' && !p.disclosureReason) issues.push({ level: 'err', text: '비공개·부분공개는 근거(1~8호)를 골라 주세요.' });
    return issues;
  }

  // 결재선 검사: 맨 끝은 결재(또는 전결), 기안자 다음부터. 사람 = { name, position, role: '검토'|'협조'|'결재'|'전결'|'대결' }
  function checkLine(line) {
    const issues = [];
    const list = (line || []).filter((p) => p && p.name);
    if (!list.length) { issues.push({ level: 'err', text: '결재선이 비어 있어요.' }); return issues; }
    const last = list[list.length - 1];
    if (!['결재', '전결'].includes(last.role)) issues.push({ level: 'err', text: `결재선 마지막(${last.name})이 결재·전결이 아니에요.` });
    const finals = list.filter((p) => p.role === '결재' || p.role === '전결');
    if (finals.length > 1) issues.push({ level: 'err', text: '결재·전결은 한 사람만 둘 수 있어요.' });
    const seen = new Set();
    list.forEach((p) => { const k = `${p.name}|${p.position || ''}`; if (seen.has(k)) issues.push({ level: 'warn', text: `${p.name}이(가) 결재선에 두 번 있어요.` }); seen.add(k); });
    return issues;
  }

  // 수신 공문 본문 → 요구사항(기한·제출물·대상). 회신 본문 '가.'항 제안에 쓴다
  function extractRequirements(text) {
    const t = String(text || '').replace(/\s+/g, ' ');
    const out = { deadline: '', submits: [], targets: [] };
    const dl = /(\d{4}\.\s*\d{1,2}\.\s*\d{1,2}\.?(?:\s*\([월화수목금토일]\))?(?:\s*\d{1,2}:\d{2})?)\s*까지/.exec(t)
      || /(\d{1,2}\.\s*\d{1,2}\.?(?:\s*\([월화수목금토일]\))?)\s*까지/.exec(t);
    if (dl) out.deadline = dl[1].trim();
    // '제출(회신·보고)하여' 앞 80자 안에서 가장 가까운 '○○을/를'을 제출물로 본다(날짜의 마침표가 문장을 끊지 않게)
    const verb = /(?:제출|회신|보고)(?:하여|해|하시|바랍|하기)/g;
    let m;
    while ((m = verb.exec(t)) && out.submits.length < 5) {
      const win = t.slice(Math.max(0, m.index - 80), m.index);
      const objs = [...win.matchAll(/([가-힣A-Za-z0-9·()]+(?: [가-힣A-Za-z0-9·()]+)?)(?:을|를) /g)];
      const s = objs.length ? objs[objs.length - 1][1].replace(/^(?:붙임|각|해당|관련하여|위하여|따라|대하여|관하여)\s*/, '').trim() : '';
      if (s && !out.submits.includes(s)) out.submits.push(s);
    }
    const tg = /대\s*상\s*[:：]\s*([^.가-힣]*[가-힣][^.]{0,40})/.exec(t);
    // 줄을 이어 붙였으므로 다음 항목 기호('다.')가 끝에 붙을 수 있다 → 뗀다
    if (tg) out.targets.push(tg[1].trim().replace(/\s+[가-하]$/, ''));
    return out;
  }

  // 짧은 요청 문장 → 종류·주제 추측(규칙만). '11월 과학실 소모품 구입' → expense, '과학실 소모품'
  function guessFromRequest(s) {
    const t = String(s || '').trim();
    let kind = 'plan';
    if (/(구입|구매|품의|지출)/.test(t)) kind = 'expense';
    else if (/(결과|실적)/.test(t)) kind = 'result';
    else if (/(회신|제출|보고서\s*제출|자료\s*제출)/.test(t)) kind = 'reply';
    const subject = t.replace(/\s*(계획|결과\s*보고|결과|물품\s*구입|구입|구매|품의|회신|제출)\s*(기안|건|하기)?$/, '').trim();
    return { kind, subject: subject || t };
  }

  D.draft = { KINDS, mark, josa, formatDate, koreanAmount, formatMoney, toNumber, relatedText, parseDocNo, renderItems, renderTail, compose, parseItems, checkItems, countAttachMarks, check, checkLine, extractRequirements, guessFromRequest };
})();
