// F3 에듀파인 기안·품의 — 본문 만들기와 검사(화면과 무관한 순수 로직). 패널과 node 테스트 양쪽에서 돈다.
// 공문 표기는 「행정업무의 운영 및 혁신에 관한 규정」 시행규칙·행정업무운영편람을 따른다:
//   항목 기호 1. → 가. → 1) → 가) → (1) → (가) → ① → ㉮, 아래 단계는 두 칸씩 들여 씀
//   날짜 2026. 10. 28.  금액 금113,560원(금일십일만삼천오백육십원)
//   붙임은 '붙임' 뒤 두 칸, 여러 개면 1. 2. … 끝에 두 칸 띄우고 '끝.'
// AI는 쓰지 않는다(CLAUDE.md F3: AI 다듬기는 승인·방침 개정 뒤 별도).
(() => {
  const D = globalThis.Doumi;
  const NL = String.fromCharCode(10);
  const GA = '가나다라마바사아자차카타파하';
  const CIRCLE = '①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮';
  const CIRCLE_GA = '㉮㉯㉰㉱㉲㉳㉴㉵㉶㉷㉸㉹㉺㉻';

  // 단계(0부터)와 순번(0부터) → 항목 기호
  function mark(level, i) {
    const ga = GA[i % GA.length];
    switch (level) {
      case 0: return `${i + 1}.`;
      case 1: return `${ga}.`;
      case 2: return `${i + 1})`;
      case 3: return `${ga})`;
      case 4: return `(${i + 1})`;
      case 5: return `(${ga})`;
      case 6: return CIRCLE[i] || `(${i + 1})`;
      default: return CIRCLE_GA[i] || `(${ga})`;
    }
  }

  // 받침 있으면 앞, 없으면 뒤: josa('계획', '을', '를') → '계획을'
  function josa(word, withFinal, withoutFinal) {
    const w = String(word || '').trim();
    const last = w.replace(/[\s)」』"'.]+$/, '').slice(-1);
    const code = last.charCodeAt(0);
    let has;
    if (code >= 0xac00 && code <= 0xd7a3) has = (code - 0xac00) % 28 !== 0;
    else if (/[0-9]/.test(last)) has = '0136781'.includes(last); // 영·일·삼·육·칠·팔·십(0)
    else if (/[a-z]/i.test(last)) has = /[lmnr]/i.test(last);
    else has = false;
    return w + (has ? withFinal : withoutFinal);
  }

  // '20261028' / '2026-10-28' / Date → '2026. 10. 28.'
  function formatDate(v) {
    let ymd = v instanceof Date ? `${v.getFullYear()}${String(v.getMonth() + 1).padStart(2, '0')}${String(v.getDate()).padStart(2, '0')}` : D.normDate(v);
    if (!ymd) return String(v ?? '');
    return `${+ymd.slice(0, 4)}. ${+ymd.slice(4, 6)}. ${+ymd.slice(6)}.`;
  }

  // 113560 → '일십일만삼천오백육십' (공문 금액 한글: 단위 앞 '일'도 쓴다)
  function koreanAmount(n) {
    n = Math.floor(Math.abs(Number(n) || 0));
    if (!n) return '영';
    const DIG = '영일이삼사오육칠팔구';
    const SMALL = ['', '십', '백', '천'];
    const BIG = ['', '만', '억', '조', '경'];
    let out = '';
    for (let g = 0; n > 0; g++, n = Math.floor(n / 10000)) {
      const part = n % 10000;
      if (!part) continue;
      let s = '';
      String(part).padStart(4, '0').split('').forEach((c, i) => { if (c !== '0') s += DIG[+c] + SMALL[3 - i]; });
      out = s + BIG[g] + out;
    }
    return out;
  }
  const comma = (n) => Math.round(Number(n) || 0).toLocaleString('en-US');
  const formatMoney = (n) => `금${comma(n)}원(금${koreanAmount(n)}원)`;
  const toNumber = (v) => {
    if (typeof v === 'number') return v;
    const s = String(v ?? '').replace(/[,\s원₩]/g, '');
    return /^-?\d+(\.\d+)?$/.test(s) ? Number(s) : NaN;
  };

  // 관련 문서 한 건 → '충청남도교육청 교육과정과-12345(2026. 10. 1.) 「제목」'
  function relatedText(r) {
    const head = [r.org, r.dept].filter(Boolean).join(' ');
    const no = r.docNo ? (head ? `${head}-${r.docNo}` : r.docNo) : head;
    const date = r.date ? `(${formatDate(r.date)})` : '';
    const title = r.title ? ` 「${String(r.title).trim()}」` : '';
    return `${no}${date}${title}`.trim();
  }
  // 에듀파인 문서번호 모양 '교육과정과-12345' / '○○고등학교-1234' 를 기관·번호로
  function parseDocNo(s) {
    const m = /^\s*(.+?)-(\d{1,7})\s*$/.exec(String(s || ''));
    return m ? { dept: m[1].trim(), docNo: m[2] } : null;
  }

  // 본문 나무 → 글 줄. node = { text, children: [] } (첫 단계는 1. 2. …)
  function renderItems(nodes, level = 0, start = 0) {
    const lines = [];
    nodes.forEach((n, i) => {
      if (!n) return;
      const text = typeof n === 'string' ? n : n.text;
      const pad = '  '.repeat(level);
      lines.push(`${pad}${mark(level, i + (level === 0 ? start : 0))} ${String(text ?? '').trim()}`);
      if (n.children?.length) lines.push(...renderItems(n.children, level + 1));
    });
    return lines;
  }

  // 붙임 줄 + '끝.' (붙임 없으면 마지막 본문 줄 뒤에 '  끝.')
  function renderTail(lines, attachments) {
    const out = lines.slice();
    const att = (attachments || []).map((a) => (typeof a === 'string' ? { name: a } : a)).filter((a) => a.name);
    const one = (a) => `${String(a.name).replace(/\.[a-z0-9]{2,5}$/i, '').trim()} ${a.copies || 1}부.`;
    if (!att.length) {
      if (out.length) out[out.length - 1] = `${out[out.length - 1].replace(/\s+$/, '')}  끝.`;
      return out;
    }
    out.push('');
    if (att.length === 1) out.push(`붙임  ${one(att[0])}  끝.`);
    else att.forEach((a, i) => out.push(`${i === 0 ? '붙임  ' : '      '}${i + 1}. ${one(a)}${i === att.length - 1 ? '  끝.' : ''}`));
    return out;
  }

  // 직접 쓴 본문의 끝을 붙임 목록에 맞춘다: 있던 붙임 줄과 '끝.'을 떼고 다시 붙인다(파일을 넣거나 뺄 때)
  function withAttachTail(body, attachments) {
    const lines = String(body || '').split('\n');
    const at = lines.findIndex((l) => /^\s*붙임\s/.test(l));
    const head = (at >= 0 ? lines.slice(0, at) : lines).join('\n').replace(/\s*끝\.\s*$/, '').replace(/\s+$/, '');
    return renderTail(head ? head.split('\n') : [], attachments).join('\n');
  }

  // 기안 종류별 틀. 입력: { subject, when, where, who, what, result, budget, items, budgetCode, method, deadline, submit }
  const KINDS = {
    free: {
      label: '직접 쓰기',
      title: (d) => d.subject,
      body: () => [],
    },
    plan: {
      label: '계획(내부결재)',
      title: (d) => `${d.year || new Date().getFullYear()}학년도 ${d.subject} 계획`,
      body: (d) => [
        { text: `${josa(d.subject, '을', '를')} 다음과 같이 실시하고자 합니다.`, children: [
          `일시: ${d.when || '　'}`, `장소: ${d.where || '　'}`, `대상: ${d.who || '　'}`, `내용: ${d.what || '　'}`,
          ...(d.budget ? [`소요 예산: ${formatMoney(d.budget)}`] : []),
        ] },
      ],
    },
    result: {
      label: '결과 보고(내부결재)',
      title: (d) => `${d.year || new Date().getFullYear()}학년도 ${d.subject} 결과 보고`,
      body: (d) => [
        { text: `${josa(d.subject, '을', '를')} 다음과 같이 실시하였기에 그 결과를 보고합니다.`, children: [
          `일시: ${d.when || '　'}`, `장소: ${d.where || '　'}`, `대상: ${d.who || '　'}`, `내용: ${d.what || '　'}`,
          ...(d.result ? [`결과: ${d.result}`] : []),
          ...(d.budget ? [`집행 금액: ${formatMoney(d.budget)}`] : []),
        ] },
      ],
    },
    expense: {
      label: '지출품의',
      title: (d) => `${d.subject} 물품 구입`,
      body: (d) => {
        const items = d.items || [];
        const total = items.reduce((s, it) => s + (toNumber(it.amount) || 0), 0);
        const name = items.length ? `${items[0].name}${items.length > 1 ? ` 외 ${items.length - 1}종` : ''}` : (d.subject || '');
        return [
          { text: `${d.subject} 운영에 필요한 물품을 다음과 같이 구입하고자 합니다.`, children: [
            `품명: ${name}`,
            `소요 예산: ${formatMoney(total || d.budget || 0)}`,
            `예산 과목: ${d.budgetCode || '　'}`,
            `구입 방법: ${d.method || '　'}`,
          ] },
        ];
      },
    },
    reply: {
      label: '대외 회신(보고)',
      title: (d) => `${d.subject} 제출`,
      body: (d) => [
        { text: `위 호와 관련하여 ${d.subject} 자료를 붙임과 같이 제출합니다.`, children: [
          ...(d.deadline ? [`제출 기한: ${formatDate(d.deadline) || d.deadline}`] : []),
          ...(d.submit ? [`제출 자료: ${d.submit}`] : []),
        ].filter(Boolean) },
      ],
    },
  };

  // 기안 초안 → { title, lines, text }
  function compose(draft) {
    const kind = KINDS[draft.kind] || KINDS.plan;
    const d = { ...draft, subject: String(draft.subject || '').trim() };
    const title = String(draft.title || '').trim() || (d.subject ? kind.title(d) : '');
    const related = (draft.related || []).filter((r) => r && (r.docNo || r.dept || r.title));
    const top = [];
    if (related.length === 1) top.push(`관련: ${relatedText(related[0])}`);
    else if (related.length > 1) top.push({ text: '관련:', children: related.map(relatedText) });
    const body = draft.bodyItems?.length ? draft.bodyItems : (d.subject ? kind.body(d) : []);
    const lines = renderTail(renderItems([...top, ...body]), draft.attachments);
    return { title, lines, text: lines.join(NL) };
  }

  // 견적서 표(2차원 배열) → 품목. 머리줄을 찾아 품명·규격·단위·수량·단가·금액 칸을 고른다
  const HEAD = {
    name: /^(품\s*명|품\s*목|물\s*품\s*명|상\s*품\s*명|내\s*역|항\s*목)$/,
    spec: /^(규\s*격|사\s*양|모\s*델)/,
    unit: /^단\s*위$/,
    qty: /^(수\s*량|수량\(.*\))$/,
    price: /^(단\s*가|단가\(.*\))$/,
    amount: /^(금\s*액|공급가액|합\s*계\s*금\s*액|금액\(.*\))$/,
  };
  function parseItems(rows) {
    const cells = (r) => (r || []).map((c) => String(c ?? '').trim());
    let headAt = -1, cols = null;
    for (let i = 0; i < Math.min(rows.length, 40); i++) {
      const r = cells(rows[i]);
      const found = {};
      r.forEach((c, j) => { for (const [k, re] of Object.entries(HEAD)) if (found[k] === undefined && re.test(c)) found[k] = j; });
      if (found.name !== undefined && (found.qty !== undefined || found.amount !== undefined)) { headAt = i; cols = found; break; }
    }
    if (!cols) return { items: [], error: '견적서에서 품명·수량(또는 금액) 머리줄을 찾지 못했어요.' };
    const items = [];
    for (let i = headAt + 1; i < rows.length; i++) {
      const r = cells(rows[i]);
      const name = r[cols.name] || '';
      if (!name) continue;
      if (/^(합\s*계|소\s*계|총\s*계|계|부가세|부가가치세|VAT)/i.test(name.replace(/\s/g, ''))) break;
      const it = { row: i + 1, name, spec: cols.spec !== undefined ? r[cols.spec] : '', unit: cols.unit !== undefined ? r[cols.unit] : '',
        qty: cols.qty !== undefined ? toNumber(r[cols.qty]) : NaN, price: cols.price !== undefined ? toNumber(r[cols.price]) : NaN,
        amount: cols.amount !== undefined ? toNumber(r[cols.amount]) : NaN };
      if (Number.isNaN(it.amount) && !Number.isNaN(it.qty) && !Number.isNaN(it.price)) it.amount = it.qty * it.price;
      items.push(it);
    }
    return { items, error: items.length ? '' : '견적서 머리줄 아래에 품목이 없어요.' };
  }

  // 품목 검사: 단가×수량=금액, 빈 칸, 합계, 예산 잔액
  function checkItems(items, { budgetLeft } = {}) {
    const issues = [];
    let total = 0;
    (items || []).forEach((it, i) => {
      const no = `${i + 1}번 품목(${it.name || '이름 없음'})`;
      if (!it.name) issues.push({ level: 'err', text: `${i + 1}번 품목: 품명이 비어 있어요.` });
      if (!(it.qty > 0)) issues.push({ level: 'err', text: `${no}: 수량이 비었거나 0이에요.` });
      if (!(it.price >= 0) || Number.isNaN(it.price)) issues.push({ level: 'err', text: `${no}: 단가가 비어 있어요.` });
      if (it.qty > 0 && it.price >= 0 && !Number.isNaN(it.amount) && Math.round(it.qty * it.price) !== Math.round(it.amount)) {
        issues.push({ level: 'err', text: `${no}: 단가×수량 ${comma(it.qty * it.price)}원 ≠ 금액 ${comma(it.amount)}원` });
      }
      total += Number.isNaN(it.amount) ? 0 : it.amount;
    });
    if (budgetLeft !== undefined && budgetLeft !== null && budgetLeft !== '' && total > toNumber(budgetLeft)) {
      issues.push({ level: 'err', text: `예산 잔액 ${comma(toNumber(budgetLeft))}원보다 품의 합계 ${comma(total)}원이 많아요.` });
    }
    return { total, issues };
  }

  // 본문의 '붙임' 개수(붙임  1. … 2. … 또는 붙임 한 줄)
  function countAttachMarks(text) {
    const lines = String(text || '').split(/\r?\n/);
    const at = lines.findIndex((l) => /^\s*붙\s*임(\s|$)/.test(l));
    if (at < 0) return 0;
    if (!/^\s*붙\s*임\s+\d+\./.test(lines[at])) return 1;
    let n = 0;
    for (let i = at; i < lines.length; i++) { if (/(^\s*붙\s*임\s+|^\s+)\d+\.\s/.test(lines[i])) n++; else if (lines[i].trim()) break; }
    return n;
  }

  // 기안 전체 검사 → [{ level: 'err'|'warn', text }]  err가 하나라도 있으면 [기안 창에 채우기]를 끈다
  function check(draft, composed) {
    const c = composed || compose(draft);
    const issues = [];
    if (!c.title) issues.push({ level: 'err', text: '제목을 적어 주세요.' });
    if (c.title.length > 100) issues.push({ level: 'warn', text: `제목이 ${c.title.length}자예요. 짧게 줄여 주세요.` });
    if (!c.lines.length) issues.push({ level: 'err', text: '본문이 비어 있어요. 요청 문장이나 본문을 넣어 주세요.' });
    const marks = countAttachMarks(c.text);
    const files = (draft.attachments || []).length;
    if (marks !== files) issues.push({ level: 'err', text: `본문 붙임 표기 ${marks}개와 붙일 파일 ${files}개가 달라요.` });
    if (/　/.test(c.text)) issues.push({ level: 'warn', text: '본문에 아직 빈 항목(일시·장소 등)이 있어요.' });
    (draft.related || []).forEach((r, i) => { if (r && !r.docNo && !r.title) issues.push({ level: 'warn', text: `관련 문서 ${i + 1}: 문서번호나 제목이 없어요.` }); });
    if (draft.kind === 'expense') {
      if (!draft.items?.length) issues.push({ level: 'err', text: '품목이 없어요. 견적서를 끌어다 놓거나 품목을 적어 주세요.' });
      issues.push(...checkItems(draft.items, { budgetLeft: draft.budgetLeft }).issues);
    }
    if (draft.kind === 'reply' && !(draft.related || []).length) issues.push({ level: 'err', text: '회신할 공문(관련 문서)을 골라 주세요.' });
    const p = draft.props || {};
    if (draft.external && !(p.receivers || []).length) issues.push({ level: 'err', text: '대외시행 문서예요. 수신처를 정해 주세요.' });
    if (p.disclosure && p.disclosure !== '공개' && !p.disclosureReason) issues.push({ level: 'err', text: '비공개·부분공개는 근거(1~8호)를 골라 주세요.' });
    return issues;
  }

  // 결재선 검사: 맨 끝은 결재(또는 전결), 기안자 다음부터. 사람 = { name, position, role: '검토'|'협조'|'결재'|'전결'|'대결' }
  function checkLine(line) {
    const issues = [];
    const list = (line || []).filter((p) => p && p.name);
    // 사람을 아직 안 고른 줄(창에서 이름 없이 읽힌 최종 등, 2026-11-24)
    const blank = (line || []).filter((p) => p && !p.name).length;
    if (blank) issues.push({ level: 'err', text: `결재선에 사람을 고르지 않은 줄이 ${blank}개 있어요. 줄의 [사람 고르기]에서 골라 주세요.` });
    if (!list.length) { issues.push({ level: 'err', text: '결재선이 비어 있어요.' }); return issues; }
    const last = list[list.length - 1];
    if (!['결재', '전결'].includes(last.role)) issues.push({ level: 'err', text: '결재선 맨 위(최종)가 결재·전결이 아니에요.' }); // 이름은 넣지 않는다(교사 요청 2026-11-12)
    const finals = list.filter((p) => p.role === '결재' || p.role === '전결');
    if (finals.length > 1) issues.push({ level: 'err', text: '결재·전결은 한 사람만 둘 수 있어요.' });
    const seen = new Set();
    list.forEach((p) => { const k = `${p.name}|${p.position || ''}`; if (seen.has(k)) issues.push({ level: 'warn', text: `${p.name}이(가) 결재선에 두 번 있어요.` }); seen.add(k); });
    return issues;
  }

  // 수신 공문 본문 → 요구사항(기한·제출물·대상). 회신 본문 '가.'항 제안에 쓴다
  function extractRequirements(text) {
    const t = String(text || '').replace(/\s+/g, ' ');
    const out = { deadline: '', submits: [], targets: [] };
    const dl = /(\d{4}\.\s*\d{1,2}\.\s*\d{1,2}\.?(?:\s*\([월화수목금토일]\))?(?:\s*\d{1,2}:\d{2})?)\s*까지/.exec(t)
      || /(\d{1,2}\.\s*\d{1,2}\.?(?:\s*\([월화수목금토일]\))?)\s*까지/.exec(t);
    if (dl) out.deadline = dl[1].trim();
    // '제출(회신·보고)하여' 앞 80자 안에서 가장 가까운 '○○을/를'을 제출물로 본다(날짜의 마침표가 문장을 끊지 않게)
    const verb = /(?:제출|회신|보고)(?:하여|해|하시|바랍|하기)/g;
    let m;
    while ((m = verb.exec(t)) && out.submits.length < 5) {
      const win = t.slice(Math.max(0, m.index - 80), m.index);
      const objs = [...win.matchAll(/([가-힣A-Za-z0-9·()]+(?: [가-힣A-Za-z0-9·()]+)?)(?:을|를) /g)];
      const s = objs.length ? objs[objs.length - 1][1].replace(/^(?:붙임|각|해당|관련하여|위하여|따라|대하여|관하여)\s*/, '').trim() : '';
      if (s && !out.submits.includes(s)) out.submits.push(s);
    }
    const tg = /대\s*상\s*[:：]\s*([^.가-힣]*[가-힣][^.]{0,40})/.exec(t);
    // 줄을 이어 붙였으므로 다음 항목 기호('다.')가 끝에 붙을 수 있다 → 뗀다
    if (tg) out.targets.push(tg[1].trim().replace(/\s+[가-하]$/, ''));
    return out;
  }

  // 짧은 요청 문장 → 종류·주제 추측(규칙만). '11월 과학실 소모품 구입' → expense, '과학실 소모품'
  function guessFromRequest(s) {
    const t = String(s || '').trim();
    let kind = 'plan';
    if (/(구입|구매|품의|지출)/.test(t)) kind = 'expense';
    else if (/(결과|실적)/.test(t)) kind = 'result';
    else if (/(회신|제출|보고서\s*제출|자료\s*제출)/.test(t)) kind = 'reply';
    const subject = t.replace(/\s*(계획|결과\s*보고|결과|물품\s*구입|구입|구매|품의|회신|제출)\s*(기안|건|하기)?$/, '').trim();
    return { kind, subject: subject || t };
  }

  // ── 기안 창 채우기(PC 도우미) ──
  // 패널 결재선 역할 ↔ 결재경로 창의 줄 종류(실제 창 2026-11-03). 마지막 줄의 '결재'는 창 안에서 user_nosign이고 저장되면 user_approval이 된다
  const ROLE_AT = { 검토: 'user_approval', 결재: 'user_nosign', 전결: 'user_jeonkyul', 대결: 'user_daekyul', 협조: 'user_agree_s' };
  const AT_ROLE = { user_jeonkyul: '전결', user_daekyul: '대결', user_agree_s: '협조', user_agree_p: '협조', user_nosign: '결재' };
  const listOf = (s) => [...new Set(String(s || '').split(/[,，\n]/).map((x) => x.trim()).filter(Boolean))];

  // 패널에 적은 것 → PC 도우미에 줄 값
  function fillPlan({ line = [], rcverOrgs = '', cnrsText = '', tkcrd = '', files = [] } = {}) {
    return {
      line: line.filter((p) => p.name).map((p) => ({ name: p.name, position: p.position || '', at: ROLE_AT[p.role] || '' })),
      rcver: listOf(rcverOrgs),
      cnrs: listOf(cnrsText),
      tkcrd: String(tkcrd || '').trim(),
      files: files.filter((f) => f.path).map((f) => ({ path: f.path })),
    };
  }

  // 기안 창 결재선(첫 줄은 기안자) → 패널 결재선. 이름이 비어 있어도 직위가 있으면 줄은 남긴다(패널에서 사람을 고름 — 교사 제보 2026-11-24 '최종은 이름 표시가 안 돼')
  function lineFromWindow(rows = []) {
    const rest = rows.slice(1);
    return rest.map((r, i) => ({ role: AT_ROLE[r.at] || (i === rest.length - 1 ? '결재' : '검토'), position: String(r.position || '').trim(), name: String(r.name || '').trim() })).filter((p) => p.name || p.position);
  }

  // 불러온 본문을 조금 고쳤을 때(교사 제보 2026-11-24 '10월을 11월로 고쳤을 뿐인데 기안이 이상하게 옮겨짐'):
  // 고친 곳만 원래 모양(HWPML) 안에서 바꿀 수 있게 '바꿀 글' 목록을 만든다. 줄 수가 같고 줄마다 고친 곳이 있을 때만.
  // 고친 곳은 빈칸 사이 낱말까지 넓힌다(10월 → 11월). nth = 원래 글에서 그 글이 몇 번째로 나오는지(한 글자씩 밀며 셈), total = 모두 몇 번
  // → PC 도우미가 모양 글에서도 같은 수만큼 나올 때만 그 자리를 바꾼다(아니면 글자만 넣기로)
  function richEdits(oldText, newText) {
    const norm = (t) => String(t ?? '').replace(/\r\n?/g, NL);
    const a = norm(oldText), b = norm(newText);
    if (a === b) return { ok: true, edits: [] };
    const al = a.split(NL), bl = b.split(NL);
    if (al.length !== bl.length) return { ok: false, why: 'lines' };
    const sp = (c) => /\s/.test(c);
    const count = (s, f) => { const at = []; for (let i = s.indexOf(f); i >= 0; i = s.indexOf(f, i + 1)) at.push(i); return at; };
    const edits = [];
    let base = 0;
    for (let i = 0; i < al.length; i++) {
      const o = al[i], n = bl[i];
      if (o !== n) {
        let p = 0;
        while (p < o.length && p < n.length && o[p] === n[p]) p++;
        let q = 0;
        while (q < o.length - p && q < n.length - p && o[o.length - 1 - q] === n[n.length - 1 - q]) q++;
        while (p > 0 && !sp(o[p - 1])) p--;
        let oe = o.length - q;
        while (oe < o.length && !sp(o[oe])) oe++;
        const ne = n.length - (o.length - oe);
        const from = o.slice(p, oe), to = n.slice(p, ne);
        if (!from.trim() || from.trim() !== from) return { ok: false, why: 'blank' };
        const at = count(a, from);
        const nth = at.indexOf(base + p);
        if (nth < 0) return { ok: false, why: 'find' };
        edits.push({ from, to, nth, total: at.length });
      }
      base += o.length + 1;
    }
    // 조금 고친 것만: 바꿀 글이 원래 글의 3할(짧으면 20자)을 넘으면 새로 쓴 글로 보고 글자만 넣는다(공문 작성법 고침도 그때)
    const changed = edits.reduce((n, e) => n + e.from.length, 0);
    if (changed > Math.max(20, a.length * 0.3)) return { ok: false, why: 'big' };
    return { ok: true, edits };
  }

  const BLOCK_WHY = { ext: '이 학교 에듀파인이 허용하지 않는 형식', 'no-ext': '확장자가 없음', 'long-name': '파일 이름이 70자를 넘음', empty: '빈 파일' };
  // 채운 결과 → 패널 문장. results: { line, rcver, picks, files, body, discLabel, explain }
  function fillReport({ line, rcver, picks, files, body, discLabel = '', explain = (r) => r?.error || '' }) {
    const done = [];
    const todo = [];
    const failed = (what, r) => { todo.push(`${what}: ${explain(r)}`); };
    const names = (a) => (a || []).map((n) => `'${n}'`).join(', ');
    if (line) {
      if (line.kept) todo.push('결재선은 이미 있어 그대로 뒀어요.');
      else if (line.ok && line.added?.length) done.push(`결재선 ${line.added.length}명`);
      if (!line.ok) failed('결재선', line);
      if (line.missing?.length) todo.push(`결재선의 ${names(line.missing)}을(를) 조직도에서 찾지 못했어요.`);
      if (line.twin?.length) todo.push(`결재선의 ${names(line.twin)}은(는) 같은 이름이 있어 직접 골라 주세요.`);
      if (line.absent?.length) todo.push(`결재선의 ${names(line.absent)}은(는) 부재 중이라 넣지 않았어요. 대결자를 직접 정해 주세요.`);
      if (line.kindMiss?.length) todo.push(`${names(line.kindMiss)}의 역할을 정하지 못했어요. 결재경로 창에서 골라 주세요.`);
    }
    if (rcver) {
      if (rcver.kept) todo.push('수신자는 이미 있어 그대로 뒀어요.');
      else if (rcver.added?.length) done.push(`수신 ${rcver.added.length}곳`);
      if (!rcver.ok) failed('수신자', rcver);
      if (rcver.missing?.length) todo.push(`수신 기관 ${names(rcver.missing)}을(를) 찾지 못했어요. 조직도 이름 그대로 적어 주세요.`);
      if (rcver.twin?.length) todo.push(`수신 기관 ${names(rcver.twin)}은(는) 같은 이름이 여럿이라 직접 골라 주세요.`);
    }
    if (picks) {
      if (picks.tkcrd?.ok) done.push('과제카드');
      else if (picks.tkcrd?.missing) todo.push('과제카드를 내 목록에서 찾지 못했어요. 직접 골라 주세요.');
      else if (picks.tkcrd) failed('과제카드', picks.tkcrd);
      if (picks.cnrs?.added?.length) done.push(`공람 ${picks.cnrs.added.length}명`);
      if (picks.cnrs && !picks.cnrs.ok) failed('공람', picks.cnrs);
      if (picks.cnrs?.missing?.length) todo.push(`공람의 ${names(picks.cnrs.missing)}을(를) 조직도에서 찾지 못했어요.`);
      if (picks.cnrs?.twin?.length) todo.push(`공람의 ${names(picks.cnrs.twin)}은(는) 같은 이름이 있어 직접 골라 주세요.`);
      if (picks.inLine?.length) todo.push(`${names(picks.inLine)}은(는) 결재선에 있어 공람에서 뺐어요.`);
      if (picks.ok === false && !picks.tkcrd && !picks.cnrs) failed('공람·과제카드', picks);
    }
    if (files) {
      if (files.added?.length) done.push(`파일 ${files.added.length}개`);
      if (!files.ok) failed('파일', files);
      for (const b of files.blocked || []) todo.push(`파일 '${b.name}'은(는) 넣지 못했어요(${BLOCK_WHY[b.why] || b.why}).`);
    }
    for (const r of [line, rcver, picks]) for (const n of r?.notes || []) todo.push(`에듀파인 안내: ${n}`);
    if (body?.ok) done.push(`제목·본문${discLabel ? `·${discLabel}` : ''}·붙임 비공개`);
    else if (body) failed('제목·본문', body);
    const bad = todo.some((t) => !/그대로 뒀어요|공람에서 뺐어요/.test(t));
    return {
      bad,
      text: [
        done.length ? `기안 창에 넣었어요: ${done.join(' · ')}.` : '기안 창에 넣은 것이 없어요.',
        ...todo,
        '창에서 확인한 뒤 저장·[결재올림]은 선생님이 직접 눌러 주세요.',
      ].join(' '),
    };
  }

  D.draft = { countAttachMarks, withAttachTail, ROLE_AT, fillPlan, lineFromWindow, richEdits, fillReport, KINDS, mark, josa, formatDate, koreanAmount, formatMoney, toNumber, relatedText, parseDocNo, renderItems, renderTail, compose, parseItems, checkItems, countAttachMarks, check, checkLine, extractRequirements, guessFromRequest };
})();
