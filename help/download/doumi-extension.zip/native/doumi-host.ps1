# Doumi PC helper (native messaging host) - talks only to the Doumi browser extension over stdin/stdout.
# It reads and fills the K-Edufine document window (WXSClient.exe, IE engine + Hancom HwpCtrl) on THIS PC.
# - No network access. Nothing is written to disk. Values are never logged.
# - Allowed operations only: ping, windows, readDoc, fillDraft. There is no "run any script" operation.
# - It never calls approve/submit/save/sign functions (fncSanctn, fncSaveTmpr, fncSaveCnsltTmp, fncSaveUpdateTmp, kcase).
# Protocol: Chrome native messaging (4-byte little-endian length + UTF-8 JSON), one request -> one response, loop until stdin closes.
# Keep this file ASCII-only (Windows PowerShell 5.1 reads BOM-less files as ANSI). Korean field names are \u escapes in the JS below.
$ErrorActionPreference = 'Stop'
$VERSION = 1

$null = Add-Type -TypeDefinition @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public class DoumiWxs {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint m, IntPtr w, IntPtr l, uint f, uint t, out IntPtr r);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h, uint flags);
  [DllImport("oleacc.dll")] public static extern int ObjectFromLresult(IntPtr r, ref Guid iid, IntPtr w, [MarshalAs(UnmanagedType.IDispatch)] out object o);
  public static List<IntPtr> IeServers(uint[] pids) {
    var list = new List<IntPtr>();
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (Array.IndexOf(pids, pid) < 0) return true;
      EnumChildWindows(h, (c, l2) => { var s = new StringBuilder(64); GetClassName(c, s, 64); if (s.ToString() == "Internet Explorer_Server") list.Add(c); return true; }, IntPtr.Zero);
      return true; }, IntPtr.Zero);
    return list;
  }
  public static uint Pid(IntPtr h) { uint pid; GetWindowThreadProcessId(h, out pid); return pid; }
  public static object Doc(IntPtr ie) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT"); IntPtr r;
    SendMessageTimeout(ie, msg, IntPtr.Zero, IntPtr.Zero, 2, 5000, out r);
    Guid iid = new Guid("626FC520-A41E-11CF-A731-00A0C9082637"); object o;
    return ObjectFromLresult(r, ref iid, IntPtr.Zero, out o) == 0 ? o : null;
  }
  public static void Front(IntPtr ie) { SetForegroundWindow(GetAncestor(ie, 2)); }
}
"@

function Get-Kind([string]$path) {
  if ($path -like '*/cz/cb/wrt/retrieveDoccrdWritng.do*') { return 'draft' }
  if ($path -like '*/cz/cb/prc/*') { return 'approve' }
  if ($path -like '*/cz/cb/viw/retrieveDoccrd*') { return 'view' }
  return 'other'
}

# All document windows of WXSClient: @{ ie; doc; pid; kind; path }
function Get-DocWindows {
  $pids = [uint32[]](Get-Process WXSClient -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
  $out = @()
  if (-not $pids) { return $out }
  foreach ($ie in [DoumiWxs]::IeServers($pids)) {
    $doc = $null
    try { $doc = [DoumiWxs]::Doc($ie) } catch { }
    if (-not $doc) { continue }
    $path = ''
    try { $path = (("$($doc.url)") -split '\?')[0] -replace '^https?://[^/]+', '' } catch { }
    if ($path -notlike '/bms/*') { continue }
    $out += @{ ie = $ie; doc = $doc; pid = [DoumiWxs]::Pid($ie); kind = (Get-Kind $path); path = $path }
  }
  return $out
}

# Run a fixed ES5 script inside the page; the script stores its JSON result on <html data-doumi-r>.
function Invoke-InPage($doc, [string]$js) {
  $doc.parentWindow.execScript($js, 'JavaScript') | Out-Null
  $res = $doc.documentElement.getAttribute('data-doumi-r')
  $doc.documentElement.removeAttribute('data-doumi-r')
  if (-not $res) { throw 'no result from page' }
  return ($res | ConvertFrom-Json)
}

# Shared ES5 helpers: find the body editor (object#editor1 in the doccrdEditor.do frame)
$JS_EDITOR = @'
function doumiEditor() {
  for (var i = 0; i < document.frames.length; i++) {
    try { var d = document.frames[i].document; var e = d.getElementById('editor1'); if (e) return e; } catch (x) {}
  }
  return null;
}
function doumiFields(ed) { try { return String(ed.GetFieldList(0, 0)).split(String.fromCharCode(2)); } catch (x) { return []; } }
function doumiHas(list, k) { for (var i = 0; i < list.length; i++) if (list[i] === k) return true; return false; }
// visible label text of a radio/checkbox (label[for], next text, or parent text) - static UI words only
function doumiLabel(e) {
  try {
    var ls = document.getElementsByTagName('label');
    for (var i = 0; i < ls.length; i++) if (e.id && ls[i].htmlFor === e.id) return String(ls[i].innerText || '');
    var n = e.nextSibling;
    while (n && n.nodeType === 3 && !/\S/.test(n.nodeValue)) n = n.nextSibling;
    if (n) return String(n.nodeType === 3 ? n.nodeValue : (n.innerText || ''));
    return String(e.parentNode.innerText || '');
  } catch (x) { return ''; }
}
function doumiTrim(s) { return String(s || '').replace(/\s+/g, ''); }
// click like the teacher would so the page's own onclick (setPublication etc.) keeps linked fields in sync
function doumiClick(e) { try { e.click(); return true; } catch (x) { return false; } }
// the page may run in an old IE document mode without JSON
function doumiJson(v) {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (typeof v === 'string') return '"' + v.replace(/[\\"\u0000-\u001f]/g, function (c) { return '\\u' + ('000' + c.charCodeAt(0).toString(16)).slice(-4); }) + '"';
  var out = [], k;
  if (Object.prototype.toString.call(v) === '[object Array]') { for (k = 0; k < v.length; k++) out.push(doumiJson(v[k])); return '[' + out.join(',') + ']'; }
  for (k in v) if (v.hasOwnProperty(k)) out.push(doumiJson(k) + ':' + doumiJson(v[k]));
  return '{' + out.join(',') + '}';
}
'@

# Title / body fields (Korean names as escapes): approval-title, body, receiver, via, enforce-date, doc-number
$JS_READ = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false, fields: {}, missing: [] };
  try {
    var names = ['\uACB0\uC7AC\uC81C\uBAA9', '\uBCF8\uBB38', '\uC218\uC2E0', '\uACBD\uC720', '\uC2DC\uD589\uC77C\uC790', '\uBB38\uC11C\uBC88\uD638'];
    var sj = document.getElementById('Sj');
    var put = function (k, v) { v = String(v == null ? '' : v); r.fields[k] = p.lengthsOnly ? v.length : v; };
    if (sj) put('Sj', sj.value); else r.missing.push('Sj');
    var ed = doumiEditor();
    if (!ed) r.missing.push('editor1');
    else {
      var list = doumiFields(ed);
      for (var i = 0; i < names.length; i++) {
        if (!doumiHas(list, names[i])) { r.missing.push(names[i]); continue; }
        put(names[i], ed.GetFieldText(names[i]));
      }
    }
    r.ok = !!ed;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# Only #Sj (title input) and the two body fields approval-title / body may be written. Nothing else is touched or clicked.
$JS_FILL = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false, done: [], missing: [] };
  try {
    if (String(location.href).indexOf('/cz/cb/wrt/retrieveDoccrdWritng.do') < 0) throw new Error('not a draft window');
    var allow = { '\uACB0\uC7AC\uC81C\uBAA9': 1, '\uBCF8\uBB38': 1 };
    if (p.title != null) {
      var sj = document.getElementById('Sj');
      if (sj) { sj.value = p.title; try { sj.fireEvent('onchange'); } catch (x) {} r.done.push('Sj'); } else r.missing.push('Sj');
    }
    var ed = doumiEditor();
    if (!ed) r.missing.push('editor1');
    else {
      var list = doumiFields(ed);
      for (var k in p.fields) {
        if (!p.fields.hasOwnProperty(k) || !allow[k]) continue;
        if (!doumiHas(list, k)) { r.missing.push(k); continue; }
        ed.PutFieldText(k, String(p.fields[k]));
        r.done.push(k + ':' + String(ed.GetFieldText(k)).length);
      }
    }
    // disclosure: { mode: 'partial'|'private'|'public', reasons: [6] } - radio name othbcLmtt, reason checkboxes othbcAt1..8
    if (p.disclosure) {
      var want = { 'partial': '\uBD80\uBD84\uACF5\uAC1C', 'private': '\uBE44\uACF5\uAC1C', 'public': '\uACF5\uAC1C' }[p.disclosure.mode];
      var radios = document.getElementsByName('othbcLmtt'), hit = null;
      for (var i = 0; i < radios.length; i++) { if (doumiTrim(doumiLabel(radios[i])) === want) hit = radios[i]; }
      if (!hit) r.missing.push('othbcLmtt:' + p.disclosure.mode);
      else { if (!hit.checked) doumiClick(hit); r.done.push('othbcLmtt:' + p.disclosure.mode); }
      if (p.disclosure.mode !== 'public') {
        var rs = {}; for (var j = 0; j < (p.disclosure.reasons || []).length; j++) rs[p.disclosure.reasons[j]] = 1;
        for (var n = 1; n <= 8; n++) {
          var cb = document.getElementById('othbcAt' + n);
          if (!cb) { if (rs[n]) r.missing.push('othbcAt' + n); continue; }
          if (!!rs[n] !== !!cb.checked) doumiClick(cb);
          if (rs[n]) r.done.push('othbcAt' + n);
        }
      }
    }
    // attachments private: per-file radios (name like modiAttachOthbcSe*/attachOthbcSe*) -> the one labelled '\uBE44\uACF5\uAC1C'
    if (p.attachPrivate) {
      var all = document.getElementsByTagName('input'), groups = {}, cnt = 0;
      for (var a = 0; a < all.length; a++) {
        var e2 = all[a];
        if (e2.type !== 'radio' || !/attachothbcse/i.test(e2.name || '')) continue;
        if (doumiTrim(doumiLabel(e2)) === '\uBE44\uACF5\uAC1C') groups[e2.name] = e2;
      }
      for (var g in groups) if (groups.hasOwnProperty(g)) { if (!groups[g].checked) doumiClick(groups[g]); cnt++; }
      r.done.push('attachPrivate:' + cnt);
    }
    r.ok = r.missing.length === 0;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

function With-Payload([string]$js, $payload) {
  $json = ConvertTo-Json -InputObject $payload -Compress -Depth 5
  return $js.Replace('PAYLOAD', $json)
}

function Pick-One($wins, [string[]]$kinds, $pidWanted, [string]$label) {
  $c = @($wins | Where-Object { $kinds -contains $_.kind -and (-not $pidWanted -or $_.pid -eq [uint32]$pidWanted) })
  if ($c.Count -eq 0) { throw "no-window:$label" }
  if ($c.Count -gt 1) { throw "many-windows:$label" }
  return $c[0]
}

function Handle($req) {
  $args0 = $req.args
  switch ($req.op) {
    'ping' { return @{ ok = $true; version = $VERSION; bits = [IntPtr]::Size * 8 } }
    'windows' {
      $list = @(Get-DocWindows | ForEach-Object { @{ pid = $_.pid; kind = $_.kind; path = $_.path } })
      return @{ ok = $true; windows = $list }
    }
    'readDoc' {
      $w = Pick-One (Get-DocWindows) @('approve', 'view', 'draft') $args0.pid 'doc'
      $r = Invoke-InPage $w.doc (With-Payload $JS_READ @{ lengthsOnly = [bool]$args0.lengthsOnly })
      return @{ ok = [bool]$r.ok; kind = $w.kind; pid = $w.pid; fields = $r.fields; missing = $r.missing; error = $r.error }
    }
    'fillDraft' {
      $w = Pick-One (Get-DocWindows) @('draft') $args0.pid 'draft'
      $fields = @{}
      if ($args0.fields) { foreach ($p in $args0.fields.PSObject.Properties) { $fields[$p.Name] = [string]$p.Value } }
      $disc = $null
      if ($args0.disclosure -and @('partial', 'private', 'public') -contains $args0.disclosure.mode) {
        $disc = @{ mode = [string]$args0.disclosure.mode; reasons = @($args0.disclosure.reasons | Where-Object { $_ -ge 1 -and $_ -le 8 } | ForEach-Object { [int]$_ }) }
      }
      $r = Invoke-InPage $w.doc (With-Payload $JS_FILL @{ title = $args0.title; fields = $fields; disclosure = $disc; attachPrivate = [bool]$args0.attachPrivate })
      if ($args0.front) { try { [DoumiWxs]::Front($w.ie) } catch { } }
      return @{ ok = [bool]$r.ok; pid = $w.pid; done = $r.done; missing = $r.missing; error = $r.error }
    }
    default { throw "unknown-op:$($req.op)" }
  }
}

# ---- native messaging loop ----
$stdin = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
function Read-Full([byte[]]$buf, [int]$count) {
  $off = 0
  while ($off -lt $count) { $n = $stdin.Read($buf, $off, $count - $off); if ($n -le 0) { break }; $off += $n }
  return $off
}
function Send($obj) {
  $b = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $obj -Compress -Depth 6))
  $stdout.Write([BitConverter]::GetBytes([int]$b.Length), 0, 4)
  $stdout.Write($b, 0, $b.Length)
  $stdout.Flush()
}
while ($true) {
  $lenBuf = New-Object byte[] 4
  if ((Read-Full $lenBuf 4) -lt 4) { break }
  $len = [BitConverter]::ToInt32($lenBuf, 0)
  if ($len -le 0 -or $len -gt 1048576) { break }
  $buf = New-Object byte[] $len
  if ((Read-Full $buf $len) -lt $len) { break }
  $req = $null
  try {
    $req = [Text.Encoding]::UTF8.GetString($buf) | ConvertFrom-Json
    $res = Handle $req
    $res.id = $req.id
    Send $res
  } catch {
    Send @{ id = $(if ($req) { $req.id } else { $null }); ok = $false; error = "$($_.Exception.Message)" }
  }
}
