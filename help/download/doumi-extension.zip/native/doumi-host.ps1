# Doumi PC helper (native messaging host) - talks only to the Doumi browser extension over stdin/stdout.
# It reads and fills the K-Edufine document window (WXSClient.exe, IE engine + Hancom HwpCtrl) on THIS PC.
# - No network access. Values are never logged. Files are written only when the teacher presses a button, and only inside
#   Downloads\<official-documents folder> (2026-11-02 teacher decision). Nothing outside that folder is read, written or opened.
# - Allowed operations only: ping, windows, readDoc, readPicks, fillPicks, readPickLists, readLine, fillLine, fillRcver, attachAdd, closeDoc, fillDraft, attachSave, launchDoc, fileWrite, fileRead, fileOpen, folderOpen. There is no "run any script" operation.
# - It never calls approve/submit/save/sign functions (fncSanctn, fncSaveTmpr, fncSaveCnsltTmp, fncSaveUpdateTmp, kcase).
# Protocol: Chrome native messaging (4-byte little-endian length + UTF-8 JSON), one request -> one response, loop until stdin closes.
# Keep this file ASCII-only (Windows PowerShell 5.1 reads BOM-less files as ANSI). Korean field names are \u escapes in the JS below.
$ErrorActionPreference = 'Stop'
$VERSION = 3

$null = Add-Type -TypeDefinition @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public class DoumiWxs {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint m, IntPtr w, IntPtr l, uint f, uint t, out IntPtr r);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h, uint flags);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("oleacc.dll")] public static extern int ObjectFromLresult(IntPtr r, ref Guid iid, IntPtr w, [MarshalAs(UnmanagedType.IDispatch)] out object o);
  [DllImport("shell32.dll", CharSet=CharSet.Unicode)] public static extern int SHGetKnownFolderPath([MarshalAs(UnmanagedType.LPStruct)] Guid id, uint flags, IntPtr token, out string path);
  public static string Downloads() { string p; int hr = SHGetKnownFolderPath(new Guid("374DE290-123F-4565-9164-39C4925E467B"), 0, IntPtr.Zero, out p); return hr == 0 ? p : null; }
  public static List<IntPtr> IeServers(uint[] pids) {
    var list = new List<IntPtr>();
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (Array.IndexOf(pids, pid) < 0) return true;
      EnumChildWindows(h, (c, l2) => { var s = new StringBuilder(64); GetClassName(c, s, 64); if (s.ToString() == "Internet Explorer_Server") list.Add(c); return true; }, IntPtr.Zero);
      return true; }, IntPtr.Zero);
    return list;
  }
  public static uint Pid(IntPtr h) { uint pid; GetWindowThreadProcessId(h, out pid); return pid; }
  public static object Doc(IntPtr ie) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT"); IntPtr r;
    SendMessageTimeout(ie, msg, IntPtr.Zero, IntPtr.Zero, 2, 5000, out r);
    Guid iid = new Guid("626FC520-A41E-11CF-A731-00A0C9082637"); object o;
    return ObjectFromLresult(r, ref iid, IntPtr.Zero, out o) == 0 ? o : null;
  }
  public static void Front(IntPtr ie) { SetForegroundWindow(GetAncestor(ie, 2)); }
  // The page message box (alert/confirm) of the IE engine. Its title follows the Windows display language: Korean "web page message"
  // or English "Message from webpage" (2026-11-06 new PC: English display language, Korean buttons). Dialog class #32770 only.
  public static bool PageBox(IntPtr h) {
    var c = new StringBuilder(16); GetClassName(h, c, 16); if (c.ToString() != "#32770") return false;
    var t = new StringBuilder(64); GetWindowText(h, t, 64); var s = t.ToString();
    return s == "\uC6F9 \uD398\uC774\uC9C0 \uBA54\uC2DC\uC9C0" || s == "Message from webpage";
  }
  public static bool IsCancel(string s) { return s.StartsWith("\uCDE8\uC18C") || s.Replace("&", "") == "Cancel"; }
  // A page message box with only an OK button, while the helper waits on its own popup: read its text and press OK. Boxes with other buttons (confirm) are never pressed.
  public static List<string> PressAlerts(uint[] pids) {
    var notes = new List<string>();
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (Array.IndexOf(pids, pid) < 0) return true;
      if (!PageBox(h)) return true;
      var btns = new List<IntPtr>(); string text = "";
      EnumChildWindows(h, (c, l2) => { var k = new StringBuilder(32); GetClassName(c, k, 32); var x = new StringBuilder(1024); GetWindowText(c, x, 1024);
        if (k.ToString() == "Button") btns.Add(c); else if (k.ToString() == "Static" && x.Length > 0) text = x.ToString(); return true; }, IntPtr.Zero);
      if (btns.Count == 1) { notes.Add(text); PostMessage(btns[0], 0x00F5, IntPtr.Zero, IntPtr.Zero); }
      return true; }, IntPtr.Zero);
    return notes;
  }
  // Closing a document that was only read: the page may ask "save as a draft?" (a box with its own OK and Cancel). Cancel saves nothing. Only that question, only while closing.
  public static int PressNoSave(uint[] pids) {
    int n = 0;
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (Array.IndexOf(pids, pid) < 0) return true;
      if (!PageBox(h)) return true;
      IntPtr cancel = IntPtr.Zero; bool asks = false;
      EnumChildWindows(h, (c, l2) => { var x = new StringBuilder(1024); GetWindowText(c, x, 1024); var s = x.ToString();
        if (s.Contains("\uC784\uC2DC \uC800\uC7A5")) asks = true;
        if (IsCancel(s)) cancel = c; return true; }, IntPtr.Zero);
      if (asks && cancel != IntPtr.Zero) { PostMessage(cancel, 0x00F5, IntPtr.Zero, IntPtr.Zero); n++; }
      return true; }, IntPtr.Zero);
    return n;
  }
  // A document window that opens while another one still exists asks "closing the open draft/approval window" (real page 2026-11-05). OK force-quits the other window, which could be the teacher's work: only Cancel, never OK. Cancel keeps both.
  public static int PressKeepOpen(uint[] pids) {
    int n = 0;
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (Array.IndexOf(pids, pid) < 0) return true;
      if (!PageBox(h)) return true;
      IntPtr cancel = IntPtr.Zero; bool asks = false;
      EnumChildWindows(h, (c, l2) => { var x = new StringBuilder(256); GetWindowText(c, x, 256); var s = x.ToString();
        if (s.Contains("\uAE30\uC548/\uACB0\uC7AC\uAE30\uB97C \uB2EB\uC2B5\uB2C8\uB2E4")) asks = true;
        if (IsCancel(s)) cancel = c; return true; }, IntPtr.Zero);
      if (asks && cancel != IntPtr.Zero) { PostMessage(cancel, 0x00F5, IntPtr.Zero, IntPtr.Zero); n++; }
      return true; }, IntPtr.Zero);
    return n;
  }
  // A draft window that finds an auto-saved document asks whether to load it (real window 2026-11-05). It can hold the teacher's unfinished work: the teacher chooses, nothing is pressed here.
  public static bool AsksAutosave(uint[] pids) {
    bool found = false;
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (Array.IndexOf(pids, pid) < 0) return true;
      if (!PageBox(h)) return true;
      EnumChildWindows(h, (c, l2) => { var x = new StringBuilder(256); GetWindowText(c, x, 256); if (x.ToString().Contains("\uC790\uB3D9\uC800\uC7A5\uBB38\uC11C")) found = true; return true; }, IntPtr.Zero);
      return true; }, IntPtr.Zero);
    return found;
  }
  // Is this process still showing a window? A closed document's window can outlive its page for a moment, and the next document then asks the question above.
  public static int TopCount(uint wanted) {
    int n = 0;
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (pid != wanted || !IsWindowVisible(h)) return true;
      var c = new StringBuilder(64); GetClassName(h, c, 64); if (c.ToString() != "Internet Explorer_Hidden") n++;
      return true; }, IntPtr.Zero);
    return n;
  }
  // A busy PC can stop the document window with the system "server busy" box (2026-11-02 real window). Press only its Retry button, nothing else.
  public static int PressBusyRetry(uint[] pids) {
    int n = 0;
    EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (Array.IndexOf(pids, pid) < 0) return true;
      var t = new StringBuilder(32); GetWindowText(h, t, 32); var bt = t.ToString(); if (bt != "\uC11C\uBC84 \uC791\uC5C5 \uC911" && bt != "Server Busy") return true;
      EnumChildWindows(h, (c, l2) => { var x = new StringBuilder(32); GetWindowText(c, x, 32); var bx = x.ToString(); if (bx.StartsWith("\uB2E4\uC2DC \uC2DC\uB3C4") || bx.Replace("&", "").StartsWith("Retry")) { PostMessage(c, 0x00F5, IntPtr.Zero, IntPtr.Zero); n++; return false; } return true; }, IntPtr.Zero);
      return true; }, IntPtr.Zero);
    return n;
  }
}
"@

function Get-Kind([string]$path) {
  if ($path -like '*/cz/cb/wrt/retrieveDoccrdWritng.do*') { return 'draft' }
  if ($path -like '*/cz/cb/prc/*') { return 'approve' }
  if ($path -like '*/cz/cb/viw/retrieveDoccrd*') { return 'view' }
  return 'other'
}

function Clear-Busy {
  $pids = [uint32[]](Get-Process WXSClient -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
  if ($pids) { $null = [DoumiWxs]::PressBusyRetry($pids) }
}

$script:Notes = @()
$script:Seq = 0
function Clear-Alerts {
  $pids = [uint32[]](Get-Process WXSClient -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
  if ($pids) { foreach ($n in [DoumiWxs]::PressAlerts($pids)) { if ($n -and $script:Notes -notcontains $n) { $script:Notes += $n } } }
}

function Clear-KeepOpen {
  $pids = [uint32[]](Get-Process WXSClient -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
  if ($pids) { $null = [DoumiWxs]::PressKeepOpen($pids) }
}

# All document windows of WXSClient: @{ ie; doc; pid; kind; path }
function Get-DocWindows {
  $pids = [uint32[]](Get-Process WXSClient -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
  $out = @()
  if (-not $pids) { return $out }
  foreach ($ie in [DoumiWxs]::IeServers($pids)) {
    $doc = $null
    try { $doc = [DoumiWxs]::Doc($ie) } catch { }
    if (-not $doc) { continue }
    $path = ''
    try { $path = (("$($doc.url)") -split '\?')[0] -replace '^https?://[^/]+', '' } catch { }
    if ($path -notlike '/bms/*') { continue }
    $out += @{ ie = $ie; doc = $doc; pid = [DoumiWxs]::Pid($ie); kind = (Get-Kind $path); path = $path }
  }
  return $out
}

# Every IE document of WXSClient including popups (some popups are not under /bms): @{ ie; doc; url }
function Get-AllDocs {
  $pids = [uint32[]](Get-Process WXSClient -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
  $out = @()
  if (-not $pids) { return $out }
  foreach ($ie in [DoumiWxs]::IeServers($pids)) {
    $doc = $null
    try { $doc = [DoumiWxs]::Doc($ie) } catch { }
    if (-not $doc) { continue }
    $u = ''
    try { $u = (("$($doc.url)") -split '\?')[0] } catch { }
    $out += @{ ie = $ie; doc = $doc; url = $u }
  }
  return $out
}

# Open a popup with the page's own function on a timer (a modal dialog must not block this host) and wait until its page has loaded.
# A window that has just opened can be seen before it has loaded (real window 2026-11-05: script calls throw for a few seconds) and, on a busy PC or with
# another small window on top, does not run its timers yet (real window 2026-11-03). Wait until the page answers: its functions exist and, in a draft window, the body editor answers too.
function Wait-DocReady($w, [string]$fn = '') {
  $readySec = $(if ($env:DOUMI_TEST_ROOT) { 5 } else { 90 })
  $edit = $(if ($w.kind -eq 'draft') { 'true' } else { 'false' })
  $need = $(if ($fn) { "typeof $fn === 'function'" } else { 'true' })
  $probe = "var a = $need; if (a && $edit) { a = false; for (var i = 0; i < document.frames.length; i++) { try { var e = document.frames[i].document.getElementById('editor1'); if (e) { e.GetFieldList(0, 0); a = true; } } catch (x) { } } } document.documentElement.setAttribute('data-doumi-r', a ? '{""ok"":true}' : '{}');"
  $end = (Get-Date).AddSeconds($readySec)
  $waited = $false
  while ((Get-Date) -lt $end) {
    $pids = [uint32[]](Get-Process WXSClient -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
    if ($pids -and [DoumiWxs]::AsksAutosave($pids)) { throw 'autosave-ask' }
    try {
      $d = [DoumiWxs]::Doc($w.ie)
      if ($d) { $w.doc = $d }
      if ("$($w.doc.readyState)" -eq 'complete') {
        $r = Invoke-Timed $w.doc $probe 3
        if ($r.ok) {
          if ($waited) { Start-Sleep -Milliseconds 1200 }
          return $true
        }
      }
    } catch { }
    $waited = $true
    Clear-Busy
    Clear-Alerts
    Start-Sleep -Milliseconds 400
  }
  return $false
}
function Open-Popup($w, [string]$openFn, [string]$like, [int]$sec = 45) {
  if (@('fncCnrsAppn', 'fncChooseTkcrd', 'fncReportCours', 'fncRcverAppn') -notcontains $openFn) { throw 'not-allowed-popup' }
  if (-not (Wait-DocReady $w $openFn)) { throw 'window-busy' }
  $known = @(Get-AllDocs | ForEach-Object { $_.ie })
  $script:Seq++
  $token = "p$($script:Seq)"
  $w.doc.parentWindow.execScript("window.__doumiPop = '$token'; window.setTimeout(function () { if (window.__doumiPop !== '$token') return; try { $openFn(); } catch (e) { } }, 0);", 'JavaScript') | Out-Null
  $end = (Get-Date).AddSeconds($sec)
  while ((Get-Date) -lt $end) {
    Start-Sleep -Milliseconds 300
    Clear-Busy
    Clear-Alerts
    foreach ($d in @(Get-AllDocs)) {
      if ($known -contains $d.ie -or $d.url -notlike $like) { continue }
      try { if ("$($d.doc.readyState)" -eq 'complete') { return $d } } catch { }
    }
  }
  # given up: a timer that has not fired yet must not open the popup later
  try { $w.doc.parentWindow.execScript("window.__doumiPop = '';", 'JavaScript') | Out-Null } catch { }
  return $null
}

# The popup's own OK or close, as a second step on a timer: the page may vanish right after, so the result above has been read already. Then wait until it is gone.
$POPUP_CALLS = @{
  close = 'window.close();'
  cnrsOk = 'fncVerify();'
  tkcrdOk = 'nexacro.getApplication().mainframe.frame.form.Tab00_Tabpage1_divAuth_btnAuthC01_onclick();'
  lineOk = 'fncVerify();'
  rcverOk = 'fncVerifyChoose();'
}
function Finish-Popup($pop, [string]$what, [string]$like, [int]$sec = 20) {
  $call = $POPUP_CALLS[$what]
  try { $pop.doc.parentWindow.execScript("window.setTimeout(function () { try { $call } catch (x) { window.close(); } }, 100);", 'JavaScript') | Out-Null } catch { }
  $end = (Get-Date).AddSeconds($sec)
  while ((Get-Date) -lt $end) {
    Start-Sleep -Milliseconds 300
    Clear-Busy
    Clear-Alerts
    if (-not @(Get-AllDocs | Where-Object { $_.ie -eq $pop.ie -and $_.url -like $like }).Count) { return $true }
  }
  return $false
}

# Run a fixed ES5 script inside the page; the script stores its JSON result on <html data-doumi-r>.
function Invoke-InPage($doc, [string]$js) {
  $doc.parentWindow.execScript($js, 'JavaScript') | Out-Null
  $res = $doc.documentElement.getAttribute('data-doumi-r')
  $null = $doc.documentElement.removeAttribute('data-doumi-r')
  if (-not $res) { throw 'no result from page' }
  return ($res | ConvertFrom-Json)
}

# Same, but the page's own functions run on a timer: a message box they raise must not block this host. An OK-only box is read and pressed while waiting.
function Invoke-Timed($doc, [string]$js, [int]$sec = 60) {
  $script:Seq++
  $mark = "t$($script:Seq)"
  $doc.parentWindow.execScript("window.setTimeout(function () {`n$js`ndocument.documentElement.setAttribute('data-doumi-n', '$mark');`n}, 0);", 'JavaScript') | Out-Null
  $end = (Get-Date).AddSeconds($sec)
  while ((Get-Date) -lt $end) {
    if ("$($doc.documentElement.getAttribute('data-doumi-n'))" -eq $mark) {
      $res = $doc.documentElement.getAttribute('data-doumi-r')
      $null = $doc.documentElement.removeAttribute('data-doumi-r')
      $null = $doc.documentElement.removeAttribute('data-doumi-n')
      return ($res | ConvertFrom-Json)
    }
    Start-Sleep -Milliseconds 150
    Clear-Busy
    Clear-Alerts
  }
  throw 'page-timeout'
}

# Shared ES5 helpers: find the body editor (object#editor1 in the doccrdEditor.do frame)
$JS_EDITOR = @'
function doumiEditor() {
  for (var i = 0; i < document.frames.length; i++) {
    try { var d = document.frames[i].document; var e = d.getElementById('editor1'); if (e) return e; } catch (x) {}
  }
  return null;
}
function doumiFields(ed) { try { return String(ed.GetFieldList(0, 0)).split(String.fromCharCode(2)); } catch (x) { return []; } }
function doumiHas(list, k) { for (var i = 0; i < list.length; i++) if (list[i] === k) return true; return false; }
// visible label text of a radio/checkbox (label[for], next text, or parent text) - static UI words only
function doumiLabel(e) {
  try {
    var ls = document.getElementsByTagName('label');
    for (var i = 0; i < ls.length; i++) if (e.id && ls[i].htmlFor === e.id) return String(ls[i].innerText || '');
    var n = e.nextSibling;
    while (n && n.nodeType === 3 && !/\S/.test(n.nodeValue)) n = n.nextSibling;
    if (n) return String(n.nodeType === 3 ? n.nodeValue : (n.innerText || ''));
    return String(e.parentNode.innerText || '');
  } catch (x) { return ''; }
}
function doumiTrim(s) { return String(s || '').replace(/\s+/g, ''); }
// click like the teacher would so the page's own onclick (setPublication etc.) keeps linked fields in sync
function doumiClick(e) { try { e.click(); return true; } catch (x) { return false; } }
// the page may run in an old IE document mode without JSON
function doumiJson(v) {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (typeof v === 'string') return '"' + v.replace(/[\\"\u0000-\u001f]/g, function (c) { return '\\u' + ('000' + c.charCodeAt(0).toString(16)).slice(-4); }) + '"';
  var out = [], k;
  if (Object.prototype.toString.call(v) === '[object Array]') { for (k = 0; k < v.length; k++) out.push(doumiJson(v[k])); return '[' + out.join(',') + ']'; }
  for (k in v) if (v.hasOwnProperty(k)) out.push(doumiJson(k) + ':' + doumiJson(v[k]));
  return '{' + out.join(',') + '}';
}
'@

# Title / body fields (Korean names as escapes): approval-title, body, receiver, via, enforce-date, doc-number, sender
$JS_READ = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false, fields: {}, missing: [] };
  try {
    var names = ['\uACB0\uC7AC\uC81C\uBAA9', '\uBCF8\uBB38', '\uC218\uC2E0', '\uACBD\uC720', '\uC2DC\uD589\uC77C\uC790', '\uBB38\uC11C\uBC88\uD638', '\uBC1C\uC2E0\uAE30\uAD00\uBA85'];
    var sj = document.getElementById('Sj');
    var put = function (k, v) { v = String(v == null ? '' : v); r.fields[k] = p.lengthsOnly ? v.length : v; };
    if (sj) put('Sj', sj.value); else r.missing.push('Sj');
    var ed = doumiEditor();
    if (!ed) r.missing.push('editor1');
    else {
      var list = doumiFields(ed);
      for (var i = 0; i < names.length; i++) {
        if (!doumiHas(list, names[i])) { r.missing.push(names[i]); continue; }
        put(names[i], ed.GetFieldText(names[i]));
      }
    }
    r.ok = !!ed;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# Only #Sj (title input) and the two body fields approval-title / body may be written. Nothing else is touched or clicked.
$JS_FILL = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false, done: [], missing: [] };
  try {
    if (String(location.href).indexOf('/cz/cb/wrt/retrieveDoccrdWritng.do') < 0) throw new Error('not a draft window');
    var allow = { '\uACB0\uC7AC\uC81C\uBAA9': 1, '\uBCF8\uBB38': 1 };
    if (p.title != null) {
      var sj = document.getElementById('Sj');
      if (sj) { sj.value = p.title; try { sj.fireEvent('onchange'); } catch (x) {} r.done.push('Sj'); } else r.missing.push('Sj');
    }
    var ed = doumiEditor();
    if (!ed) r.missing.push('editor1');
    else {
      var list = doumiFields(ed);
      for (var k in p.fields) {
        if (!p.fields.hasOwnProperty(k) || !allow[k]) continue;
        if (!doumiHas(list, k)) { r.missing.push(k); continue; }
        ed.PutFieldText(k, String(p.fields[k]));
        r.done.push(k + ':' + String(ed.GetFieldText(k)).length);
      }
    }
    // disclosure: { mode: 'partial'|'private'|'public', reasons: [6] } - radio name othbcLmtt, reason checkboxes othbcAt1..8
    if (p.disclosure) {
      var want = { 'partial': '\uBD80\uBD84\uACF5\uAC1C', 'private': '\uBE44\uACF5\uAC1C', 'public': '\uACF5\uAC1C' }[p.disclosure.mode];
      var radios = document.getElementsByName('othbcLmtt'), hit = null;
      for (var i = 0; i < radios.length; i++) { if (doumiTrim(doumiLabel(radios[i])) === want) hit = radios[i]; }
      if (!hit) r.missing.push('othbcLmtt:' + p.disclosure.mode);
      else { if (!hit.checked) doumiClick(hit); r.done.push('othbcLmtt:' + p.disclosure.mode); }
      if (p.disclosure.mode !== 'public') {
        var rs = {}; for (var j = 0; j < (p.disclosure.reasons || []).length; j++) rs[p.disclosure.reasons[j]] = 1;
        for (var n = 1; n <= 8; n++) {
          var cb = document.getElementById('othbcAt' + n);
          if (!cb) { if (rs[n]) r.missing.push('othbcAt' + n); continue; }
          if (!!rs[n] !== !!cb.checked) doumiClick(cb);
          if (rs[n]) r.done.push('othbcAt' + n);
        }
      }
    }
    // attachments private: per-file radios (name like modiAttachOthbcSe*/attachOthbcSe*) -> the one labelled '\uBE44\uACF5\uAC1C'
    if (p.attachPrivate) {
      var all = document.getElementsByTagName('input'), groups = {}, cnt = 0;
      for (var a = 0; a < all.length; a++) {
        var e2 = all[a];
        if (e2.type !== 'radio' || !/attachothbcse/i.test(e2.name || '')) continue;
        if (doumiTrim(doumiLabel(e2)) === '\uBE44\uACF5\uAC1C') groups[e2.name] = e2;
      }
      for (var g in groups) if (groups.hasOwnProperty(g)) { if (!groups[g].checked) doumiClick(groups[g]); cnt++; }
      r.done.push('attachPrivate:' + cnt);
    }
    r.ok = r.missing.length === 0;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# Attachment list of the open document window: the page's own Attach.fileBox (names and sizes only). 2026-11-02 real window.
$JS_ATTACH = $JS_EDITOR + @'
(function () {
  var r = { ok: false, files: [] };
  try {
    var fs = window.Attach.fileBox.files();
    for (var i = 0; i < fs.length; i++) {
      var f = fs[i];
      r.files.push({ i: i, name: String(f.fileName || f.name || ''), size: Number(f.fileSize || f.size || 0) || 0 });
    }
    r.ok = true;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})();
'@

# Save one attachment with the page's own Attach.save (same path as the window's [save] button, same access log; no dialog because the path is given).
# Data-collection attachments of unfinished documents stay blocked exactly like fncSaveFile does.
$JS_ATTACH_SAVE = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false };
  try {
    if (window.pInfo && pInfo.apprStatus !== 'apprstatus_finish' && typeof window.isKTotalizingData === 'function' && isKTotalizingData()) throw new Error('total-data');
    var f = window.Attach.fileBox.files()[p.i];
    if (!f) throw new Error('no-attach');
    if (String(f.fileName || f.name || '') !== p.name) throw new Error('attach-changed');
    window.Attach.save(f, p.path);
    r.ok = true;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# What the document window holds now: viewers (name of /hox/pubShowInfo/pubShow is 'dept/position/name', real window 2026-11-03: people only, the last piece) and task cards. Read only.
$JS_READ_PICKS = $JS_EDITOR + @'
(function () {
  var r = { ok: false, cnrs: [], tkcrd: [], tkcrdId: [] };
  try {
    var ps = domHox1.selectNodes('/hox/pubShowInfo/pubShow');
    for (var i = 0; i < ps.length; i++) { if (String(get_text(ps[i], 'type') || '') !== 'user') continue; var n = String(get_text(ps[i], 'name') || '').split('/').pop(); if (n) r.cnrs.push(n); }
    var cs = domHox1.selectNodes('/hox/docInfo/taskInfo/taskCard');
    for (var j = 0; j < cs.length; j++) { r.tkcrd.push(String(get_text(cs[j], 'cardName') || '')); r.tkcrdId.push(String(get_text(cs[j], 'cardID') || '')); }
    r.ok = true;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})();
'@

# Yellow mark on the filled rows of the document window (nothing is saved)
$JS_MARK = $JS_EDITOR + @'
(function (p) {
  var r = { ok: true };
  try {
    var mark = function (id) { var e = document.getElementById(id), t = e; while (t && t.tagName !== 'TR') t = t.parentNode; if (t || e) (t || e).style.backgroundColor = '#fff4c2'; };
    if (p.tkcrd) mark('tablebodyView');
    if (p.cnrs) mark('spnCnrsAppn');
  } catch (e) { r.ok = false; }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# In the viewer popup: tick people by exact name, add them to the list. The host presses the popup's own OK afterwards (Finish-Popup).
# Only in submit mode (draft or approve window): there OK only writes to the document in memory, the server gets it when the teacher submits.
$JS_CNRS = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false, added: [], missing: [], twin: [] };
  try {
    if (rInfo.appType !== 'sancgian' && rInfo.appType !== 'sanckyul') throw new Error('not-submit-mode');
    var as = document.getElementsByTagName('a'), map = {};
    for (var i = 0; i < as.length; i++) {
      var oc = String(as[i].getAttribute('onclick') || as[i].getAttribute('href') || '');
      if (oc.indexOf('fncNodeOrgnztUserOnClick') < 0) continue;
      var box = null, n = as[i].previousSibling;
      while (n) { if (n.tagName === 'INPUT') { box = n; break; } n = n.previousSibling; }
      var name = doumiTrim(as[i].innerText);
      if (box && name) { (map[name] = map[name] || []).push(box); }
    }
    for (var j = 0; j < p.names.length; j++) {
      var want = doumiTrim(p.names[j]), list = map[want];
      if (!list) r.missing.push(p.names[j]);
      else if (list.length > 1) r.twin.push(p.names[j]);
      else { list[0].checked = true; r.added.push(p.names[j]); }
    }
    if (r.added.length) fncChooseOrgnztUserUserTr();
    r.total = document.getElementsByName('selID').length;
    r.ok = true;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# In the task card popup (a Nexacro screen): find the card by exact name in the teacher's own list and select it. The host presses the popup's own choose button
# afterwards, or closes the popup without choosing if the card is not there (Finish-Popup).
$JS_TKCRD = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false };
  try {
    var fm = nexacro.getApplication().mainframe.frame.form, ds = fm.dsAList;
    r.rows = ds.getRowCount();
    if (!r.rows && !p.last) { r.wait = true; }
    else {
      var row = -1;
      for (var i = 0; i < r.rows; i++) { if (doumiTrim(ds.getColumn(i, 'tkcrdNm')) === doumiTrim(p.name)) { row = i; break; } }
      if (row < 0) r.missing = true;
      else { fm.fnSelectUnitTkcrd(row); r.ok = true; }
    }
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# Lists for the panel to choose from: the teacher's task cards and the names in the viewer popup. Read only, the popups are closed without OK.
$JS_CARDS = $JS_EDITOR + @'
(function () {
  var r = { ok: false, list: [] };
  try {
    var ds = nexacro.getApplication().mainframe.frame.form.dsAList, n = ds.getRowCount();
    if (!n) r.wait = true;
    for (var i = 0; i < n; i++) { var v = String(ds.getColumn(i, 'tkcrdNm') || ''); if (v) r.list.push(v); }
    r.ok = true;
  } catch (e) { r.wait = true; r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})();
'@
$JS_PEOPLE = $JS_EDITOR + @'
(function () {
  var r = { ok: false, list: [] };
  try {
    var as = document.getElementsByTagName('a');
    for (var i = 0; i < as.length; i++) {
      var oc = String(as[i].getAttribute('onclick') || as[i].getAttribute('href') || '');
      if (oc.indexOf('fncNodeOrgnztUserOnClick') < 0) continue;
      var n = doumiTrim(as[i].innerText);
      if (n) r.list.push(n);
    }
    if (!r.list.length) r.wait = true;
    r.ok = true;
  } catch (e) { r.wait = true; r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})();
'@

# Approval line of the document window (name, position, kind). Read only. Real window 2026-11-03: /hox/approvalFlow/participant.
$JS_READ_LINE = $JS_EDITOR + @'
(function () {
  var r = { ok: false, line: [] };
  try {
    var ps = domHox1.selectNodes('/hox/approvalFlow/participant');
    for (var i = 0; i < ps.length; i++) r.line.push({ name: String(get_text(ps[i], 'name') || ''), position: String(get_text(ps[i], 'position') || ''), at: String(get_text(ps[i], 'approvalType') || '') });
    r.ok = true;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})();
'@

# In the approval line popup (new draft only): add people by exact name from the school's list with the popup's own add function, set each row's kind. The host presses the popup's own OK
# afterwards (Finish-Popup): that writes to the document in memory only, the server gets it when the teacher submits. A line that already has people is left alone. Absent people are not added
# (the page would open its own substitute dialog); the teacher handles them.
$JS_LINE = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false, added: [], missing: [], twin: [], absent: [], kindMiss: [], ats: [] };
  try {
    if (rInfo.appType !== 'sancgian' || pInfo.isAccept()) throw new Error('not-draft');
    var fr = document.getElementById('reportOrgList'), tb = fr && fr.contentWindow.document.getElementById('orgnztUserList');
    var rows = tb ? tb.getElementsByTagName('tr') : [];
    if (typeof PrtcpList === 'undefined' || !PrtcpList.toArray().length || rows.length < 2) { r.wait = !p.last; if (p.last) r.error = 'no-list'; }
    else if (PrtcpList.toArray().length > 1) { r.ok = true; r.kept = true; }
    else {
      var map = {};
      for (var i = 0; i < rows.length; i++) {
        var box = rows[i].getElementsByTagName('input')[0], tds = rows[i].getElementsByTagName('td');
        if (!box || tds.length < 3) continue;
        var nm = doumiTrim(tds[2].getAttribute('title') || tds[2].innerText);
        (map[nm] = map[nm] || []).push({ id: box.id, pos: doumiTrim(tds[1].innerText), tr: rows[i] });
      }
      var kinds = [];
      for (var k = 0; k < p.line.length; k++) {
        var w = p.line[k], list = map[doumiTrim(w.name)] || [], pick = [];
        for (var j = 0; j < list.length; j++) if (!w.position || list.length === 1 || list[j].pos === doumiTrim(w.position)) pick.push(list[j]);
        if (!list.length) { r.missing.push(w.name); continue; }
        if (pick.length !== 1) { r.twin.push(w.name); continue; }
        doumiClick(pick[0].tr); // the row's own click sets the person and department
        if (selectedID !== pick[0].id) { r.missing.push(w.name); continue; }
        var node = Capi.getUser(selectedID, searchDept).user;
        if (!node) { r.missing.push(w.name); continue; }
        if (Prtcp.createFromNode(node).absent) { r.absent.push(w.name); continue; }
        if (PrtcpList.getSameUser(selectedID, node.deptID)) continue;
        nlr.selectItem(nlr.RowCount() - 1);
        var before = nlr.RowCount();
        fncAdd();
        if (nlr.RowCount() === before) { r.missing.push(w.name); continue; }
        r.added.push(w.name);
        kinds.push({ row: nlr.RowCount() - 1, at: w.at, name: w.name });
      }
      // kinds after everybody is in: which kinds a row offers depends on its place in the line
      for (var c = 0; c < kinds.length; c++) {
        var sel = document.getElementById('draft' + kinds[c].row), at = kinds[c].at;
        if (!at || !sel || sel.value === at) continue;
        var has = false;
        for (var o = 0; o < sel.options.length; o++) if (sel.options[o].value === at) has = true;
        if (has) { nlr.selectItem(kinds[c].row); sel.value = at; PrtcpList.onchangemethod(at); } else r.kindMiss.push(kinds[c].name);
      }
      for (var a = 0; a < nlr.RowCount(); a++) { var s2 = document.getElementById('draft' + a); r.ats.push(s2 ? String(s2.value) : ''); }
      r.ok = true;
    }
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# In the receiver popup: search the organization tree for one exact name, tick it, add it with the popup's own add function. The host presses the popup's own OK afterwards (memory only).
$JS_RCVER = $JS_EDITOR + @'
(function (p) {
  var r = { ok: true, state: 'wait' };
  try {
    if (p.count) {
      r.state = String(RecptList.toArray().length);
    } else if (p.search) {
      onTabRecpChange('RecpOrgTree');
      document.getElementsByName('orgnztNm')[0].value = p.name;
      fncOrgnztSearch2();
      r.state = 'searching';
    } else {
      // a result label can be 'upper-organization organization' (real window 2026-11-03): exact first, then the last word
      var bs = document.getElementsByName('orgnztChk'), want = doumiTrim(p.name), hits = [], tail = [];
      var lastWord = function (t) { var a = String(t || '').replace(/^\s+|\s+$/g, '').split(/\s+/); return a[a.length - 1]; };
      for (var i = 0; i < bs.length; i++) {
        var sp = bs[i].parentNode.getElementsByTagName('span')[0], tx = sp ? sp.innerText : '';
        if (doumiTrim(tx) === want || doumiTrim(bs[i].title) === want) hits.push(bs[i]);
        else if (lastWord(tx) === want || lastWord(bs[i].title) === want) tail.push(bs[i]);
      }
      if (!hits.length) hits = tail;
      if (hits.length === 1) {
        if (!hits[0].checked) doumiClick(hits[0]);
        fncAdd();
        r.state = 'adding';
      } else if (hits.length > 1) r.state = 'twin';
      else if (bs.length) r.state = 'missing';
    }
  } catch (e) { r.ok = false; r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# Add files from this PC to the draft the same way the page's own file dialog does (same checks; the page uploads them only when the teacher saves or submits).
$JS_ATTACH_ADD = $JS_EDITOR + @'
(function (p) {
  var r = { ok: false, added: [], blocked: [] };
  try {
    if (String(location.href).indexOf('/cz/cb/wrt/retrieveDoccrdWritng.do') < 0) throw new Error('not a draft window');
    var pr = Attach.fileBox.properties, gb = String(pr.docFileExtListGubun || ''), list = [];
    var inList = function (txt, ext) { var a = String(txt || '').split(','); for (var j = 0; j < a.length; j++) if (a[j] === ext) return true; return false; };
    var have = Attach.fileBox.files();
    for (var i = 0; i < p.files.length; i++) {
      var f = p.files[i], dot = f.name.lastIndexOf('.'), ext = dot > 0 ? f.name.substr(dot + 1).toUpperCase() : '', dup = false;
      for (var h = 0; h < have.length; h++) if (have[h].path === f.path && have[h].name === f.name) dup = true;
      if (dup) continue;
      if (!f.size) r.blocked.push({ name: f.name, why: 'empty' });
      else if (!ext) r.blocked.push({ name: f.name, why: 'no-ext' });
      else if (dot > 70) r.blocked.push({ name: f.name, why: 'long-name' });
      else if ((gb === '02' && !inList(pr.extensions, ext)) || (gb === '01' && inList(pr.disallows, ext))) r.blocked.push({ name: f.name, why: 'ext' });
      else { list.push(new HsFile(f.path, f.name, f.size)); r.added.push(f.name); }
    }
    if (list.length) Attach.addFiles(list);
    r.count = Attach.fileBox.files().length;
    r.ok = true;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})(PAYLOAD);
'@

# Close a document window that was only read: check here, the page's own close function runs as a second step on a timer (a page dialog must not block this host).
$JS_CLOSE = $JS_EDITOR + @'
(function () {
  var r = { ok: false };
  try {
    if (String(location.href).indexOf('/cz/cb/prc/') < 0 && String(location.href).indexOf('/cz/cb/viw/retrieveDoccrd') < 0) throw new Error('not a document window');
    if (typeof window.fncClose !== 'function') throw new Error('no close function');
    r.ok = true;
  } catch (e) { r.error = String(e.message || e); }
  document.documentElement.setAttribute('data-doumi-r', doumiJson(r));
})();
'@

# ---- files: only inside Downloads\<folder>; the teacher pressed a button for each ----
$ROOT_NAME = -join ([char[]](0xACF5, 0xBB38, 0x20, 0xC815, 0xB9AC))  # official-documents folder name
$OPEN_OK = @('.hwp', '.hwpx', '.hwt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.csv', '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.zip')
function Get-Root {
  if ($env:DOUMI_TEST_ROOT) { return [IO.Path]::GetFullPath($env:DOUMI_TEST_ROOT) }
  $dl = [DoumiWxs]::Downloads()
  if (-not $dl) { $dl = Join-Path $env:USERPROFILE 'Downloads' }
  return (Join-Path $dl $ROOT_NAME)
}
function Clean-Name([string]$s) {
  $bad = [IO.Path]::GetInvalidFileNameChars()
  $t = (-join ($s.ToCharArray() | ForEach-Object { if ($bad -contains $_) { '_' } else { $_ } })).Trim().TrimEnd('.', ' ')
  if ($t -eq '' -or $t -eq '.' -or $t -eq '..') { throw 'bad-name' }
  if ($t.Length -gt 120) { $e = [IO.Path]::GetExtension($t); $t = $t.Substring(0, 120 - $e.Length) + $e }
  return $t
}
function In-Root([string]$path) {
  $root = Get-Root
  $full = [IO.Path]::GetFullPath($path)
  if (-not $full.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'outside-folder' }
  return $full
}
function File-Path([string]$folder, [string]$name) {
  $dir = Get-Root
  if ($folder) { $dir = Join-Path $dir (Clean-Name $folder) }
  return (In-Root (Join-Path $dir (Clean-Name $name)))
}

function With-Payload([string]$js, $payload) {
  $json = ConvertTo-Json -InputObject $payload -Compress -Depth 5
  return $js.Replace('PAYLOAD', $json)
}

function Pick-One($wins, [string[]]$kinds, $pidWanted, [string]$label) {
  $c = @($wins | Where-Object { $kinds -contains $_.kind -and (-not $pidWanted -or $_.pid -eq [uint32]$pidWanted) })
  if ($c.Count -eq 0) { throw "no-window:$label" }
  if ($c.Count -gt 1) { throw "many-windows:$label" }
  return $c[0]
}

function Handle($req) {
  $args0 = $req.args
  switch ($req.op) {
    'ping' { return @{ ok = $true; version = $VERSION; bits = [IntPtr]::Size * 8 } }
    'windows' {
      Clear-Busy
      if ($args0.keepOpen) { Clear-KeepOpen }
      $list = @(Get-DocWindows | ForEach-Object { @{ pid = $_.pid; kind = $_.kind; path = $_.path } })
      return @{ ok = $true; windows = $list }
    }
    'readDoc' {
      if ($args0.keepOpen) { Clear-KeepOpen }
      $w = Pick-One (Get-DocWindows) @('approve', 'view', 'draft') $args0.pid 'doc'
      $r = Invoke-InPage $w.doc (With-Payload $JS_READ @{ lengthsOnly = [bool]$args0.lengthsOnly })
      $files = $null
      if ($args0.attach) { try { $a = Invoke-InPage $w.doc $JS_ATTACH; if ($a.ok) { $files = @($a.files) } } catch { } }
      return @{ ok = [bool]$r.ok; kind = $w.kind; pid = $w.pid; fields = $r.fields; missing = $r.missing; error = $r.error; files = $files }
    }
    'fillDraft' {
      $w = Pick-One (Get-DocWindows) @('draft') $args0.pid 'draft'
      if (-not (Wait-DocReady $w)) { return @{ ok = $false; pid = $w.pid; error = 'window-busy' } }
      $fields = @{}
      if ($args0.fields) { foreach ($p in $args0.fields.PSObject.Properties) { $fields[$p.Name] = [string]$p.Value } }
      $disc = $null
      if ($args0.disclosure -and @('partial', 'private', 'public') -contains $args0.disclosure.mode) {
        $disc = @{ mode = [string]$args0.disclosure.mode; reasons = @($args0.disclosure.reasons | Where-Object { $_ -ge 1 -and $_ -le 8 } | ForEach-Object { [int]$_ }) }
      }
      $r = Invoke-InPage $w.doc (With-Payload $JS_FILL @{ title = $args0.title; fields = $fields; disclosure = $disc; attachPrivate = [bool]$args0.attachPrivate })
      if ($args0.front) { try { [DoumiWxs]::Front($w.ie) } catch { } }
      return @{ ok = [bool]$r.ok; pid = $w.pid; done = $r.done; missing = $r.missing; error = $r.error }
    }
    'readPicks' {
      $w = Pick-One (Get-DocWindows) @('approve', 'draft') $args0.pid 'doc'
      $r = Invoke-InPage $w.doc $JS_READ_PICKS
      return @{ ok = [bool]$r.ok; cnrs = @($r.cnrs | Where-Object { $_ }); tkcrd = @($r.tkcrd | Where-Object { $_ }); tkcrdId = @($r.tkcrdId | Where-Object { $_ }); error = $r.error }
    }
    # Fill viewers and task card in the document window. Nothing goes to the server here; the teacher submits.
    'fillPicks' {
      $w = Pick-One (Get-DocWindows) @('approve', 'draft') $args0.pid 'doc'
      $script:Notes = @()
      $res = @{ ok = $true; cnrs = $null; tkcrd = $null; error = $null }
      $now = Invoke-InPage $w.doc $JS_READ_PICKS
      if ($args0.tkcrd -and -not @($now.tkcrd | Where-Object { $_ }).Count) {
        $pop = Open-Popup $w 'fncChooseTkcrd' '*taskChoise*'
        if (-not $pop) { $res.ok = $false; $res.error = 'no-popup' }
        else {
          $tr = $null
          for ($t = 0; $t -lt 20; $t++) {
            $tr = Invoke-Timed $pop.doc (With-Payload $JS_TKCRD @{ name = [string]$args0.tkcrd; last = ($t -eq 19) })
            if (-not $tr.wait) { break }
            Start-Sleep -Milliseconds 500
          }
          $res.tkcrd = @{ ok = [bool]$tr.ok; missing = [bool]$tr.missing; error = $tr.error }
          if ($tr.ok) { Start-Sleep -Milliseconds 1500 }
          $gone = Finish-Popup $pop $(if ($tr.ok) { 'tkcrdOk' } else { 'close' }) '*taskChoise*'
          if ($tr.ok -and -not $gone) { $res.ok = $false; $res.tkcrd.ok = $false; $res.tkcrd.error = 'popup-stays' }
        }
      }
      # people on the approval line: the page refuses them with a message box, so they are left out here
      $inLine = @((Invoke-InPage $w.doc $JS_READ_LINE).line | ForEach-Object { [string]$_.name })
      $names = @($args0.cnrs | Where-Object { $_ -and @($now.cnrs) -notcontains $_ -and $inLine -notcontains $_ })
      $res.inLine = @($args0.cnrs | Where-Object { $inLine -contains $_ })
      if ($names.Count) {
        $pop = Open-Popup $w 'fncCnrsAppn' '*/cz/cb/wrt/retrieveCnrsAppn.do'
        if (-not $pop) { $res.ok = $false; $res.error = 'no-popup' }
        else {
          $cr = Invoke-Timed $pop.doc (With-Payload $JS_CNRS @{ names = @($names) })
          $res.cnrs = @{ ok = [bool]$cr.ok; added = @($cr.added | Where-Object { $_ }); missing = @($cr.missing | Where-Object { $_ }); twin = @($cr.twin | Where-Object { $_ }); error = $cr.error }
          $gone = Finish-Popup $pop $(if ($cr.ok -and @($cr.added | Where-Object { $_ }).Count) { 'cnrsOk' } else { 'close' }) '*/cz/cb/wrt/retrieveCnrsAppn.do'
          if ($cr.ok -and -not $gone) { $res.ok = $false; $res.cnrs.ok = $false; $res.cnrs.error = 'popup-stays' }
        }
      }
      $null = Invoke-InPage $w.doc (With-Payload $JS_MARK @{ tkcrd = [bool]($res.tkcrd -and $res.tkcrd.ok); cnrs = [bool]($res.cnrs -and $res.cnrs.ok -and @($res.cnrs.added).Count) })
      if ($args0.front) { try { [DoumiWxs]::Front($w.ie) } catch { } }
      $res.notes = @($script:Notes)
      return $res
    }
    'readPickLists' {
      $script:Notes = @()
      $w = Pick-One (Get-DocWindows) @('approve', 'draft') $args0.pid 'doc'
      $cards = @(); $people = @()
      $pop = Open-Popup $w 'fncChooseTkcrd' '*taskChoise*'
      if ($pop) {
        for ($t = 0; $t -lt 20; $t++) {
          $r = Invoke-Timed $pop.doc $JS_CARDS
          if (-not $r.wait) { $cards = @($r.list | Where-Object { $_ }); break }
          Start-Sleep -Milliseconds 500
        }
        $null = Finish-Popup $pop 'close' '*taskChoise*'
      }
      $pop = Open-Popup $w 'fncCnrsAppn' '*/cz/cb/wrt/retrieveCnrsAppn.do'
      if ($pop) {
        for ($t = 0; $t -lt 20; $t++) {
          $r = Invoke-Timed $pop.doc $JS_PEOPLE
          if (-not $r.wait) { $people = @($r.list | Where-Object { $_ }); break }
          Start-Sleep -Milliseconds 500
        }
        $null = Finish-Popup $pop 'close' '*/cz/cb/wrt/retrieveCnrsAppn.do'
      }
      return @{ ok = $true; cards = $cards; people = $people; error = $null }
    }
    'readLine' {
      $w = Pick-One (Get-DocWindows) @('approve', 'draft') $args0.pid 'doc'
      $r = Invoke-InPage $w.doc $JS_READ_LINE
      return @{ ok = [bool]$r.ok; line = @($r.line | Where-Object { $_ }); error = $r.error }
    }
    # Fill the approval line of a new draft. Nothing goes to the server here; the teacher submits.
    'fillLine' {
      $script:Notes = @()
      $w = Pick-One (Get-DocWindows) @('draft') $args0.pid 'draft'
      $pop = Open-Popup $w 'fncReportCours' '*/cz/cb/wrt/retrieveReportCoursSetintup.do'
      if (-not $pop) { return @{ ok = $false; error = 'no-popup' } }
      $line = @($args0.line | ForEach-Object { @{ name = [string]$_.name; position = [string]$_.position; at = [string]$_.at } })
      $r = $null
      for ($t = 0; $t -lt 40; $t++) {
        $r = Invoke-Timed $pop.doc (With-Payload $JS_LINE @{ line = $line; last = ($t -eq 39) })
        if (-not $r.wait) { break }
        Start-Sleep -Milliseconds 500
      }
      $added = @($r.added | Where-Object { $_ })
      $res = @{ ok = [bool]$r.ok; kept = [bool]$r.kept; added = $added; missing = @($r.missing | Where-Object { $_ }); twin = @($r.twin | Where-Object { $_ }); absent = @($r.absent | Where-Object { $_ }); kindMiss = @($r.kindMiss | Where-Object { $_ }); ats = @($r.ats | Where-Object { $_ }); error = $r.error }
      $gone = Finish-Popup $pop $(if ($r.ok -and $added.Count) { 'lineOk' } else { 'close' }) '*/cz/cb/wrt/retrieveReportCoursSetintup.do'
      if (-not $gone) { $res.ok = $false; $res.error = 'popup-stays' }
      if ($args0.front) { try { [DoumiWxs]::Front($w.ie) } catch { } }
      $res.notes = @($script:Notes)
      return $res
    }
    # Fill receivers of a draft by exact organization name. Nothing goes to the server here.
    'fillRcver' {
      $script:Notes = @()
      $w = Pick-One (Get-DocWindows) @('draft') $args0.pid 'draft'
      $pop = Open-Popup $w 'fncRcverAppn' '*/cz/cb/wrt/retrieveRcverSetup.do'
      if (-not $pop) { return @{ ok = $false; error = 'no-popup' } }
      $added = @(); $missing = @(); $twin = @()
      # receivers already set stay as they are (pressing the panel button twice must not add them again)
      $have = 0
      for ($t = 0; $t -lt 20; $t++) {
        try { $have = [int](Invoke-Timed $pop.doc (With-Payload $JS_RCVER @{ count = $true })).state; break } catch { Start-Sleep -Milliseconds 500 }
      }
      if ($have -gt 0) {
        $gone = Finish-Popup $pop 'close' '*/cz/cb/wrt/retrieveRcverSetup.do'
        return @{ ok = [bool]$gone; kept = $true; added = @(); missing = @(); twin = @(); notes = @($script:Notes); error = $(if ($gone) { $null } else { 'popup-stays' }) }
      }
      foreach ($n in @($args0.names | Where-Object { $_ })) {
        $null = Invoke-Timed $pop.doc (With-Payload $JS_RCVER @{ name = [string]$n; search = $true })
        $st = 'wait'
        for ($t = 0; $t -lt 24 -and $st -eq 'wait'; $t++) {
          Start-Sleep -Milliseconds 500
          $st = (Invoke-Timed $pop.doc (With-Payload $JS_RCVER @{ name = [string]$n; search = $false })).state
        }
        if ($st -eq 'adding') {
          # the popup's add function finishes on its own time; a refused one raises a message box (Notes)
          for ($t = 0; $t -lt 20 -and $st -eq 'adding'; $t++) {
            Start-Sleep -Milliseconds 300
            $c = $have
            try { $c = [int](Invoke-Timed $pop.doc (With-Payload $JS_RCVER @{ count = $true })).state } catch { }
            if ($c -gt $have) { $have = $c; $st = 'added' }
          }
        }
        if ($st -eq 'added') { $added += [string]$n } elseif ($st -eq 'twin') { $twin += [string]$n } else { $missing += [string]$n }
      }
      $res = @{ ok = $true; added = $added; missing = $missing; twin = $twin; error = $null }
      $gone = Finish-Popup $pop $(if ($added.Count) { 'rcverOk' } else { 'close' }) '*/cz/cb/wrt/retrieveRcverSetup.do'
      if (-not $gone) { $res.ok = $false; $res.error = 'popup-stays' }
      if ($args0.front) { try { [DoumiWxs]::Front($w.ie) } catch { } }
      $res.notes = @($script:Notes)
      return $res
    }
    # Add files to a draft. Only files inside the official-documents folder.
    'attachAdd' {
      $w = Pick-One (Get-DocWindows) @('draft') $args0.pid 'draft'
      $list = @()
      foreach ($f in @($args0.files)) {
        $full = In-Root ([string]$f.path)
        if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw 'no-file' }
        $list += @{ path = $full; name = [IO.Path]::GetFileName($full); size = [long](Get-Item -LiteralPath $full).Length }
      }
      if (-not (Wait-DocReady $w)) { return @{ ok = $false; error = 'window-busy' } }
      $r = Invoke-InPage $w.doc (With-Payload $JS_ATTACH_ADD @{ files = $list })
      return @{ ok = [bool]$r.ok; added = @($r.added | Where-Object { $_ }); blocked = @($r.blocked | Where-Object { $_ }); count = $r.count; error = $r.error }
    }
    # Open a document window from the wxsclient:// address the K-Edufine page got from its own server (browsers block repeated protocol launches without a click).
    'launchDoc' {
      $u = [string]$args0.url
      if ($u -notmatch '^wxsclient://handysoft\.co\.kr/open&') { throw 'not-allowed-url' }
      Start-Process -FilePath $u
      return @{ ok = $true }
    }
    'closeDoc' {
      $w = Pick-One (Get-DocWindows) @('approve', 'view') $args0.pid 'doc'
      $r = Invoke-InPage $w.doc $JS_CLOSE
      if (-not $r.ok) { return @{ ok = $false; error = $r.error } }
      try { $w.doc.parentWindow.execScript('window.setTimeout(function () { try { window.fncClose(); } catch (x) {} }, 50);', 'JavaScript') | Out-Null } catch { }
      # wait until it is really gone; a box on top is handled, and if the page's close did nothing, the page's own close without the save question
      $start = Get-Date
      $again = $false
      while (((Get-Date) - $start).TotalSeconds -lt 15) {
        Start-Sleep -Milliseconds 300
        Clear-Busy
        Clear-Alerts
        $pids = [uint32[]](Get-Process WXSClient -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
        if ($pids) { $null = [DoumiWxs]::PressNoSave($pids) }
        if (-not @(Get-AllDocs | Where-Object { $_.ie -eq $w.ie }).Count) {
          # the page is gone; wait for its window too, so the next document does not find it
          $until = (Get-Date).AddSeconds(10)
          while ((Get-Date) -lt $until -and [DoumiWxs]::TopCount([uint32]$w.pid) -gt 0) { Start-Sleep -Milliseconds 200 }
          return @{ ok = $true; error = $null }
        }
        if (-not $again -and ((Get-Date) - $start).TotalSeconds -gt 6) {
          $again = $true
          try { $w.doc.parentWindow.execScript('window.setTimeout(function () { try { if (typeof docCloseRetry === "function") docCloseRetry(); else window.close(); } catch (x) { window.close(); } }, 0);', 'JavaScript') | Out-Null } catch { }
        }
      }
      return @{ ok = $false; error = 'window-stays' }
    }
    'attachSave' {
      $w = Pick-One (Get-DocWindows) @('approve', 'view') $args0.pid 'doc'
      $path = File-Path ([string]$args0.folder) ([string]$args0.name)
      $null = New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($path))
      $r = Invoke-InPage $w.doc (With-Payload $JS_ATTACH_SAVE @{ i = [int]$args0.i; name = [string]$args0.name; path = $path })
      if (-not $r.ok) { return @{ ok = $false; error = $r.error } }
      if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return @{ ok = $false; error = 'not-saved' } }
      $len = (Get-Item -LiteralPath $path).Length
      if ($len -le 0) { return @{ ok = $false; error = 'not-saved' } }
      $head = New-Object byte[] 4
      $fs = [IO.File]::OpenRead($path)
      try { $null = $fs.Read($head, 0, 4) } finally { $fs.Close() }
      return @{ ok = $true; path = $path; size = $len; head = [BitConverter]::ToString($head) }
    }
    # bytes from the panel (a form copy, a file to attach). Chunks because native messages are limited to 1 MB.
    'fileWrite' {
      $path = File-Path ([string]$args0.folder) ([string]$args0.name)
      $null = New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($path))
      $bytes = [Convert]::FromBase64String([string]$args0.b64)
      $mode = if ($args0.append) { [IO.FileMode]::Append } else { [IO.FileMode]::Create }
      $fs = New-Object IO.FileStream($path, $mode, [IO.FileAccess]::Write)
      try { $fs.Write($bytes, 0, $bytes.Length) } finally { $fs.Close() }
      return @{ ok = $true; path = $path; size = (Get-Item -LiteralPath $path).Length }
    }
    'fileRead' {
      $path = In-Root ([string]$args0.path)
      $fs = [IO.File]::OpenRead($path)
      try {
        $size = $fs.Length
        $null = $fs.Seek([long]$args0.offset, [IO.SeekOrigin]::Begin)
        $want = [Math]::Min(600000, [int]$args0.length)
        $buf = New-Object byte[] $want
        $n = $fs.Read($buf, 0, $want)
      } finally { $fs.Close() }
      return @{ ok = $true; size = $size; b64 = [Convert]::ToBase64String($buf, 0, $n); read = $n }
    }
    'fileOpen' {
      $path = In-Root ([string]$args0.path)
      if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'no-file' }
      if ($OPEN_OK -notcontains [IO.Path]::GetExtension($path).ToLowerInvariant()) { throw 'not-allowed-type' }
      Start-Process -FilePath $path
      return @{ ok = $true }
    }
    'folderOpen' {
      $root = Get-Root
      $dir = if ($args0.folder) { Join-Path $root (Clean-Name ([string]$args0.folder)) } else { $root }
      $dir = if ($dir -eq $root) { $root } else { In-Root $dir }
      $null = New-Item -ItemType Directory -Force -Path $dir
      Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $dir + '"')
      return @{ ok = $true; path = $dir }
    }
    default { throw "unknown-op:$($req.op)" }
  }
}

# ---- native messaging loop ----
$stdin = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()
function Read-Full([byte[]]$buf, [int]$count) {
  $off = 0
  while ($off -lt $count) { $n = $stdin.Read($buf, $off, $count - $off); if ($n -le 0) { break }; $off += $n }
  return $off
}
function Send($obj) {
  $b = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $obj -Compress -Depth 6))
  $stdout.Write([BitConverter]::GetBytes([int]$b.Length), 0, 4)
  $stdout.Write($b, 0, $b.Length)
  $stdout.Flush()
}
while ($true) {
  $lenBuf = New-Object byte[] 4
  if ((Read-Full $lenBuf 4) -lt 4) { break }
  $len = [BitConverter]::ToInt32($lenBuf, 0)
  if ($len -le 0 -or $len -gt 1048576) { break }
  $buf = New-Object byte[] $len
  if ((Read-Full $buf $len) -lt $len) { break }
  $req = $null
  try {
    $req = [Text.Encoding]::UTF8.GetString($buf) | ConvertFrom-Json
    $res = Handle $req
    $res.id = $req.id
    Send $res
  } catch {
    Send @{ id = $(if ($req) { $req.id } else { $null }); ok = $false; error = "$($_.Exception.Message)" }
  }
}
