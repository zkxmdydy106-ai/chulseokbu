// 교과담임 > 시간표관리 > 전체시간표조회 (2026-11-06 실제 조사, 읽기만 — docs/probe/neis-timetable-2026-11-06.md)
// 빈 시간 찾기·오늘 내 수업: [강의실별조회]를 날짜로 조회하면 그날 실제 수업(바뀐 수업 포함)이 '과목(선생님)'으로 나온다.
// 결과는 보고서(크라운릭스)라 뷰어가 받은 자료를 content/report-hook.js가 잡고 엔진 reportGrab이 돌려준다. 학년마다 한 번 조회.
// 메뉴 열기·조회는 교사가 [시간표 가져오기]·[찾기]를 누를 때만. 저장·출력 단추는 누르지 않는다.
(() => {
  globalThis.Doumi.screens.register({
    id: 'neis.timetable', site: 'neis', otp: false, feature: 'freetime', title: '전체시간표조회', short: '시간표',
    appId: 'edu/sw/his/edc/tm/his_edctm06_m00', menu: { menuId: 'AMHIS40388', prefer: '002002' },
    report: {
      dataMap: 'dmSearch', from: 'bgngYmd', to: 'endYmd', button: 'btnSearch',
      radio: { id: 'rdbClrmClsAccItrt', value: '1' }, // 강의실별조회(1) — 반·강의실 칸 모두, 그날 바뀐 수업 포함
      udcs: ['udcswcauth1', 'udcswcauth2', 'udcswcauth3', 'udcswcauth4'], // 학년도·학기·과정(주간)·학년 고르기 칸
      gradeUdc: 'udcswcauth4', // 학년 칸(목록 이름이 '1'·'2'·'3' 숫자뿐, 2026-11-06 실제)
    },
    readOnly: true,
  });
})();
