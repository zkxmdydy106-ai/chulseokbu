// 평가 화면(교과담임): 성취기준관리, 문항정보표관리. 화면 위쪽 조건(학년도·학기·과목·고사)은 나이스에 이미 고른 그대로 조회한다.
// 근거: docs/probe/neis-screens-2026-10-27.md (2026-10-27 읽기 전용 조사). '확인 필요' 값은 첫 실제 시험(1건)으로 고친다.
(() => {
  const reg = (s) => globalThis.Doumi.screens.register({ site: 'neis', otp: false, ...s });

  // N2 성취기준: dsStr 한 줄 = 성취기준 하나. 있는 코드는 내용·영역을 고치고, 없는 코드는 [행추가]로 새 줄을 만든다(지우지는 않음).
  // 확인 필요: [행추가]가 대화상자 없이 빈 줄을 만드는지, 새 줄에 evlCriaSccesCtrCd('01')를 넣어야 하는지
  reg({
    id: 'neis.assess.standard', feature: 'standard', title: '성취기준관리', short: '성취기준',
    appId: 'edu/sw/his/scr/pp/his_scrpp30_m01', menu: { menuId: 'AMHIS40480', prefer: '002002' },
    wrapperAppIds: ['edu/sw/his/scr/pp/his_scrpp30_m00'],
    grid: 'grdMain', dataset: 'dsStr',
    columns: { code: 'sccesCtrCd', cria: 'evlCriaSccesCtrCd', area: 'relmNo', areaName: 'relmNm', text: 'sccesCtrCn', closed: 'ddlnYn' },
    areas: { dataset: 'dsRelmNm', no: 'relmNo', name: 'relmNm' },
    newRow: { evlCriaSccesCtrCd: '01' },
    search: { button: 'btnSearch' },
    insert: { button: 'btnInsert' },
    save: { button: 'btnSave', submission: 'subSave', forbidden: ['btnDelete', 'btnData', 'btnUpld'] },
  });

  // N2 성취수준(평가기준): 성취기준관리 래퍼(m00)의 [성취수준(평가기준)관리] 단계(btnStep02)로 연다.
  // 왼쪽 dsRelm = 성취기준 × 수준 한 줄씩(수준이 아직 없으면 성취기준마다 한 줄), 줄을 누르면 subEvlCtr → 오른쪽 dsEvl(수준마다 한 줄: evlCtrCd 1~, evlCtrNm 상중하 또는 A~E, evlCtrCn 글)
  // 2022 개정(chasu 795~)은 A~E 5단계, 그 전은 상·중·하. 1~3단계는 꼭 채워야 하고 순서대로, 4000바이트까지(화면 스크립트 doRowValueCeck).
  // 저장 btn1 → 확인 창 → subSave(dsEvl·dsRelm) → 다시 조회 → 알림. 근거: 2026-10-28 화면 스크립트(his_scrpp30_m02) 읽기.
  // 확인 필요: 줄 누르기(그리드 DOM)가 실제로 subEvlCtr를 부르는지, 저장 확인 창 문구(CM-CMC-0003)
  reg({
    id: 'neis.assess.levels', feature: 'levels', title: '성취수준(평가기준)관리', short: '평가기준',
    appId: 'edu/sw/his/scr/pp/his_scrpp30_m02', menu: { menuId: 'AMHIS40480', prefer: '002002' },
    step: { appId: 'edu/sw/his/scr/pp/his_scrpp30_m00', button: 'btnStep02' },
    grid: 'grdSccesCtr', dataset: 'dsRelm',
    columns: { code: 'sccesCtrCd', cria: 'evlCriaSccesCtrCd', text: 'sccesCtrCn', area: 'relmNm', count: 'rcnt', levelName: 'evlCtrNm', levelText: 'evlCtrCn' },
    detail: { grid: 'grdEvlCtr', dataset: 'dsEvl', submission: 'subEvlCtr', no: 'evlCtrCd', name: 'evlCtrNm', text: 'evlCtrCn', code: 'sccesCtrCd' },
    chasu: { dataMap: 'dmSearch', column: 'chasu', from: 795 },
    maxBytes: 4000, required: 3,
    search: { button: 'btnSearch' },
    save: { button: 'btn1', submission: 'subSave', forbidden: ['btn2', 'btnPrint'] },
  });

  // N3 문항정보표: 객관식 dsObt / 서답형 dsSbjct, 문항마다 한 줄(문항 수는 나이스에서 먼저 정해 둠). 줄을 만들거나 지우지 않는다.
  // 난이도 quitmDffly 1 어려움·2 보통·3 쉬움, 배점 allot, 정답 col1~col5(객관식은 체크, 서답형은 col1 글), 복수정답 plsc 0 없음·1 AND·2 OR·3 2개 이상·4 ALL
  // 확인 필요: 정답 체크 칸 값 모양(나이스 값에서 알아내고, 모르면 '1'/'0')
  reg({
    id: 'neis.assess.items', feature: 'items', title: '문항정보표관리', short: '문항정보표',
    appId: 'edu/sw/his/scr/pe/his_scrpe00_m00', menu: { menuId: 'AMHIS40487', prefer: '002002' },
    types: {
      G: { name: '객관식', dataset: 'dsObt', grid: 'grdObt', pes: 'obtPesScr' },
      J: { name: '서답형', dataset: 'dsSbjct', grid: 'grdSbjct', pes: 'sbjctPesScr' },
    },
    columns: { no: 'seq', text: 'quitmSbmsnCn', area: 'relmNo', level: 'quitmDffly', allot: 'allot', plsc: 'plsc', answers: ['col1', 'col2', 'col3', 'col4', 'col5'] },
    totals: { dataset: 'dsCoranAllot', closed: 'ddlnYn', done: 'coranAllotInptCmptnYn' },
    // 서답형 첨부파일(채점기준표, 과목·고사마다 한 개). 마감(ddlnYn)·정답배점 입력완료(coranAllotInptCmptnYn)면 나이스가 삭제 버튼을 숨김 → 붙이지 않음
    // 파일을 고르면 나이스 파일 서버로 바로 올라가고(subFileList), 링크(dmAtchFile.screAtchFileCn)는 [저장](subSave)이 함께 저장. btnFileDelete(삭제)는 누르지 않음
    attach: { uploader: 'udcSingleUploader', picker: 'udcRaonkSingleUpload', dataMap: 'dmAtchFile', nameColumn: 'fileNm', idColumn: 'screAtchFileCn', accept: ['hwp', 'hwpx', 'pdf'] },
    exams: { '3': '1회고사', '4': '2회고사' },
    // 조회 조건(앞에서 뒤로 이어짐: 학기 → 고사 → 학년 → 과목). 패널에서 고르면 나이스 칸을 그대로 고름(2026-10-28 실제 확인: 학년을 바꾸면 과목 목록이 다시 불러와짐)
    picks: [{ key: 'sem', udc: 'udcSem', label: '학기' }, { key: 'exam', udc: 'udcExmNo', label: '고사' }, { key: 'grade', udc: 'udcOrdGrdDddepCd', label: '학년' }, { key: 'subject', udc: 'udcOsuCd', label: '과목' }],
    answerOn: '1', answerOff: '0',
    // 성취기준 연결(N3, 2026-10-29 실제 확인 — 읽기만): 목록은 [성취기준] 칸이 여는 '성취기준자료 가져오기' 창(his_scrpp50_p02)의 dsSccesCtrList
    // (성취기준 × 성취수준 A~E 줄, 코드는 뒤 빈칸 붙은 26자). 창이 돌려주는 값 그대로 문항 줄 7칸에 넣는다: 여러 개는 '^'로 잇고
    // sccesCtrCn만 빈칸으로 이음, relmNo는 가장 작은 영역. 한 문항 6개·sccesCtrCnList 500바이트까지(창 규칙 mnMaxCnt·mnMaxLen)
    std: {
      popup: 'edu/sw/his/scr/pp/his_scrpp50_p02', list: 'dsSccesCtrList', menuName: 'his_scrpe00_m00', title: '문항정보표-성취기준자료 가져오기',
      listColumns: ['sccesCtrCd', 'evlCriaSccesCtrCd', 'sccesCtrCn', 'relmNo', 'relmNm', 'evlCtrNm', 'evlCtrCn'],
      columns: { area: 'relmNo', areas: 'relmNoList', codes: 'sccesCtrCdList', crias: 'evlCriaSccesCtrCdList', texts: 'sccesCtrCnList', text: 'sccesCtrCn', count: 'sccesCtrCdCnt' },
      max: 6, maxBytes: 500,
    },
    dataset: 'dsObt',
    search: { button: 'btnSearch' },
    // 학생 답안·분할점수가 이미 있으면 저장 확인 창이 분할점수 경고로 바뀜 → 엔진이 그 창은 누르지 않음(DIALOG_DENY, 선생님이 직접 — 교사 결정 2026-10-29)
    save: { button: 'btnSave', submission: 'subSave', forbidden: ['btnDdln', 'btnDdlnRtrcn', 'btnDelete', 'btnDrft', 'btnCopy', 'btnSbjctClear', 'btnFileDelete'] },
  });

  // N2 수행평가 영역: dsFulEvlRelm 한 줄 = 영역 하나(이름·만점·반영비율). 같은 이름은 고치고, 없는 영역은 [행추가]로 새 줄. 지우지 않음.
  // 확인 필요: [행추가] 뒤 영역번호(fulEvlRelmNo)를 나이스가 채우는지, 새 줄에 반영 여부(cshtRfltYn)를 넣어야 하는지
  reg({
    id: 'neis.assess.areas', feature: 'areas', title: '수행평가영역관리', short: '수행평가 영역',
    appId: 'edu/sw/his/scr/pp/his_scrpp50_m00', menu: { menuId: 'AMHIS40483', prefer: '002002' },
    grid: 'grdMain', dataset: 'dsFulEvlRelm',
    columns: { no: 'fulEvlRelmNo', name: 'fulEvlRelmNm', max: 'relmPesScr', ratio: 'cshtRfltRto', closed: 'ddlnYn' },
    newRow: { cshtRfltYn: 'Y' },
    search: { button: 'btnSearch' },
    insert: { button: 'btnInsert' },
    save: { button: 'btnSave', submission: 'subSave', forbidden: ['btnDelete', 'btnBfrData', 'btnBndeAplcn'] },
  });

  // V2 반영비율 점검(읽기만, 2026-10-29): 반영비율/만점관리 dsRfltRtoPesInfo 한 줄 = 평가 하나.
  // 실제 모양(강경고 2026 기하 2학기): evlSc '정기시험'(examDomainNm '1회고사', exmNo 3) · '수행평가'(examDomainNm 영역 이름, ctrFulRelmNo = 수행평가영역관리 fulEvlRelmNo),
  // cshtRfltYn 반영 여부 Y, cshtRfltRto 반영비율, pesScr 만점, ddlnYn 마감. 화면이 막 열리면 학년도가 비어 '학년도 필수' 알림 → 엔진 search가 채워질 때까지 기다림
  // 저장·등록·삭제·복사는 누르지 않음(점검만)
  reg({
    id: 'neis.assess.ratio', feature: 'ratio', title: '반영비율/만점관리', short: '반영비율 점검',
    appId: 'edu/sw/his/scr/pp/his_scrpp60_m00', menu: { menuId: 'AMHIS40484', prefer: '002002' },
    grid: 'grdMain', dataset: 'dsRfltRtoPesInfo',
    columns: { subject: 'sbjtNm', kind: 'evlSc', kindNo: 'evlScNo', name: 'examDomainNm', exam: 'exmNo', used: 'cshtRfltYn', ratio: 'cshtRfltRto', max: 'pesScr', closed: 'ddlnYn', area: 'ctrFulRelmNo' },
    kinds: { exam: '1', perf: '2' },
    search: { button: 'btnSearch' },
    save: { button: null, forbidden: ['btnSave', 'btnInsert', 'btnDelete', 'btnCopy', 'btnCopy2'] },
  });

  // V2 수행평가 점수: 영역마다 조회(dmSearch.fulEvlRelmNo) → dsFulEvlScrMng 학생별 fulEvlScr(점수)·afeCd/afeNm(결시 등 사유) → 저장
  // 영역 목록·만점은 dsFulEvlRelmAllBySbjt, 사유 코드표는 dsAfeCd. 과목·반은 화면에 고른 그대로.
  // 확인 필요: 영역을 바꾸는 조건 칸 이름(fulEvlRelmNo로 봄), 사유를 넣을 때 점수 칸을 비워야 하는지, 저장 통신 이름
  reg({
    id: 'neis.assess.perf', feature: 'perf', title: '수행평가성적관리', short: '수행평가 점수',
    appId: 'edu/sw/his/scr/fe/his_scrfe30_m00', menu: { menuId: 'AMHIS40498', prefer: '002002' },
    // 조건 칸(2026-11-02 실제): 학년(값 06/2/00685, 글 2) · 과목(글 기하(4)) · 영역(빈 값 = 전체) · 강의실(글 202). 학생은 고른 강의실만 나옴
    picks: { grade: 'udcswcauth4', subject: 'udcswcauth5', area: 'udcswcauth6', room: 'udcswcauth7' },
    gradeColumn: 'grd',
    grid: 'grdMain', dataset: 'dsFulEvlScrMng',
    key: { no: 'clsNo', name: 'stuFlnm', cls: 'clsNm' },
    columns: { score: 'fulEvlScr', afe: 'afeCd', afeName: 'afeNm' },
    areas: { dataset: 'dsFulEvlRelmAllBySbjt', no: 'fulEvlRelmNo', name: 'fulEvlRelmNm', max: 'relmPesScr', ratio: 'cshtRfltRto', closed: 'ddlnYn' },
    reasons: { dataset: 'dsAfeCd', code: 'unyCdValue', name: 'unyCdValueNm' },
    search: { dataMap: 'dmSearch', area: 'fulEvlRelmNo', button: 'btnSearch' },
    save: {
      button: 'btnSave', submission: 'subSaveFulEvlScr',
      forbidden: ['btnDdln', 'btnAllRelmDdln', 'btnDdlnRtrcn', 'btnAllRelmDdlnRtrcn', 'btn15', 'btn5', 'btnBndeFileUpload'],
    },
  });

  // V2 결시생 인정점(교과담임 성적처리): 결시 처리(수행평가성적관리의 사유)가 된 학생 칸에 기준점·인정점을 넣는다.
  // dsGridMain 학생 한 줄, 고사/영역마다 칸이 만들어짐: 'A' + papFulScCd + '_' + colSbjtCd + '_' + exmRelmNo + 접미사
  //   _afe '[질병결시]'(결시 이름) · _afeCd · _acscBasScr 기준점 · _scr 인정점. papFulScCd 1 정기시험 · 2 수행평가
  // 고사/영역 목록 dsAfeStuPapFulAbtUnit(exmNm 이름, evlTrgtPesScr 만점). 상태 dmAcscProdYn(ddlnYn 마감, regYn 인정점 기준 등록).
  // [저장] → (기준점·인정점 빈칸·만점 초과 검사) → 확인 창(SW-SCR-0693) → subSave → 다시 조회 → 알림. [인정점산출]·[인정점삭제]는 누르지 않음.
  // 근거: 2026-10-28 화면 스크립트(his_scrmc05_m00) 읽기. 확인 필요: 확인 창 문구, [수동입력] 없이 값만 바꿔도 저장되는지
  reg({
    id: 'neis.assess.absence', feature: 'absence', title: '결시생인정점관리', short: '결시생 인정점',
    appId: 'edu/sw/his/scr/mc/his_scrmc05_m00', menu: { menuId: 'AMHIS40504', prefer: '002002' }, step: { appId: 'edu/sw/his/scr/mc/his_scrmc00_m00', button: 'btnStep01' }, // AMHIS40667은 숨은 메뉴라 나이스가 오류를 냄(실제 2026-11-02) → 성적산출관리를 열면 첫 단계로 저절로 뜸
    grid: 'grdMain', dataset: 'dsGridMain',
    key: { cls: 'clsNm', no: 'clsNo', name: 'stuFlnm' },
    exams: { dataset: 'dsAfeStuPapFulAbtUnit', kind: 'papFulScCd', perf: '2', sbjt: 'colSbjtCd', no: 'exmRelmNo', name: 'exmNm', max: 'evlTrgtPesScr' },
    cell: { afe: '_afe', afeCd: '_afeCd', base: '_acscBasScr', score: '_scr' },
    status: { dataMap: 'dmAcscProdYn', closed: 'ddlnYn', reg: 'regYn' },
    search: { button: 'btnSearch' },
    save: { button: 'btnSave', submission: 'subSave', forbidden: ['btnAcscProd', 'btnAcscDel', 'btnLock', 'btnAvgScr'] },
  });
})();
