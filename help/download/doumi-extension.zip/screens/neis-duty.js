// 복무 > 일일근무상황조회 (기본 메뉴, 2026-10-28 읽기 전용 조사 — docs/selectors.md)
// 날짜 하나를 조회하면 학교 전체 근무상황이 dsMain에 나온다. 빈 시간 찾기는 성명·기간만 읽는다(근무상황 종류·목적지는 안 읽음).
// 메뉴 열기: 기본 메뉴(dsBaseMenu)의 AMCMC40044 — [찾기]를 누를 때 도우미가 연다(2026-10-29, 실제 열리는지 확인 필요).
//   못 열면 교사가 [기본 메뉴 → 복무 → 일일근무상황조회]를 한 번 열도록 안내한다.
(() => {
  globalThis.Doumi.screens.register({
    id: 'neis.duty.daily', site: 'neis', otp: false, feature: 'freetime', title: '일일근무상황조회', short: '근무상황',
    appId: 'edu/ga/srv/mym/mm/srv_mymmm01_m00', menu: { menuId: 'AMCMC40044', prefer: '' },
    grid: 'grdMain', dataset: 'dsMain',
    columns: { name: 'invlFlnm', period: 'workSittnPrd' },
    search: { dataMap: 'dmSearch', date: 'workYmd', staff: 'srvPsnScCd', teacher: '1', button: 'btnSearch' },
    readOnly: true,
  });
})();
