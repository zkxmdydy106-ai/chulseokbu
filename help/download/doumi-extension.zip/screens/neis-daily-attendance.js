// 나이스 > 학급담임 > 학적 > 출결관리 > 일일출결관리(담임용)
// 근거: docs/selectors.md '출결관리 > 일일출결관리(담임용)' (2026-10-27 조사)
// '확인 필요' 표시가 붙은 값은 첫 실제 테스트(학생 1명) 결과로 고친다.
globalThis.Doumi.screens.register({
  id: 'neis.dailyAttendance',
  site: 'neis',
  title: '일일출결관리(담임)',
  feature: 'attendance',

  appId: 'edu/sw/his/srg/aa/his_srgaa02_m02',
  // 메뉴 열기: 학급담임(002001) > 학적 > 출결관리 > 출결관리. 래퍼 m00과 본 화면 m02가 같이 열린다(2026-10-27 확인)
  menu: { menuId: 'AMHIS40420', prefer: '002001' },
  wrapperAppIds: ['edu/sw/his/srg/aa/his_srgaa02_m00'],
  grid: 'grdMain',
  dataset: 'dsListDdAtte',

  // 조회 조건 (학년도·학년·반·일자)
  // 날짜별(월별) 입력은 date 값을 바꾸고 button(조회)을 눌러 날짜마다 다시 읽는다.
  search: { dataMap: 'dmSearch', year: 'ayr', grade: 'grd', cls: 'clsCd', date: 'atteYmd', chasu: 'chasu', button: 'btnSearch' },
  // 저장 때 '교시만 찍히고 구분 없는 학생' 검사는 교육과정 차수 795 미만에서만 한다(나이스 doDayAtteChk)
  markCheckBelowChasu: 795,

  // 학생 매칭
  key: { no: 'clsNo', name: 'stuFlnm', sameName: 'sameFlnm' },

  columns: {
    kind: 'chulgyulGb',          // 출결구분(그리드 '마감' 칸). 값은 이름('질병결석') — 2026-10-27 화면 스크립트로 확인
    reason: 'atteRmkCn',         // 사유
    closed: ['atteDdlnYn', 'ddlnYn'], // 'Y'면 마감된 줄
  },
  kindFormat: 'label',
  reasonMaxBytes: 300,           // 확인 필요: 나이스 사유 칸 최대 길이. 넘으면 입력 버튼이 꺼진다
  // 사유는 '기타'일 때만 적는다(교사 2026-10-30: "사유는 기타 말고는 안 적어도 돼"). 기타결석은 나이스도 막음(SW-SRG-4156)
  reasonRequired: ['03', '13', '23', '33'],
  recognizedKinds: ['04', '14', '24', '34'], // 출석인정 → 교시 표시 'Ø'

  // 교시 표시: 조회(jo)·1~12교시(gyo1…)·종례(jong). 수업 있음 g1…='Y', 행사 아님 e1…='Y', 최대 교시 totMax
  // 저장 검사: 구분이 있으면 표시가 하나 이상, 표시가 있으면 구분이 있어야 한다(SW-SRG-4023)
  // 출석인정 'Ø'는 2026학년도부터, 그리고 2022 개정(교육과정 차수 795 이상) 학년만 — 2015 개정 학년은 출석인정도 '/'
  // (2026-10-30 나이스 화면 스크립트 his_srgaa02_m02: 'Ø'를 넣는 코드가 chasu >= 795 안에만 있고, 795 미만은 '/'가 없는 출결구분을 저장에서 막음)
  marks: { totMax: 'totMax', first: 'jo', last: 'jong', period: 'gyo', hasClass: 'g', noEvent: 'e', max: 12, absent: '/', recognized: 'Ø', recognizedFromYear: 2026, recognizedFromChasu: 795 },

  // 출결 구분 코드표. 화면의 dsAtteGb를 먼저 쓰고, 못 읽으면 아래 표를 쓴다.
  codeTable: { dataset: 'dsAtteGb', code: 'code', label: 'data' },
  codes: {
    '': '출석',
    '01': '질병결석', '02': '미인정결석', '03': '기타결석', '04': '출석인정결석',
    '11': '질병지각', '12': '미인정지각', '13': '기타지각', '14': '출석인정지각',
    '21': '질병조퇴', '22': '미인정조퇴', '23': '기타조퇴', '24': '출석인정조퇴',
    '31': '질병결과', '32': '미인정결과', '33': '기타결과', '34': '출석인정결과',
  },

  // 저장: btnSave → 확인 창 "저장하시겠습니까?"(도우미가 확인) → subInsertDdAtteDdln → "저장했습니다." 알림
  save: {
    button: 'btnSave',
    submission: 'subInsertDdAtteDdln',
    forbidden: ['btnAtte', 'btnAtteCancle'], // 출결마감·마감취소는 절대 누르지 않는다
  },

  // 개발용 진단에서 값 종류(짧은 값만)를 볼 칼럼
  probe: {
    datasets: ['dsListDdAtte', 'dsListInsertDelete', 'dsAtteGb'],
    columns: ['chulgyulGb', 'jo', 'jong', 'gyo1', 'gyo2', 'gyo3', 'gyo4', 'gyo5', 'gyo6', 'gyo7', 'gyo8',
      'magamGyo1', 'atteDdlnYn', 'ddlnYn', 'sameFlnm', 'dayAtteScCd', 'code'],
    buttons: ['btnSearch', 'btnSave', 'btnAtte', 'btnAtteRmkAplcn'],
  },
});
