// 복무 신청(기본 메뉴 → 복무): 개인초과근무관리 · 개인근무상황관리(연가·병가·조퇴·외출 등) · 개인출장관리
// 근거: docs/probe/neis-duty-apply-2026-10-30.md (2026-10-30 실제 — 메뉴 목록·화면 스크립트 읽기, [신청] 창 열고 읽기, 초과근무 칸 값 넣기·시간합 다시 계산 확인)
// - 메뉴는 기본 메뉴라 MENU_ID 그대로 openMdiMenu로 열림(실제 확인). [신청](btnAply)을 누르면 나이스 안 창(대화상자)이 뜨고, 열자마자 오늘 줄이 하나 있다
// - 창 표는 모두 grdMain. 칸은 선생님이 고르듯 넣는다(입력칸: value + value-change, 콤보: selectItem + selection-change)
// - [승인요청](결재 요청)·[행삭제]·[닫기]는 도우미가 누르지 않는다 — 선생님이 창에서 확인하고 승인요청
// fields: 넣는 순서대로. key = 즐겨찾기 칸('date'는 고른 날짜), type input|date|combo|check, col = 창 줄 데이터셋 칼럼(다시 읽어 확인)
(() => {
  const R = (s) => globalThis.Doumi.screens.register(s);
  const DLG = 'edu/ga/srv/mym/mm/';

  R({
    id: 'neis.dutyApply.overtime', site: 'neis', feature: 'dutyApply', title: '개인초과근무관리', short: '초과근무',
    appId: `${DLG}srv_mymmm02_m00`, menu: { menuId: 'AMCMC40045', prefer: '' },
    apply: {
      open: 'btnAply', dialog: `${DLG}srv_mymmm02_p00`, dataset: 'dsMain', grid: 'grdMain', addRow: 'btnRowAdd',
      // 시각은 입력칸(두 자리 글 '16'·'30'), 시간합은 화면 처리 함수가 계산(평일 저녁 1시간 빼고 하루 4시간까지 — 실제 확인)
      fields: [
        { key: 'date', ctl: 'dtiMtWorkYmd', type: 'date', col: 'mtWorkYmd', label: '초과근무일자', wait: 700 },
        { key: 'typ', ctl: 'cmbMtWorkTypCd', type: 'combo', col: 'mtWorkTypCd', label: '초과근무종별' },
        { key: 'hldy', ctl: 'cbxHldyYn', type: 'check', col: 'hldyYn', label: '휴일' },
        { key: 'fromH', ctl: 'ipbAplyBgngH', type: 'input', col: 'aplyBgngH', label: '시작 시' },
        { key: 'fromM', ctl: 'ipbAplyBgngM', type: 'input', col: 'aplyBgngM', label: '시작 분' },
        { key: 'toH', ctl: 'ipbAplyEndH', type: 'input', col: 'aplyEndH', label: '끝 시' },
        { key: 'toM', ctl: 'ipbAplyEndM', type: 'input', col: 'aplyEndM', label: '끝 분' },
        // 방과후수업 차감 시간(두 자리 글, 시간합에서 빠짐 — 2026-10-30 실제 확인)
        { key: 'dedH', ctl: 'dtiMtWorkItrtDdctH', type: 'input', col: 'mtWorkItrtDdctH', label: '방과후 차감 시간' },
        { key: 'dedM', ctl: 'dtiMtWorkItrtDdctM', type: 'input', col: 'mtWorkItrtDdctM', label: '방과후 차감 분' },
        { key: 'todo', ctl: 'txaMtWorkRsnCn', type: 'input', col: 'mtWorkRsnCn', label: '하여야 할 일' },
      ],
      read: ['mtWorkYmd', 'mtWorkTypCd', 'hldyYn', 'aplyBgngHm', 'aplyEndHm', 'mtWorkItrtDdctH', 'mtWorkItrtDdctM', 'mtWorkH', 'mtWorkM', 'mtWorkRsnCn'],
      total: { h: 'mtWorkH', m: 'mtWorkM' },
      // [이 창 내용을 즐겨찾기로]: 창에서 고른 줄의 칼럼 → 즐겨찾기 칸
      capture: { typ: 'mtWorkTypCd', from: 'aplyBgngHm', to: 'aplyEndHm', dedH: 'mtWorkItrtDdctH', dedM: 'mtWorkItrtDdctM', todo: 'mtWorkRsnCn' },
      forbidden: ['btnAprvDmnd', 'btnRowDel', 'btnCancel', 'btnAdd'],
    },
  });

  R({
    id: 'neis.dutyApply.leave', site: 'neis', feature: 'dutyApply', title: '개인근무상황관리', short: '연가·조퇴·외출',
    appId: `${DLG}srv_mymmm00_m00`, menu: { menuId: 'AMCMC40043', prefer: '' },
    apply: {
      // 교원은 p00(복무구분 3 — 교육공무직은 p01, 이 설정은 p00만)
      open: 'btnAply', dialog: `${DLG}srv_mymmm00_p00`, dataset: 'dsMain', grid: 'grdMain', addRow: 'btnRowAdd',
      // 시각은 콤보: 시 '00'~'23'(끝 시 '01'~'24'), 분 '00'·'05'…'55'. 날짜를 바꾸면 나이스가 일수를 다시 셈(통신) → 넉넉히 기다림
      fields: [
        { key: 'date', ctl: 'dtiWorkYmdFrom', type: 'date', col: 'bgngYmd', label: '시작일', wait: 900 },
        { key: 'date', ctl: 'dtiWorkYmdTo', type: 'date', col: 'endYmd', label: '끝일', wait: 900 },
        { key: 'lclf', ctl: 'cmbWorkSittnLclfCd', type: 'combo', col: 'workSittnLclfCd', label: '근무상황', wait: 500 },
        { key: 'sclf', ctl: 'cmbWorkSittnSclfCd', type: 'combo', col: 'workSittnSclfCd', label: '세부 종류', wait: 400 },
        { key: 'dtl', ctl: 'cmbWorkSittnDtlCd', type: 'combo', col: 'workSittnDtlCd', label: '세부 항목', wait: 300 },
        { key: 'fromH', ctl: 'cmbBgngH', type: 'combo', col: 'bgngH', label: '시작 시' },
        { key: 'fromM', ctl: 'cmbBgngM', type: 'combo', col: 'bgngM', label: '시작 분' },
        { key: 'toH', ctl: 'cmbEndH', type: 'combo', col: 'endH', label: '끝 시' },
        { key: 'toM', ctl: 'cmbEndM', type: 'combo', col: 'endM', label: '끝 분' },
        { key: 'avRsn', ctl: 'cmbAvRsnCd', type: 'combo', col: 'avRsnCd', label: '연가 사유' },
        { key: 'reason', ctl: 'ipbWorkSittnRsnCn', type: 'input', col: 'workSittnRsnCn', label: '사유' },
        { key: 'desti', ctl: 'ipbDestiNm', type: 'input', col: 'destiNm', label: '목적지' },
        { key: 'emg', ctl: 'mse1', type: 'input', col: 'emgCnctTelno', label: '비상연락처' },
      ],
      // 넣은 직후 bgngHm·endHm은 빈칸(승인요청 때 만듦 — 2026-10-30 실제) → 시각은 bgngH·bgngM·endH·endM으로 확인
      read: ['bgngYmd', 'endYmd', 'bgngH', 'bgngM', 'endH', 'endM', 'workSittnLclfCd', 'workSittnSclfCd', 'workSittnDtlCd', 'avRsnCd', 'workSittnRsnCn', 'destiNm', 'workSittnDdTtl', 'workSittnHrTtl', 'workSittnMTtl'],
      total: { d: 'workSittnDdTtl', h: 'workSittnHrTtl', m: 'workSittnMTtl' },
      capture: { lclf: 'workSittnLclfCd', sclf: 'workSittnSclfCd', dtl: 'workSittnDtlCd', fromH: 'bgngH', fromM: 'bgngM', toH: 'endH', toM: 'endM', avRsn: 'avRsnCd', reason: 'workSittnRsnCn', desti: 'destiNm', emg: 'emgCnctTelno' },
      forbidden: ['btnAprvDmnd', 'btnRowDel', 'btnCancel'],
    },
  });

  R({
    id: 'neis.dutyApply.trip', site: 'neis', feature: 'dutyApply', title: '개인출장관리', short: '출장',
    appId: `${DLG}srv_mymmm03_m00`, menu: { menuId: 'AMCMC40046', prefer: '' },
    apply: {
      // 줄 = 출장 기간 하나([기간추가]로 늘림). 출장지 [찾기]·동행자는 창에서 선생님이(도우미는 글만 넣음)
      open: 'btnAply', dialog: `${DLG}srv_mymmm03_p00`, dataset: 'dsBsrp', grid: 'grdMain', addRow: 'btnAddPeriod',
      fields: [
        { key: 'date', ctl: 'dti1', type: 'date', col: 'bgngYmd', label: '시작일', wait: 600 },
        { key: 'date', ctl: 'dti2', type: 'date', col: 'endYmd', label: '끝일', wait: 600 },
        { key: 'fromH', ctl: 'cmb10', type: 'combo', col: 'bgngHh', label: '시작 시' },
        { key: 'fromM', ctl: 'cmb2', type: 'combo', col: 'bgngMm', label: '시작 분' },
        { key: 'toH', ctl: 'cmb3', type: 'combo', col: 'endHh', label: '끝 시' },
        { key: 'toM', ctl: 'cmb4', type: 'combo', col: 'endMm', label: '끝 분' },
        { key: 'sc', ctl: 'cmbBsrpScCd', type: 'combo', col: 'bsrpScCd', label: '출장 구분' },
        { key: 'car', ctl: 'cbxOfflVhcUtilzYn', type: 'check', col: 'offlVhcUtilzYn', label: '공용차량 이용' },
        { key: 'pay', ctl: 'cbxTvctPyrfYn', type: 'check', col: 'tvctPyrfYn', label: '여비 지급하지 않음' }, // Y = 여비 안 받음(실제 칸 이름 '여비지급하지않음')
        { key: 'emg', ctl: 'mse1', type: 'input', col: 'emgCnctTelno', label: '연락처' }, // 출장 창 필수 칸(*연락처)
        { key: 'place', ctl: 'ipbDobtNm', type: 'input', col: 'dobtNm', label: '출장지' },
        { key: 'purpose', ctl: 'ipbBsrpCn', type: 'input', col: 'bsrpCn', label: '목적' },
        { key: 'move', ctl: 'ipbMvmnMteCn', type: 'input', col: 'mvmnMteCn', label: '이동사항' },
      ],
      read: ['bgngYmd', 'endYmd', 'bgngHh', 'bgngMm', 'endHh', 'endMm', 'bsrpScCd', 'dobtNm', 'bsrpCn', 'offlVhcUtilzYn', 'tvctPyrfYn', 'allBsrpHrDdCnt', 'allBsrpHrHCnt', 'allBsrpHrMCnt'],
      total: { d: 'allBsrpHrDdCnt', h: 'allBsrpHrHCnt', m: 'allBsrpHrMCnt' },
      capture: { sc: 'bsrpScCd', fromH: 'bgngHh', fromM: 'bgngMm', toH: 'endHh', toM: 'endMm', place: 'dobtNm', purpose: 'bsrpCn', move: 'mvmnMteCn', car: 'offlVhcUtilzYn', pay: 'tvctPyrfYn', emg: 'emgCnctTelno' },
      forbidden: ['btnAply', 'btnDeletePeriod', 'btnCancel', 'btnDeleteTgpr'],
    },
  });
})();
