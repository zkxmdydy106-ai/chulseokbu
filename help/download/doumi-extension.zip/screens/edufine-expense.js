// 에듀파인 학교회계 > 사업관리 > 품의/정산 > 품의등록(넥사크로 화면 FADMANGEXCN001M01 '품의작성') 설정.
// 근거: 정적 화면 스크립트(로그인 없이 받는 파일, 2026-10-29) — docs/selectors.md '품의'. 실제 화면에서 넣어 본 적은 없음(교사 시험 전).
// 도우미가 하는 것: 메뉴 열기(gfnOpenMenu) · 머리(제목·개요, 비었을 때만) · [행추가] 처리 함수로 품목 줄 만들기 · 품목 칸 값 · 금액 다시 계산.
// 예산(세부사업·세부항목)은 교사가 화면 [예산선택] 창에서 고른다(코드값은 서버 조회 결과에만 있음, 돈이 걸린 칸이라 짐작하지 않음).
// 저장·결재요청·삭제·신규·기본문구적용 등은 부르지 않는다(아래 forbidden — 페이지 함수는 이 목록의 함수를 이름으로도 부르지 않음).
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  D.edufineScreens = D.edufineScreens || {};
  D.edufineScreens.expense = Object.freeze({
    id: 'edufine.expense',
    title: '품의등록',
    menuId: 'A00FAA0104001001',
    menuFn: 'gfnOpenMenu', // mainframe.MainVFrameSet.SubHFrameSet.LeftFrame.form
    formVar: 'gv_frmFADMANGEXCN001M01', // 화면이 열리면 폼 자신을 window에 둔다(화면 스크립트 s2bInit)
    head: 'dsCnsulRegist', // 1줄: sj 제목(300바이트), cnsulPurpsCn 개요(2000바이트), sclCnsulNo 품의번호(저장 뒤 생김)
    budget: 'dsBgtDtlList', // 예산 줄: detlBsnsNm 세부사업, detlIem 세부항목, bgtBlce 예산잔액
    items: 'dsPrdlstDtlList', // 품목 줄(고른 예산 줄로 걸러 보임): prdlstCn 내용 · stndrd 규격 · qty 수량 · thngUnitSeCd 단위 · expectUntpc 예상단가 · expectAmt 예상금액
    units: { dataset: 'dsEAB0005200', code: 'cmmnDetailCd', name: 'cmmnDetailCdNm' },
    addRowFn: 'divAuth2_btnRowAdit_onclick', // [행추가] — 고른 예산 줄의 연결 칸·기본값을 채운 새 줄(rowposition)
    amtFn: 'fnExpectAmtCreat', // 예상금액 = 수량 × 단가, 요구금액 합계
    lenFn: 'fnLenCoSetting', // 제목·개요 바이트 표시
    maxBytes: { sj: 300, cnsulPurpsCn: 2000 },
    forbidden: ['divAuth0_btnAuthR02_onclick', 'divAuth0_btnAuthC03_onclick', 'divAuth0_btnAuthR01_onclick', 'divAuth_btnAuthR01_onclick', 'divAuth_btnAuthC05_onclick',
      'fnSave', 'fnSanctnRequst', 'divMain_btnCnsulBassWordsApplc_onclick', 'divAuth1_btnDelRow_onclick', 'divAuth2_btnAuthRDelRow_onclick', 'divAuth2_btnS2BPrdlstSearch_onclick'],
  });
})();
