// 생기부 글 입력 화면(학급담임): 자율·진로·행동특성. 모두 같은 모양 — 조회 → dsScrgRec(학생별 한 줄)의 글 칸 → 저장
// 근거: docs/probe/neis-screens-2026-10-27.md (2026-10-27 읽기 전용 조사). '확인 필요' 값은 첫 실제 시험(1건)으로 고친다.
// 바이트 한도는 기재요령 기준(한글 3바이트) — 확인 필요
(() => {
  const common = {
    site: 'neis', feature: 'record',
    grid: 'grdMain', dataset: 'dsScrgRec',
    key: { no: 'clsNo', name: 'stuFlnm', sameName: 'sameFlnm' },
    search: { button: 'btnSearch' },         // 화면에 들어 있는 조회 조건(내 반·학기) 그대로 조회
    // OTP(2차 인증)는 교과 세특에만 뜬다(2026-10-29 교사 확인: 자율·진로·행동특성은 OTP 없음) → 세특에만 otp: true
  };
  const reg = (s) => globalThis.Doumi.screens.register({ ...common, ...s });
  // 자율·진로는 메뉴로 열면 [출결관리] 탭이 먼저 열려 조회 조건(과정·학년·반)이 비어 있다 → 조회 전에 [학생부자료기록] 탭을 고른다
  // (2026-10-29 실제 확인: 안 고르면 '과정은(는) 필수 입력입니다.' 행동특성은 처음부터 이 탭이라 그대로)
  const RECORD_TAB = { folder: 'tabFolder', item: '학생부자료기록' };

  reg({
    id: 'neis.record.jayul', title: '자율활동 특기사항', short: '자율', tab: RECORD_TAB,
    appId: 'edu/sw/his/sdl/ce/his_sdlce00_m00', menu: { menuId: 'AMHIS40453', prefer: '002001' },
    text: 'speclActSpablMteCn', maxBytes: 1500,
    words: ['자율', '자치', '자율활동'],
    save: { button: 'btnSave', submission: 'subSaveScrgRec', forbidden: [] },
  });
  // 진로 희망분야(2026-10-29 교사 결정 '넷 다', 2026-10-30 실제 칸 확인): 특기사항과 같은 줄·같은 저장. 희망분야 150바이트(입력창 한도),
  // 특기사항 + 희망분야 합계가 한도를 넘으면 나이스가 저장을 막음. 마감은 줄 칸이 아니라 dmScrgDdln.ddlnYn. 체크된 줄이 있으면 저장 막힘(SW-SCR-0582)
  reg({
    id: 'neis.record.jinro', title: '진로활동 특기사항', short: '진로', tab: RECORD_TAB,
    appId: 'edu/sw/his/sdl/ce/his_sdlce04_m00', menu: { menuId: 'AMHIS40458', prefer: '002001' },
    // 한도 1500바이트(한글 500자) — 교사 확인(2026-10-30, 전에는 기재요령 짐작 2100). 나이스는 특기사항 + 희망분야 합으로 봄
    text: 'speclActSpablMteCn', maxBytes: 1500,
    hope: { column: 'stuHopMteCn', maxBytes: 150 },
    closedMap: { dataMap: 'dmScrgDdln', column: 'ddlnYn' },
    words: ['진로', '진로활동', '희망'],
    save: { button: 'btnSave', submission: 'subSaveScrgRec', clearChecks: true, forbidden: ['btnDelete', 'btnBndeSave', 'btnChrsChg', 'btnExcelUpload', 'btnIsuHr', 'btnEntrJnt', 'btnCwordScan'] },
  });
  reg({
    id: 'neis.record.haengteuk', title: '행동특성 및 종합의견', short: '행동특성', tab: RECORD_TAB,
    appId: 'edu/sw/his/sdl/bg/his_sdlbg00_m00', menu: { menuId: 'AMHIS40474', prefer: '002001' },
    text: 'gnrlzOpiCn', maxBytes: 900, closed: ['ddlnYn'],
    words: ['행동특성', '행특', '종합의견', '행동특성및종합의견'],
    save: { button: 'btnSave', submission: 'subSaveScrgRec', forbidden: ['btnDelete'] },
  });

  // 교과담임: 과목별 세부능력 및 특기사항. 화면 위쪽에 고른 과목·반 그대로 조회. 여러 반이 한 표에 나올 수 있어 반(clsNm)도 맞춘다.
  // 학생별 입력 가능 바이트는 나이스가 othSemInputLen01로 준다(화면 스크립트: 넘으면 SW-SCR-0136). 없으면 1500.
  // 확인 필요: 저장 통신 이름(subSave1/subSave2 중 어느 것)
  // 열 때 함께 뜨는 sym_usmsc99_p04는 '2차인증'(OTP) 창이다(2026-10-29 실제: M-OTP·ARS·PC-OTP). 창 뒤에서도 조회는 되지만 인증 전에는 조회하지 않는다
  reg({
    id: 'neis.record.setuk', title: '과목별 세부능력 및 특기사항', short: '교과 세특',
    appId: 'edu/sw/his/scr/mc/his_scrmc50_m00', menu: { menuId: 'AMHIS40508', prefer: '002002' },
    grid: 'grdMain', dataset: 'dsGridMain',
    key: { no: 'classNo', name: 'stuFlnm', cls: 'clsNm' },
    text: 'genDetaAbtSpablMteCn', maxBytes: 1500, maxBytesColumn: 'othSemInputLen01', enable: { column: 'enableYn', off: 'N' },
    otp: true,                               // 메뉴를 열면 2차 인증(OTP) 창이 먼저 뜸
    words: ['세특', '세부능력', '과목', '교과'],
    save: { button: 'btnSave', submission: 'subSave1', forbidden: ['btnDelete'] },
  });

  // ── 생기부 화면 더하기(2026-10-28 교사 결정 '넷 다', 구조: docs/probe/neis-records4-2026-10-30.md) ──
  const SW_FORBID = (n) => Array.from({ length: n }, (_, i) => i + 1).flatMap((i) => [`btnDelete${i}`, `btnAllCopy${i}`, `btnChrsChg${i}`, `btnCwordScan${i}`]);

  // 동아리활동 특기사항(동아리 담당 교사 메뉴 002003): 메뉴를 열면 껍데기 m00이 '이수시간기준등록' 단계로 열림(2026-10-30 실제)
  // → [동아리활동관리] 단계(btnStep05) → m04 '학생부자료기록' 탭 안의 입력 앱 m06. 부서는 열 때 이미 골라져 있음(여러 부서면 나이스에서 고른 그대로).
  // 여러 학년·반이 섞여 학년+반+번호로 맞춤. 자율동아리(4)는 프로그램 클릭이 '학생부 반영'까지 가는 화면 코드라, 청소년단체(3)는 글이 자동이라 넣지 않음.
  // 이수시간 빈 학생이 하나라도 있으면 나이스가 저장을 막음. 성공 알림 '자료의 저장이 완료되었습니다.'(엔진 0.12.0이 알아봄). 한도 1500은 기재요령 기준(확인 필요)
  reg({
    id: 'neis.record.club', title: '동아리활동 특기사항', short: '동아리',
    appId: 'edu/sw/his/sdl/ce/his_sdlce01_m06', menu: { menuId: 'AMHIS40454', prefer: '002003' },
    step: { appId: 'edu/sw/his/sdl/ce/his_sdlce01_m00', button: 'btnStep05' },
    key: { grade: 'grd', cls: 'clsNm', no: 'clsNo', name: 'stuFlnm', sameName: 'sameFlnm' },
    text: 'speclActSpablMteCn', maxBytes: 1500, extraBytesColumn: 'sportsLength',
    closed: ['scrgClsDdlnYn'],
    skip: { column: 'clubActDptScCd', values: { 3: '청소년단체는 나이스가 글을 정해요', 4: '자율동아리는 나이스에서 직접 넣어 주세요(학생부 반영까지 함께 일어남)' } },
    requiredAll: { column: 'comptHr', message: '이수시간이 빈 학생이 있어 나이스가 저장을 막아요. 나이스에서 [이수시간반영]을 먼저 해 주세요.' },
    words: ['동아리', '동아리활동'],
    save: { button: 'btnSave', submission: 'subSaveScrgRec', forbidden: ['btnDelete', 'btnBndeSave', 'btnChrsChg', 'btnScrgRfltAll', 'btnScrgRfltAllCen', 'btnExcelUpload', 'btnIsuHr', 'btnScrgRflt', 'btnEntrJnt', 'btnCwordScan'] },
  });

  // 개인별 세부능력 및 특기사항(담임): 한 표(dsGridMain)를 탭 6개가 나눠 씀. 2015 개정(chasuFlag false)은 탭 1, 2022 개정은 탭 4 '보통교과및전문교과'
  // (두 탭 글자가 같아 id로 고름 — 2026-10-30 실제). 탭을 바꾸면 고친 값이 되돌려지므로 탭 → 조회 → 넣기 → 그 탭 저장 버튼 순서.
  // 저장 검사는 입력창이 갱신하는 …Len 칸 세 개의 합 ≤ genCanLength(쉼표 든 글자) → 넣을 때 그 칸 길이도 함께 넣음. 학생 칸 stdntCn(번호), 동명이인 칸 없음
  reg({
    id: 'neis.record.personal', title: '개인별 세부능력 및 특기사항', short: '개인별 세특',
    appId: 'edu/sw/his/scr/mc/his_scrmc60_m01', menu: { menuId: 'AMHIS40509', prefer: '002001' },
    grid: 'grdMain', dataset: 'dsGridMain',
    key: { no: 'stdntCn', name: 'stuFlnm' },
    text: 'invlDetaAbtSpablMteCn', maxBytes: 1500, maxBytesColumn: 'genCanLength',
    closedMap: { dataMap: 'dmValues', column: 'finYn' },
    variant: {
      dataMap: 'dmSearch', column: 'chasuFlag',
      options: {
        false: { label: '2015 개정 · 보통교과및전문교과', tab: { folder: 'tabForm', id: '1' }, grid: 'grdMain', text: 'invlDetaAbtSpablMteCn', lenColumn: 'invlDetaAbtSpablMteCnLen', sumLenColumns: ['invlDetaAbtSpablMteCnLen', 'invlCoseDetaAbtSpablMteCnLen', 'invlSpablMteCnLen'], saveButton: 'btnSave1' },
        true: { label: '2022 개정 · 보통교과및전문교과', tab: { folder: 'tabForm', id: '4' }, grid: 'grdMain02', text: 'rakClaDetaAbtSpablMteCn', lenColumn: 'rakClaDetaAbtSpablMteCnLen', sumLenColumns: ['rakClaDetaAbtSpablMteCnLen', 'scdgDetaAbtSpablMteCnLen', 'comptYnDetaAbtSpablMteCnLen'], saveButton: 'btnSave4' },
      },
    },
    words: ['개인별', '개인별세특', '개인별세부능력', '개인별세부능력및특기사항'],
    save: { button: 'btnSave1', submission: 'subSave', forbidden: SW_FORBID(6) },
  });

  // 독서활동상황(담임): 껍데기 m00의 '반별' 탭을 골라야 반 전체 화면 m01이 생기고 스스로 조회(2026-10-30 실제). 영역은 공통(A005), 학기는 화면에 고른 그대로.
  // 한 학생 한 칸 '도서명(저자), 도서명(저자)'. regSize = 이 칸 바이트 + regSizeOld(검사 칸), NBSP·'□'가 있으면 막힘, 빈 글로는 지울 수 없음, 체크된 줄이 있으면 저장 막힘.
  // 한도 숫자는 나이스 모듈 값이라 모름 → 도우미는 길이만 맞추고 한도 검사는 나이스에 맡김(넘으면 나이스 안내 그대로)
  reg({
    id: 'neis.record.reading', title: '독서활동상황', short: '독서',
    appId: 'edu/sw/his/sdl/rd/his_sdlrd00_m01', menu: { menuId: 'AMHIS40473', prefer: '002001' },
    step: { appId: 'edu/sw/his/sdl/rd/his_sdlrd00_m00', tab: { folder: 'tabFolder', item: '반별' } },
    grid: 'grdMain', dataset: 'dsStuRdCls',
    text: 'rreadActSpablMteCn', maxBytes: 0, lenColumn: 'regSize', lenBaseColumn: 'regSizeOld',
    closedMap: { dataMap: 'dmScrgDdln', column: 'ddlnYn' },
    clean: 'reading', noEmpty: true,
    words: ['독서', '독서활동', '도서명', '도서', '책'],
    save: { button: 'btnSave', submission: 'saveHisSdlRdCls02', clearChecks: true, forbidden: ['btnBndeSave', 'btnDelete', 'btnEntrJnt'] },
  });
})();
