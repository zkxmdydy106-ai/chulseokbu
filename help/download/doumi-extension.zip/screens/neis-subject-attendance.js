// 나이스 > 교과담임 > 학적 > 출결관리 > 과목별출결관리
// 근거: docs/probe/neis-screens-2026-10-27.md '과목별출결관리' (2026-10-27, 읽기 전용 조사)
// 흐름: 날짜 조회(dmSearch.atteYmd + btnSearch → 왼쪽 수업 목록) → 수업 줄 고르기(→ 학생 목록) → 학생별 출결 표시 → 저장
globalThis.Doumi.screens.register({
  id: 'neis.subjectAttendance',
  site: 'neis',
  title: '과목별출결관리',
  feature: 'subject',

  appId: 'edu/sw/his/srg/aa/his_srgaa04_m01',
  menu: { menuId: 'AMHIS40738', prefer: '002002' }, // 교과담임 메뉴
  wrapperAppIds: ['edu/sw/his/srg/aa/his_srgaa04_m00'],

  // 날짜 조회 → 왼쪽 수업 목록
  search: { dataMap: 'dmSearch', date: 'atteYmd', button: 'btnSearch', list: 'dsListChrgeTcrPir' },
  // 왼쪽 목록: 교시·과목·반
  periods: {
    grid: 'grdAtteYmd', dataset: 'dsListChrgeTcrPir',
    pir: 'pir', subject: 'etbSbjtNm', cls: 'clsNm', clsCd: 'clsCd', closed: 'atteDdlnNm',
    // 줄을 고를 때 나이스 화면이 조회 조건에 옮겨 넣는 값(화면 스크립트에서 확인)
    copy: {
      etbSbjtCd: 'etbSbjtCd', sem: 'sem', grd: 'grd', pir: 'pir', dghtCrseScCd: 'dghtCrseScCd', ordScCd: 'ordScCd',
      dddepCd: 'dddepCd', tcrIdfId: 'tcrIdfId', abtUnitScCd: 'abtUnitScCd', clrmCd: 'clsCd', clsCd: { col: 'clsCd', last: 2 },
    },
    verify: ['pir', 'etbSbjtCd'],
    submission: 'SubListCurrHrAtteStu',
  },

  // 오른쪽 학생 목록
  grid: 'grd1',
  dataset: 'dsListCurrHrAtteStu',
  key: { no: 'clsNo', name: 'stuFlnm', cls: 'clsNm', sameName: 'sameFlnm' },
  columns: { mark: 'chulScCd', reason: 'atteRmkCn', closed: ['atteDdlnYn'] },
  // chulScCd 값: '/' 결과, 'Ø' 출석인정결과, '' 출석 (화면 툴팁 식에서 확인)
  marks: { '': '출석', '/': '결과', 'Ø': '출석인정결과' },
  reasonMaxBytes: 300, // 확인 필요

  save: {
    button: 'btnSave',
    submission: 'SubSavePirAtteRlt',
    forbidden: ['btnInsert', 'btnPirDdlnYn', 'btnDelete'], // 출결마감·일괄마감·마감취소
  },
});
