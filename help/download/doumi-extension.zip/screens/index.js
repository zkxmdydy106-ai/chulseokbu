// 화면 설정 모음. 화면 하나 = screens/<화면>.js 파일 하나. 엔진 코드는 여기 두지 않는다.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const all = [];
  globalThis.Doumi.screens = {
    all,
    register(screen) { all.push(Object.freeze(screen)); },
    get(id) { return all.find((s) => s.id === id) || null; },
    // 나이스에 열려 있는 앱 ID 목록 → 도우미가 아는 화면들
    match(appIds) { return all.filter((s) => appIds.includes(s.appId)); },
    // 본 화면은 아직 안 열렸지만 단계 래퍼만 열린 경우(예: 출결관리 1단계 화면)
    wrapperOnly(appIds) { return all.filter((s) => !appIds.includes(s.appId) && (s.wrapperAppIds || []).some((w) => appIds.includes(w))); },
  };
})();
