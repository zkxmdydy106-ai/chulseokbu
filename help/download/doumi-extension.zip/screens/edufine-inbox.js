// 에듀파인 > 업무관리 > 결재 > 결재대기 화면 설정. 조사 기록은 docs/selectors.md '결재대기'.
// 에듀파인 화면은 나이스 화면 목록(D.screens)과 따로 둔다(나이스 앱 ID로 찾지 않음).
// 도우미가 누를 수 있는 것은 아래 세 가지뿐: 메뉴의 '결재대기', 목록의 [조회], 교사가 [열기]를 누른 줄의 제목 링크.
globalThis.Doumi = globalThis.Doumi || {};
(() => {
  const D = globalThis.Doumi;
  D.edufineScreens = D.edufineScreens || {};
  D.edufineScreens.inbox = Object.freeze({
    id: 'edufine.sanctnWait',
    title: '결재대기',
    menuId: 'A00AAB',
    listPath: '/bms/cz/cb/viw/retrieveSanctnWaitDocList.do',
    table: 'table#tbList',
    docinfo: 'input[name=docinfo]', // 값 '문서ID,…' → 첫 값이 문서 ID
    openFn: 'doCallClientApp', // 제목 링크 함수 — 이 함수를 부르는 링크만 누른다
    // 머리줄 → 칸. 실제 머리: 선택, 상태, 문서종류, 문서유형, 공개여부, 문서번호, 제목, 기안(발송)부서, 기안(담당)자, 기안일시, 수신/발신
    headers: {
      status: ['상태'],
      kind: ['문서종류'],
      type: ['문서유형'],
      docNo: ['문서번호'],
      title: ['제목'],
      dept: ['기안(발송)부서', '기안부서', '발송부서', '부서'],
      drafter: ['기안(담당)자', '기안자', '담당자'],
      date: ['기안일시', '기안일', '일시'],
      recv: ['수신/발신'],
    },
    searchLabel: '조회',
    // 넥사크로 메뉴: '결재대기'가 안 보이면 위 단계부터 차례로(확인 필요 — 실제 메뉴 구조 미확인)
    menuPath: ['업무관리', '결재', '결재대기'],
    // 이 글자가 든 버튼은 절대 누르지 않는다(동작 원칙 3: 결재·상신은 교사가). 메뉴는 menuPath 글자와 똑같을 때만 누른다
    forbidden: ['일괄', '결재', '상신', '반려', '전결', '대결', '보류', '회수', '삭제', '발송', '접수', '서명'],
    // [조회] 버튼이라도 함수 이름에 이 글자가 있으면 누르지 않는다
    forbiddenFn: ['Batch', 'batch', 'Bundle', 'Delete', 'delete', 'Approv', 'approv', 'Sign', 'sign', 'Report', 'Send', 'send'],
  });

  // 관련 공문 찾기(F1 2단계, 2026-10-29 실제 확인 — docs/selectors.md '문서등록대장'):
  // 메뉴는 넥사크로 왼쪽 프레임 gfnOpenMenu(메뉴ID)로 열고, 검색은 페이지 칸을 채운 뒤 페이지 검색 함수(fncRealSearch)를 부른다.
  // 도우미가 하는 것은 메뉴 열기·칸 채우기·검색까지. 결과 줄의 문서는 교사가 에듀파인에서 직접 연다
  D.edufineScreens.docRegist = Object.freeze({
    id: 'edufine.docRegist',
    title: '문서등록대장',
    menuId: 'A00AAB0107001',
    menuFn: 'gfnOpenMenu', // mainframe.MainVFrameSet.SubHFrameSet.LeftFrame.form
    path: '/bms/cz/cb/dbx/retrieveDocRegistRegstrList.do',
    table: 'table#tbList',
    searchFn: 'fncRealSearch',
    // 채울 칸(폼 paginationInfo). 검색 전에 비우는 칸: 다른 조건이 남아 있으면 엉뚱하게 좁혀지므로
    fields: { docNo: 'docNo', orignlDocNo: 'orignlDocNo', title: 'basicSj', from: 'reportDe', to: 'reportDe3', basicFrom: 'basicReportDe', basicTo: 'basicReportDe3' },
    clear: ['basicSj', 'sj', 'docNo', 'orignlDocNo', 'searchDsptchNmCn', 'reportr'],
    empty: '조회 결과가 없습니다',
  });

  // 기안 공용서식 목록(docs/selectors.md '기안'): 서식 이름 링크 fncFormDraft(서식 ID, 분류, 이름) → 기안 창(WXSClient)
  D.edufineScreens.forms = Object.freeze({
    id: 'edufine.cmmnForms',
    title: '공용서식',
    menuId: 'A00AAB0101001',
    menuFn: 'gfnOpenMenu',
    path: '/bms/cz/cb/wrt/retrieveCmmnFormatList.do',
    table: 'body',
    openFn: 'fncFormDraft',
  });

  // 위쪽 알림 줄 건수(H1 '오늘'): 글자에서 숫자만 읽는다('결재(긴급) 1(0)|' → 결재 1, 긴급 0)
  D.edufineScreens.counts = Object.freeze({
    prefix: 'mainframe.MainVFrameSet.TopFrame.form.divTopGrp.form.divNtzn.form.divNtznDtl.form.',
    items: { sanctn: 'AAB01', cnrs: 'AAB02', progress: 'AAB03' },
  });
})();
