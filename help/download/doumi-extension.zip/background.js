importScripts('shared/sites.js');

// 툴바 아이콘을 누르면 사이드패널을 연다. 패널은 탭과 직접 메시지를 주고받으므로 여기서는 중계하지 않는다.
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch(() => {});

// 설치·업데이트 직후 이미 열려 있는 나이스 탭에도 바로 붙는다(새로고침 없이).
chrome.runtime.onInstalled.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: DoumiSites.neisMatches });
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content/bridge.js'] });
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['engine/neis-engine.js'], world: 'MAIN' });
    } catch { /* 닫히는 중이거나 아직 로딩 중인 탭 */ }
  }
});
