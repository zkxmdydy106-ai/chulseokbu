// 패널 ↔ 나이스 엔진 중계 (content script, isolated world).
// 나이스 화면 객체(eXbuilder6 `cpr`)는 페이지 쪽에만 있으므로, 실제 작업은 engine/neis-engine.js(MAIN world)가 한다.
// 두 세계는 DOM 이벤트로만 이야기한다. detail은 JSON 문자열로 주고받는다.
(() => {
  // 도우미를 설치·업데이트하면 열린 탭에 다시 주입된다. 앞서 주입된 중계가 아직 살아 있으면(같은 판) 두 번 붙지 않는다.
  // 업데이트로 끊긴 옛 중계는 chrome.runtime.id가 사라지므로 새 중계가 대신 붙는다.
  if (typeof window.__doumiBridgeAlive === 'function' && window.__doumiBridgeAlive()) return;
  window.__doumiBridgeAlive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };

  const pending = new Map();
  let seq = 0;

  document.addEventListener('doumi2:res', (e) => {
    let m;
    try { m = JSON.parse(e.detail); } catch { return; }
    const p = m && pending.get(m.id);
    if (!p) return;
    pending.delete(m.id);
    clearTimeout(p.timer);
    p.resolve(m.res);
  });

  function call(op, args, timeout = 15000) {
    return new Promise((resolve) => {
      const id = `q${++seq}${Math.random().toString(36).slice(2, 8)}`;
      const timer = setTimeout(() => {
        pending.delete(id);
        resolve({ ok: false, code: 'timeout', error: '나이스 화면이 응답하지 않아요. 나이스 탭을 새로고침한 뒤 다시 해 주세요.' });
      }, timeout);
      pending.set(id, { resolve, timer });
      document.dispatchEvent(new CustomEvent('doumi2:req', { detail: JSON.stringify({ id, op, args }) }));
    });
  }

  chrome.runtime.onMessage.addListener((msg, _sender, send) => {
    if (!msg || msg.target !== 'neis') return;
    call(msg.op, msg.args, msg.timeout).then(send);
    return true;
  });
})();
