// 나이스 보고서 뷰어 창(/thirdparty/crownix/…) 안에서만: 뷰어가 받은 보고서 자료(MML)를 이 창 메모리에 남긴다.
// 보고서 주소는 한 번만 쓰여 다시 받을 수 없어서(2026-11-06 실제: ERS-12002), 받는 순간의 글을 잡아 둔다.
// 어디로도 보내지 않고, 도우미 엔진(같은 나이스 탭)이 [시간표 가져오기] 때 읽는다. 창이 바뀌면 사라진다.
(() => {
  if (!/\/thirdparty\/crownix\//.test(location.pathname) || window.__doumiReportHook) return;
  window.__doumiReportHook = 1;
  const keep = (url, text) => {
    if (typeof text !== 'string' || !/\/report\/service/.test(String(url)) || !text.includes('<MML')) return;
    window.__doumiMml = { at: Date.now(), text };
  };
  const X = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
  if (X) {
    const open = X.open, send = X.send;
    X.open = function (m, u, ...rest) { this.__doumiUrl = u; return open.call(this, m, u, ...rest); };
    X.send = function (...args) {
      this.addEventListener('load', () => { try { if (!this.responseType || this.responseType === 'text') keep(this.__doumiUrl, this.responseText); } catch (e) { /* 못 읽으면 그만 */ } });
      return send.apply(this, args);
    };
  }
  if (window.fetch) {
    const f = window.fetch;
    window.fetch = function (input, init) {
      const p = f.call(this, input, init);
      const url = typeof input === 'string' ? input : input && input.url;
      if (/\/report\/service/.test(String(url))) p.then((r) => r.clone().text()).then((t) => keep(url, t)).catch(() => {});
      return p;
    };
  }
})();
