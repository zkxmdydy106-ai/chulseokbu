// 보낼 곳: 글 복사 — 클립보드에 넣고, 교사가 원하는 곳(메신저·메모·메일)에 붙여넣는다. 도우미는 어디로도 보내지 않는다.
(() => {
  const D = globalThis.Doumi;
  D.destinations.register({
    id: 'copy',
    label: '글 복사',
    sub: '붙여넣을 곳 어디든',
    order: 10,
    kind: 'copy',
    editable: true,
    build: (items, ctx) => ({ text: D.destinations.text(items, { now: ctx.now }) }),
    async send(out, ctx) {
      const ok = await ctx.copy(out.text);
      return ok ? { ok: true, message: '복사했어요. 붙여넣을 곳에서 Ctrl+V를 누르세요.' }
        : { ok: false, message: '복사하지 못했어요. 미리보기 글이 선택돼 있으니 Ctrl+C를 눌러 주세요.' };
    },
  });
})();
