// 보낼 곳: 글 파일(.txt) — 이 PC의 다운로드 폴더에 저장(downloads 권한 없이 패널에서 내려받기).
(() => {
  const D = globalThis.Doumi;
  D.destinations.register({
    id: 'txt',
    label: '글 파일(.txt)',
    sub: '다운로드 폴더에 저장',
    order: 30,
    kind: 'file',
    editable: true,
    build: (items, ctx) => ({ text: D.destinations.text(items, { now: ctx.now }) }),
    async send(out, ctx) {
      const name = `할일_${D.todo.todayYmd(ctx.now || new Date())}.txt`;
      // 메모장에서 한글이 깨지지 않게 BOM
      ctx.download(name, `\ufeff${out.text.replace(/\n/g, '\r\n')}`, 'text/plain;charset=utf-8');
      return { ok: true, message: `${name} 파일을 내려받았어요(다운로드 폴더). 안 보이면 [다시 받기]를 누르세요.` };
    },
  });
})();
