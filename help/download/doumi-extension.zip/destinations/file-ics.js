// 보낼 곳: 캘린더 파일(.ics) — 아웃룩·구글 캘린더·윈도우 일정 앱에서 '가져오기'로 넣는다. 도우미는 파일만 만든다.
// 기한 날짜만 있으면 하루 종일 일정(알림: 전날 오후 4시), 시각도 있으면 그 시각 30분 일정(알림: 전날 오후 4시 + 1시간 전).
(() => {
  const D = globalThis.Doumi;
  const CRLF = '\r\n';

  const esc = (s) => String(s ?? '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
  // 한 줄 75바이트 접기(UTF-8 글자를 자르지 않게)
  function fold(line) {
    const out = [];
    let cur = '', n = 0;
    for (const ch of line) {
      const b = D.bytes(ch);
      if (n + b > (out.length ? 74 : 75)) { out.push(cur); cur = ''; n = 0; }
      cur += ch; n += b;
    }
    out.push(cur);
    return out.join(`${CRLF} `);
  }
  const pad = (x) => String(x).padStart(2, '0');
  const ymdOf = (d) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
  const addDays = (ymd, n) => ymdOf(new Date(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6) + n));
  const utcStamp = (d) => `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
  // 한국 시각 → UTC 도장(한국은 서머타임 없음, +9)
  const kstToUtc = (ymd, hh, mm) => utcStamp(new Date(Date.UTC(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6), hh - 9, mm)));

  const alarm = (trigger, title) => ['BEGIN:VALARM', 'ACTION:DISPLAY', trigger, `DESCRIPTION:${esc(title)}`, 'END:VALARM'];

  function ics(items, now = new Date()) {
    const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//doumi//todo-export//KO', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH',
      'BEGIN:VTIMEZONE', 'TZID:Asia/Seoul', 'BEGIN:STANDARD', 'DTSTART:19700101T000000', 'TZOFFSETFROM:+0900', 'TZOFFSETTO:+0900', 'TZNAME:KST', 'END:STANDARD', 'END:VTIMEZONE'];
    for (const it of items) {
      const desc = [it.memo, it.source ? `(${it.source})` : ''].filter(Boolean).join('\n');
      const remind = alarm(`TRIGGER;VALUE=DATE-TIME:${kstToUtc(addDays(it.due, -1), 16, 0)}`, it.title);
      L.push('BEGIN:VEVENT', `UID:${it.id || Math.random().toString(36).slice(2)}@doumi.todo`, `DTSTAMP:${utcStamp(now)}`, `SUMMARY:${esc(it.title)}`);
      if (it.time) {
        const [h, m] = it.time.split(':').map(Number);
        const end = new Date(2000, 0, 1, h, m + 30);
        const endYmd = end.getDate() === 2 ? addDays(it.due, 1) : it.due;
        L.push(`DTSTART;TZID=Asia/Seoul:${it.due}T${pad(h)}${pad(m)}00`, `DTEND;TZID=Asia/Seoul:${endYmd}T${pad(end.getHours())}${pad(end.getMinutes())}00`);
        if (desc) L.push(`DESCRIPTION:${esc(desc)}`);
        L.push(...remind, ...alarm('TRIGGER:-PT1H', it.title));
      } else {
        L.push(`DTSTART;VALUE=DATE:${it.due}`, `DTEND;VALUE=DATE:${addDays(it.due, 1)}`, 'TRANSP:TRANSPARENT');
        if (desc) L.push(`DESCRIPTION:${esc(desc)}`);
        L.push(...remind);
      }
      L.push('END:VEVENT');
    }
    L.push('END:VCALENDAR');
    return L.map(fold).join(CRLF) + CRLF;
  }

  D.destinations.register({
    id: 'ics',
    label: '캘린더 파일(.ics)',
    sub: '아웃룩·구글 캘린더로 가져오기',
    order: 40,
    kind: 'file',
    needsDue: true,
    build(items, ctx) {
      const show = items.map((it) => `${D.destinations.dueText(it).replace(/까지$/, '')} · ${it.title}\n   알림: 전날 오후 4시${it.time ? ' · 1시간 전' : ''}`).join('\n');
      return { text: ics(items, ctx.now), show };
    },
    async send(out, ctx) {
      const name = `할일_${D.todo.todayYmd(ctx.now || new Date())}.ics`;
      ctx.download(name, out.text, 'text/calendar;charset=utf-8');
      return { ok: true, message: `${name} 파일을 내려받았어요. 아웃룩: 파일을 두 번 누르기 · 구글 캘린더: 설정 → 가져오기/내보내기 → 이 파일 고르기. 안 보이면 [다시 받기]를 누르세요.` };
    },
  });
  D.destinations.ics = ics;
})();
