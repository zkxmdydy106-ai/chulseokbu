// F2 보낼 곳 등록부. 보낼 곳 하나 = extension/destinations/<이름>.js 한 파일(+ panel.html에 script 한 줄).
//   D.destinations.register({
//     id, label, sub, order,
//     kind: 'copy'(클립보드) | 'file'(내려받기) — 결과 화면의 [다시 복사]/[다시 받기],
//     needsDue: true면 기한 없는 할 일은 빼고 보냄(캘린더 등),
//     editable: true면 미리보기 글을 교사가 고쳐서 보낼 수 있음,
//     build(items, ctx) → { text, show?, skipped, note? }   // 순수 함수(node 시험), items는 이미 가린 것
//     send(out, ctx)    → { ok, message }                    // ctx.copy(text) · ctx.download(name, text, mime)
//   })
// 외부 서비스로 직접 보내는 보낼 곳(카톡 API·구글 캘린더 등)은 교사 승인 + 방침 개정 뒤에만 더한다.
(() => {
  const D = globalThis.Doumi;
  const list = [];

  const md = (ymd) => (/^\d{8}$/.test(ymd) ? `${+ymd.slice(4, 6)}월 ${+ymd.slice(6)}일(${D.weekday(ymd)})` : '');
  const dueText = (it) => (it.due ? `${md(it.due)}${it.time ? ` ${it.time}` : ''}까지` : '기한 없음');

  // 보내기 전 가리기: 제목·메모를 D.mask로. 출처는 이름표만(문서 ID는 빼고)
  function prepare(items) {
    const kinds = {};
    const add = (k) => { for (const [n, c] of Object.entries(k)) kinds[n] = (kinds[n] || 0) + c; };
    const out = items.map((it) => {
      const t = D.mask(it.title), m = D.mask(it.memo);
      add(t.kinds); add(m.kinds);
      return { id: it.id, title: t.text, memo: m.text, due: it.due || '', time: it.time || '', source: it.source?.label || '', masked: t.total + m.total };
    });
    return { items: out, kinds, total: Object.values(kinds).reduce((a, b) => a + b, 0) };
  }

  // 사람이 읽는 글(복사·스티커 메모·.txt 공용)
  function text(items, { header = true, now = new Date() } = {}) {
    const blocks = items.map((it) => {
      const lines = [`□ ${dueText(it)} — ${it.title}`];
      for (const l of String(it.memo || '').split('\n').filter((x) => x.trim())) lines.push(`   ${l.trim()}`);
      if (it.source) lines.push(`   (${it.source})`);
      return lines.join('\n');
    });
    const head = header ? [`할 일 ${items.length}개 · ${md(D.todo.todayYmd(now))} 정리`, ''] : [];
    return [...head, ...blocks].join('\n');
  }

  D.destinations = {
    register(def) {
      if (!def?.id || list.some((d) => d.id === def.id)) return;
      list.push({ order: 50, kind: 'copy', needsDue: false, editable: false, sub: '', ...def });
      list.sort((a, b) => a.order - b.order);
    },
    all: () => [...list],
    get: (id) => list.find((d) => d.id === id) || null,
    prepare,
    text,
    dueText,
    // 보낼 곳 하나의 미리보기: 기한 필요한 곳은 기한 없는 것을 뺀다
    build(dest, prepared, ctx = {}) {
      const usable = dest.needsDue ? prepared.items.filter((it) => it.due) : prepared.items;
      const skipped = prepared.items.length - usable.length;
      if (!usable.length) return { text: '', skipped, empty: true, note: dest.needsDue ? '기한이 있는 할 일이 없어 보낼 게 없어요.' : '' };
      const out = dest.build(usable, ctx);
      return { ...out, skipped, ids: usable.map((it) => it.id), note: [out.note, skipped ? `기한 없는 할 일 ${skipped}개는 뺐어요.` : ''].filter(Boolean).join(' ') };
    },
  };
})();
