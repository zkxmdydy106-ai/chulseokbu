// 보낼 곳: 윈도우 스티커 메모 — 스티커 메모는 브라우저에서 여는 주소(프로토콜)가 없어(2026-10-28 이 PC에서 확인)
// 글을 복사해 두고 여는 방법을 알려 준다. 스티커 메모의 마이크로소프트 계정 동기화는 윈도우 설정을 따른다.
(() => {
  const D = globalThis.Doumi;
  D.destinations.register({
    id: 'sticky',
    label: '스티커 메모',
    sub: '복사 → 스티커 메모에 붙여넣기',
    order: 20,
    kind: 'copy',
    editable: true,
    build: (items, ctx) => ({ text: D.destinations.text(items, { header: false, now: ctx.now }) }),
    async send(out, ctx) {
      const ok = await ctx.copy(out.text);
      const how = '키보드 Win 키 → "스티커 메모" 입력 → 열린 메모에서 Ctrl+N(새 메모) → Ctrl+V.';
      return ok ? { ok: true, message: `복사했어요. ${how}` }
        : { ok: false, message: `복사하지 못했어요. 미리보기 글을 Ctrl+C로 복사한 뒤 ${how}` };
    },
  });
})();
