// 나이스 길잡이 글(신규 교사용, 2026-10-30 교사 요청: 출결 + 평가계획·문항정보표·수행평가).
// - 화면(앱)·컨트롤 ID는 extension/screens/*.js, docs/selectors.md, docs/probe/neis-screens-2026-10-27.md에 있는 것만 쓴다(짐작 금지).
// - 확실하지 않은 것(마감 시기, 학교 규정)은 '학교 규정 확인'으로 둔다. 글에는 학생 정보가 없다.
// 길잡이: { id, group, title, who, summary, menu: { menuId, prefer, path, apps }, open, steps, tips }
//   menu.path는 메뉴 목록을 못 읽을 때 쓰는 이름(업무 탭 … 화면), menu.apps는 메뉴로 열면 뜨는 화면(하나라도 뜨면 메뉴 단계 끝)
//   open은 [메뉴 바로 열기] — panel/neis.js open()에 그대로 줌(누를 때만, 조회는 안 함)
// 단계: { title, body, caution, look, targets, when, figure }
//   look: press(눌러요) · see(보기만) · nopress(지금은 누르지 마세요) / when이 없으면 말풍선 [다음]으로 넘김
//   targets: { app, id } 컨트롤 · { app, id, text } 컨트롤 안의 그 글자(표 머리 칸) · { app, text, near } 그 컨트롤 가까운 글자
//   when: { clicked: true } 테두리 친 곳을 누름 · { app } 화면이 열림 · { rows: { app, dataset, min } } 표에 줄이 생김(값은 안 읽음) — 적힌 것이 모두 맞아야
(() => {
  const D = globalThis.Doumi = globalThis.Doumi || {};
  const P = 'edu/sw/his/';
  const DAILY_W = `${P}srg/aa/his_srgaa02_m00`, DAILY = `${P}srg/aa/his_srgaa02_m02`;
  const SUBJ_W = `${P}srg/aa/his_srgaa04_m00`, SUBJ = `${P}srg/aa/his_srgaa04_m01`;
  const STD_W = `${P}scr/pp/his_scrpp30_m00`, STD = `${P}scr/pp/his_scrpp30_m01`, LVL = `${P}scr/pp/his_scrpp30_m02`;
  const AREA = `${P}scr/pp/his_scrpp50_m00`, RATIO = `${P}scr/pp/his_scrpp60_m00`, ITEMS = `${P}scr/pe/his_scrpe00_m00`;
  const PERF = `${P}scr/fe/his_scrfe30_m00`, ABS_W = `${P}scr/mc/his_scrmc00_m00`, ABS = `${P}scr/mc/his_scrmc05_m00`;
  const search = (app, extra = '') => ({ title: '[조회] 누르기', targets: [{ app, id: 'btnSearch' }], when: { clicked: true }, body: `위쪽 조건(학년도·학기·학년·과목 등)이 맞는지 보고 [조회]를 누르세요.${extra}`, caution: '화면을 막 열면 위쪽 조건이 1초쯤 비어 있다가 채워져요. 그 사이에 누르면 "필수 입력" 안내가 떠요 — 채워진 뒤 누르세요.' });
  const save = (app, id = 'btnSave', body = '[저장] → 확인 창에서 [확인]을 누르면 저장돼요.', caution = '') => ({ title: '[저장] 누르기', targets: [{ app, id }], when: { clicked: true }, body, caution });

  D.guideGroups = [
    { name: '출결', intro: '담임은 날마다 [일일출결 입력], 교과는 수업마다 [과목별출결]. 마감은 학교가 정한 때에 선생님이 직접.' },
    { name: '평가', intro: '한 학기 순서: ① 성취기준 → ② 성취수준(평가기준) → ③ 수행평가 영역 → ④ 반영비율/만점 → ⑤ 문항정보표(시험지 확정 뒤) → ⑥ 수행평가 성적 → ⑦ 결시생 인정점. 평가계획은 학교 학업성적관리위원회 심의를 거친 계획과 같게 넣어요.' },
  ];

  D.guides = [
    // ── 출결 ───────────────────────────────────────────
    {
      id: 'daily', group: '출결', title: '일일출결 입력', who: '학급담임',
      summary: '날짜별로 우리 반 학생의 결석·지각·조퇴·결과를 넣고 저장해요.',
      menu: { menuId: 'AMHIS40420', prefer: '002001', path: ['학급담임', '학적', '출결관리', '출결관리'], apps: [DAILY_W, DAILY] },
      open: 'neis.dailyAttendance',
      steps: [
        { title: '단계 단추 보기', look: 'see', targets: [{ app: DAILY_W, id: 'btnStep02', label: '지금 단계' }],
          body: '출결관리 화면 위쪽에 단계 단추가 있어요. 처음 열면 [일일출결관리(담임용)]이 열려 있어요.\n다른 단추의 뜻은 [출결관리 단계 설명] 길잡이에서 볼 수 있어요.' },
        { title: '날짜 고르기', look: 'see', targets: [{ app: DAILY, text: ['일자', '출결일자', '기준일자'], near: 'btnSearch', label: '날짜' }],
          body: '출결을 넣을 날짜를 고르세요. 처음에는 오늘이에요. 지난 날짜도 고를 수 있어요.',
          caution: '날짜를 바꾼 뒤에는 꼭 [조회]를 눌러요. 조회하지 않고 저장하면 나이스가 "일자가 변경되었습니다"로 막아요.' },
        { title: '[조회] 누르기', targets: [{ app: DAILY, id: 'btnSearch' }], when: { clicked: true },
          body: '[조회]를 누르면 그날 우리 반 학생 목록이 나와요.' },
        { title: '표 칸 읽기', look: 'see', targets: [{ app: DAILY, id: 'grdMain' }], figure: 'dailyGrid',
          body: '왼쪽부터 번호 · 성명 · 마감(= 출결구분) · 조회 · 1교시 ~ 마지막 교시 · 종례 · 사유예요.\n교과 선생님이 수업 시간에 찍은 \'/\'가 교시 칸에 먼저 보일 수 있어요. 담임은 그 학생의 출결구분(결석·지각·조퇴·결과와 질병·미인정·기타·출석인정)을 정해 줘요.',
          caution: '교시 칸에 \'/\'만 있고 출결구분이 빈 학생이 있으면 2015 개정 교육과정 학년은 저장이 막히고, 2022 개정 학년은 마감 전에 꼭 처리해야 해요.' },
        { title: '하루 결석', look: 'see', targets: [{ app: DAILY, id: 'grdMain', text: '마감', label: '이 칸' }],
          body: '하루 전체를 빠진 학생은 그 학생 줄의 \'마감\' 칸을 눌러 구분(질병결석 · 미인정결석 · 기타결석 · 출석인정결석)을 고르세요. 수업이 있는 교시와 조회·종례에 표시가 저절로 찍혀요.',
          caution: '출석인정결석 표시는 학년의 교육과정에 따라 달라요. 2022 개정 학년은 \'Ø\', 2015 개정 학년은 \'/\'(예: 2026학년도 고등학교는 1·2학년 \'Ø\', 3학년 \'/\'). 나이스가 알아서 찍으니 손으로 바꾸지 마세요.' },
        { title: '지각 · 조퇴 · 결과', look: 'see', targets: [{ app: DAILY, id: 'cmbAtteScCd', label: '구분' }, { app: DAILY, id: 'atteRmkCnSlot', label: '사유' }],
          body: '① 위쪽 구분 칸에서 종류(예: 질병지각)를 고르고 ② 필요하면 사유를 적은 뒤 ③ 그 학생 줄의 교시 칸을 누르세요.\n지각은 조회부터 누른 교시까지, 조퇴는 누른 교시부터 종례까지 한 번에 찍혀요. 결과는 누른 교시만 찍혀요.',
          caution: '수업이 없는 칸(공강)은 찍히지 않아요. 잘못 찍었으면 같은 칸을 다시 누르면 지워져요.' },
        { title: '사유 적기', look: 'see', targets: [{ app: DAILY, id: 'grdMain', text: '사유', label: '사유' }],
          body: '\'기타\'(기타결석 · 기타지각 · 기타조퇴 · 기타결과)는 사유를 적어 주세요. 기타결석은 사유가 없으면 나이스가 저장을 막아요(SW-SRG-4156).\n질병 · 미인정 · 출석인정은 사유를 비워도 저장돼요(학교 규정에 따라 적기도 해요).',
          caution: '사유에 병명 같은 건강 정보는 꼭 필요한 만큼만 적어요.' },
        { title: '[저장] 누르기', targets: [{ app: DAILY, id: 'btnSave' }], when: { clicked: true },
          body: '[저장] → "저장하시겠습니까?"에서 [확인] → "저장했습니다."가 뜨면 끝이에요.',
          caution: '"출결마감구분만 존재하거나, 교시만 체크되어있는 학생이 존재합니다"(SW-SRG-4023)가 뜨면: 교시에 \'/\'가 있는데 출결구분이 빈 학생, 또는 출결구분은 있는데 교시 표시가 없는 학생이 있다는 뜻이에요. 그 학생 줄을 고친 뒤 다시 저장해요.' },
        { title: '출결마감은 나중에', look: 'nopress', targets: [{ app: DAILY, id: 'btnAtte', label: '출결마감' }],
          body: '[출결마감]은 출결을 다 확인한 뒤 학교가 정한 때에 누르는 단추예요. 마감한 날은 [마감취소]를 해야 고칠 수 있어요.',
          caution: '마감 시기는 학교마다 달라요 — 출결 담당 선생님께 확인하세요. 길잡이와 도우미는 이 단추를 누르지 않아요.' },
      ],
      tips: [
        '날짜를 바꾸면 [조회] 다음에 입력·저장해요.',
        '교과 선생님이 찍은 \'/\'만 있고 출결구분이 빈 학생은 담임이 구분을 정해 줘야 저장·마감할 수 있어요.',
        '출석인정 표시: 2022 개정 학년 \'Ø\', 2015 개정 학년 \'/\' — 나이스가 알아서 찍어요.',
        '기타결석은 사유가 꼭 있어야 저장돼요. 건강 정보는 필요한 만큼만.',
        '결석계·체험학습 서류 같은 증빙과 마감 시기는 학교 규정대로 해요.',
      ],
    },
    {
      id: 'daily-steps', group: '출결', title: '출결관리 단계 설명', who: '학급담임',
      summary: '출결관리 화면 위쪽 단계 단추 6개가 각각 무엇을 하는지 차례로 짚어 줘요.',
      menu: { menuId: 'AMHIS40420', prefer: '002001', path: ['학급담임', '학적', '출결관리', '출결관리'], apps: [DAILY_W] },
      open: 'neis.dailyAttendance',
      steps: [
        { title: '일일출결관리(담임용)', look: 'see', targets: [{ app: DAILY_W, id: 'btnStep02' }],
          body: '날짜별로 학생 출결을 넣고 저장하는 곳이에요. 담임이 가장 자주 써요([일일출결 입력] 길잡이).' },
        { title: '일일결석자조회', look: 'see', targets: [{ app: DAILY_W, id: 'btnStep03' }],
          body: '날짜를 고르면 그날 결석·지각·조퇴·결과가 있는 학생을 모아서 보여 줘요. 확인할 때 써요.' },
        { title: '반별일출결마감관리', look: 'see', targets: [{ app: DAILY_W, id: 'btnStep04' }],
          body: '날짜마다 우리 반 출결을 마감(확정)하는 곳이에요.',
          caution: '마감 시기는 학교 규정 확인. 길잡이와 도우미는 마감 단추를 누르지 않아요.' },
        { title: '반별월출결마감관리', look: 'see', targets: [{ app: DAILY_W, id: 'btnStep05' }],
          body: '한 달 출결을 마감하는 곳이에요. 학교가 정한 날에 해요.',
          caution: '마감 뒤에는 고치기 어려워요. 그 달 출결과 서류를 먼저 확인해요.' },
        { title: '월출결마감현황', look: 'see', targets: [{ app: DAILY_W, id: 'btnStep06' }],
          body: '달마다 마감이 됐는지 한눈에 보는 곳이에요.' },
        { title: '출결특기사항등록', look: 'see', targets: [{ app: DAILY_W, id: 'btnStep07' }],
          body: '학교생활기록부 출결상황 특기사항을 적는 곳이에요. 주로 학년말에 학교생활기록부 기재요령을 보고 적어요.' },
      ],
      tips: ['마감 단계(반별일·반별월)는 학교가 정한 때에 선생님이 직접 해요.'],
    },
    {
      id: 'subject', group: '출결', title: '과목별출결', who: '교과담임',
      summary: '내 수업 시간에 빠진 학생(결과·출석인정결과)을 수업마다 넣고 저장해요.',
      menu: { menuId: 'AMHIS40738', prefer: '002002', path: ['교과담임', '학적', '출결관리', '과목별출결관리'], apps: [SUBJ_W, SUBJ] },
      open: 'neis.subjectAttendance',
      steps: [
        { title: '단계 단추 보기', look: 'see', targets: [{ app: SUBJ_W, id: 'btnStep01-1', label: '지금 단계' }],
          body: '위쪽 단계 단추 중 [과목별 출결관리]가 출결을 넣는 곳이에요. [과목별 출결조회]는 보기만 하고, 마감 단계는 학교가 정한 때에 써요.' },
        { title: '날짜 고르기', look: 'see', targets: [{ app: SUBJ, id: 'cmbAtteYmd', label: '날짜' }, { app: SUBJ, id: 'btnDateMinus', label: '하루 전' }, { app: SUBJ, id: 'btnDatePlus', label: '하루 뒤' }],
          body: '출결을 넣을 날짜를 고르세요. 옆 단추로 하루씩 옮길 수 있어요.' },
        { title: '[조회] 누르기', targets: [{ app: SUBJ, id: 'btnSearch' }], when: { clicked: true },
          body: '[조회]를 누르면 왼쪽에 그날 내 수업(교시 · 과목 · 반)이 나와요.' },
        { title: '수업 고르기', targets: [{ app: SUBJ, id: 'grdAtteYmd' }], when: { clicked: true, rows: { app: SUBJ, dataset: 'dsListCurrHrAtteStu', min: 1 } },
          body: '왼쪽 목록에서 출결을 넣을 수업 줄을 누르세요. 오른쪽에 그 반 학생이 나와요.' },
        { title: '출석상태 칸', look: 'see', targets: [{ app: SUBJ, id: 'grd1' }],
          body: '수업에 빠진 학생은 그 줄의 출석상태 칸을 누르세요. 누를 때마다 표시가 바뀌어요.\n\'/\' = 결과, \'Ø\' = 출석인정결과, 빈칸 = 출석.',
          caution: '결과·출석인정결과를 무엇으로 할지는 학교 출결 규정대로 해요.' },
        { title: '사유 적기', look: 'see', targets: [{ app: SUBJ, id: 'grd1', text: '사유', label: '사유' }],
          body: '필요하면 사유를 적어요.', caution: '건강 정보는 꼭 필요한 만큼만 적어요.' },
        { title: '[저장] 누르기', targets: [{ app: SUBJ, id: 'btnSave' }], when: { clicked: true },
          body: '[저장]을 누르면 저장돼요. 다른 수업은 왼쪽에서 줄을 바꿔 같은 순서로 해요.' },
        { title: '출결마감은 나중에', look: 'nopress', targets: [{ app: SUBJ, id: 'btnInsert', label: '출결마감' }, { app: SUBJ, id: 'btnPirDdlnYn', label: '출결일괄마감' }],
          body: '마감 단추는 학교가 정한 때에 눌러요. 마감한 뒤에는 [마감취소]를 해야 고칠 수 있어요.',
          caution: '길잡이와 도우미는 마감 단추를 누르지 않아요.' },
      ],
      tips: [
        '나이스 메뉴는 [교과담임] 탭을 먼저 눌러야 열려요.',
        '\'/\' = 결과, \'Ø\' = 출석인정결과, 빈칸 = 출석.',
        '마감 시기는 학교 규정 확인.',
      ],
    },

    // ── 평가 ───────────────────────────────────────────
    {
      id: 'standard', group: '평가', title: '① 성취기준', who: '교과담임',
      summary: '과목의 성취기준(코드·영역·내용)을 평가계획에 넣어요.',
      menu: { menuId: 'AMHIS40480', prefer: '002002', path: ['교과담임', '성취기준관리'], apps: [STD_W, STD] },
      open: 'neis.assess.standard',
      steps: [
        { title: '단계 단추 보기', look: 'see', targets: [{ app: STD_W, id: 'btnStep01', label: '성취기준' }, { app: STD_W, id: 'btnStep02', label: '성취수준' }],
          body: '[성취기준관리]에서 성취기준을 넣고, 다음에 [성취수준(평가기준)관리]에서 수준별 평가기준을 넣어요. 순서대로 해요.' },
        search(STD),
        { title: '표 읽기', look: 'see', targets: [{ app: STD, id: 'grdMain' }],
          body: '한 줄이 성취기준 하나예요: 성취기준 코드 · 영역 · 성취기준 내용.' },
        { title: '성취기준 넣는 방법', look: 'see', targets: [{ app: STD, id: 'btnData', label: '가져오기' }, { app: STD, id: 'btnUpld', label: '일괄업로드' }, { app: STD, id: 'btnInsert', label: '행추가' }],
          body: '[가져오기]나 [일괄업로드](엑셀)로 한 번에 넣거나, [행추가]로 한 줄씩 넣어요.' },
        { title: '영역 이름', look: 'see', targets: [{ app: STD, id: 'btnRelmNm' }],
          body: '영역 이름은 [영역명관리]에서 정해요.' },
        save(STD, 'btnSave', '[저장] → 확인 창에서 [확인]을 누르면 저장돼요.', '평가계획은 학교 학업성적관리위원회 심의를 거친 계획과 같아야 해요.'),
      ],
      tips: ['평가계획(성취기준·성취수준·수행평가 영역·반영비율)은 학교 심의를 거친 계획과 같게 넣어요.'],
    },
    {
      id: 'levels', group: '평가', title: '② 성취수준(평가기준)', who: '교과담임',
      summary: '성취기준마다 수준별(A~E 또는 상·중·하) 평가기준 문장을 넣어요.',
      menu: { menuId: 'AMHIS40480', prefer: '002002', path: ['교과담임', '성취기준관리'], apps: [STD_W, LVL] },
      open: 'neis.assess.levels',
      steps: [
        { title: '[성취수준(평가기준)관리] 단계', targets: [{ app: STD_W, id: 'btnStep02' }], when: { app: LVL },
          body: '위쪽 단계 단추 [성취수준(평가기준)관리]를 누르세요.' },
        search(LVL),
        { title: '성취기준 고르기', targets: [{ app: LVL, id: 'grdSccesCtr' }], when: { clicked: true, rows: { app: LVL, dataset: 'dsEvl', min: 1 } },
          body: '왼쪽에서 성취기준 줄을 누르면 오른쪽에 수준별 칸이 나와요.' },
        { title: '수준별 평가기준 적기', look: 'see', targets: [{ app: LVL, id: 'grdEvlCtr' }],
          body: '수준마다 평가기준 문장을 적어요.',
          caution: '2022 개정 교육과정 과목은 A~E 5단계, 2015 개정 과목은 상·중·하 3단계예요. 1~3단계는 꼭 채우고 순서대로 적어요(4000바이트까지).' },
        save(LVL, 'btn1'),
      ],
      tips: ['2022 개정 A~E, 2015 개정 상·중·하. 1~3단계는 꼭 채워요.'],
    },
    {
      id: 'areas', group: '평가', title: '③ 수행평가 영역', who: '교과담임',
      summary: '수행평가 영역의 이름·만점·반영비율을 넣어요.',
      menu: { menuId: 'AMHIS40483', prefer: '002002', path: ['교과담임', '수행평가영역관리'], apps: [AREA] },
      open: 'neis.assess.areas',
      steps: [
        search(AREA),
        { title: '표 읽기', look: 'see', targets: [{ app: AREA, id: 'grdMain' }],
          body: '한 줄이 수행평가 영역 하나예요: 영역명 · 영역 만점 · 반영비율 · 연결한 성취기준.' },
        { title: '영역 넣기', look: 'see', targets: [{ app: AREA, id: 'btnInsert', label: '행추가' }, { app: AREA, id: 'btnBfrData', label: '이전자료가져오기' }],
          body: '새 영역은 [행추가]로 줄을 만든 뒤 이름·만점·반영비율을 적어요. 지난 학기 자료는 [이전자료가져오기]로 불러올 수 있어요.' },
        save(AREA, 'btnSave', '[저장] → 확인 창에서 [확인]을 누르면 저장돼요.', '지필평가와 수행평가 반영비율을 더하면 100%가 돼야 해요. [④ 반영비율/만점]에서 한 번에 확인해요.'),
      ],
      tips: ['수행평가 영역·만점·반영비율은 학교 평가계획과 같게.'],
    },
    {
      id: 'ratio', group: '평가', title: '④ 반영비율/만점', who: '교과담임',
      summary: '정기시험·수행평가 영역마다 반영비율과 만점을 확인하고 넣어요.',
      menu: { menuId: 'AMHIS40484', prefer: '002002', path: ['교과담임', '반영비율/만점관리'], apps: [RATIO] },
      open: 'neis.assess.ratio',
      steps: [
        search(RATIO),
        { title: '표 읽기', look: 'see', targets: [{ app: RATIO, id: 'grdMain' }],
          body: '평가마다 한 줄이에요: 정기시험(1회고사·2회고사 등)과 수행평가 영역별 반영 여부 · 반영비율 · 만점.',
          caution: '반영하는 줄의 반영비율을 모두 더하면 100%가 돼야 해요.' },
        { title: '없는 평가 등록', look: 'see', targets: [{ app: RATIO, id: 'btnInsert', label: '등록' }],
          body: '목록에 없는 평가는 [등록]으로 줄을 만들어요.' },
        save(RATIO),
      ],
      tips: ['반영비율 합계 100%, 만점은 평가계획대로.'],
    },
    {
      id: 'items', group: '평가', title: '⑤ 문항정보표', who: '교과담임',
      summary: '정기시험 문항마다 배점·난이도·정답·성취기준을 넣어요.',
      menu: { menuId: 'AMHIS40487', prefer: '002002', path: ['교과담임', '문항정보표관리'], apps: [ITEMS] },
      open: 'neis.assess.items',
      steps: [
        search(ITEMS, '\n학기 → 고사 → 학년 → 과목 순서로 고르면 돼요. 앞 칸을 바꾸면 뒤 칸 목록이 다시 불러와져요.'),
        { title: '객관식 표', look: 'see', targets: [{ app: ITEMS, id: 'grdObt' }],
          body: '객관식 문항마다 한 줄이에요: 문항 번호 · 영역 · 난이도 · 배점 · 정답 · 성취기준.',
          caution: '줄 수(문항 수)는 미리 정해져 있어요. 시험지와 다르면 평가 담당 선생님께 확인해요.' },
        { title: '서답형 표', look: 'see', targets: [{ app: ITEMS, id: 'grdSbjct' }],
          body: '서답형 문항도 배점 · 난이도 · 정답(채점기준)을 적어요. 서답형 채점기준표 파일은 첨부 칸에 붙여요.' },
        { title: '배점 한 번에', look: 'see', targets: [{ app: ITEMS, id: 'btnBndeInpt' }],
          body: '같은 배점이 많으면 [배점일괄입력]으로 한 번에 넣어요.' },
        { title: '성취기준 고르기', look: 'see', targets: [{ app: ITEMS, id: 'grdObt', text: '성취기준', label: '성취기준' }],
          body: '문항마다 성취기준 칸을 누르면 \'성취기준자료 가져오기\' 창이 떠요. 그 문항이 평가하는 성취기준을 골라요(한 문항에 6개까지).' },
        save(ITEMS, 'btnSave', '[저장] → 확인 창에서 [확인]을 누르면 저장돼요.', '배점 합계가 [④ 반영비율/만점]의 만점과 같은지 봐요. 학생 답안이 이미 들어간 뒤 저장하면 분할점수 경고 창이 뜰 수 있어요 — 내용을 읽고 선생님이 판단해요.'),
        { title: '승인요청 · 마감은 나중에', look: 'nopress', targets: [{ app: ITEMS, id: 'btnDrft', label: '승인요청' }, { app: ITEMS, id: 'btnDdln', label: '마감' }],
          body: '문항정보표를 다 확인한 뒤 학교 절차(평가 담당 확인·결재)에 따라 [승인요청]·[마감]을 눌러요.',
          caution: '길잡이와 도우미는 이 단추를 누르지 않아요.' },
      ],
      tips: ['고사·과목을 잘못 고르면 다른 시험에 들어가요. 조회 뒤 위쪽 조건을 한 번 더 봐요.', '배점 합계 = 만점.'],
    },
    {
      id: 'perf', group: '평가', title: '⑥ 수행평가 성적', who: '교과담임',
      summary: '수행평가 영역마다 학생 점수와 결시 사유를 넣어요.',
      menu: { menuId: 'AMHIS40498', prefer: '002002', path: ['교과담임', '수행평가성적관리'], apps: [PERF] },
      open: 'neis.assess.perf',
      steps: [
        search(PERF, '\n영역을 고른 뒤 조회하면 그 영역의 학생 점수 칸이 나와요.'),
        { title: '점수 적기', look: 'see', targets: [{ app: PERF, id: 'grdMain' }],
          body: '학생마다 점수를 적어요. 결시한 학생은 점수 대신 사유(결시 종류)를 골라요.',
          caution: '영역 만점을 넘는 점수는 넣지 않아요. 저장하기 전에 빈 점수가 없는지 봐요.' },
        { title: '같은 점수 한 번에', look: 'see', targets: [{ app: PERF, id: 'btn15' }],
          body: '같은 점수를 여러 명에게 줄 때는 [점수일괄입력]을 써요.' },
        save(PERF, 'btnSave', '[저장]을 누르면 저장돼요. 다른 영역도 같은 순서로 해요.'),
        { title: '마감은 나중에', look: 'nopress', targets: [{ app: PERF, id: 'btnDdln', label: '마감' }, { app: PERF, id: 'btnAllRelmDdln', label: '전체영역마감' }],
          body: '점수를 모두 확인하고 학생 확인 절차가 끝난 뒤 학교가 정한 때에 마감해요.',
          caution: '마감 시기는 학교 규정 확인. 길잡이와 도우미는 마감 단추를 누르지 않아요.' },
      ],
      tips: ['만점 초과·빈 점수 없이. 결시는 사유로.'],
    },
    {
      id: 'absence', group: '평가', title: '⑦ 결시생 인정점', who: '교과담임',
      summary: '결시한 학생의 기준점·인정점을 넣어요.',
      menu: { menuId: 'AMHIS40504', prefer: '002002', path: ['교과담임', '성적산출관리'], apps: [ABS_W, ABS] },
      open: { menu: { menuId: 'AMHIS40504', prefer: '002002' }, appId: ABS, step: { appId: ABS_W, button: 'btnStep01' } },
      steps: [
        { title: '단계 단추 보기', look: 'see', targets: [{ app: ABS_W, id: 'btnStep01', label: '결시생 인정점 관리' }],
          body: '[성적산출관리]를 열면 첫 단계 [결시생 인정점 관리]가 저절로 열려요.' },
        search(ABS),
        { title: '인정점 적기', look: 'see', targets: [{ app: ABS, id: 'grdMain' }],
          body: '결시 처리(수행평가 성적의 사유)가 된 학생만 칸이 있어요. 고사·영역마다 기준점과 인정점을 적어요.',
          caution: '인정점 계산 방법은 학교 학업성적관리규정대로 해요. 만점을 넘지 않게.' },
        save(ABS),
        { title: '인정점산출 · 삭제', look: 'nopress', targets: [{ app: ABS, id: 'btnAcscProd', label: '인정점산출' }, { app: ABS, id: 'btnAcscDel', label: '인정점삭제' }],
          body: '[인정점산출]·[인정점삭제]는 칸 전체를 한 번에 바꾸는 단추예요. 쓸지는 평가 담당 선생님과 확인해요.',
          caution: '길잡이와 도우미는 이 단추를 누르지 않아요.' },
      ],
      tips: ['결시생 인정점은 숨은 메뉴라 [성적산출관리]로 들어가요.', '계산 방법은 학교 학업성적관리규정대로.'],
    },
  ];
})();
